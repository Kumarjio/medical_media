<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Sales extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Sales_model');		  
     }
	 //get_rows used to get rows of table
	 //get_single_row used to get 
	 
	 public function index(){
		//$table="tbl_manufacturer";$table1="tbl_item";$con="*";
		 $con="*";
		 $data['item'] = $this->Sales_model->get_all_pro();
		$data['customer'] = $this->Sales_model->get_rows();
		$data['expenses'] = $this->Sales_model->get_expenses();	
		
		$data['title'] = 'Sales Billing:: Arrow18 ';
		$this->load->view('sales_billing', $data);
	}
	public function gen_inv()
	{
		if($this->input->post())
		{
			$inps = $this->input->post();
			//echo '<pre>'; print_r($inps);exit;
			$ins_ary = array('sales_id'=>$inps['bill_no'],'customer_code'=>$inps['customer_code'],'total_amount'=>$inps['invpice_amount'],'created_date'=>date('Y-m-d H:i:s'));
			$this->db->insert('tbl_invoice',$ins_ary);
			redirect($this->config->item('base_url').'index.php/Sales/Invoicelist','refresh');
		}
		$inps = $this->input->get();
		//echo '<pre>'; print_r($inps); //exit;
		$data['list'] = $this->Sales_model->get_sales_byid($inps);
		$in['cus'] = $data['list'][0]['customer_code'];
		$this->load->model('Installation_model');
		$cus = $this->Installation_model->get_cus_det($in);
		if($cus[0]['customer_type']==1)
		{
			$custype = 'Private Hospital';
		}
		else if($cus[0]['customer_type']==2)
		{
			$custype = 'Clinic';
		}
		else if($cus[0]['customer_type']==3)
		{
			$custype = 'Government Hospital';
		}
		else if($cus[0]['customer_type']==4)
		{
			$custype = 'PHC (Primary Health Center)';
		}
		else
		{
			$custype = 'Scan Centers';
		}
		$data['c_det'] = '<strong>Name :</strong> '.$cus[0]['customer_name'].'<br /><strong>Area Name :</strong> '.$cus[0]['area_name'].'<br /><strong>City Name :</strong> '.$cus[0]['city_name'].'<br /><strong>State :</strong> '.$cus[0]['state_name'].'<br /><strong>Country : </strong>'.$cus[0]['country_name'].'<br /><strong>Pincode :</strong> '.$cus[0]['pincode'].'<br /><strong>Contact No : </strong> '.$cus[0]['mob_no1'].'<br /><strong>Customer Type : </strong> '.$custype;
		//echo '<pre>';print_r($data); exit;
		$this->load->view('gen_invoice',$data);
	}
	public function makepayment()
	{
		$data['title'] = 'MakePayment :: Arrow18 ';
		$inps = $this->input->get();
		if($this->input->post())
		{
			$inps = $this->input->post();
			//echo '<pre>'; print_r($inps); exit;
			if($inps['payment_method'] == 1 ){
			$ins_ary = array('tbl_invoice_id'=>$inps['bill_no'],'customer_code'=>$inps['customer_code'],'product_amount'=>$inps['product_amt'],'reference_no'=>$inps['ref_nos'],'cheque_no'=>$inps['che_no'],'bank_name'=>$inps['bank_name'],'payment_method'=>$inps['payment_method'],'trans_id'=>$inps['trans_id'],'paym_amount'=>$inps['paym_amount'],'payment_date'=>date('Y-m-d', strtotime($inps['purdate'])),'created_date'=>date('Y-m-d H:i:s'));
			}
			else
			{
				$ins_ary = array('tbl_invoice_id'=>$inps['bill_no'],'customer_code'=>$inps['customer_code'],'product_amount'=>$inps['product_amt'],'reference_no'=>$inps['ref_nos'],'cheque_no'=>$inps['che_no'],'bank_name'=>$inps['bank_name'],'get_amt_date'=>date('Y-m-d', strtotime($inps['chq_dt'])),'payment_method'=>$inps['payment_method'],'trans_id'=>$inps['trans_id'],'paym_amount'=>$inps['paym_amount'],'payment_date'=>date('Y-m-d', strtotime($inps['purdate'])),'created_date'=>date('Y-m-d H:i:s'));
			}
			//echo '<pre>'; print_r($ins_ary); exit;
			$this->db->insert('tbl_invoice_payment',$ins_ary);
			$var = $this->db->select('paid_amt')->where('s_no',$inps['bill_no'])->get('tbl_invoice')->result_array();
				$proarray = array(
				'paid_amt'  =>$var[0]['paid_amt']+$inps['paym_amount'],
			);
			$this->db->where('s_no',$inps['bill_no']);
			$this->db->update('tbl_invoice',$proarray);
			echo "<script> alert('Order Confirmed');window.location= '".base_url('index.php/Sales/Paymentlist')."'</script>";
			//redirect($this->config->item('base_url').'index.php/Sales/Paymentlist');
		}
		else
		{
			$data['list'] = $this->Sales_model->getInvoicedbysearch($inps);
			$data['list1'] = $this->Sales_model->getInvoicedbysearch1($inps);
			//$data['item3'] = $this->Sales_model->get_seller_rows_paym();
		    //$data['item4'] = $this->Sales_model->getInvoicedbysearch($inps);
			$this->load->view('gen_payment_sale',$data);
		}
	}
	public function Invoicelist()
	{
		$data['title'] = 'Invoicelist :: Arrow18 ';
		$data['list'] = $this->Sales_model->getInvoiced();
		$this->load->view('invoice_list',$data);
	}
	public function ajaxgetCustomer() {
		$data['customer'] = $this->Sales_model->get_rowsdet('cb_customer', '*', array('cid' => $_POST['id']));
		echo json_encode($data['customer']);
	}
public function addSales() {
		$muinput= $this->security->xss_clean($this->input->post());
		//echo '<pre>';print_r($muinput);exit;
		$conf_id=$this->Sales_model->add_sales_entry($muinput);
		$data['title'] = 'Sales Entry:: Arrow18 ';
		//$data['list'] = $this->Sales_model->getInvoicedbysearch($muinput);
		//exit;
		echo "<script> alert('Order Confirmed');window.location= '".base_url('index.php/Sales/makepayment?id='.urlencode($conf_id))."'</script>";
		 //redirect('Sales/sold_list', 'refresh');
	}
	public function makepaymentinv1()
	{
		$data['title'] = 'MakePayment :: Arrow18 ';
		$inps = $this->input->get();
		$data['list'] = $this->Sales_model->getInvoicedbysearch($inps);
		$data['list1'] = $this->Sales_model->getInvoicedbysearch1($inps);
		$data['item3'] = $this->Sales_model->get_seller_rows_paym();
		    //$data['item4'] = $this->Sales_model->getInvoicedbysearch($inps);
			$this->load->view('gen_payment',$data);
		
	}
	
	public function Paymentlist()
	{
		$data['title'] = 'Paymentlist :: Arrow18 ';
		$data['list'] = $this->Sales_model->Getpaymentlist();
		$this->load->view('Paymentlist',$data);
	}
	public function sold_list() 
	{
		$data['title'] = 'Sales List :: Arrow18 ';
		$data['list'] = $this->Sales_model->getList();
		$this->load->view('sold_list',$data);
	}
	public function print_data()
	{
		$session_data = $this->session->all_userdata();
		//$this->db->select('*');
		//$this->db->where('area_name',$session_data['location']);
		//$this->db->where('user_type',2);
		//$data['adrs'] = $this->db->get('cp_admin_login')->result_array();
		$inps = $this->input->get();
		$data['title'] = 'Invoice';
		$data['calls']= $this->Sales_model->getinvoiceds($inps);
		$this->load->view('table2',$data);
	}
	
	public function get_cus_det()
	{
		$inps = $this->input->post();
		//echo '<pre>';print_r($inps);exit;
		$cus = $this->Sales_model->get_cus_det($inps);
		//echo '<pre>';print_r($cus);exit;
		
		if($cus[0]['customer_type']==1)
		{
			$custype = 'REGULAR';
		}
		else if($cus[0]['customer_type']==2)
		{
			$custype = 'SPECIAL';
		}
		else if($cus[0]['customer_type']==3)
		{
			$custype = 'IMPORTANT';
		}
		else if($cus[0]['customer_type']==4)
		{
			$custype = 'RO CUSTOMER';
		}
		else
		{
			$custype = 'GENERAL';
		}
		$c_det = '<strong>Name :</strong> '.$cus[0]['customer_name'].'<br /><strong>Area Name :</strong> '.$cus[0]['area_name'].'<br /><strong>City Name :</strong> '.$cus[0]['city_name'].'<br /><strong>State :</strong> '.$cus[0]['state_name'].'<br /><strong>Country : </strong>'.$cus[0]['country_name'].'<br /><strong>Pincode :</strong> '.$cus[0]['pincode'].'<br /><strong>Contact No : </strong> '.$cus[0]['mob_no1'].'<br /><strong>Customer Type : </strong> '.$custype;
		echo $c_det;
	}
	
	
//******************************************************************Sales return ends here**********************************************************************//
	
}
