<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Stocktransfer extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  } 
		  	  
		  $this->load->model('Stock_model');
		  
     }
	
	public function index(){
		$data['title'] = 'View All Stocks :: Arrow18 ';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}	
		$data['list']= $this->Stock_model->getstockdetails1($inps);	
		//$data['list2']= $this->stock_model->getstockdetails1($inps);	
	    //echo '<pre>';print_r($data['list']); exit;
	    if(isset($inps['export']))
		{
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
		}
	    
		$this->load->view('stocks_lists1', $data);
	}
	public function insert_request()
	{
		$session_data = $this->session->all_userdata();
		$data['title'] = 'Insert Request :: Arrow18 ';
		$inps= $this->input->post();
		
		$var2= $this->db->select('req_emp_id,req_qty,tbl_product_id,emp_id,req_emp_location')->where('tbl_product_id',$inps['req_pro_id'])->where('emp_id',$inps['emp_id'])->get('purchase_product')->result_array();
		
		$arr= array('req_qty'=>$inps['req_qty'],'req_emp_id'=>$session_data['user_id'],'req_emp_location'=>$session_data['location']);
		  $this->db->where('tbl_product_id',$inps['req_pro_id']);
		  $this->db->where('emp_id',$inps['emp_id']);
		$this->db->update('purchase_product',$arr);
		echo '<script type="text/javascript">window.location.href="'.$this->config->item('base_url').'index.php/Stocktransfer";</script>';
	}
	public function addrequest()
	{
		$data['title'] = 'Add Request :: Arrow18 ';
		$data['list']= $this->Stock_model->getpro();
		//echo '<pre>';print_r($data['list']);exit;	
		$this->load->view('addrequest',$data);
	}
	public function get_pro_det()
	{
		$inps = $this->input->post();
		//echo '<pre>';print_r($inps);exit;
		$pro = $this->Stock_model->get_pro_det1($inps);
		$c_det = '';
			foreach($pro as $row)
		    {
				
			
			$c_det .= '<strong>Emp Name :</strong> '.$row['name'].'<br /><strong>Product Name :</strong>'. $row['i_name'].'<br /><strong>Qty :</strong> '.$row['qty'].'<br />';
	      			
	         }
	         echo $c_det;
		
			
	}
}
?>