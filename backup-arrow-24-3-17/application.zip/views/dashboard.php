<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
    
<head>        
        <!-- META SECTION -->
        <title>Arrow18</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
       <!-- <link rel="icon" href="favicon.ico" type="image/x-icon" />-->
        <!-- END META SECTION -->
        
        <!-- CSS INCLUDE -->        
		<?php $this->load->view('include_css'); ?>
        <!-- EOF CSS INCLUDE -->
       
        <?php $this->load->view('menu_navigation'); ?>    
                     

                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap" style="margin-bottom:5%; margin-top:5%">
                    
                    <!-- START WIDGETS -->                    
                    <div class="row">
                        <div class="col-md-3">
                            
                            <!-- START WIDGET SLIDER -->
                            <div class="widget widget-default widget-carousel">
                              <div class="owl-carousel" id="owl-example">
                                    <div>                                    
                                        <div class="widget-title">Total</div>                                                                        
                                        <div class="widget-subtitle">Stocks</div>
                                        <div class="widget-int">3,548</div>
                                    </div>
                                    <div>                                    
                                        <div class="widget-title">Todays</div>
                                        <div class="widget-subtitle">Purchases</div>
                                        <div class="widget-int">1,695</div>
                                    </div>
                                    <div>                                    
                                        <div class="widget-title">Todays</div>
                                        <div class="widget-subtitle">Deliveries</div>
                                        <div class="widget-int">1,977</div>
                                    </div>
                                </div>                           
                                <div class="widget-controls">                                
                                    <a href="#" class="widget-control-right widget-remove" data-toggle="tooltip" data-placement="top" title="Remove Widget"><span class="fa fa-times"></span></a>
                                </div>                             
                            </div>        
                            <!-- END WIDGET SLIDER -->
                            
                        </div>
                        
                        <div class="col-md-3">
                            
                            <!-- START WIDGET MESSAGES -->
                            <div class="widget widget-default widget-item-icon" onClick="location.href='#';">
                                <div class="widget-item-left">
                                    <span class="fa fa-file"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count">Stocks</div>
                                  <!--  <div class="widget-title">Purchases</div>
                                    <div class="widget-subtitle">This Week</div> -->
                                </div>      
                                <div class="widget-controls">                                
                                    <a href="#" class="widget-control-right widget-remove" data-toggle="tooltip" data-placement="top" title="Remove Widget"><span class="fa fa-times"></span></a>
                                </div>
                            </div>                            
                           <!-- END WIDGET MESSAGES -->
                            
                        </div>
                        <div class="col-md-3">
                            
                            <!-- START WIDGET REGISTRED -->
                            <div class="widget widget-default widget-item-icon" onClick="location.href='#';">
                                <div class="widget-item-left">
                                    <span class="fa fa-user"></span>
                                </div>
                                <div class="widget-data">
                                    <div class="widget-int num-count">Sales</div>
                                    <!--<div class="widget-title">Transporters</div>
                                    <div class="widget-subtitle">On Track</div>-->
                                </div>
                                <div class="widget-controls">                                
                                    <a href="#" class="widget-control-right widget-remove" data-toggle="tooltip" data-placement="top" title="Remove Widget"><span class="fa fa-times"></span></a>
                                </div>                            
                            </div>                            
                            <!-- END WIDGET REGISTRED -->
                            
                        </div>
                        <div class="col-md-3">
                            
                            <!-- START WIDGET CLOCK -->
                            <div class="widget widget-primary widget-padding-sm">
                                <div class="widget-big-int plugin-clock">00:00</div>                            
                                <div class="widget-subtitle plugin-date">Loading...</div>
                                <div class="widget-controls">                                
                                    <a href="#" class="widget-control-right widget-remove" data-toggle="tooltip" data-placement="left" title="Remove Widget"><span class="fa fa-times"></span></a>
                                </div>                            
                                                      
                            </div>                        
                            <!-- END WIDGET CLOCK -->
                            
                        </div>
                    </div>
                    <!-- END WIDGETS -->                    
                    
                
                    
                    
                    <?php /*?><div class="row">
                        <div class="col-md-8">
                            
                          <div class="content-frame">            
                    
                    <!-- START CONTENT FRAME LEFT -->
                    
                    <!-- END CONTENT FRAME LEFT -->
                    
                    <!-- START CONTENT FRAME BODY -->
                        <style>
						.fc-right{display:none;}
						
						</style>
                        <div class="row">
                            <div class="col-md-12">
                                <div id="alert_holder"></div>
                                <div class="calendar">                                
                                    <div id="calendar"></div>                            
                                </div>
                            </div>
                        </div>
                        
                    </div>                    
                    <!-- END CONTENT FRAME BODY -->
                    
                            
                        </div>
                        <div class="col-md-4">
                            
                            <!-- START PROJECTS BLOCK -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title-box">
                                        <h3>Products</h3>
                                        <!--<span>Projects activity</span>-->
                                    </div>                                    
                                    <ul class="panel-controls" style="margin-top: 2px;">
                                        <li><a href="#" class="panel-fullscreen"><span class="fa fa-expand"></span></a></li>
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-cog"></span></a>                                        
                                            <ul class="dropdown-menu">
                                                <li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span> Collapse</a></li>
                                                <li><a href="#" class="panel-remove"><span class="fa fa-times"></span> Remove</a></li>
                                            </ul>                                        
                                        </li>                                        
                                    </ul>
                                </div>
                                <div class="panel-body panel-body-table">
                                    
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th width="50%">Products</th>
                                                    <th width="20%">Promotions</th>
                                                    <th width="30%">Sales</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><strong>Product 1</strong></td>
                                                    <td><span class="label label-success">Developing</span></td>
                                                    <td>
                                                        <div class="progress progress-small progress-striped active">
                                                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 85%;">85%</div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Product 2</strong></td>
                                                    <td><span class="label label-warning">warning</span></td>
                                                    <td>
                                                        <div class="progress progress-small progress-striped active">
                                                            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">40%</div>
                                                        </div>
                                                    </td>
                                                </tr>                                                
                                                <tr>
                                                    <td><strong>Product 3</strong></td>
                                                    <td><span class="label label-warning">Updating</span></td>
                                                    <td>
                                                        <div class="progress progress-small progress-striped active">
                                                            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 72%;">72%</div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Product 4</strong></td>
                                                    <td><span class="label label-info">Support</span></td>
                                                    <td>
                                                        <div class="progress progress-small progress-striped active">
                                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">100%</div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Product 5</strong></td>
                                                    <td><span class="label label-danger">Support</span></td>
                                                    <td>
                                                        <div class="progress progress-small progress-striped active">
                                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 25%;">25%</div>
                                                        </div>
                                                    </td>
                                                </tr>                                                
                                                <tr>
                                                    <td><strong>Product 6</strong></td>
                                                    <td><span class="label label-warning">Support</span></td>
                                                    <td>
                                                        <div class="progress progress-small progress-striped active">
                                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;">50%</div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END PROJECTS BLOCK -->
                            
                        </div>
                    </div><?php */?>
                    <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Requested Employee Code</th>
                                                    <th>Requested Employee Name</th>
                                                    <th>Requested Product Name </th>
                                                    <th>Requested Employee Location </th>
                                                    <th>Requested Qty </th>
                                                     <th>Status</th>
                                                    <th width="72">Action</th>
                                                 </tr>
											</thead>
                                            <tbody>
                                       <?php 
										$cnt=1;
										$i= 0;
										if(is_array($list) && count($list) ) {
                                       
                                            foreach($list as $loop){
                                                    ?>
											<tr>
												<td><?php echo $cnt; $cnt++; ?></td>
												<td><?php echo "EMP00".$loop->req_emp_id;?></td>
												<td><?php echo strtoupper($loop->name) ; ?></td>
                                                
                                                 <td><?=$loop->i_name;?></td>
                                                  <td><?=$loop->req_emp_location;?></td>
                                                   <td><?=$loop->req_qty;?></td>
                                                   <td><?php if($loop->status_req == 0){
													   echo 'Pending';
												   }
												   else{
													   echo 'Done';
												   }
													   ?></td>
                                                       
                                                       
                                                <td>
                                                 <button type="button"  name="action" class="btn btn-info btn-rounded btn-condensed btn-sm view_data" data-toggle="modal" data-target="#getmodal_<?php echo $loop->req_emp_id?>" id="<?php echo $loop->req_emp_id?>" value="<?php echo $loop->req_emp_id?>" data-placement="bottom" title="" data-original-title="View"><i class="fa fa-pencil"></i> </button>
                                                 </td>
                                                 
                                                    
											</tr>
											<?php }} ?>
                                           
                                            
										</tbody>
                                        </table>
                                    </div>
                              
                                </div>
                    
                    <!-- START DASHBOARD CHART -->
                    <!--<div class="block-full-width">
                        <div id="dashboard-chart" style="height: 250px; width: 100%; float: left;"></div>
                        <div class="chart-legend">
                            <div id="dashboard-legend"></div>
                        </div>                                                
                    </div>-->                    
                    <!-- END DASHBOARD CHART -->
                    
                </div>
                
                <!-- END PAGE CONTENT WRAPPER -->                                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
       
        <!-- END PAGE CONTAINER -->
<?php foreach ($list as $loop){?>
                                         
     								<form id="getdet" role="form" action="<?php echo base_url('index.php/Edit/update');?>" method="post">
                                        <div id="getmodal_<?php echo $loop->req_emp_id?>" class="modal fade" role="dialog">
                                          <div class="modal-dialog" style="width:1000px">
                                        
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">stock Transfer Details</h4>
                                              </div>
                                              
                                              <div class="modal-body" id="pop_data<?php echo $loop->req_emp_id?>">
                                              <div class="col-md-6"> 
                                              <div class="form-group" style="display:none">                                        
                                                <label class="col-md-7 control-label">Emp Id<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-5">
                                                	<input type="text name="req_emp_id" id="req_emp_id"  value="<?php echo $loop->req_emp_id?>">
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                        <div class="form-group">                                        
                                                <label class="col-md-7 control-label">Do You Want To Allow The Qty<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-5">
                                                	<select  class="selectpicker form-control uppercase"  name="status">
                                                    <option value="1">Success</option>
                                                    <option value="2">Success</option>
                                                   </select>
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                        <div class="form-group" style="display:none" >                                        
                                                <label class="col-md-7 control-label">Id<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="number" class="form-control uppercase"  name="ids"   id="qty" value="<?=$loop->id?>" >
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                       
                                      </div>
                                      </div>
                                      
                                                <div class="modal-footer">
                                                 <button type="submit" class="btn btn-success"  >Update</button>
                                             <button type="button" class="btn btn-primary" data-dismiss="modal" >Cancel</button>
                                              </div>
                                             
                                              </div>
                                              
                                            </div>
                    </div>
                                              </div>
                                            </div>
                                            </form>
 										<?php } ?>
         
             <?php $this->load->view('include_js'); ?>
             <script type="text/javascript" src="<?php echo base_url('assets/js/demo_dashboard.js'); ?>"></script>
        
   
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS -->     
    
    <!-- COUNTERS // NOT INCLUDED IN TEMPLATE -->
       
        
    <!-- END COUNTERS // NOT INCLUDED IN TEMPLATE -->
    
    </body>

</html>







