<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
<?php
if(isset($inps) && !empty($inps))
{
	//$customer = $inps['customer'];
	$storages = $inps['storage'];
	$product_cde = $inps['product_cde'];
	$sellers = $inps['seller'];
	$frmdt = $inps['from_dt'];
	$todt = $inps['to_dt'];
}
else
{
	//$customer = '';
	$storages = '';
	$product_cde = '';
	$sellers = '';
	$frmdt = '';
	$todt = '';
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Stock</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">  
                                <?php if($session_data['user_type']=='1'){?>
                                                    <a href="<?php echo base_url('index.php/Purchase'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Purchase Entry</button></a><br><br>
                                                    <?php }?>  
                                                    <?php if($session_data['user_type']=='5'){?>
                                                   <a href="<?php echo base_url('index.php/Purchase'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Purchase Entry</button></a><br><br>
                                                    <?php }?> 
                                                    <?php if($session_data['user_type']=='2'){?>
                                                   <a href="<?php echo base_url('index.php/Purchase'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Purchase Entry</button></a><br><br>
                                                    <?php }?>  
                                           
                                <form action="" method="post" enctype="multipart/form-data" >
                                <div class="col-md-12">
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Storage</label>
                                    <div class="col-md-8">                                            
                                       <select class="selectpicker uppercase bs-select-hidden form-control" id="storage" name="storage" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                    <?php /*?> <option <?=($storage=='all')?'selected':''?> value="all">ALL</option>
                                     <option <?=($storage=='DEC')?'selected':''?> value="DEC">DECLARED</option>
                                     <option <?=($storage=="")?'selected':''?> value="">NOT DECLARED</option><?php */?>
                                      <option value="" selected> ALL </option>
                                      
									<?php
                                    foreach($storage as $sval)
                                    { ?>
                                     <option <?=($storages==$sval->Location)?'selected':''?> value="<?=$sval->Location?>"> <?=$sval->storage_name?></option>
                                       
                                        <?php } ?>
                                     </select>                                       
                                    </div>
                                </div>
                                </div>
                              <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">product Code</label>
                                    <div class="col-md-8">
                                    <?php $prd_cd = $this->db->select('*')->get('tbl_product')->result_array(); ?>
                                     <select class="selectpicker uppercase bs-select-hidden form-control" name="product_cde" id="product_cde" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                      	<option <?=($product_cde=='')?'selected':''?> value="">All</option>
                                        <?php foreach($prd_cd as $prded) { ?>
                                        <option <?=($product_cde==$prded['i_code'])?'selected':''?> value="<?=$prded['i_code']?>"><?=$prded['i_code']?> - <?=$prded['i_name']?></option>
                                        <?php } ?>
                                    </select>                                               
                                       <?php /*?><input type="text" style="form-controlx" class="form-control bs-select-hidden" name="product_cde" id="product_cde" value="<?=$product_cde?>" />   <?php */?>                            
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Vendor</label>
                                    <div class="col-md-8">                                            
                                       <select class="selectpicker uppercase bs-select-hidden form-control" name="seller" id="seller" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                         <option value="" selected> ALL </option>
                                         <?php ?>
                                         <?php foreach($seller as $row){ ?>
                                         <option <?=($sellers==$row->cid)?'selected':''?> value="<?php echo $row->cid; ?>"><?php echo $row->seller_name; ?></option>
                                         <?php } ?>
                                         <?php ?>
                                       </select>                 
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="col-md-12">
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">From Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="from_dt" value="<?=$frmdt?>" id="from_dt">                
                                    </div>
                                </div>
                                </div>
                                
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">To Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="to_dt" id="to_dt" value="<?=$todt?>">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div>
                                   
                                     <?php if($session_data['user_type']=='5'){?>
                                        <div class="col-md-4"><button type="submit" name="export" class="btn btn-primary"><span class="fa fa-download"></span>Export</button>
                                    </div>
                                    <?php }?>
                                </div>
                                </div>
                                </div>
                                    </form>
                                      
                                    <ul class="panel-controls">
                                    <!--<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span></a></li>-->
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
                                        <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                                    </ul>                                
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
											<tr>
												<th width="20">S No</th>
												<th width="53">Invoice No</th>
                                                <th width="77">Invoice Date</th>
												<th width="76">Vendor </th>
												<th width="52">Storage</th>
												<th width="279">Product Code - Description</th>
												<th width="34">Pur Price</th>
												<!--<th width="77">Sale Price</th>
                                                <th width="54">Account</th>
                                                <th width="34">Currency</th>
												<th width="37">Profit</th>-->
												<?php /*?><th width="33">Pur Date</th><?php */?>
												<th width="25">Qty</th>
                                               <th width="340">View / Change</th>
                                                   
												
												<!--<th width="59">Damage / FOC Out</th>-->
											</tr>
										</thead>
                                            <tbody>
                                        	<?php
                                        $sno=1;
										if(is_array($stock) && count($stock) ) {
											foreach($stock as $loop){
												?>
												<tr>
													<td><?php echo $sno++; ?></td>
													<td><?php echo $loop['vinvno']; ?></td>
                                                    <td><?php echo $loop['supplier_date']; ?></td>
													<td><?=$loop['vname'] ?></td>
													<td><?=$loop['storage_name']?></td>
											     	<td><strong><?php echo $loop['i_code']; ?></strong> - <?php echo $loop['i_name']; ?> - <?=$loop['descr']?></td>
													
													<td><?php echo $loop['gtotal']; ?></td>
													
													<td><?=$loop['qtys']?></td>
												  <td>
                                                <a href="<?php echo base_url('index.php/Stock/viewstock/'.$loop['po_id']); ?>"><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><span class="fa fa-eye"></span></button></a>
                                                   <?php /*?>  <?php if($session_data['user_type']=='1'){?>
												 
                                                <a href="<?php echo base_url('index.php/Stock/editstock/'.$loop['po_id']);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
                                                 
                                                 <?php }?>
                                                 <?php if($session_data['user_type']=='5'){?><?php */?>
                                                 
                                                 <a href="<?php echo base_url('index.php/Stock/editstock/'.$loop['po_id']);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
                                                
                                                 <?php /*?><?php }?><?php */?>
                                                    
                                                    
                                                    
                                                  
                                                </td>
												 <!-- <td><input type="button" id="offer_btn_<?=$loop['pi_id']?>" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#assign_<?=$loop['pi_id']?>" value="Edit"  />&nbsp;&nbsp;&nbsp;<a class="btn btn-success btn-xs"  href="<?php echo base_url('index.php/Stock/export_damage?id='.$loop['pi_id']); ?>">Export FOC</a></td>-->
												
										      </tr>
											<?php }} ?>
										</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
     
<script type="text/javascript">
	function fndelete(id) {
		var deletopt=confirm('Are you sure, do you want to delete this record?');
	  	if(deletopt)  {
			window.location =  '<?php echo base_url('index.php/Stock/deletestock/')?>/'+id;
		    return true;
	  	}  else  {
		  	return false;
	  	}
	}
</script>
<script>
function chStatus(id,st){
		if(st == 1) {
		var chst = 0; //change status value
		}
		else {
		var chst = 1;	
		}
	//alert(chst);	
		jQuery.ajax({
			type: "POST",
			url: "<?php echo base_url(); ?>" + "index.php/Stock/statuschange",
			dataType: 'json',
			data: {id: id, st: chst},
			success: function(res) {
			if(res == 0) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			if(res == 1) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			
				//console.log(res);
				
			}
		});
}
$('.update_amt').on('click',function()
{
	var id = $(this).attr('id');
	
	id = id.split('_');
	id = id[2];
	//alert(id)
	var amount = $('#sel_price_'+id).val();
	$.ajax(
	{
		url:'<?php echo base_url(); ?>index.php/Stock/update_amt',
		type:'POST',
		data:{amount:amount,id:id},
		success: function(result)
		{
			alert('Sale amount updated successfully...!')
		}
	}
	);
});
function calc(id)
{
	var pur_amt = $('#pur_price_'+id).val();
	var sel_amt = $('#sel_price_'+id).val();
	var total = parseFloat(sel_amt)-parseFloat(pur_amt);
	if(total>0)
	{
		var data = '<font size="+1" color="#009933">'+total+'</fonnt>';
	}
	else
	{
		var data = '<font size="+1" color="#FF0000">'+total+'</fonnt>';
	}
	$('#pnl_profit_'+id).html(data);
}
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            //document.getElementById("sign_mobile_err").style.display = ret ? "none" : "inline";
            return ret;
        }


	<!------------------------Status Activate End----------------------------!>

	
</script>
<?php
$sno=1;
$po_id = '';
$po_id[] = '';
if(is_array($stock) && count($stock) ) 
{
	foreach($stock as $loop)
	{
	/*
	switch ($loop->supplier_code){
	case 1: $name1 = 'Supplier1'; break;
	case 2: $name1 = 'Supplier2'; break;
	case 3: $name1 = 'Supplier3'; break;
	case 4: $name1 = 'Supplier4'; break;
	default:
	$name1 = 'Supplier7';
	break;
	} */
		
//$po_id[] = $loop['po_id'];
												?>

<?php
		}
	}?>
<script type="text/javascript">
$('.update_storage').on('click',function()
{
	var id = $(this).attr('id');
	id = id.split('_');
	id = id[1];
	var qty_no = $('#qty_no'+id).val();
	//alert(waarehosue)
	var cus_name = $('#cus_name'+id).val();
	var type_action = $('#type_action'+id).val();
	if(qty_no != '' && cus_name != '' && type_action != '')
	{
		$(this).attr('disabled',true);
		$.ajax(
		{
			url:"<?php echo base_url('index.php/Stock/update_foc_info');?>",
			type:'POST',
			data:{qty_no:qty_no,cus_name:cus_name,type_action:type_action,id:id},
			success: function(result)
			{
				$('#offer_closemodal_btn_'+id).click();
				window.location.reload();
			}
		});
	}
});
</script>
<script>
  $(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
  </script>
</body>
</html>