<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_products(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_product');
		
		$this->db->order_by('i_id','desc');		
		//$this->db->where('is_delete =', 0);
        $query = $this->db->get();	
		return $query->result();			
	 }
	  function get_products_drop(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_product');
		//$this->db->where('is_delete =', 0);
		//$this->db->where('status =', 1);
        $query = $this->db->get();	
		return $query->result();			
	 }
	 
	  function get_rows_product(){
		$this->db->select('*')->from('tbl_product')->order_by('i_id','DESC')->limit('1');
        $query = $this->db->get();		
		return $query->result();			
		// $this->db->insert_id();
	 }
	 
	 function add_product($post) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_name'=>strtoupper($i_name),
		            'i_code'=>strtoupper($i_code),
                    'i_category'=>strtoupper($type),
                    'descr'=>strtoupper($descr),
					'ime'=>strtoupper($ime),
					'serial'=>strtoupper($serial),
					'date'=>$created_date,
					'status'=>1);	
	    $this->db->set($array);
	    $this->db->insert('tbl_product',$array);
	}
 
	function view_product($id){
		/**$this->db->select('tbl_product.*, `tbl_tax`.percentage AS percentage, tbl_manufacturer.m_name');
		$this->db->from('tbl_product');
		$this->db->join('tbl_tax as tbl_tax', 'tbl_tax.t_id = tbl_product.p_tax', 'left');
		$this->db->join('tbl_manufacturer', 'tbl_manufacturer.m_id = tbl_product.i_code', 'left');
		$this->db->where('i_id =', $id);
		*/
		$this->db->select('*')->from('tbl_product');
		$this->db->where('i_id =', $id);
		//echo $this->db->last_query();
		//$this->output->enable_profiler(TRUE);
		$query = $this->db->get();	
		return $query->result();			
	}
	
	
	function edit_product($id){			
		$this->db->select('*')->from('tbl_product')
		->where('i_id =', $id); 
		$query = $this->db->get();	
		$this->db->last_query();
		return $query->result();			
	}
	
	
	function update_product($id) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
                //echo '<pre>'; print_r($_REQUEST); exit;
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_name'=>strtoupper($i_name),
		            'i_code'=>strtoupper($i_code),
                  'i_category'=>strtoupper($i_type),
				  'ime'=>strtoupper($ime),
				  'serial'=>strtoupper($serial),
				  'descr'=>strtoupper($descr),);
		$this->db->set($array);
                $this->db->where('i_id',$id);
		$this->db->update('tbl_product',$array);
	}
	
	public function delete_product($id)
	{
		$array=array('is_delete'=>1);	
		$this->db->where('i_id', $id);
		$this->db->update('tbl_product', $array);
		return true;
	}
	
	 function statuschange($post) {
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
		$created_date=date('Y-m-d h:i:s');
		$array=array('date'=>$created_date,'status'=>$st);	
		$this->db->set($array);
	    $this->db->where('i_id',$id);
		$this->db->update('tbl_product',$array);	 
		echo $st;
	 }
	 
	 
	 

}