<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
          parent::__construct();
     }
    
	 
	 function get_profile($userid){	
		$array = array('cp_admin_login.admin_id' =>$userid);		
		$this->db->select('*')->from('cp_admin_login')
        ->where($array); 
		$query = $this->db->get();		
		return $query->result();			
	 }
	 
	 function edit_profile($id,$post) {
		$session_data = $this->session->all_userdata();
	    $password=$post['password'];
		$emp_code=$post['emp_code'];
		$name=$post['name'];
		//$mobile_number=$post['mobile_number'];
		$created_date=date('Y-m-d h:i:s');
		$array=array('password'=>$password,'name'=>$name,'emp_code'=>$emp_code,'status'=>1);	
	    $this->db->set($array);
	    $this->db->where('admin_id',$id);
		$this->db->update('cp_admin_login',$array);
		
	}
	  function get_pro_det() {
		$session_data = $this->session->all_userdata();
	    $this->db->select('tbl_leads.*,product_selling_price.price,inr_rates');
		 if(isset($inps['pono']) && $inps['pono']!='')
		    {
			    $this->db->where('tbl_leads.po_no', $inps['pono']);	
		    }
			 if(isset($inps['date']) && $inps['date']!='')
		    {
			    $this->db->where('tbl_leads.po_date', $inps['date']);	
		    }
		 $this->db->join('product_selling_price','product_selling_price.part_no = tbl_leads.part_no','left');
		$query = $this->db->get('tbl_leads')->result_array();
		 return $query;	
		
	}
	 
function get_pro_request(){
		$session_data = $this->session->all_userdata();	
	   $this->db->select('purchase_product.*,purchase_product.qty as qtys,tbl_product.i_id,tbl_product.i_name,i_category, i_code');
		$this->db->select('cp_admin_login.*');
		$this->db->where('purchase_product.location', $session_data['location']);
		
		$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		$this->db->join('cp_admin_login','cp_admin_login.admin_id = purchase_product.req_emp_id','left');
		$query = $this->db->get('purchase_product');	
		//echo '<pre>';print_r($query);exit;
		return $query->result();			
	 }
}