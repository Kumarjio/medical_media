<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Storage_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_all_Storage(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('cb_storage');	
		
		$this->db->order_by('cid','desc');	
		
			
		 $query = $this->db->get();		
		return $query->result();			
	 }
	  function get_all_Storage_loc(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('master_location');	
		 $query = $this->db->get();		
		return $query->result();			
	 }
	 
	public function delete_Storage($id)
	{
		
	    $this->db->where('cid',$id);
		$this->db->delete('cb_storage');	
		return true;
	}
	
	 function add_Storage($post) {
		 $session_data = $this->session->all_userdata();	
		 extract($_REQUEST);
		$created_date=date('Y-m-d h:i:s');
		//echo '<pre>'; print_r($post);
		
		$array=array(
		'storage_name'=>$Storage_name,
		/*'area_name'=>$area_name,
		'city_name'=>$city_name,
		'state_name'=>$state_name,*/
		'Location'=>$Location,
		//'pincode'=>$pincode,
		'created_date'=>$created_date);	
	    $this->db->set($array);
	    $this->db->insert('cb_storage',$array);
		//$last_id = $this->db->insert_id();
			
	}
	 
	 
	  function view_Storage($id){	
		$array = array('cid' => $id);		
		$this->db->select('*')->from('cb_storage')
        ->where($array); 
		$query = $this->db->get();
				
		return $query->result();	
		$this->output->enable_profiler(true);		
	 }
	
	function edit_Storage($id){	
		$array = array('cid' => $id);		
		$this->db->select('*')->from('cb_storage')
         ->where($array); 
		$query = $this->db->get();		
		return $query->result();			
	 }
	
	
	function update_Storage($id,$post) {
	    
	extract($_REQUEST);
		$created_date=date('Y-m-d h:i:s');
		
		$array=array(
		'storage_name'=>strtoupper($Storage_name),
		/*'area_name'=>$area_name,
		'state_name'=>$state_name,
		'city_name'=>strtoupper($city_name),*/
		'Location'=>$Location,
		/*'pincode'=>strtoupper($pincode),
	    'state_name'=>strtoupper($state_name),*/
		'created_date'=>$created_date);	

		$this->db->set($array);
	    $this->db->where('cid',$id);
		$this->db->update('cb_storage',$array);
		
	}
  
	

}