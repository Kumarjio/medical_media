<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stock_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_stocks($id){
		$session_data = $this->session->all_userdata();	
		$this->db->select('tbl_po_inv.*');
		$this->db->select('tbl_po_inv_item.pi_id,vname,tbl_po_inv_item.tbl_purchase_req_id,tbl_po_inv_item.p_rate,tbl_po_inv_item.qty as qtys,tbl_po_inv_item.total as totals');
		$this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1');
		$this->db->select('tbl_product.i_name,i_code');
		$this->db->select('tbl_statutory.id as ids,tbl_statutory.product_type,vat as vats');
		
		$this->db->join('tbl_po_inv_item','tbl_po_inv_item.po_inv_id=tbl_po_inv.po_id','left');
		$this->db->join('tbl_purchase_request','tbl_purchase_request.id=tbl_po_inv_item.tbl_purchase_req_id','left');
		$this->db->join('tbl_product','tbl_product.i_id=tbl_purchase_request.pro_id','left');
		$this->db->join('tbl_statutory','tbl_statutory.product_type=tbl_purchase_request.pro_type','left');
		if(isset($id) && !empty($id))
		{
			$this->db->where('tbl_po_inv.po_id =', $id);
		}
		//$this->db->order_by('po_id','asc');
		//$this->db->group_by('po_id');
		$query =$this->db->get('tbl_po_inv')->result_array();
		return $query;			
	 }
	 function get_all_stocks($inps)
	 {
		$session_data = $this->session->all_userdata();	
		$this->db->select('tbl_po_inv.*');
		//$this->db->select('cb_storage.storage_name,cb_storage.Location as loc');
		$this->db->select('tbl_po_inv_item.*,tbl_po_inv_item.qty as qtys');
		$this->db->select('cb_seller.seller_name');
		$this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1');
		$this->db->select('tbl_product.i_name,i_code,descr');
		
		$this->db->join('tbl_po_inv_item','tbl_po_inv_item.po_inv_id=tbl_po_inv.po_id','left');
		//$this->db->join('cb_storage','cb_storage.cid=tbl_po_inv.storage_name','left');
		$this->db->join('cb_seller','cb_seller.cid=tbl_po_inv_item.vname','left');
		$this->db->join('tbl_purchase_request','tbl_purchase_request.id=tbl_po_inv_item.tbl_purchase_req_id','left');
		$this->db->join('tbl_product','tbl_product.i_id=tbl_purchase_request.pro_id','left');
		
		//$this->db->join('cb_customer','cb_customer.cid=tbl_po_inv.customer','left');
		if(isset($inps['from_dt']) && !empty($inps['from_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_po_inv.pdate,'%Y-%m-%d')>=",date('Y-m-d',strtotime($inps['from_dt'])));
		}
		if(isset($inps['to_dt']) && !empty($inps['to_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_po_inv.pdate,'%Y-%m-%d')<=",date('Y-m-d',strtotime($inps['to_dt'])));
		}
		
		if(isset($inps['seller']) && $inps['seller']!='')
		{
			$this->db->where('tbl_po_inv.vname =', $inps['seller']);	
		}
		if(isset($inps['storage']) && $inps['storage']!='')
	    {
			$this->db->where('cb_storage.Location =', $inps['storage']);	
		}
		
		if(isset($inps['product_cde']) && !empty($inps['product_cde']))
		{
			$this->db->where('tbl_product.i_code =', $inps['product_cde']);
		}
		
		//$this->db->order_by('po_id','desc');
		$this->db->group_by('tbl_po_inv.po_id','asc');
		$query =$this->db->get('tbl_po_inv')->result_array();
			//echo $this->db->last_query(); //exit;
		return $query;			
	 }
	  function get_stocks_drop(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_po_inv');
		//$this->db->where('is_delete =', 0);
		$this->db->where('status =', 1);
        $query = $this->db->get();	
		return $query->result();			
	 } 
	 function getstockdetails($inps){
		    $session_data = $this->session->all_userdata();
			$this->db->select('purchase_product.*,purchase_product.qty as qtys,tbl_product.i_id,tbl_product.i_name,i_category, i_code');
			$this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1');
			$this->db->where('purchase_product.location', $session_data['location']);
			if(isset($inps['pname']) && $inps['pname']!='')
		    {
			    $this->db->where('tbl_product.i_name', $inps['pname']);	
		    }
			$this->db->join('tbl_purchase_request','tbl_purchase_request.id=purchase_product.tbl_purchase_req_id','left');
			$this->db->join('tbl_product','tbl_product.i_id = tbl_purchase_request.pro_id','left');
			
			
			
		/*if(isset($inps['pname1']) && $inps['pname1']!='')
		{
			$this->db->where('product_total_allocation.tbl_product_id', $inps['pname1']);	
		}*/
			$query = $this->db->get('purchase_product');	
			return $query->result_array();
	 }
	 function get_pro_det1($inps){ 
	    $session_data = $this->session->all_userdata();
		$this->db->select('purchase_product.*');
		$this->db->select('tbl_product.*');
		$this->db->select('cp_admin_login.*');
		$this->db->where('purchase_product.tbl_product_id=',$inps['cus']);
		$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		$this->db->join('cp_admin_login','cp_admin_login.admin_id = purchase_product.emp_id','left');
	   $query= $this->db->get('purchase_product')->result_array();
	//echo '<pre>';print_r($query);exit;
		return $query;	
	  
	}
	 function getpro(){
		    $session_data = $this->session->all_userdata();
			$this->db->select('purchase_product.*,purchase_product.qty as qtys,tbl_product.i_id,tbl_product.i_name,i_category, i_code');
			
			$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
			
			
			
		/*if(isset($inps['pname1']) && $inps['pname1']!='')
		{
			$this->db->where('product_total_allocation.tbl_product_id', $inps['pname1']);	
		}*/
			$query = $this->db->get('purchase_product');	
			return $query->result_array();
	 }
	  function getstockdetails1($inps){
		    $session_data = $this->session->all_userdata();
			$this->db->select('purchase_product.*,purchase_product.qty as qtys,tbl_product.i_id,tbl_product.i_name,i_category, i_code');
			$this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1');
			$this->db->select('cp_admin_login.*');
			$this->db->where('purchase_product.req_emp_location', $session_data['location']);
			if(isset($inps['pname']) && $inps['pname']!='')
		    {
			    $this->db->where('tbl_product.i_name', $inps['pname']);	
		    }
			$this->db->join('tbl_purchase_request','tbl_purchase_request.id=purchase_product.tbl_purchase_req_id','left');
			$this->db->join('tbl_product','tbl_product.i_id = tbl_purchase_request.pro_id','left');
			$this->db->join('cp_admin_login','cp_admin_login.admin_id = purchase_product.emp_id','left');
			
			
		/*if(isset($inps['pname1']) && $inps['pname1']!='')
		{
			$this->db->where('product_total_allocation.tbl_product_id', $inps['pname1']);	
		}*/
			$query = $this->db->get('purchase_product');	
			return $query->result_array();
	 }
	 
	 	 
	  function get_rows_stock(){
		$this->db->select('i_id')->from('tbl_po_inv')->order_by('i_id','DESC')->limit('1');
        $query = $this->db->get();		
		return $query->result();			
		// $this->db->insert_id();
	 }
	 
	 function add_stock($post) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post stock details
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_category'=>$i_category,'i_name'=>strtoupper($i_name),'i_code'=>strtoupper($i_code),'m_code'=>strtoupper($m_code),'fixed_rate'=>$fixed_rate,'m_date'=>$m_date,'packing'=>strtoupper($packing),'exp_date'=>$exp_date,'s_price'=>$s_price,'p_rate'=>$p_rate,'p_tax'=>$p_tax,'offer'=>strtoupper($offer),'combination'=>strtoupper($combination),'min_qty'=>$min_qty,'max_qty'=>$max_qty,/*'batch_no'=>strtoupper($batch_no),*/'mrp'=>$mrp,'s_tax'=>$s_tax,'date'=>$created_date,'status'=>1);	
	    $this->db->set($array);
	    $this->db->insert('tbl_po_inv',$array);
	}
	
	
 
	function view_stock($id){
		print_r($id); exit;
		$this->db->select('tbl_po_inv.*, tbl_packing.pk_type, `tbl_tax`.percentage AS percentage, tbl_tax_1`.percentage AS percentage1, tbl_category.ct_name, tbl_manufacturer.m_name');
		$this->db->from('tbl_po_inv');
		$this->db->join('tbl_packing', 'tbl_packing.pk_id = tbl_po_inv.packing', 'left');
		$this->db->join('tbl_tax as tbl_tax', 'tbl_tax.t_id = tbl_po_inv.p_tax', 'left');
		$this->db->join('tbl_tax as tbl_tax_1' , 'tbl_tax_1.t_id = tbl_po_inv.s_tax', 'left');
		$this->db->join('tbl_category', 'tbl_category.ct_id = tbl_po_inv.i_category', 'left');
		$this->db->join('tbl_manufacturer', 'tbl_manufacturer.m_id = tbl_po_inv.m_code', 'left');
		$this->db->where('i_id =', $id);
		
		//echo $this->db->last_query();
		//$this->output->enable_profiler(TRUE);
		$query = $this->db->get();	
		return $query->result();			
	}
	
	
	function edit_stock($id){			
		$this->db->select('*')->from('tbl_po_inv')
		->where('i_id =', $id); 
		$query = $this->db->get();	
		$this->db->last_query();
		return $query->result();			
	}
	
	
	function update_stock($id) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post stock details
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_category'=>$i_category,'i_name'=>strtoupper($i_name),'i_code'=>strtoupper($i_code),'m_code'=>strtoupper($m_code),'fixed_rate'=>$fixed_rate,'m_date'=>$m_date,'packing'=>strtoupper($packing),'exp_date'=>$exp_date,'s_price'=>$s_price,'p_rate'=>$p_rate,'p_tax'=>$p_tax,'offer'=>strtoupper($offer),'combination'=>strtoupper($combination),'min_qty'=>$min_qty,'max_qty'=>$max_qty,/*'batch_no'=>strtoupper($batch_no),*/'mrp'=>$mrp,'s_tax'=>$s_tax,'date'=>$created_date,'status'=>1);	
		$this->db->set($array);
	    $this->db->where('i_id',$id);
		$this->db->update('tbl_po_inv',$array);
	}
	
	
	public function delete_stock($id)
	{
		$array=array('is_delete'=>1);	
		$this->db->where('vinvno', $id);
		$this->db->update('tbl_po_inv', $array);
		$array=array('is_delete'=>1);	
		$this->db->where('po_inv_id', $id);
		$this->db->update('tbl_po_inv_item', $array);
		return true;
	}
	
	 function statuschange($post) {
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post stock details
		$created_date=date('Y-m-d h:i:s');
		$array=array('date'=>$created_date,'status'=>$st);	
		$this->db->set($array);
	    $this->db->where('i_id',$id);
		$this->db->update('tbl_po_inv',$array);	 
		echo $st;
	 }
	 function get_all_sell($id)
	 {
		 $this->db->select('tbl_item_sel_price.*,tbl_item_sel_price.post_dt as checked_dt');
		 $this->db->select('cb_storage.storage_name,Location');
		 $this->db->select('cb_seller.seller_name');
		 $this->db->select('tbl_po_inv.vname,tbl_po_inv.created_date as purdate,customer');
		$this->db->select('tbl_po_inv_item.pi_id,tbl_po_inv_item.item_code,tbl_po_inv_item.p_rate,tbl_po_inv_item.p_tax,tbl_po_inv_item.s_price,tbl_po_inv_item.s_tax,tbl_po_inv_item.qty,tbl_po_inv_item.total,tbl_po_inv_item.po_inv_id');
		$this->db->select('tbl_product.i_name,i_code,descr');
		$this->db->join('tbl_po_inv_item','tbl_po_inv_item.pi_id=tbl_item_sel_price.product_id','left');
		$this->db->join('tbl_product','tbl_product.i_id=tbl_po_inv_item.item_code','left');
		$this->db->join('cb_storage','cb_storage.cid=tbl_po_inv_item.slocation','left');
		$this->db->join('tbl_po_inv','tbl_po_inv_item.po_inv_id=tbl_po_inv.vinvno','left');
		$this->db->join('cb_seller','cb_seller.cid=tbl_po_inv.vname','left');
		$this->db->where('tbl_item_sel_price.product_id',$id); 
		$query =$this->db->get('tbl_item_sel_price')->result_array();
		//echo $this->db->last_query(); exit;
		return $query;	
	 }
	 function get_all_sell_out($id)
	 {
		 $this->db->select('tbl_item_sel_price.*');
		 $this->db->select('cb_storage.storage_name,Location');
		 $this->db->select('cb_seller.seller_name');
		 $this->db->select('tbl_foc_dam.foc_dam_qty,tbl_foc_dam.foc_out_name,tbl_foc_dam.foc_dam_sts');
		 $this->db->select('tbl_po_inv.vname,tbl_po_inv.created_date as purdate,customer');
		$this->db->select('tbl_po_inv_item.pi_id,tbl_po_inv_item.item_code,tbl_po_inv_item.p_rate,tbl_po_inv_item.p_tax,tbl_po_inv_item.s_price,tbl_po_inv_item.s_tax,tbl_po_inv_item.qty,tbl_po_inv_item.total,tbl_po_inv_item.po_inv_id');
		$this->db->select('tbl_product.i_name,i_code,descr');
		$this->db->join('tbl_po_inv_item','tbl_po_inv_item.pi_id=tbl_item_sel_price.product_id','left');
		$this->db->join('tbl_product','tbl_product.i_id=tbl_po_inv_item.item_code','left');
		$this->db->join('cb_storage','cb_storage.cid=tbl_po_inv_item.slocation','left');
		$this->db->join('tbl_po_inv','tbl_po_inv_item.po_inv_id=tbl_po_inv.vinvno','left');
		$this->db->join('cb_seller','cb_seller.cid=tbl_po_inv.vname','left');
		$this->db->join('tbl_foc_dam','tbl_foc_dam.inv_item_id=tbl_po_inv_item.pi_id','left');
		$this->db->where('tbl_foc_dam.inv_item_id',$id); 
		$query =$this->db->get('tbl_item_sel_price')->result_array();
		//echo $this->db->last_query(); exit;
		return $query;	
	 }
	 
	 
	 

}