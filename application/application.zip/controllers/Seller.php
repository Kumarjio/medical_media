<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Seller extends CI_Controller 
{
	public function __construct()
	{
		  parent::__construct();
		  $this->load->library('session');
		  //load the login model
		  $this->load->model('Seller_model');
		  $this->load->model('Storage_model');
		  
	 }	
	public function index(){		
		$query = $this->Seller_model->get_all_seller();
		if($query){
			$data['seller'] =  $query;
		} else {
			$data['seller'] =  '';
		}
		$data['title'] = 'View All Seller :: ACC ';
		$this->load->view('sellerlist', $data);
	}
	public function addSeller()
	{
		$this->form_validation->set_rules('seller_name', 'Seller Name', 'required|trim|xss_clean');
		$this->form_validation->set_rules('city_name', 'City Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('state_name', 'State', 'required|trim');
		$this->form_validation->set_rules('country_name', 'Country', 'required|trim|xss_clean');
		$this->form_validation->set_rules('pincode', 'Zip Code', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('joining_date', 'Joining Date', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('advance', 'Advance', 'required|numeric|trim|xss_clean');
		
		
		
		if ($this->form_validation->run() == FALSE) 
		{ 
			 $data['title'] = 'Add Seller :: ACC ';
			  $data['head'] = $this->Storage_model->get_all_Storage_loc();
 			  $this->load->view('add_seller',$data);	
		} 
		else 
		{
			$muinput= $this->security->xss_clean($this->input->post());
			$manage_category=$this->Seller_model->add_seller($muinput);
			echo "<script> alert('Successfully added');window.location= '".base_url('index.php/Seller')."'</script>";
			
		}
		//$this->load->view('add_seller');
	}
	public function viewseller($id){
		 $data['title'] = 'View Seller :: ACC ';
	   //	 $data['seller']=$this->Seller_model->view_seller($id);
		 $this->load->view('sellerview',$data);
	}
	
	public function editseller1($id){
		 $data['title'] = 'Edit Seller :: ACC ';
		 //$data['head'] = $this->Seller_model->get_head();
		 /*$data['salesman_rep'] = $this->Seller_model->get_salesman_rep();
		 $data['salesman_asm'] = $this->Seller_model->get_salesman_asm();
		 $data['salesman_rsm'] = $this->Seller_model->get_salesman_rsm();*/
		 $data['seller']=$this->Seller_model->edit_seller($id);
		  $data['head'] = $this->Storage_model->get_all_Storage_loc();
		 $this->load->view('selleredit',$data);
	}
		
	public function updateSeller($id){
		
		
		$this->form_validation->set_rules('seller_code', 'Seller Code', 'required|trim|xss_clean');
		$this->form_validation->set_rules('seller_name', 'Seller Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('city_name', 'City Name', 'trim|xss_clean');
		//$this->form_validation->set_rules('state_name', 'State', 'trim');
		//$this->form_validation->set_rules('country_name', 'Country', 'trim|xss_clean');
		//$this->form_validation->set_rules('pincode', 'Pincode', 'numeric|trim|xss_clean');
		//$this->form_validation->set_rules('joining_date', 'Joining Date', 'trim|xss_clean');
		//$this->form_validation->set_rules('advance', 'Advance', 'numeric|trim|xss_clean');
		
		if ($this->form_validation->run() == FALSE) { 
			 $data['title'] = 'Edit Seller :: ACC ';
			 //$data['head'] = $this->Seller_model->get_head();
			 $data['seller']=$this->Seller_model->edit_seller($id);
		 	 $this->load->view('selleredit',$data);	
		} else {
			$muinput= $this->security->xss_clean($this->input->post());
			$manage_category=$this->Seller_model->update_seller($id,$muinput);
			echo "<script> alert('Successfully updated');window.location= '".base_url('index.php/Seller')."'</script>";
			
		}
	}	

	
	
}
