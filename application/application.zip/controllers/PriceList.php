<?php defined('BASEPATH') OR exit('No direct script access allowed');
class PriceList extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  } 
		  	  
                $this->load->model('Pricelist_model');
     }
	
	public function index()
	{
       
        $data['title'] = 'View All Products  ';
		$data['list'] = $this->Pricelist_model->get_prices();
		
		//$pro = $this->Pricelist_model->get_pro_rows($inps);
		$data['get_storage'] = $this->Pricelist_model->get_storage();
		$this->load->view('pricelist', $data);
	}
	
	public function addrate()
	{
        $data['title'] = 'Add Products Rate  ';
		//$inps = $this->input->post();
		
		$data['get_product'] = $this->Pricelist_model->get_product();
		$this->load->view('product_price_add',$data);   
    }

	public function addprice()
	{
		$inps = $this->input->post();
		//echo '<pre>';print_r($inps);exit;
		$conf_id=$this->Pricelist_model->add_price($inps);
		
		$data['title'] = 'PriceList ';
		echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/PriceList')."'</script>";
		//redirect('PriceList',refresh);
	}
	public function get_all_det1()
	{
		$inps = $this->input->post();
		//echo '<pre>';print_r($inps);exit;
		$pro = $this->Pricelist_model->get_pro_rows($inps);
		//echo '<pre>';print_r($pro);exit;
		//$this->load->view('product_price_add',$pro);*/
	//echo '<pre>';print_r($data);exit;   
		//$c_det = '';
			/*foreach($pro as $row)
		    {
				$c_det .= '<select class="selectpicker form-control uppercase"  name="NITE_'.$row['i_id'].'" id="NIITE_'.$row['i_id'].' "data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"><option  value="'.$row['i_id'].'"><?php echo '.$row['i_name'].'; ?></option></select><br />';
				}*/
				
		foreach($pro as $row)
			{
				
				$data['serial'] = $row['i_name'];
				//echo '<pre>';print_r($data['serial']);exit;   
			}
			
	echo json_encode($data);
			
			
			
	}
	
}
