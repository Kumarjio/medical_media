<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Reports extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Reports_model');
		  $this->load->model('Stock_model');
		  $this->load->model('Purchase_model');		
		  $this->load->model('Sales_model');
		  $this->load->model('Storage_model');
     }

	
	 public function index()
	 {
			
		$data['title'] = 'VAT Reports:: Union Trading ';
		$this->load->view('reports_vat_daily', $data);
	}
	public function Purchase()
	{
		$data['title'] = 'Reports';
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		
		/*$query = $this->Storage_model->get_all_Storage();
		if($query){
			$data['Storage'] =  $query;
		} else {
			$data['Storage'] =  '';
		}*/
		$query = $this->Reports_model->get_all_stocks($inps);
		//echo '<pre>'; print_r($query);//exit;
		if(isset($inps['export']))
		{
			$amts = '0';
			$spr = '0';
			$profitt = '0';
			$tot_qty = '0';
			//$this->load->library("excel");
			$heading = Array ('S.NO','Invoice No','Vendor','Product Name','Qty','Purchase Price','Tax','Total') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Purchase List Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			foreach($query as $row) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = $row['vinvno'];
				//$newrow[2] = $customer;
				$newrow[2] = $row['vname'];
				//$newrow[4] = $row['i_code'];
				$newrow[3] = $row['i_name']. ' - ' .$row['descr'];
				$newrow[4] = $row['qty'];
				$newrow[5] = $row['p_rate'];
				$newrow[6] = $row['per_taxamt'];
				$newrow[7] = $row['gtotal'];
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			
			exit;
		}
		$data['inps'] = $inps; 
		if($query){
			$data['stock'] =  $query;
		} else {
			$data['stock'] =  '';
		}

		$data['title'] = 'Purchase List  ';
		$con = '*';
		$data['storage']  = $this->Storage_model->get_all_Storage();
		$data['seller'] = $this->Purchase_model->get_all_datase('cb_seller',$con);
		$this->load->view('stockreportlist', $data);
	}
	public function statutory()
	{
		$data['title'] = 'Vat Returns Reports';
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		
		/*$query = $this->Storage_model->get_all_Storage();
		if($query){
			$data['Storage'] =  $query;
		} else {
			$data['Storage'] =  '';
		}*/
		$query = $this->Reports_model->get_all_statutory($inps);
		//echo '<pre>'; print_r($query);exit;
		if(isset($inps['export']))
		{
			$amts = '0';
			$spr = '0';
			$profitt = '0';
			$tot_qty = '0';
			//$this->load->library("excel");
			$heading = Array ('S.NO','Vendor','Tin No','Cst No','Bill No','Bill Date','Product Name','Purchase Price','Qty','Tax','Total','Cus Name','Bill No','Date','Rate','Qty','Tax Amt','Total','Vat To Be Paid') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Vat Returns Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			$vat_paid=0;
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			foreach($query as $row) 
			{
				if($row['tax_amt']>$row['tax_amount']){
															$vat_paid =$row['tax_amt']-$row['tax_amount'];
															}
															else{
																$vat_paid =$row['tax_amount']-$row['tax_amt'];
															}
				$newrow[0] = $cnt;
				$newrow[1] = $row['vname'];
				$newrow[2] = $row['tin_no'];
				$newrow[3] = $row['cst_no'];
				$newrow[4] = $row['vinvno'];
				$newrow[5] = date('d-m-Y', strtotime($row['date']));
				$newrow[6] = $row['i_name']. ' - ' .$row['descr'];
				$newrow[7] = $row['pro_total'];
				$newrow[8] = $row['tax_amount'];
				$newrow[9] = $row['qty'];	
				$newrow[10] = $row['gtotal'];
				
				$newrow[11] = $row['customer_name']. ' - ' .$row['mob_no1'];
				$newrow[12] = $row['sno'];
				$newrow[13] = date('d-m-Y', strtotime($row['cf']));
				$newrow[14] = $row['total'];
				$newrow[15] = $row['quantity'];
				$newrow[16] = $row['tax_amt'];
				$newrow[17] = $row['total_value'];
				
				$newrow[18] = $vat_paid;
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			
			exit;
		}
		$data['inps'] = $inps; 
		if($query){
			$data['stock'] =  $query;
		} else {
			$data['stock'] =  '';
		}

		$data['title'] = 'Vat Returns List  ';
		$con = '*';
		$data['storage']  = $this->Storage_model->get_all_Storage();
		$data['seller'] = $this->Purchase_model->get_all_datase('cb_seller',$con);
		$this->load->view('statutory_report', $data);
	}
	public function sold_list() 
	{
		$data['title'] = 'Reports';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}
		//echo '<pre>';print_r($inps); exit;
		$data['title'] = 'Sales List';
		//$data['customer'] = $this->Sales_model->getList();
		$data['list'] = $this->Reports_model->getList($inps);
		//echo '<pre>';print_r($data['list']); exit;
		if(isset($inps['export']))
		{
			
			//$this->load->library("excel");
			$heading = Array ('S.NO','Invoice No','Customer Name','Mobile','Product Name','Qty','Total Amt','Date') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Sales List Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			$type=0;
			foreach($data['list'] as $row) 
			{
				/*if($row['payment_method'] == 1)
								{
									$type = "Cash";
								}
								else if($row['payment_method'] == 2)
								{
									$type = "Cheque / DD";
								}
								else if($row['payment_method'] == 3)
								{
									$type = "Online Transfer";
								}
								else if($row['payment_method'] == 4)
								{
									$type = "Credit Card / Debit Card";;
								}
								else if($row['payment_method'] == 5)
								{
									$type = 'Finance';
								}*/
				$newrow[0] = $cnt;
				$newrow[1] = $row['bill_no'];
				$newrow[2] = $row['customer_name'];
				$newrow[3] = $row['mob_no1'];
				$newrow[4] = $row['i_name'];
				$newrow[5] = $row['quantity'];
				$newrow[6] = $row['total_amount'];
				/*$newrow[6] = $row['paym_amount'];
				$newrow[7] = $row['product_amount']-$row['paym_amount'];
				$newrow[8] = $type;
				$newrow[9] = $row['reference_no'];
				$newrow[10] = $row['trans_id'];
				$newrow[11] = $row['bank_name'];
				$newrow[12] = $row['cheque_no'];
				$newrow[13] = $row['finance_name'];
				$newrow[14] = $row['tot_month'];
				$newrow[15] = $row['emi'];*/
				$newrow[7] = date('d-m-Y', strtotime($row['cds']));
				
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			
			exit;
		}
		

		
		$data['inps']=$inps;
		$this->load->view('sold_list_reoprt',$data);
	}
	public function vendor_det() 
	{
		$data['title'] = 'Reports';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}
		//echo '<pre>';print_r($inps); exit;
		$data['title'] = 'vendor details  ';
		//$data['customer'] = $this->Sales_model->getList();
		$data['items'] = $this->Reports_model->get_vendor_List($inps);
		//echo '<pre>';print_r($data['list']); exit;
		if(isset($inps['export']))
		{
			
			//$this->load->library("excel");
			$heading = Array ('S.NO','PO No','Vendor Name','Product Type','Product Name','Req Qty','Total Amt','Purchase Request Date','Invoice No','Pur Price','Pur Date','Qty','Payment Method','Paid Amt','Reference NO','Transaction Id','Bank Name','Cheque NO','Date') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Vendor Transaction Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			$type=0;
			foreach($data['items'] as $row) 
			{
				if($row['payment_method'] == 1)
								{
									$type = "Cash";
								}
								else if($row['payment_method'] == 2)
								{
									$type = "Cheque / DD";
								}
								else if($row['payment_method'] == 3)
								{
									$type = "Online Transfer";
								}
								else if($row['payment_method'] == 4)
								{
									$type = "Credit Card / Debit Card";;
								}
								else if($row['payment_method'] == 5)
								{
									$type = 'Finance';
								}
				$newrow[0] = $cnt;
				$newrow[1] = $row['pur_req_id'];
				$newrow[2] = $row['vname'];
				$newrow[3] = $row['type_name'];
				$newrow[4] = $row['i_name'];
				$newrow[5] = $row['qtyss'];
				$newrow[6] = $row['total_amt'];
				$newrow[7] = $row['pur_date'];
				$newrow[8] = $row['vinvno'];
				$newrow[9] = $row['gtotal'];
				$newrow[10] = date('d-m-Y', strtotime($row['date']));
				$newrow[11] = $row['qty'];
				$newrow[12] = $type;
				$newrow[13] = $row['amt'];
				$newrow[14] = $row['reference_no'];
				$newrow[15] = $row['trans_id'];
				$newrow[16] = $row['bank_name'];
				$newrow[17] = $row['cheque_no'];
				$newrow[18] = date('d-m-Y', strtotime($row['created_date']));
				
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			
			exit;
		}
		

		$con = '*';
		$data['inps']=$inps;
		$data['seller'] = $this->Purchase_model->get_all_datase('cb_seller',$con);
		$this->load->view('vendor_list_reoprt',$data);
	}
	public function stock(){
		$data['title'] = 'Reports';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}		
		$query = $this->Reports_model->get_stock_summary($inps);
		//echo '<pre>';print_r($query); exit;
		//if($this->input->get())
		if(isset($inps['export']))
		{
			$heading = Array ('S.NO','Invoice No','Customer Name','Mobile No','Product Name','Billed Qty','Total Amt','Date','Hands In Quantity') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			$fileName = "Stocks Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			// file name for download
			
			$flag = false;
			$cnt = 1;
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			foreach($query as $row) 
			{
				
				
				
				$newrow[0] = $cnt;
                $newrow[1] = $row['bill_no'];
				$newrow[2] = $row['customer_name'];
				$newrow[3] = $row['mob_no1'];
				$newrow[4] = $row['i_name'];
				$newrow[5] = $row['quantity'];
				$newrow[6] = $row['total_amount'];
				$newrow[7] = date('d-m-Y', strtotime($row['cds']));
				$newrow[8] = $row['qty'];
				
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			
			
			exit;
		}
		$data['inps'] = $inps; 
		if($query){
			$data['list'] =  $query;
		} else {
			$data['list'] =  '';
		}
		//echo '<pre>';print_r($data['customer']);exit();
		$data['title'] = 'stocks ists ';
		//echo '<pre>';print_r($data['product']);exit();
		$this->load->view('stocks_lists_report', $data);
	}
	public function stock_transfer(){
		$data['title'] = 'Reports';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}		
		$query = $this->Reports_model->get_stock_transfer($inps);
		//echo '<pre>';print_r($query); exit;
		//if($this->input->get())
		if(isset($inps['export']))
		{
			$heading = Array ('S.NO','Requested Location','Product Name','Product Type','Serial/Ime NO','Req Qty','Req Date','Material Request From','Approved Qty','Date') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			$fileName = "stock transfer" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			// file name for download
			
			$flag = false;
			$cnt = 1;
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			foreach($query as $row) 
			{
				
				
				
				$newrow[0] = $cnt;
                $newrow[1] = $row['req_emp_location'];
				$newrow[2] = $row['i_name'];
                $newrow[3] = $row['type_name'];
				$newrow[4] = $row['serial_ime'];
				$newrow[5] = $row['req_qty'];
				$newrow[6] = date('d-m-Y', strtotime($row['cd']));
				$newrow[7] = $row['req_product_location'];
				$newrow[8] = $row['approved_qty'];
				$newrow[9] = date('d-m-Y', strtotime($row['delivery_date']));
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			
			
			exit;
		}
		$data['inps'] = $inps; 
		if($query){
			$data['list'] =  $query;
		} else {
			$data['list'] =  '';
		}
		//echo '<pre>';print_r($data['customer']);exit();
		$data['title'] = 'stock transfer';
		//echo '<pre>';print_r($data['product']);exit();
		$data['storage']  = $this->Storage_model->get_all_Storage_loc();
		$this->load->view('stock_transfer_report', $data);
	}
	 public function customer(){
		 $data['title'] = 'Reports';
		 if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}		
		$query = $this->Reports_model->get_cus($inps);
		//echo '<pre>';print_r($query); exit;
		if($this->input->post())
		{
			$heading = Array ('S.NO','Customer Id','Customer Name','Mobile','Area Name','Product Type','Product Name','Selling Rate','Payment Method','Amount','Reference NO','Transaction Id','Bank Name','Cheque NO','Date') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			$type =0;
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true; //print '<br>';
			}
			foreach($query as $row) 
			{
				if($row->payment_method == 1)
								{
									$type = "Cash";
								}
								else if($row->payment_method == 2)
								{
									$type = "Cheque / DD";
								}
								else if($row->payment_method == 3)
								{
									$type = "Online Transfer";
								}
								else if($row->payment_method == 4)
								{
									$type = "Credit Card / Debit Card";;
								}
								else if($row->payment_method == 5)
								{
									$type = 'Finance';
								}
				
				
				$newrow[0] = $cnt;
				$newrow[1] = $row->cid;
				$newrow[2] = $row->customer_name;
				$newrow[3] = $row->mob_no1;
				$newrow[4] = $row->area_name;
				$newrow[5] = $row->type_name;
				$newrow[6] = $row->i_name;
				$newrow[7] = $row->selling_rate;
				$newrow[8] = $type;
				$newrow[9] = $row->amt;
				$newrow[10] = $row->reference_no;
				$newrow[11] = $row->trans_id;
				$newrow[12] = $row->bank_name;
				$newrow[13] = $row->cheque_no;
				$newrow[14] = date('d-m-Y', strtotime($row->created_date));
				
				// filter data
				array_walk($newrow, 'filterData'); ///print '<br>';
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
				
				
				// filter data
				
			
			//echo implode("\t", array_values($blankrow)) . "\n";
			//$totalarry = array("","","","Total : ", number_format($totalamount, 2, '.', ''),"");
			//array_walk($totalarry, 'filterData');
			//echo implode("\t", array_values($totalarry)) . "\n";
			// headers for download
			$fileName = "Customer Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			exit;
		}
		$data['inps'] = $inps; 
		if($query){
			$data['customer'] =  $query;
		} else {
			$data['customer'] =  '';
		}
		//echo '<pre>';print_r($data['customer']);exit();
		$data['title'] = 'View All Customer  Trading ';
		//echo '<pre>';print_r($data['product']);exit();
		$this->load->view('customerlist_report', $data);
	}
		 
		 
	
	
}
