<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Location extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Employee_model');
        // $this->load->model('Sales_model');
		  //$this->load->model('dealer_model'); 
     }
	
	public function index()	
	{
		$data['title'] = 'Location list:: ACC ';
		$data['list']= $this->Employee_model->getlocationdetails();
		//echo '<pre>';print_r($data);
		$this->load->view('location_list', $data);
		
	}
}
	?>