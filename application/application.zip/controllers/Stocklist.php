<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Stocklist extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  } 
		  	  
		  $this->load->model('Stock_model');
		  
     }
	
	public function index(){
		$data['title'] = 'View All Stocks :: ACC ';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}	
		$data['list']= $this->Stock_model->getstockdetails($inps);	
		//$data['list2']= $this->stock_model->getstockdetails1($inps);	
	  // echo '<pre>';print_r($data['list']); exit;
	    if(isset($inps['export']))
		{
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
		}
	    
		$this->load->view('stocks_lists', $data);
	}
	public function addStocks(){
		$data['title'] = 'View All Stocks :: ACC ';
		$this->load->view('add_stocks', $data);
	}
	public function import()
	{
		//echo '<pre>';print_r($_FILES);exit;
		$session_data = $this->session->all_userdata();	
		$inps = $this->input->post();
		 
		
		
	  if(isset($_FILES["excel_file"]))
		{
			$filename=$_FILES["excel_file"]["tmp_name"];
			if($_FILES["excel_file"]["size"] > 0)
			  {
				$file = fopen($filename, "r");
				$i=0;
				$type=0;
				 while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
				 {
					  if($i>0)
						 {
							/* $this->db->select('*');
							 $this->db->where('i_id',$emapData[4]);
							 $get_det = $this->db->get('tbl_product');
							 if($get_det->num_rows()>0)
							 {
								 //update 
								 $data = array(
									'ime_serial' => $emapData[7],
									);
								$this->db->where('i_id',$emapData[4]);
								$this->db->update('tbl_product', $data);
								exit;
							 }
							 else
							 {*/
								 $data = array(
								    'emp_id'=>$session_data['user_id'],
									'tbl_product_id'=>$emapData[0],
									'location' => $emapData[1],
								    'vendor_date' => date('Y-m-d', strtotime($emapData[2])),
									'vendor_name' => $emapData[3],
									'vendor_invoice' => $emapData[4],
									
									'serial_ime' => $emapData[7],
									'p_rate'=>$emapData[9],
									'total_val'=>$emapData[10],
									'qty' => $emapData[11],
									'tbl_purchase_req_id'=>0,
									'status_req' =>0,
									'created_date' => date('Y-m-d H:i:s'),
									);
								$this->db->insert('purchase_product', $data);
								if($emapData[8] == 'ACCESSORIES')
								{
									$type = 5;
								}
								else if($emapData[8] == 'Laptop')
								{
									$type = 1;
								}
								else if($emapData[8] == 'Mobile')
								{
									$type = 2;
								}
								else if($emapData[8] == 'TABLETS')
								{
									$type = 3;
								}
								else if($emapData[8] == 'SOFTWARE')
								{
									$type = 4;
								}
								else if($emapData[8] == 'AIO')
								{
									$type = 6;
								}
								else if($emapData[8] == 'BACK PACK')
								{
									$type = 7;
								}
								$data1 = array(
								    'i_category'=>$type,
									'i_name' => $emapData[5],
									'descr' =>$emapData[6],
									'storage'=>$emapData[1],
									//'ime_serial' => $emapData[7],
									'date' => date('Y-m-d H:i:s'),
									);
								$this->db->insert('tbl_product', $data1);
								
								
							//}
						
					 }
					 $i++;
				 }
				fclose($file);
				echo "<script> alert('Successfully added');window.location= '".base_url('index.php/Stocklist')."'</script>";
			  }
		}
	}
}?>