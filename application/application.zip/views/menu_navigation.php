 <?php $session_data = $this->session->all_userdata(); $methodname = $this->router->fetch_method();  $classname= $this->router->fetch_class(); $cls_mtd = $classname.'/'.$methodname;
 if($cls_mtd == 'Warehouse_stock')
 {
	 $sales = 'active';
 }
 else
 {
	 $sales  = '';
 }
 ?>
        <!-- START PAGE CONTAINER -->
       
        <div class="page-container">
         <div class="page-sidebar">
                <!-- START X-NAVIGATION -->
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo base_url('index.php/Dashboard'); ?>">ACC</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li>
                    <li class="xn-profile">
                        <!--<a href="#" class="profile-mini">
                            <img src="assets/images/users/avatar.jpg" alt="John Doe"/>
                        </a>-->
                        <div class="profile">
                            <div class="profile-image"><?php /*?><a href="<?php echo base_url('index.php/Dashboard'); ?>">
                                <img  src="<?php echo base_url('assets/img/Final_New.jpg'); ?>" alt="Arrow18"/></a><?php */?>
                                <h2>ACC</h2>
                            </div>
                            <!--style="height:334px;width:375px;"<div class="profile-data">
                                <div class="profile-data-name">John Doe</div>
                                <div class="profile-data-title">Web Developer/Designer</div>
                            </div>
                            <div class="profile-controls">
                                <a href="pages-profile.html" class="profile-control-left"><span class="fa fa-info"></span></a>
                                <a href="pages-messages.html" class="profile-control-right"><span class="fa fa-envelope"></span></a>
                            </div>-->
                        </div>                                                                        
                    </li>
                    
                    <li class="<?php echo active_link('Dashboard');  ?>">
                        <a href="<?php echo base_url('index.php/Dashboard'); ?>"  data-toggle="tooltip" data-placement="right" data-original-title="Dashboard" ><span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span></a>                        
                    </li> 
                  <?php /*?>  <li class="xn-openable <?php echo active_link('Business'); ?>">
                        <a href="#"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Business Management</span></a>
                        <ul>
                        	
                        	<li><a href="<?php echo base_url('index.php/Business'); ?>">Add Leads</a></li>
                              <li><a href="<?php echo base_url('index.php/Business/Assigned_list'); ?>">Leads Assigned List</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo base_url('index.php/Business'); ?>"><span class="fa fa-files-o"></span> <span class="xn-text">Business Management</span></a></li><?php */?>
                  
					<li><a href="<?php echo base_url('index.php/Employee'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Employee"><span class="fa fa-files-o"></span> <span class="xn-text">Employee Management</span></a></li>
                      <li class="xn-openable <?php echo active_link('Location'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Location list"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Unit Details</span></a>
                        <ul>
                        	 <!--  <li><a href="<?php echo base_url('index.php/Location'); ?>">Add Location</a></li>-->
                        	<li><a href="<?php echo base_url('index.php/Location'); ?>">Unit List</a></li>
                        </ul>
                    </li>          
                 <li class="<?php echo active_link('Seller'); ?>">
                        <a href="<?php echo $this->config->item('base_url'); ?>index.php/Seller" data-toggle="tooltip" data-placement="right" data-original-title="Vendor Master"><span class="fa fa-files-o"></span> <span class="xn-text">Vendor Master</span></a>
                    </li>
                    <li class="<?php echo active_link('Storage'); ?>">
                        <a href="<?php echo $this->config->item('base_url'); ?>index.php/Storage" data-toggle="tooltip" data-placement="right" data-original-title="Storage Master"><span class="fa fa-files-o"></span> <span class="xn-text">Storage Master</span></a>
                    </li>
                  <?php /*?> <li class="<?php echo active_link('Customer_master'); ?>">
                        <a href="<?php echo base_url('index.php/Customer_master'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Customer"><span class="fa fa-bar-chart-o"></span> <span class="xn-text">Customer Type</span></a>
                    </li><?php */?>
                    <li class="<?php echo active_link('Customer'); ?>">
                        <a href="<?php echo base_url('index.php/Customer'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Customer"><span class="fa fa-bar-chart-o"></span> <span class="xn-text">Customer Master</span></a>
                    </li>
                      <?php /*?><li class="<?php echo active_link('Protype'); ?>">
                        <a href="<?php echo base_url('index.php/Protype'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Product Type"><span class="fa fa-bar-chart-o"></span> <span class="xn-text">Product Type</span></a>
                    </li><?php */?>
                  <li class="<?php echo active_link('Product'); ?>">
                        <a href="<?php echo base_url('index.php/Product'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Products Master"><span class="fa fa-files-o"></span> <span class="xn-text">Products Master</span></a>
                    </li>
                    <li class="<?php echo active_link('PriceList'); ?>">
                        <a href="<?php echo base_url('index.php/PriceList'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Price List"><span class="fa fa-files-o"></span> <span class="xn-text">Price List</span></a>
                    </li>
                     <?php /*?>
                    <li class="<?php echo active_link('Statutory'); ?>">
                        <a href="<?php echo base_url('index.php/Statutory'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Statutory List"><span class="fa fa-files-o"></span> <span class="xn-text">Statutory List</span></a>
                    </li>
                   <li class="<?php echo active_link('Pos_orders'); ?>">
                        <a href="<?php echo base_url('index.php/Pos_orders'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Purchase list"><span class="fa fa-files-o"></span> <span class="xn-text">Purchase Order</span></a>
                    </li><?php */?>
                   
                    <li class="<?=($cls_mtd=='Stock/index')?'active':''?>">
                        <a href="<?php echo base_url('index.php/Stock'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Goods Received Note"><span class="fa fa-files-o"></span> <span class="xn-text">Goods Received Note</span></a>
                    </li>
                     <li class="<?php echo active_link('Stocklist'); ?>">
                        <a href="<?php echo base_url('index.php/Stocklist'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Stock Summary"><span class="fa fa-files-o"></span> <span class="xn-text">Stock Summary</span></a>
                    </li>
                    <li class="xn-openable <?php echo active_link('Vendor'); ?>">
                        <a href="#"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Vendor Transaction</span></a>
                        <ul>
                        	   <li><a href="<?php echo base_url('index.php/Vendor'); ?>">Vendor Billing</a></li>
                        	<li><a href="<?php echo base_url('index.php/Vendor/paymentlist'); ?>">Vendor Payment List</a></li>
                        </ul>
                    </li>
                    <?php /*?> <li class="<?php echo active_link('Expenses_master'); ?>">
                        <a href="<?php echo base_url('index.php/Expenses_master'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Customer"><span class="fa fa-bar-chart-o"></span> <span class="xn-text">Expenses Master</span></a>
                    </li><?php */?>
                   <?php /*?> <li class="<?php echo active_link('Advance_payment_list'); ?>">
                        <a href="<?php echo base_url('index.php/Advance_payment_list'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Advance Payment Of Customer"><span class="fa fa-file-text-o"></span><span class="xn-text">Advance Payment </span></a>
                    </li><?php */?>
                    <li class="xn-openable <?php echo active_link('Sales'); ?>">
                        <a href="#"><span class="fa fa-file-text-o"></span> <span class="xn-text">Sales & Invoice</span></a>
                        <ul>
                           <li><a href="<?php echo base_url('index.php/Sales'); ?>">Add Sale</a></li>
                            <!--<li><a href="<?php echo base_url('index.php/Sales/sold_list'); ?>">Sales List</a></li>-->
                            <?php /*?><li><a href="<?php echo base_url('index.php/Sales'); ?>">Generate Invoice</a></li><?php */?>
                            <li><a href="<?php echo base_url('index.php/Sales/Invoicelist'); ?>">Invoice List</a></li>
                            <li><a href="<?php echo base_url('index.php/Sales/Paymentlist'); ?>">Invoice Payment List</a></li>
                        </ul>
                    </li>
                    
                    <li class="<?php echo active_link('Reports'); ?>">
                        <a href="#"><span class="fa fa-list"></span> <span class="xn-text">Reports</span></a>
                        <ul>
                        <?php /*?> <li><a href="<?php echo base_url('index.php/Reports/Purchase'); ?>">Goods Received Report</a></li><?php */?>
                            <li><a href="<?php echo base_url('index.php/Reports/stock'); ?>">Stock Summary Report</a></li>
                        	<li><a href="<?php echo base_url('index.php/Reports/sold_list'); ?>">Sales Report</a></li>
                            <?php /*?><li><a href="<?php echo base_url('index.php/Reports/customer'); ?>">Customer History</a></li><?php */?>
                            
                            
                        </ul>
                    </li>
                    
                    
                </ul>
                <!-- END X-NAVIGATION -->
            </div>
            <!-- END PAGE SIDEBAR -->
            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START X-NAVIGATION VERTICAL -->
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <!-- TOGGLE NAVIGATION -->
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>
                    <!-- END TOGGLE NAVIGATION -->
                    <!-- SEARCH -->
                    <?php /*?><li class="xn-search">
                        <form role="form">
                            <input type="text" name="search" placeholder="Search..."/>
                        </form>
                    </li>  <?php */?> 
                    <!-- END SEARCH -->                    
                    <!-- POWER OFF -->
                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-power-off"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="<?php echo base_url('index.php/Dashboard/ProfileSettings_bk'); ?>"><span class="fa fa-lock"></span> Profile Setting</a></li>
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Sign Out</a></li>
                        </ul>                        
                    </li> 
                    <!-- END POWER OFF -->                    

                    <!-- TASKS -->
                    <li class="pull-right" style="color:#fff; font-weight:bold; padding:1.5% 2% 0 0 ">
                        <div class="">Welcome <?php echo $session_data['name']; ?> | 
 (<?php if($session_data['user_type'] == 1){echo "Admin";}else{ echo "user";}; ?>)</span></div>
                    </li>
                    <!-- END TASKS -->
                </ul>
                <!-- END X-NAVIGATION VERTICAL -->   
                   <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <!--<li><a href="#">Home</a></li>                    
                    <li class="active">Dashboard</li>-->
                </ul>
                <!-- END BREADCRUMB -->                 
                