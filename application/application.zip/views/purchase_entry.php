<!DOCTYPE html>
<html lang="en">
<head>
<style>



.forcedWidth{
    width:200px;
    word-wrap:break-word;
    display:inline-block;
}

</style>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    <link type="text/css" href="<?php echo base_url('assets/css/jquery-ui.css'); ?>" rel="stylesheet" />

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2>Purchase Entry</h2>
                </div>
                <!-- END PAGE TITLE --> 
                               
                
                <!-- PAGE CONTENT WRAPPER -->
               <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Purchase/addPurchaseEntry');?>" method="post" >

                <div class="row">
                        <div class="col-md-12">
                           <div class="panel panel-default">
                                <div class="panel-body">
                                    <h3>Add Entry</span></h3>
                               
<div class="panel-body">                                                                        
                                    
<div class="row">
<div class="col-md-6">

   <!-- <div class="form-group">
        <label class="col-md-4 control-label">Purchase Type<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">                                            
            <select class="selectpicker form-control " name="purchase_type"   required id="purchase_type" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true" >
                <option value=""  selected > SELECT </option>
                <option value="2"   >Self</option>
                <option value="1"   >Vendor</option>
                <option value="3"   >Agent</option>
                <option value="4"   >Auction</option>
            </select>
            <div class="error" ><?php echo form_error('purchase_type'); ?></div>                                       
        </div>
    </div>-->
    <div class="form-group">
        <label class="col-md-4 control-label">Vendor Name<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
            <select class="selectpicker form-control "    name="vname" id="vname" required data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                    <option value="" disabled selected> SELECT </option>
                   	<?php foreach($seller as $row){ ?>	
                                    <option value="<?php echo $row->cid; ?>"><?php echo $row->seller_name; ?></option>
                            <?php } ?>
                            </select>
            <div class="error" ><?php echo form_error('vname'); ?></div>                                       
        </div>
    </div>
    
    <!--<div class="form-group">
    <label class="col-md-4 control-label">Account</label>
    <div class="col-md-8">
    <?php $cust = $this->db->select('*')->get('cb_customer')->result_array(); ?>          
       <select class="selectpicker form-control " name="customer"   required id="customer" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true" >
       <?php foreach($cust as $cust_det)  { ?>
       <option value="<?=$cust_det['cid']?>"><?=$cust_det['customer_name']?></option>
       <?php } ?>
        </select><div class="error" ><?php echo form_error('customer'); ?></div>                                       
    </div>
</div>-->
                                            
     <div class="form-group">                                        
        <label class="col-md-4 control-label">Date of Purchase</label>
        <div class="col-md-8">
            <input type="text" class="form-control datepicker "  required placeholder="Enter Date of Purchase" name="pdate" id="pdate" value="<?php echo date("Y-m-d");  ?>">
            <div class="error" ><?php echo form_error('pdate'); ?></div>                                               
        </div>
    </div>
           <!--<div class="form-group">                                        
                                                <label class="col-md-4 control-label">Warranty Start Date<sup  style="color:#f00">*</sup></label>
                                                <div class="col-md-8">
                                                  <input type="text" name="maintanance_str_date" placeholder="SELECT WARRANTY START DATE" id="maintanance_str_date" class="form-control  datepickerr" /> 
                                                  <div class="error" ><?php echo form_error('maintanance_str_date'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Warranty Exp Date<sup  style="color:#f00">*</sup></label>
                                                <div class="col-md-8">
                                                  <input type="text" name="maintanance_exp_date" placeholder="SELECT WARRANTY EXP DATE" id="maintanance_exp_date" class="form-control  datepickerr" /> 
                                                  <div class="error" ><?php echo form_error('street_name'); ?></div>                                               
                                                </div>
                                            </div>-->
    <div class="form-group">                                        
        <label class="col-md-4 control-label">Invoice No<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
            <input type="text"   class="form-control  " required placeholder="Enter Invoice No"  name="vinvno" id="vinvno" value="<?php echo set_value('vinvno');  ?>">
            <div class="error" ><?php echo form_error('vinvno'); ?></div>                                               
        </div>
    </div>
  <?php /*?><div class="form-group minqty" >
        <label class="col-md-4 control-label">Minimum Quantity</label>  
        <div class="col-md-8">
       <input type="number" class="form-control " placeholder="Enter Product Quantity" name="minqty" id="minqty" />
        </div>
    </div><?php */?>
    

</div>
<div class="col-md-6">
  <?php /*?><div class="form-group maxqty" >
        <label class="col-md-4 control-label">Maximum Quantity</label>  
        <div class="col-md-8">
        <input type="number" class="form-control " placeholder="Enter Product Quantity" name="maxqty" id="maxqty" />
        </div>
    </div><?php */?>
    <div class="form-group">
        <label class="col-md-4 control-label">Remarks</label>  
        <div class="col-md-8">
            <input type="text" class="form-control " placeholder="Enter Remarks" name="remarks" id="phone1" value="<?php echo set_value('remarks');  ?>"/>
          <div class="error" ><?php echo form_error('remarks'); ?></div>	
        </div>
    </div>
   
    <?php /*?><div class="form-group">
        <label class="col-md-4 control-label">VAT</label>  
        <div class="col-md-8">
            <input type="text" class="form-control groupOfTexbox" onchange="totalamt(1); " placeholder="Enter VAT" name="vat" id="vat" onchange="gtotal1();"  value="<?php echo set_value('vat');  ?>" />
          <div class="error" ><?php echo form_error('vat'); ?></div>
        </div>
    </div><?php */?>
    
  <div class="form-group">
        <label class="col-md-4 control-label">Storage Name<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
         <input type="text" class="form-control " placeholder="Enter storage" name="storage" value="" />
            
            <div class="error" ><?php echo form_error('vname'); ?></div>                                       
        </div>
    </div>
    <?php /*?><!--<div class="form-group">                                        
                                                <label class="col-md-4 control-label">SM Date 1<sup  style="color:#f00">*</sup></label>
                                                <div class="col-md-8">
                                              <input type="text" name="date1" placeholder="SELECT DATE 1" id="date1" class="form-control datepickerr"  /> 
                                                  <div class="error" ><?php echo form_error('street_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">SM Date 2<sup  style="color:#f00">*</sup></label>
                                                <div class="col-md-8">
                                                  <input type="text" name="date2"  placeholder="SELECT DATE 2" id="date2" class="form-control datepickerr" /> 
                                                  <div class="error" ><?php echo form_error('street_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">SM Date 3<sup  style="color:#f00">*</sup></label>
                                                <div class="col-md-8">
                                                  <input type="text"  name="date3" placeholder="SELECT DATE 3" id="date3" class="form-control datepickerr" /> 
                                                  <div class="error" ><?php echo form_error('street_name'); ?>
                                                  </div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">SM Date 4<sup  style="color:#f00">*</sup></label>
                                                <div class="col-md-8">
                                                  <input type="text"  name="date4" placeholder="SELECT DATE 4" id="date4" class="form-control datepickerr" /> 
                                                  <div class="error" ><?php echo form_error('street_name'); ?></div>                                               
                                                </div>
                                            </div>-->
   <!-- <div class="form-group">
        <label class="col-md-4 control-label">FOC Inward<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
            <select class="selectpicker form-control "    name="foc" id="foc" required data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                    <option value="0">NO</option>
                                    <option value="1">YES</option>
                            </select>
            <div class="error" ><?php echo form_error('vname'); ?></div>                                       
        </div>--><?php */?>
    </div>
</div>
</div>

    </div>
                                
                           
                            
                            
                            
                			</div>
                            </div>
                       
						 <div class="col-md-12">
							
                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                          
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table" id="mytable">
                                            <thead>
                                                <tr>
                                                    <th width="7%">Unit Type<sup style="color:#f00"> * </sup></th>
                                                    <th width="14%">Product<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">SGST%<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">CGST%<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">IGST%<sup  style="color:#f00"> * </sup></th>
                                                    <th width="7%">Pur.Rate<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">Qty<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">SGST Amt<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">CGST Amt<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">IGST Amt<sup  style="color:#f00"> * </sup></th>

                                                    <th width="10%">Total</th>
                                                </tr>
											</thead>
        <tbody id="testid">

            <tr>
             <td >
                                             <select  class="selectpicker form-control "  name="unit[]" id="unit1"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"> <option value="" disabled selected>Select</option>       <?php foreach($unit as $row){?><option value="<?php echo $row->id; ?>"><?php echo $row->location_name; ?></option><?php }?></select>
                                               </td>

                                           <td class="forcedWidth">
          <select  class="selectpicker form-control itemsq2"  name="item_name1[]" id="item_name1_1"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"> <option value="" disabled selected>Select</option>       <?php foreach($item as $row){?><option value="<?php echo $row->i_id; ?>"><?php echo $row->i_name; ?></option><?php }?></select>
         
                </td>
                 <td><input  type="text" required class="form-control  groupOfTexbox" name="sgst[]" id="sgst1" onchange="totalamt(1); "  value="0"  required/> </td>
                 <td><input   type="text" required class="form-control  groupOfTexbox" name="cgst[]" id="cgst1" onchange="totalamt(1); " value="0"   required/> </td>
                 <td><input   type="text" required class="form-control  groupOfTexbox" name="igst[]" id="igst1" onchange="totalamt(1); " value="0"   required/> </td>
                   
                    <td><input min="0"  type="text" step="any" class="form-control  groupOfTexbox" name="purrate[]" id="purrate1" onchange="totalamt(1); "  required/></td>
                   
                    <td><input min="0"  type="text" required class="form-control  groupOfTexbox" name="qty[]" id="qty1" onchange="totalamt(1); "   required/> </td>
                    
                    <td><input  type="text" required class="form-control  groupOfTexbox" name="sgst_amt[]" id="sgst_amt1"    readonly/> </td>
                    <td><input   type="text" required class="form-control  groupOfTexbox" name="cgst_amt[]" id="cgst_amt1"    readonly/> </td>
                    <td><input   type="text" required class="form-control  groupOfTexbox" name="igst_amt[]" id="igst_amt1"    readonly/> </td>
                    <td><input   type="text" step="any" class="form-control " name="total[]" id="total1"  required readonly/></td>
            </tr>

        </tbody>
                                        </table><br>
<br>
<br>

                                        <table class="table" width="100%">
    <thead>
        <!--<tr>
            <td colspan="9" width="70%"></td>
            <td style="font-weight:bold;">Additional Charges</td>
            <td style="font-weight:bold;" width="15%"><input type="text" class="form-control groupOfTexbox" name="adcharges"   value="0.00" style="color:#000"  id="adcharges" onchange="totalamt(1); "></td>
        </tr>
        <tr>
            <td colspan="9" ></td>
            <td style="font-weight:bold;">Discount</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control groupOfTexbox" name="discount" style="color:#000"   onchange="totalamt(1); "  id="discount" value="0.00"></td>
        </tr>
        <tr>
            <td colspan="9" ></td>
            <td style="font-weight:bold;">Insurance</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control groupOfTexbox" name="insurance" value="0.00" style="color:#000"   id="insurance"  onchange="gtotal1();"></td>
        </tr>
        <tr>
            <td colspan="9" ></td>
            <td style="font-weight:bold;">Transportation Charges</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control groupOfTexbox" name="trans_charge" value="0.00" style="color:#000"   id="trans_charge"  onchange="gtotal1();"></td>
        </tr>
        <tr>
            <td colspan="9" ></td>
            <td style="font-weight:bold;">Custom Duty</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control groupOfTexbox" name="customduty" value="0.00" style="color:#000"   id="customduty"  onchange="gtotal1();"></td>
        </tr>-->
        <tr>
            <td colspan="9" width="75%"><button type="button" style="visibility:hidden;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="opener" ></button></td>
            <td style="font-weight:bold;" width="12%">Total</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control" name="stotal" style="color:#000" readonly id="stotal"></td>
        </tr>
       <?php /*?> <tr>
             <td colspan="9" width="75%"><button type="button" style="visibility:hidden;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="opener" ></button></td>
            <td style="font-weight:bold;" width="12%">Tax Amount</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control" name="taxamount" style="color:#000" readonly id="taxamount"></td>
        </tr><?php */?>
        <tr>
            <td colspan="9" width="75%"><button type="button" style="visibility:hidden;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="opener" ></button></td>
            <td style="font-weight:bold;" width="12%">Grand Total</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control" readonly name="gtotal" style="color:#000" id="gtotal"></td>
        </tr>
        
                                </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

							<input type="hidden" name="testno" id="testno" value="2"  />
							<input type="hidden" name="extratax" id="extratax" value="" />
							     <div class="panel-footer">                            
                                    <button class="btn btn-primary pull-left" type="button" style="margin-bottom:20px;" onclick="fnadd()">Add More</button>
                                    <button class="btn btn-warning pull-left" type="button" style="margin-bottom:20px;margin-left:10px;" onclick="fnremove()">Remove</button>       
                                    <input class="btn btn-danger pull-right" value="Back" onClick="window.history.go(-1)" type="button">                              
                                    <button class="btn btn-primary pull-right" type="submit"  style="margin-bottom:20px;" >Submit</button>
									
                                </div>
                                
                                
                          
						  
                        </div>
                  

					   </div>
					
					</form>
					</div>
                


                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
		

					
					
					
					<!-- Button trigger modal -->


<!-- Modal -->



        <!-- END PAGE CONTAINER -->
          <?php $this->load->view('include_js'); ?>
		 
<script type="text/javascript">


	  
	
	//Short menu navigation code//
	function fnadd() 
		{
			var supplier_id=$('#vname').val();
			//alert(supplier_id);
			//if(supplier_id != '') {					
				var a=$("#testno").val();
				num=parseInt(a) + 1;
				$("#testno").val(num);
				//alert('kaja');
				
				var inn=$("#payment_method_1").html();
				var inn=$("#item_name_1").html();
				$("#testid").append('<tr><td ><select  class="selectpicker form-control "  name="unit[]" id="unit'+a+'"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"><option value="" disabled selected>Select</option><?php foreach($unit as $row){?><option value="<?php echo $row->id; ?>"><?php echo $row->location_name; ?></option><?php } ?></select></td>'
		+'<td class="forcedWidth"><select  class="selectpicker form-control itemsq2 "  name="item_name1[]" id="item_name1_'+a+'"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"><option value="" disabled selected>Select</option><?php foreach($item as $row){?><option value="<?php echo $row->i_id; ?>"><?php echo $row->i_name; ?></option><?php } ?></select></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="sgst[]" id="sgst'+a+'" value="0"  onblur="totalamt('+a+'); " required /></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="cgst[]" id="cgst'+a+'" value="0"   onblur="totalamt('+a+'); " required /></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="igst[]" id="igst'+a+'" value="0"   onblur="totalamt('+a+'); " required /></td>'
				+'<td><input min="0"  type="text" step="any" class="form-control  groupOfTexbox" name="purrate[]" id="purrate'+a+'" onblur="totalamt('+a+'); "  required/></td>'
				+'<td style="display:none"><input min="0"  type="text" step="any" class="form-control  groupOfTexbox" name="selprice[]" id="selprice'+a+'"  /></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="qty[]" id="qty'+a+'"  onblur="totalamt('+a+'); " required /></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="sgst_amt[]" id="sgst_amt'+a+'"  readonly required /></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="cgst_amt[]" id="cgst_amt'+a+'"  readonly required /></td>'
				+'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="igst_amt[]" id="igst_amt'+a+'"  readonly required /></td>'
				+''
				+'<td><input min="0"  type="text" step="any" class="form-control " name="total[]" id="total'+a+'" required readonly/></td></tr>');
				
				$(".selectpicker").selectpicker('refresh');
				$(".groupOfTexbox").keypress(function (event) {
		 			   return isNumber(event, this)
				}); 
				
			/*}
			else {
				alert("Select Supplier");
			}*/
		}
		function fnremove() 
		{
			var a=$("#testno").val();
			if(a>=3){
				
				num=parseInt(a) - 1;
				$("#testno").val(num);
				$('#mytable tr:eq('+num+')').remove();
			}
		}		
		
		
		
		
    function totalamt(item){
        var purrate=parseFloat($('#purrate'+item).val());
        var qty=parseFloat($('#qty'+item).val());
	    var sgst=parseFloat($('#sgst'+item).val());
		var cgst=parseFloat($('#cgst'+item).val());
		var igst=parseFloat($('#igst'+item).val());
        if(!isNaN(purrate) && !isNaN(qty) && qty!=0){
        //	var tax=(parseFloat(purrate)/100)*parseFloat(purtax);
        //	var total=(parseFloat(purrate)+parseFloat(tax))*parseFloat(qty);					
                var total=(parseFloat(purrate))*parseFloat(qty);
				var sgstamt  = parseFloat(( total * parseFloat(sgst))/100);
				var cgstamt  = parseFloat(( total * parseFloat(cgst))/100);
				var igstamt  = parseFloat(( total * parseFloat(igst))/100);
				
				$("#sgst_amt"+item).val(sgstamt);
				$("#cgst_amt"+item).val(cgstamt);
				$("#igst_amt"+item).val(igstamt);
				
				gtotal = parseFloat(total+sgstamt+cgstamt+igstamt);
				if(isNaN(total)){ } else {
                    $("#total"+item).val(gtotal);
                    gtotal1();
                }
        }else{
                $("#total"+item).val("");
        }


    }

    function gtotal1(){
        var a=$("#testno").val();
        a=a-1;
        var gt=0;
		 var gt1=0;
        for(i=1;i<=a;i++){
			var purrate=parseFloat($('#purrate'+i).val());
        	var qty=parseFloat($('#qty'+i).val());
	        var sgst=parseFloat($('#sgst'+i).val());
		    var cgst=parseFloat($('#cgst'+i).val());
		    var igst=parseFloat($('#igst'+i).val());
			
	   		var total=(parseFloat(purrate))*parseFloat(qty);
			var sgstamt  = parseFloat(( total * parseFloat(sgst))/100);
			var cgstamt  = parseFloat(( total * parseFloat(cgst))/100);
			var igstamt  = parseFloat(( total * parseFloat(igst))/100);
			//var taxamt  = parseFloat(( total * parseFloat(vat))/100);
               // var total=$('#total'+i).val();
			   var gt=parseFloat(gt)+parseFloat(total);
				var gt1=parseFloat(gt1)+parseFloat(sgstamt)+parseFloat(cgstamt)+parseFloat(igstamt);
                
        }
       
		var stotal = gt;
		var gtot = gt1;
        //alert(stotal);
		if(stotal == '')
			{
				stotal = '00.00';
			}
        
        if(stotal!=''){
            $("#stotal").val(stotal);
            
				//$("#taxamount").val(taxamt);
				gtotal = parseFloat(stotal+gtot);
				
				
					$("#gtotal").val(parseFloat(gtotal).toFixed(2));
					
			}
            




        else{
            $("#stotal").val('00.00');
            $("#taxamount").val('00.00');
            $("#gtotal").val('00.00');
        }
    }
                
		
</script>
<script type="text/javascript">

$(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
  

$(document).on('change','.itemsq',function()
{
		var cus = $(this).val();
		var id= $(this).attr('id');
		sid = id.split('_');
		id = sid[2];
	//alert(id);
	if(cus!='')
	{
		$.ajax(
		{
			url:'<?php echo base_url('index.php/Purchase/get_pro_det');?>',
			type:'POST',
			data:{cus:cus},
			success: function(result)
			{
				var obj = jQuery.parseJSON(result);
				//alert('obj');
				/*if(obj.minqty != '')
				{*/
					$('#minqty_'+id).val(obj.minqty);
					$('#maxqty_'+id).val(obj.maxqty);
				/*}*/
				
				
			}
		});
	}
});
$(document).on('change','.itemsq2',function()
{
	
	    var id= $(this).attr('id');
		sid = id.split('_');
		id = sid[2];
		var cus = $(this).val();
	//alert(id);
	if(cus!='')
	{
		$.ajax(
		{
			url:'<?php echo base_url('index.php/Purchase/get_pro_det');?>',
			type:'POST',
			data:{cus:cus},
			success: function(result)
			{
				var obj = jQuery.parseJSON(result);
				//alert('obj');
				if(obj.minqty != '')
				{
					$('#minqty_'+id).val(obj.minqty);
					$('#maxqty_'+id).val(obj.maxqty);
				}
				
				
			}
		});
	}
});

</script>
	 
</body>
</html>
   


