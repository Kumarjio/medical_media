<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2>Manage Product</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading"> 
                                
                                                    <a href="<?php echo base_url('index.php/Product/productadd'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Add Product</button></a>
                                                              
                                </div>
                                <div class="panel-body">
<div class="table-responsive">
    <table class="table datatable">
    <thead>
        <tr>
            <th width="37">S. No</th>
             <th width="80">Product Id</th>
             <th width="58">Unit Type</th>
            <th width="80">Product Name</th>
            <th width="105">Product Description</th>
            
            
            
            <?php /*?> <th width="58">Amount</th>
           <th width="42">Status</th><?php */?>
            
                                                    <th>Action</th>
                                                    
        </tr>
    </thead>
        <tbody>
            <?php
                $sno=1;
                                            if(is_array($product) && count($product) ) {
                                                    foreach($product as $loop){
                                                            ?>
            <tr>
                    <td><?php echo $sno++; ?></td>
                     <td><?php echo 'PRO00'.$loop->i_id; ?></td>
                    
                   <?php /*?> <td><?php echo $loop->i_code; ?></td>
                    <td><?=($loop->i_category==1)?'Laptop':'Mobile'; ?></td><?php */?>
                    <td><?php echo $loop->i_category?>
                                                         </td>
                    <?php /*?><td><?php if($loop->i_category == '1')
												{
													echo 'Laptop';
												}
												else if($loop->i_category == '2')
												{
													echo 'Mobile';
												}
												else if($loop->i_category == '3')
												{
													echo 'TABLETS';
												}
												else if($loop->i_category == '4')
												{
													echo 'SOFTWARE';
												}
												else if($loop->i_category == '5')
												{
													echo 'ACCESSORIES';
												}
												
												?></td><?php */?>
                                                <td><?php echo $loop->i_name; ?> </td>
                                                <td><?=$loop->descr?></td>
                                                
                                                
                    <td>
            <a href="<?php echo base_url('index.php/Product/viewproduct/'.$loop->i_id); ?>"><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><span class="fa fa-eye"></span></button></a>
           
                                                  
                                                 <a href="<?php echo base_url('index.php/Product/editproduct/'.$loop->i_id);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
                                                 
                                               
            
           
           
            </td>

            </tr>
                                                    <?php }} ?>
        </tbody>
    </table>
</div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
     
<script type="text/javascript">
	function fndelete(id) {
		var deletopt=confirm('Are you sure, do you want to delete this record?');
	  	if(deletopt)  {
			window.location =  '<?php echo base_url('index.php/Product/deleteproduct/')?>/'+id;
		    return true;
	  	}  else  {
		  	return false;
	  	}
	}
</script>
<script>
function chStatus(id,st){
		if(st == 1) {
		var chst = 0; //change status value
		}
		else {
		var chst = 1;	
		}
	//alert(chst);	
		jQuery.ajax({
			type: "POST",
			url: "<?php echo base_url(); ?>" + "index.php/Product/statuschange",
			dataType: 'json',
			data: {id: id, st: chst},
			success: function(res) {
			if(res == 0) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			if(res == 1) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			
				//console.log(res);
				
			}
		});
}


	<!------------------------Status Activate End----------------------------!>

	
</script>
</body>
</html>