<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3>Add Vendor</h3>
                            
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Seller/addSeller');?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">										
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Vendor Name<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="seller_name"  placeholder="Enter Company Name" required id="seller_name" value="<?php echo set_value('seller_name');  ?>">
                                                    <div class="error" ><?php echo form_error('seller_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <?php /*?><div class="form-group">                                        
                                                <label class="col-md-4 control-label">Area Name<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control " name="area_name"  placeholder="Enter Area Name"  id="customer_name" value="<?php echo set_value('area_name');  ?>">
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div><?php */?>
                                            											
                                           
											<div class="form-group">                                        
                                                <label class="col-md-4 control-label">Location<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                <input type="text" class="form-control "  name="Location"  placeholder="Enter Location Name" required id="seller_name" value="<?php echo set_value('Location');  ?>">
                                                 <?php /*?><?php $loc = $this->db->select('*')->get('master_location')->result_array(); ?>
                                                	<select class="form-control select align-left" name="Location" required id="Location">
                                                    <option disabled selected value="">Select Location</option> 
													<?php foreach($head as $locval)
                                                    { ?>
                                                        <option value="<?=$locval->location_name?>" ><?=$locval->location_name?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                    </select><?php */?>
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Address<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="city_name"  placeholder="Enter Address" required id="customer_name" value="<?php echo set_value('city_name');  ?>">
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">State<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="state_name"  placeholder="Enter State Name" required id="customer_name">
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Country<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="country_name"  placeholder="Enter Country Name" required id="customer_name" value="<?php echo set_value('country_name');  ?>">
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Zip Code<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="pincode"  placeholder="Enter Zipcode" id="customer_name" required value="<?php echo set_value('pincode');  ?>">
                                                    <div class="error" ><?php echo form_error('pincode'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                      </div>
                                        <div class="col-md-6">
                                        <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Tin No<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="tin_no"  placeholder="Enter Tin No" required id="tin_no">
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">CST No<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="cst_no"  placeholder="Enter CST No" required id="cst_no">
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                        <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Service Tax<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="service_tax"  placeholder="Enter Service Tax" required id="service_tax" >
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>                                            											
                                           
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Tele Phone<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control "  name="telephone"  placeholder="Enter Tele Phone" required id="telephone" value="<?php echo set_value('telephone');  ?>">
                                                    <div class="error" ><?php echo form_error('telephone'); ?></div>                                               
                                                </div>
                                            </div> 	
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Email<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" required class="form-control"  name="email"  placeholder="Enter Email" id="email" value="<?php echo set_value('email');  ?>">
                                                    <div class="error" ><?php echo form_error('email'); ?></div>                                               
                                                </div>
                                            </div>	
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Credit Days<sup style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="number" required class="form-control"  name="days"  placeholder="Enter Total Credit Days" id="days" >
                                               </div>
                                            </div>
                                            											
                                           <?php /*?><div class="form-group">
                                            <label class="col-md-4 control-label">Joining Date<sup  style="color:#f00"> * </sup>  </label>  
                                            <div class="col-md-8">
                                             <div class="input-group">
                                             <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                <input type="text" class="mask_date form-control  datepicker"  placeholder="Enter Joining Date" name="joining_date" id="joining_date" value="<?php if(set_value('joining_date')!="") { echo set_value('joining_date'); }else { echo date("Y-m-d"); }  ?>"/>
                                              <div class="error" ><?php echo form_error('joining_date'); ?></div>
                                              </div>

                                            </div>
                                        </div><?php */?>


                                    </div> 
            
                                </div>
                                        
                                      </div>
                                    
                                    
                                    <div class="row">
                                        <div class="form-group pull-right">
                                        <div class="btn-group pull-right col-md-12"> <input class="btn btn-danger pull-right" value="Back" onClick="window.history.go(-1)" type="button"><input class="btn btn-primary" value="Submit" type="submit" name="submit">
                                        </div>    
                                    </div>

                                    </div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

