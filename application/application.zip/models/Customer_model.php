<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_all_customer(){
		$session_data = $this->session->all_userdata();	
		
		$this->db->select('cb_customer.*');
		//$this->db->select('cp_admin_login.*');
	   if($session_data['location'] !=  'Chennai')
		    {
				$this->db->where('cb_customer.location',$session_data['location']);
			}
		//$this->db->join('cp_admin_login','cp_admin_login.area_name = cb_customer.location','left');
		$this->db->order_by('cid','desc');			
        $query = $this->db->get('cb_customer');	
		//echo $this->db->last_query();exit;
		return $query->result();			
	 }
	 
	
	
	 function add_customer($post) {
		 extract($_REQUEST);
		 $session_data = $this->session->all_userdata();	
		 //echo '<pre>';print_r($session_data); exit;
		$created_date=date('Y-m-d h:i:s');
		$get_loc = $this->db->select('*')->where('admin_id',$session_data['user_id'])->get('cp_admin_login')->result_array();
		$array=array(
		'customer_name'=>$customer_name,
		'mob_no1'=>$mob_no1,
		'landline_no'=>$land_no,
		//'customer_type' => $cus_type,
		'email_id'	=>$email,
		'area_name'=>$area_name,
		'city_name'=>$city_name,
		'state_name'=>$state_name,
		'credit_days'=>$days,
		'country_name'=>$country_name,
		'pincode'=>$pincode,
		'created_date'=>$created_date,
		'location'=>$get_loc[0]['area_name'],);	
		 $this->db->insert('cb_customer',$array);
		
			
	}
	 
	 
	  function view_customer($id){	
		$array = array('cid' => $id);		
		$this->db->select('*')->from('cb_customer')
        ->where($array); 
		$query = $this->db->get();
				
		return $query->result();	
		$this->output->enable_profiler(true);		
	 }
	
	function edit_customer($id){	
		$array = array('cid' => $id);		
		$this->db->select('*')->from('cb_customer')
         ->where($array); 
		$query = $this->db->get();		
		return $query->result();			
	 }
	
	
	function update_customer($id,$post) {
	    
	extract($_REQUEST);
	$session_data = $this->session->all_userdata();	
		$created_date=date('Y-m-d h:i:s');
		$get_loc = $this->db->select('*')->where('admin_id',$session_data['user_id'])->get('cp_admin_login')->result_array();
		$array=array(
		'customer_name'=>$customer_name,
		'mob_no1'=>$mobile1,
		'landline_no'=>$land,
		//'customer_type' => $cus_type,
		'email_id'	=>$email,
		'area_name'=>$area_name,
		'city_name'=>$city_name,
		'state_name'=>$state_name,
		'country_name'=>$country_name,
		'pincode'=>$pincode,
		'credit_days'=>$days,
		'created_date'=>$created_date,
		'location'=>$get_loc[0]['area_name']);	

		$this->db->set($array);
	    $this->db->where('cid',$id);
		//$this->db->last_query();exit;
		$this->db->update('cb_customer',$array);
		
	}
  
	public function delete_customer($id)
	{
		
	    $this->db->where('cid',$id);
		$this->db->delete('cb_customer');	
		return true;
	}

}