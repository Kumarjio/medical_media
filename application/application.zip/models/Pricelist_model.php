<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pricelist_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_prices(){
		$this->db->select('tbl_pricelist.*');
		$this->db->select('tbl_product.*');
		$this->db->join('tbl_product','tbl_product.i_id=tbl_pricelist.po_id','left');
		//$this->db->order_by('id','desc');		
		//$this->db->where('is_delete =', 0);
        $query = $this->db->get('tbl_pricelist');	
		return $query->result();			
	 }
	 function add_price($post) {
		//echo '<pre>'; print_r($post);exit;
            extract($_REQUEST);
			
			
		  
				$arr = array(
				'po_id'=>$pname1,
				'price'=>$price,
				'created_date'=>date('Y-m-d H:i:s'),
				);
				$this->db->insert('tbl_pricelist',$arr);
				 $insert_id = $this->db->insert_id();
		 
			
	 
				   
			 return $insert_id;
			
           
        }
	  function get_product()
	  {
		 $this->db->select('tbl_product.*');
		 //$this->db->group_by('i_name','desc');
		//$this->db->where('tbl_product.i_category', $inps['cus']);	
		$query = $this->db->get('tbl_product')->result_array();
		 //echo $this->db->last_query();
		 return $query;
		 			
	  }
	  function get_pro_rows($inps){
			$session_data = $this->session->all_userdata();	
		//$this->db->select('purchase_product.*');
		$this->db->select('tbl_product.*');
		$this->db->where('tbl_product.i_category',$inps['cus']);
		//$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		//$this->db->from('tbl_product');
        $query = $this->db->get('tbl_product');	
		return $query->result_array();			
	 }	

 function get_storage()
      {
		 $this->db->select('*')->from('cb_storage');
		 $query = $this->db->get();		
         return $query->result();			
	 }
	  
}