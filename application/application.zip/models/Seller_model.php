<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Seller_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_all_seller(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('cb_seller');	
		 $this->db->order_by('cid','desc');		
        $query = $this->db->get();		
		return $query->result();			
	 }
	 
	
	
	 function add_seller($post) {
		 extract($_REQUEST);
		 $session_data = $this->session->all_userdata();	
		$created_date=date('Y-m-d h:i:s');
		
		$array=array(
		'tin_no'=>$tin_no,
		'cst_no'=>$cst_no,
		'service_tax'=>$service_tax,
		'seller_name'=>$seller_name,
		//'area_name'=>$area_name,
		'city_name'=>$city_name,
		'state_name'=>$state_name,
		'country_name'=>$country_name,
		'pincode'=>$pincode,
		'telephone'=>$telephone,
		'email'=>$email,
		'vendor_location'=>$Location,
		'credit_days'=>$days,
		'created_date'=>$created_date);	
	    $this->db->insert('cb_seller',$array);
		$last_id = $this->db->insert_id();
			
	}
	 
	 
	  function view_seller($id){	
		$array = array('cid' => $id);		
		$this->db->select('*')->from('cb_seller')
        ->where($array); 
		$query = $this->db->get();
				
		return $query->result();	
		$this->output->enable_profiler(true);		
	 }
	
	function edit_seller($id){	
		$array = array('cid' => $id);		
		$this->db->select('*')->from('cb_seller')
         ->where($array); 
		$query = $this->db->get();		
		return $query->result();			
	 }
	
	
	function update_seller($id,$post) {
	    
	extract($_REQUEST);
		$created_date=date('Y-m-d h:i:s');
		
		$array=array(
		'seller_name'=>$seller_name,
		//'area_name'=>$area_name,
		'city_name'=>$city_name,
		'state_name'=>$state_name,
		'country_name'=>$country_name,
		'pincode'=>$pincode,
		'telephone'=>$telephone,
		'email'=>$email,
		'credit_days'=>$days,
		'vendor_location'=>$Location,
		'created_date'=>$created_date,
		'tin_no'=>$tin_no,
		'cst_no'=>$cst_no,
		'service_tax'=>$service_tax,
		);	

		$this->db->set($array);
	    $this->db->where('cid',$id);
		$this->db->update('cb_seller',$array);
		
	}
  
	

}