<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Warehouse_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }

		function get_trimming()
		{
	    $session_data = $this->session->all_userdata();	
		$this->db->select('trimming_warehouse.*');
		$this->db->from('trimming_warehouse');
        $query = $this->db->get();	
		return $query->result();			
	 }	
	 function get_finished_goods()
	 {
	    $session_data = $this->session->all_userdata();	
		$this->db->select('finished_goods_warehouse.*');
		$this->db->from('finished_goods_warehouse');
        $query = $this->db->get();	
		return $query->result();			
	 }	
	 function get_inspection()
	 {
	    $session_data = $this->session->all_userdata();	
		$this->db->select('inspection_warehouse.*');
		$this->db->from('inspection_warehouse');
        $query = $this->db->get();
		return $query->result();	
	 }
			
	function get_rejection()
	 {
	    $session_data = $this->session->all_userdata();	
		$this->db->select('rejection_warehouse.*');
		$this->db->from('rejection_warehouse');
        $query = $this->db->get();	
		return $query->result();			
	 		
	 }
	 function get_po_diff_detsss()
	 {
	 $this->db->select('tbl_leads.*,finished_goods_warehouse.part_no as pono,finished_goods_warehouse.qty as quantity');
		 if(isset($inps['pono']) && $inps['pono']!='')
		    {
			    $this->db->where('tbl_leads.po_no', $inps['pono']);	
		    }
		 //$this->db->where('finished_goods_warehouse.part_no');
		 $this->db->join('finished_goods_warehouse','finished_goods_warehouse.part_no = tbl_leads.part_no','left');
		$this->db->order_by('tbl_leads.id','desc');
		$query = $this->db->get('tbl_leads')->result_array();
		 return $query;
	 }	
 }