<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Item_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_items(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_item');
		$this->db->where('is_delete =', 0);
        $query = $this->db->get();	
		return $query->result();			
	 }
	  function get_items_drop(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_item');
		$this->db->where('is_delete =', 0);
		$this->db->where('status =', 1);
        $query = $this->db->get();	
		return $query->result();			
	 }
	 
	  function get_rows_item(){
		$this->db->select('i_id')->from('tbl_item')->order_by('i_id','DESC')->limit('1');
        $query = $this->db->get();		
		return $query->result();			
		// $this->db->insert_id();
	 }
	 
	 function add_item($post) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post item details
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_category'=>$i_category,'i_name'=>strtoupper($i_name),'i_code'=>strtoupper($i_code),'m_code'=>strtoupper($m_code),'fixed_rate'=>$fixed_rate,'m_date'=>$m_date,'packing'=>strtoupper($packing),'exp_date'=>$exp_date,'s_price'=>$s_price,'p_rate'=>$p_rate,'p_tax'=>$p_tax,'offer'=>strtoupper($offer),'combination'=>strtoupper($combination),'min_qty'=>$min_qty,'max_qty'=>$max_qty,/*'batch_no'=>strtoupper($batch_no),*/'mrp'=>$mrp,'s_tax'=>$s_tax,'date'=>$created_date,'status'=>1);	
	    $this->db->set($array);
	    $this->db->insert('tbl_item',$array);
	}
	
	
 
	function view_item($id){
		/*SELECT `tbl_tax`.t_code AS tcode,`tbl_tax_1`.t_code AS tcode1,`tbl_item`.*
FROM
    `tbl_item`
    INNER JOIN `tbl_tax` 
        ON (`tbl_item`.`p_tax` = `tbl_tax`.`t_id`)
    INNER JOIN `tbl_tax` AS `tbl_tax_1`
        ON (`tbl_item`.`s_tax` = `tbl_tax_1`.`t_id`);
*/
		$this->db->select('tbl_item.*, tbl_packing.pk_type, `tbl_tax`.percentage AS percentage, tbl_tax_1`.percentage AS percentage1, tbl_category.ct_name, tbl_manufacturer.m_name');
		$this->db->from('tbl_item');
		$this->db->join('tbl_packing', 'tbl_packing.pk_id = tbl_item.packing', 'left');
		$this->db->join('tbl_tax as tbl_tax', 'tbl_tax.t_id = tbl_item.p_tax', 'left');
		$this->db->join('tbl_tax as tbl_tax_1' , 'tbl_tax_1.t_id = tbl_item.s_tax', 'left');
		$this->db->join('tbl_category', 'tbl_category.ct_id = tbl_item.i_category', 'left');
		$this->db->join('tbl_manufacturer', 'tbl_manufacturer.m_id = tbl_item.m_code', 'left');
		$this->db->where('i_id =', $id);
		
		//echo $this->db->last_query();
		//$this->output->enable_profiler(TRUE);
		$query = $this->db->get();	
		return $query->result();			
	}
	
	
	function edit_item($id){			
		$this->db->select('*')->from('tbl_item')
		->where('i_id =', $id); 
		$query = $this->db->get();	
		$this->db->last_query();
		return $query->result();			
	}
	
	
	function update_item($id) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post item details
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_category'=>$i_category,'i_name'=>strtoupper($i_name),'i_code'=>strtoupper($i_code),'m_code'=>strtoupper($m_code),'fixed_rate'=>$fixed_rate,'m_date'=>$m_date,'packing'=>strtoupper($packing),'exp_date'=>$exp_date,'s_price'=>$s_price,'p_rate'=>$p_rate,'p_tax'=>$p_tax,'offer'=>strtoupper($offer),'combination'=>strtoupper($combination),'min_qty'=>$min_qty,'max_qty'=>$max_qty,/*'batch_no'=>strtoupper($batch_no),*/'mrp'=>$mrp,'s_tax'=>$s_tax,'date'=>$created_date,'status'=>1);	
		$this->db->set($array);
	    $this->db->where('i_id',$id);
		$this->db->update('tbl_item',$array);
	}
	
	
	public function delete_item($id)
	{
		$array=array('is_delete'=>1);	
		$this->db->where('i_id', $id);
		$this->db->update('tbl_item', $array);
		return true;
	}
	
	 function statuschange($post) {
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post item details
		$created_date=date('Y-m-d h:i:s');
		$array=array('date'=>$created_date,'status'=>$st);	
		$this->db->set($array);
	    $this->db->where('i_id',$id);
		$this->db->update('tbl_item',$array);	 
		echo $st;
	 }
	 
	 
	 

}