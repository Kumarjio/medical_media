<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_products(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_product');
		$this->db->where('is_delete =', 0);
        $query = $this->db->get();	
		return $query->result();			
	 }
	 function get_accessories(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_accessories');
		$query = $this->db->get();	
		return $query->result();			
	 }
	  function get_products_drop(){
		$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_product');
		$this->db->where('is_delete =', 0);
		$this->db->where('status =', 1);
        $query = $this->db->get();	
		return $query->result();			
	 }
	 
	  function get_rows_product(){
		$this->db->select('*')->from('tbl_product')->order_by('i_id','DESC')->limit('1');
        $query = $this->db->get();		
		return $query->result();			
		// $this->db->insert_id();
	 }
	 
	 function add_product($post) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
		$created_date=date('Y-m-d h:i:s');
		$array=array('i_name'=>strtoupper($i_name),
		             'part_no'=>strtoupper($part_no),
                    'prate'=>$rate,
                    'descr'=>strtoupper($descr),
                     'qty'=>$qty,
                    'date'=>$created_date,'status'=>1);	
	    $this->db->set($array);
	    $this->db->insert('tbl_product',$array);
	}
	function add_accessories($post) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
		$created_date=date('Y-m-d h:i:s');
		$array=array('pro_name'=>strtoupper($i_name),
		             'part_no'=>strtoupper($part_no),
                    'product_rate'=>$rate,
                    'description'=>strtoupper($descr),
                     'qty'=>$qty,
                    'created_date'=>$created_date,);	
	    $this->db->set($array);
	    $this->db->insert('tbl_accessories',$array);
	}
 
	function view_product($id){
		$this->db->select('tbl_product.*');
		$this->db->from('tbl_product');
		//$this->db->join('tbl_tax as tbl_tax', 'tbl_tax.t_id = tbl_product.p_tax', 'left');
		//$this->db->join('tbl_manufacturer', 'tbl_manufacturer.m_id = tbl_product.i_code', 'left');
		$this->db->where('i_id =', $id);
		
		//echo $this->db->last_query();
		//$this->output->enable_profiler(TRUE);
		$query = $this->db->get();	
		return $query->result();			
	}
	function view_acc($id){
		$this->db->select('tbl_accessories.*');
		$this->db->from('tbl_accessories');
		//$this->db->join('tbl_tax as tbl_tax', 'tbl_tax.t_id = tbl_product.p_tax', 'left');
		//$this->db->join('tbl_manufacturer', 'tbl_manufacturer.m_id = tbl_product.i_code', 'left');
		$this->db->where('acc_id =', $id);
		
		//echo $this->db->last_query();
		//$this->output->enable_profiler(TRUE);
		$query = $this->db->get();	
		return $query->result();			
	}
	
	
	function edit_product($id){			
		$this->db->select('*')->from('tbl_product')
		->where('i_id =', $id); 
		$query = $this->db->get();	
		$this->db->last_query();
		return $query->result();			
	}
	function edit_acc($id){			
		$this->db->select('*')->from('tbl_accessories')
		->where('acc_id =', $id); 
		$query = $this->db->get();	
		$this->db->last_query();
		return $query->result();			
	}
	
	function update_product($id) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
       $array=array('i_name'=>strtoupper($i_name),
	                'descr'=>strtoupper($descr),
                    'qty'=>$qty);
		$this->db->set($array);
                $this->db->where('i_id',$id);
		$this->db->update('tbl_product',$array);
	}
	function update_acc($id) {
		
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
       $array=array('pro_name'=>strtoupper($accname),
	                'description'=>strtoupper($descr),
                    'qty'=>$qty);	
		$this->db->set($array);
                $this->db->where('acc_id',$id);
		$this->db->update('tbl_accessories',$array);
	}
	
	public function delete_product($id)
	{
		$array=array('is_delete'=>1);	
		$this->db->where('i_id', $id);
		$this->db->update('tbl_product', $array);
		return true;
	}
	
	 function statuschange($post) {
		$session_data = $this->session->all_userdata();
		extract($_REQUEST); //Used to get all post product details
		$created_date=date('Y-m-d h:i:s');
		$array=array('date'=>$created_date,'status'=>$st);	
		$this->db->set($array);
	    $this->db->where('i_id',$id);
		$this->db->update('tbl_product',$array);	 
		echo $st;
	 }
	 
	 
	 

}