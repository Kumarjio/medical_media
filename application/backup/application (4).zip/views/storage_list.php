<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
<?php
if(isset($inps) && !empty($inps))
{
	$customer = $inps['customer'];
	$storage = $inps['storage'];
	$product_cde = $inps['product_cde'];
	$sellers = $inps['seller'];
	$frmdt = $inps['from_dt'];
	$todt = $inps['to_dt'];
}
else
{
	$customer = '';
	$storage = 'all';
	$product_cde = '';
	$sellers = '';
	$frmdt = '';
	$todt = '';
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Storage</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">   
                                <a href="<?php echo base_url('index.php/Purchase'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Purchase Entry</button></a><br><br>           
                                <form action="" method="post" enctype="multipart/form-data" >
                                <div class="col-md-12">
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Storage</label>
                                    <div class="col-md-8">                                            
                                       <select class="selectpicker uppercase bs-select-hidden form-control" id="storage" name="storage" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($storage=='all')?'selected':''?> value="all">ALL</option>
                                     <option <?=($storage=='DEC')?'selected':''?> value="DEC">DECLARED</option>
                                     <option <?=($storage=="")?'selected':''?> value="">NOT DECLARED</option>
									<?php
                                    foreach($Storage as $sval)
                                    {
                                    ?>
                                        <option <?=($storage==$sval->cid)?'selected':''?> value="<?=$sval->cid?>"><?=$sval->storage_name?> - <?php if($sval->Location==1){echo 'London';}else if($sval->Location==2){echo 'Singapore';}else if($sval->Location==3){echo 'Hydrabad';}?></option>
                                        <?php
                                    }
                                        ?>
                                     </select>                                       
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Customer</label>
                                    <div class="col-md-8">                                            
                                        <?php $cust = $this->db->select('*')->get('cb_customer')->result_array(); ?>          
                                    <select class="selectpicker form-control uppercase" name="customer"   id="customer" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true" >
                                    <option <?=($customer=='')?'selected':''?> value="">All</option>
										<?php foreach($cust as $cust_det)  { ?>
                                        <option <?=($customer==$cust_det['cid'])?'selected':''?> value="<?=$cust_det['cid']?>"><?=$cust_det['customer_name']?></option>
                                        <?php } ?>
                                    </select>                                     
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">product Code</label>
                                    <div class="col-md-8">                                            
                                       <?php $prd_cd = $this->db->select('*')->get('tbl_product')->result_array(); ?>
                                     <select class="selectpicker uppercase bs-select-hidden form-control" name="product_cde" id="product_cde" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                      	<option <?=($product_cde=='')?'selected':''?> value="">All</option>
                                        <?php foreach($prd_cd as $prded) { ?>
                                        <option <?=($product_cde==$prded['i_code'])?'selected':''?> value="<?=$prded['i_code']?>"><?=$prded['i_code']?> - <?=$prded['i_name']?></option>
                                        <?php } ?>
                                    </select>                                               
                                       <?php /*?><input type="text" style="form-controlx" class="form-control bs-select-hidden" name="product_cde" id="product_cde" value="<?=$product_cde?>" />   <?php */?>                                 
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Vedor</label>
                                    <div class="col-md-8">                                            
                                       <select class="selectpicker uppercase bs-select-hidden form-control" name="seller" id="seller" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                         <option value="" selected> ALL </option>
                                         <?php ?>
                                         <?php foreach($seller as $row){ ?>
                                         <option <?=($sellers==$row->cid)?'selected':''?> value="<?php echo $row->cid; ?>"><?php echo $row->seller_name; ?></option>
                                         <?php } ?>
                                         <?php ?>
                                       </select>                 
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="col-md-12">
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">From Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="from_dt" value="<?=$frmdt?>" id="from_dt">                
                                    </div>
                                </div>
                                </div>
                                
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">To Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="to_dt" id="to_dt" value="<?=$todt?>">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div><div class="col-md-4"><button type="submit" name="export" class="btn btn-primary"><span class="fa fa-download"></span>Export</button>
                                    </div>
                                </div>
                                </div>
                                </div>
                                    </form>
                                      
                                    <ul class="panel-controls">
                                    <!--<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span></a></li>-->
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
                                        <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                                    </ul>                                
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
											<tr>
												<th>S. No</th>
												<th>Invoice No</th>
												<th>Seller</th>
												<th>Account</th>
												<th>Storage</th>
												<th>Product Code - Name</th>
												<th>Date Of Pur</th>
												<th>Pur Price</th>
												<th>Update Storage</th>
											  </tr>
										</thead>
                                            <tbody>
                                        	<?php
                                         $sno=1;
										if(is_array($stock) && count($stock) ) {
											foreach($stock as $loop){
                                                                                            /*
                                                                                            switch ($loop->supplier_code){
                                                                                                case 1: $name1 = 'Supplier1'; break;
                                                                                                case 2: $name1 = 'Supplier2'; break;
                                                                                                case 3: $name1 = 'Supplier3'; break;
                                                                                                case 4: $name1 = 'Supplier4'; break;
                                                                                                default:
                                                                                                    $name1 = 'Supplier7';
                                                                                                    break;
                                                                                            } */                                                                                            	switch ($loop['purchase_type'])
																								{
																									case 1: $type1 = 'Vendor'; break;
																									case 2: $type1 = 'Self'; break;
																									case 3: $type1 = 'Agent'; break;
																									case 4: $type1 = 'Auction'; break;
																									default:
																										$type1 = 'Self';
																										break;
                                                                                            	}
																								//$po_id[] = $loop['po_id'];
												?>
												<tr>
													<td><?php echo $sno++; ?></td>
													<td><?php echo $loop['vinvno']; ?></td>
													<td><?php echo $loop['seller_name']; ?></td>
													<td><?=$loop['acc_name']?></td>
													<td><?=$loop['storage_name']?> - <?php if($loop['Location']==1){echo 'LONDON';} else if($loop['Location']==2){echo 'SINGAPORE';} else if($loop['Location']==3) {echo 'HYDRABAD';} else { echo 'NOT DECLARED';} ?></td>
													<td><?php echo $loop['i_code']; ?> - <?php echo $loop['i_name']; ?> - <?=$loop['descr']?></td>
													<td><?=date('d-m-Y',strtotime($loop['pdate']))?></td>
													<td><?php echo $loop['p_rate']; ?>
                                                    
                                                    
												
                                                  <!--
                                                        <span id="statusspan<?php echo $loop['po_id']; ?>" <?php if($loop['status'] == 1) { ?> style="display:none;"<?php } ?> >
                                                   <label class="switch switch-medium">
                                                    <input type="checkbox" onclick="chStatus('<?php echo $loop['po_id']; ?>','0')">
                                                    <span style="color:#fff; ">&nbsp;ON &nbsp;&nbsp;&nbsp;  OFF</span></label>
                                                    </span>
                                                    
                                                    <span id="statusspande<?php echo $loop['po_id']; ?>" <?php  if($loop['status'] == 0) { ?> style="display:none;" <?php } ?>>
                                                    <label class="switch switch-medium">
                                                    <input type="checkbox" checked  onclick="chStatus('<?php echo $loop['po_id']; ?>','1')" >
                                                    <span style="color:#fff; ">&nbsp;ON &nbsp;&nbsp;&nbsp;  OFF</span></label>
                                                        </span> -->
                                                    
                                                
                                                </td>
													<td>
                                                    <input type="button" id="offer_btn_<?=$loop['pi_id']?>" <?php if($loop['slocation']!='' || $loop['wr_name']!=''){echo 'class="btn btn-xs btn-success"'; } else { ?> class="btn btn-xs btn-primary" <?php } ?> data-toggle="modal" data-target="#assign_<?=$loop['pi_id']?>" value="Update"  /></td>
                                              </tr>
											<?php }} ?>
										</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends --> 
    <?php
$sno=1;
										$po_id = '';
										$po_id[] = '';
										if(is_array($stock) && count($stock) ) {
											foreach($stock as $loop){
                                                                                            /*
                                                                                            switch ($loop->supplier_code){
                                                                                                case 1: $name1 = 'Supplier1'; break;
                                                                                                case 2: $name1 = 'Supplier2'; break;
                                                                                                case 3: $name1 = 'Supplier3'; break;
                                                                                                case 4: $name1 = 'Supplier4'; break;
                                                                                                default:
                                                                                                    $name1 = 'Supplier7';
                                                                                                    break;
                                                                                            } */                                                                                            	switch ($loop['purchase_type'])
																								{
																									case 1: $type1 = 'Vendor'; break;
																									case 2: $type1 = 'Self'; break;
																									case 3: $type1 = 'Agent'; break;
																									case 4: $type1 = 'Auction'; break;
																									default:
																										$type1 = 'Self';
																										break;
                                                                                            	}
																								//$po_id[] = $loop['po_id'];
												?>
<div class="modal fade" id="assign_<?=$loop['pi_id']?>" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Update Storage Infromation</h4>
                                </div>
                                <div class="modal-body" id="response_off_cls_<?=$loop['pi_id']?>">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Storage<sup  style="color:#f00"> * </sup>  </label>  
                                    <div class="col-md-8">
                                        <select class="selectpicker form-control uppercase slocation" name="slocation" id="slocation_<?=$loop['pi_id']?>" data-live-search="true" data-live-search-placeholder="Search">
                                        <option <?=($loop['slocation']=="")?'selected':''?> value="">NOT DECLARED</option>
                                        <?php
										foreach($Storage as $sval)
										{
										?>
                                        	<option <?=($loop['slocation']==$sval->cid)?'selected':''?> value="<?=$sval->cid?>~<?=$sval->storage_name?>"><?=$sval->storage_name?> - <?php if($sval->Location==1){echo 'London';}else if($sval->Location==2){echo 'Singapore';}else if($sval->Location==3){echo 'Hydrabad';}?></option>
                                        <?php
										}
										?>
                                        </select> 
                                      <div class="error" ><?php echo form_error('slocation'); ?></div>
                                    </div>
                                </div>
                                    <div class="form-group" style="display:none">                                        
                                        <label class="col-md-4 control-label">Warehouse Name<sup  style="color:#f00"> * </sup></label>
                                        <div class="col-md-8">
                                        <input type="text" readonly name="warehouse" id="warehouse<?=$loop['pi_id']?>" value="<?=$loop['wr_name']?>" required class="form-control" >
                                            <div class="error" ><?php echo form_error('pi_id'); ?></div>                                               
                                        </div>
                                    </div>
                                    <div class="form-group">                                        
                                        <label class="col-md-4 control-label">Rotation Number<sup  style="color:#f00"> * </sup></label>
                                        <div class="col-md-8">
                                        <input type="text" name="rota_no" id="rota_no<?=$loop['pi_id']?>" value="<?=$loop['rotateno']?>" required class="form-control" >
                                            <div class="error" ><?php echo form_error('pi_id'); ?></div>                                               
                                        </div>
                                    </div>
                                    <div class="form-group">                                        
                                        <label class="col-md-4 control-label">Date of Storage<sup  style="color:#f00"> * </sup></label>
                                        <div class="col-md-8">
                                        <input type="text" name="dt_of_str" id="dt_of_str<?=$loop['pi_id']?>" value="<?=($loop['stordate']!='0000-00-00')?$loop['stordate']:''?>" required class="mask_date form-control uppercase datepicker" >
                                            <div class="error" ><?php echo form_error('pi_id'); ?></div>                                               
                                        </div>
                                    </div>
                                    <div class="form-group" style="display:none">                                        
                                        <label class="col-md-4 control-label">Cask Bottle Number<sup  style="color:#f00"></sup></label>
                                        <div class="col-md-8">
                                        <input type="text" name="cask_bottle_no" id="cask_bottle_no<?=$loop['pi_id']?>" value="<?=$loop['cask_no']?>" class="form-control" >
                                            <div class="error" ><?php echo form_error('pi_id'); ?></div>                                               
                                        </div>
                                    </div>
                                    <?php /*?><div class="form-group">                                        
                                        <label class="col-md-4 control-label">Remarks<sup  style="color:#f00"> * </sup></label>
                                        <div class="col-md-8">
                                        <input type="text" name="warehouse" id="warehouse" value="" required class="form-control" >
                                            <div class="error" ><?php echo form_error('pi_id'); ?></div>                                               
                                        </div>
                                    </div><?php */?>
                                </div>
                                <div class="modal-footer">
                                	<button type="button" class="btn btn-success update_storage" id='assign_<?=$loop['pi_id']?>' >Update</button>
                                	<button type="button" class="btn btn-default" data-dismiss="modal" id='offer_closemodal_btn_<?=$loop['pi_id']?>'>Close</button>
                                </div>
                        	</div>
                        </div>
                    </div>
<?php
		}
										}?>
     <?php $this->load->view('include_js'); ?>
     
<script type="text/javascript">
	function fndelete(id) {
		var deletopt=confirm('Are you sure, do you want to delete this record?');
	  	if(deletopt)  {
			window.location =  '<?php echo base_url('index.php/Stock/deletestock/')?>/'+id;
		    return true;
	  	}  else  {
		  	return false;
	  	}
	}
</script>
<script>
function chStatus(id,st){
		if(st == 1) {
		var chst = 0; //change status value
		}
		else {
		var chst = 1;	
		}
	//alert(chst);	
		jQuery.ajax({
			type: "POST",
			url: "<?php echo base_url(); ?>" + "index.php/Stock/statuschange",
			dataType: 'json',
			data: {id: id, st: chst},
			success: function(res) {
			if(res == 0) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			if(res == 1) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			
				//console.log(res);
				
			}
		});
}
$('.update_amt').on('click',function()
{
	var id = $(this).attr('id');
	
	id = id.split('_');
	id = id[2];
	//alert(id)
	var amount = $('#sel_price_'+id).val();
	$.ajax(
	{
		url:'<?php echo base_url(); ?>index.php/Stock/update_amt',
		type:'POST',
		data:{amount:amount,id:id},
		success: function(result)
		{
			alert('Sale amount updated successfully...!')
		}
	}
	);
});
function calc(id)
{
	var pur_amt = $('#pur_price_'+id).val();
	var sel_amt = $('#sel_price_'+id).val();
	var total = parseFloat(sel_amt)-parseFloat(pur_amt);
	if(total>0)
	{
		var data = '<font size="+1" color="#009933">'+total+'</fonnt>';
	}
	else
	{
		var data = '<font size="+1" color="#FF0000">'+total+'</fonnt>';
	}
	$('#pnl_profit_'+id).html(data);
}
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            //document.getElementById("sign_mobile_err").style.display = ret ? "none" : "inline";
            return ret;
        }


	<!------------------------Status Activate End----------------------------!>
$('.update_storage').on('click',function()
{
	var id = $(this).attr('id');
	id = id.split('_');
	id = id[1];
	var wr_name = $('#warehouse'+id).val();
	//alert(waarehosue)
	var rotateno = $('#rota_no'+id).val();
	var dt_str = $('#dt_of_str'+id).val();
	var cask_no = $('#cask_bottle_no'+id).val();
	var slocation = $('#slocation_'+id).val();
	if(rotateno != '' && dt_str != '')
	{
		$(this).attr('disabled',true);
		$.ajax(
		{
			url:"<?php echo base_url('index.php/Stock/update_storage_info');?>",
			type:'POST',
			data:{wr_name:wr_name,rotateno:rotateno,dt_str:dt_str,cask_no:cask_no,id:id,slocation:slocation},
			success: function(result)
			{
				$('#offer_closemodal_btn_'+id).click();
				window.location.reload();
			}
		});
	}
});

$('.slocation').on('change',function()
{
	var this_id = $(this).attr('id');
	var this_val = $(this).val();
	this_id = this_id.split('_');
	id = this_id[1];
	
	this_val = this_val.split('~');
	//alert(this_val[1])
	
	$('#warehouse'+id).val(this_val[1])
});
</script>
<script>
  $(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
  </script>
</body>
</html>