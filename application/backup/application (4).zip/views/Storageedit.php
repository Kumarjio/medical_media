<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Storage</h2>
                </div>
                <!-- END PAGE TITLE -->                
		<?php $Storage = $Storage[0]; ?>
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3>Edit Storage</h3>
                            
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Storage/updateStorage/'.$Storage->cid);?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        


									<div class="col-md-6">
                                          
										  
										  
                                            <div class="form-group">
												<?php $query = $this->db->query("select cid from cb_storage")->num_rows(); ?>
                                                <label class="col-md-4 control-label">Storage ID<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">                                            
                                                    <input type="text" class="form-control uppercase" style="color:#000;" readonly name="Storage_code" placeholder="Enter Storage Code" id="Storage_code" value="<?php echo "CU00".$Storage->cid;  ?>">     
                                    			<div class="error" ><?php echo form_error('Storage_code'); ?></div>                                       
                                                </div>
                                            </div>
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Storage Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="Storage_name"  placeholder="Enter Storage Name" id="Storage_name" value="<?php echo $Storage->storage_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('storage_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Area Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase" name="area_name"  placeholder="Enter City Name" id="Storage_name" value="<?php echo $Storage->area_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">City Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="city_name"  placeholder="Enter Storage Name" id="Storage_name" value="<?php echo $Storage->city_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>

                                           <div class="form-group" style="display:none">                                        
                                                <label class="col-md-4 control-label">State<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="state_name"  placeholder="Enter State Name" id="Storage_name" value="- - - - - - -">   
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                      </div>
									  <div class="col-md-6">                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Location<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8"> 
                                                    <select name="Location" id="Location" class="selectpicker form-control uppercase bs-select-hidden">
                                                    <option <?=($Storage->Location=='1')?'selected':''?> value="1">LONDON</option>
                                                    <option <?=($Storage->Location=='2')?'selected':''?> value="2">SINGAPORE</option>
                                                    <option <?=($Storage->Location=='3')?'selected':''?> value="3">HYDRABAD</option>
                                                    </select>  
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Zipcode<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="pincode"  placeholder="Enter Pincode" id="Storage_name" value="<?php echo $Storage->pincode;  ?>">   
                                                    <div class="error" ><?php echo form_error('pincode'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <?php /*?><div class="form-group">
                                            <label class="col-md-4 control-label">Joining Date<sup  style="color:#f00"> * </sup>  </label>  
                                            <div class="col-md-8">
                                             <div class="input-group">
                                             <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                <input type="text" class="mask_date form-control uppercase datepicker"  placeholder="Enter Joining Date" name="joining_date" id="joining_date" value="<?php echo $Storage->joining_date;  ?>">   
                                              <div class="error" ><?php echo form_error('joining_date'); ?></div>
                                              </div>

                                            </div>
                                        </div>
                                           
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Advance Amount<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="advance"  placeholder="Enter Storage Name" id="Storage_name" value="<?php echo $Storage->advance;  ?>">   
                                                    <div class="error" ><?php echo form_error('advance'); ?></div>                                               
                                                </div>
                                            </div><?php */?>
                                           
                                            
                                          
                                            
                                            
                                            
                                          	<div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                                            <input class="btn btn-primary" value="Submit" type="submit" name="submit"><input class="btn btn-warning" type="Reset">
</div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>										
										
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

<script type="text/javascript">
    function custrDetails(id) {
		var res = id.substring(0,3)
		var Storage_code=$('#Storage_code').val();
		var res_c = Storage_code.substring(3)
		$("#Storage_code").val(res+res_c);
		
	}
</script>

       
 <script type="text/javascript">
          /*  var jvalidate = $("#jvalidate").validate({
                ignore: [],
                rules: { 
						phone_no: {
                               required : true
                        },
						phone_no_one: {
                              required : true 
                        },
						email_id: {
                                required : true
                        },
						email_id_one: {
							required : true
                               
                        },
						fax: {
							required : true
                               
                        },
						to_add: {
							required : true,
							min: 0,
							max: 99.99
						}
                                                         
                       
                    }                                        
                });    */                                

        </script>
