<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Product</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <a href="<?php echo base_url('index.php/Product/addproduct'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Add Finished Product</button></a>
                                     <a href="<?php echo base_url('index.php/Product/addaccessories'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Add Accessories</button></a>
                                    <ul class="panel-controls">
                                    <!--<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span></a></li>-->
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
                                        <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                                    </ul>                                
                                </div>
                                <div class="panel-body">
<div class="table-responsive">
<h3>Finished Goods</h3>
    <table class="table datatable">
    <thead>
        <tr>
            <th>S. No</th>
            <th>Product Name</th>
            <th>Part No</th>
            <th>Description</th>
            <th>Quantity</th>
           <th>Action</th>
            
        </tr>
    </thead>
        <tbody>
        
         <?php
                $sno=1;
                                            if(is_array($product) && count($product) ) {
                                                    foreach($product as $loop){
                                                            ?>
            <tr>
                    <td><?php echo $sno++; ?></td>
                    <td><?php echo $loop->i_name; ?> - <?=$loop->descr?></td>
                    <td><?php echo $loop->part_no; ?></td>
                    <td><?=$loop->descr?></td>
                    <td><?php echo $loop->qty;; ?></td>
                    <td>
           
            <a href="<?php echo base_url('index.php/Product/viewproduct/'.$loop->i_id); ?>"><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><span class="fa fa-eye"></span></button></a>
            <a href="<?php echo base_url('index.php/Product/editproduct/'.$loop->i_id);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
            <?php /*?><a href="javascript:void(0);" onClick="fndelete('<?php echo $loop->i_id;?>');" >
            <button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete"><span class="fa fa-times"></span></button> </a><?php */?>
            </td>

            </tr>
                                                    <?php }} ?>
        </tbody>
    </table>
    
    
    
    
   					<h3>Accessories</h3>
    <table class="table datatable">
    <thead>
        <tr>
            <th>S. No</th>
            <th>Product Name</th>
            <th>Part No</th>
            <th>Description</th>
            <th>Quantity</th>
           <th>Action</th>
            
        </tr>
    </thead>
        <tbody>
        
         <?php
                $sno=1;
                                            if(is_array($acc) && count($acc) ) {
                                                    foreach($acc as $loop){
                                                            ?>
            <tr>
                    <td><?php echo $sno++; ?></td>
                    <td><?php echo $loop->pro_name; ?> - <?=$loop->description?></td>
                    <td><?php echo $loop->part_no; ?></td>
                    <td><?=$loop->description?></td>
                    <td><?php echo $loop->qty;; ?></td>
                    <td>
           
            <a href="<?php echo base_url('index.php/Product/viewaccessories/'.$loop->acc_id); ?>"><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><span class="fa fa-eye"></span></button></a>
            <a href="<?php echo base_url('index.php/Product/editaccessories/'.$loop->acc_id);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
            <?php /*?><a href="javascript:void(0);" onClick="fndelete('<?php echo $loop->acc_id;?>');" >
            <button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Delete"><span class="fa fa-times"></span></button> </a><?php */?>
            </td>

            </tr>
                                                    <?php }} ?>
        </tbody>
    </table>
</div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
     
<script type="text/javascript">
	function fndelete(id) {
		var deletopt=confirm('Are you sure, do you want to delete this record?');
	  	if(deletopt)  {
			window.location =  '<?php echo base_url('index.php/Product/deleteproduct/')?>/'+id;
		    return true;
	  	}  else  {
		  	return false;
	  	}
	}
</script>
<script>
function chStatus(id,st){
		if(st == 1) {
		var chst = 0; //change status value
		}
		else {
		var chst = 1;	
		}
	//alert(chst);	
		jQuery.ajax({
			type: "POST",
			url: "<?php echo base_url(); ?>" + "index.php/Product/statuschange",
			dataType: 'json',
			data: {id: id, st: chst},
			success: function(res) {
			if(res == 0) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			if(res == 1) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			
				//console.log(res);
				
			}
		});
}


	<!------------------------Status Activate End----------------------------!>

	
</script>
</body>
</html>