<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> <a href="<?php echo base_url('index.php/Product'); ?>">Manage Product</a></h2>
                </div>
                <!-- END PAGE TITLE -->                
				<?php 	$product = $product[0]; ?> 
                
                <!-- PAGE CONTENT WRAPPER -->
<div class="row">
<div class="col-md-12">

<form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Product/editaccessories/'.$product->acc_id);?>" method="post">
<div class="panel panel-default">
    <div class="panel-body">
        <h3 class="panel-title"><strong>Edit Product</strong></h3>

    </div>

<div class="panel-body">                                                                        
    <div class="row">
<div class="col-md-6">
    
    <div class="form-group">                                        
        <label class="col-md-4 control-label">Part No<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
                <input type="text" class="form-control uppercase" style="color:#000;" readonly placeholder="Enter Product Code" name="part_no" id="i_code" value="<?php echo $product->part_no;  ?>">
            <div class="error" ><?php echo form_error('i_code'); ?></div>                                               
        </div>
    </div>
    <div class="form-group">                                        
        <label class="col-md-4 control-label">Product Name<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
                <input type="text" class="form-control uppercase"   placeholder="Enter Product Name" name="accname" id="accname" value="<?php echo $product->pro_name;  ?>">
            <div class="error" ><?php echo form_error('i_name'); ?></div>                                               
        </div>
    </div>
<div class="form-group">
        <label class="col-md-4 control-label">Description<sup  style="color:#f00"> * </sup>  </label>  
        <div class="col-md-8">
            <textarea type="text" class="form-control uppercase" placeholder="Enter Description" name="descr" id="address"><?php echo $product->description;  ?></textarea>
            <span class="help-block"></span>
          <div class="error" ><?php echo form_error('descr'); ?></div>	
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label">Qty<sup  style="color:#f00"> * </sup>  </label>  
        <div class="col-md-8">
            <input type="number" class="form-control uppercase" placeholder="Enter Age" name="qty" value="<?php echo $product->qty; ?>" id="age" />
          <div class="error" ><?php echo form_error('age'); ?></div>	
        </div>
    </div>
    <input class="btn btn-primary pull-right" value="Update" type="submit">
    
  </div>



   
    
   

</div>

</div>
</div>


</div>
</form>

</div>
</div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

<script type="text/javascript">
    function productDetails(id) {
		var res = id.substring(0,3)
		var i_code=$('#i_code').val();
		var res_c = i_code.substring(3)
		$("#i_code").val(res+res_c);
		
	}
</script>

        
 <?php /*?><script type="text/javascript">
            var jvalidate = $("#jvalidate").validate({
                ignore: [],
                rules: {                                            
                        i_category: {
                                required: true,
                        },                                            
                        i_name: {
                                required: true,
                        },                                            
                        i_code: {
                                required: true,
                        },                                            
                        m_code: {
                                required: true,
                        },                                            
                        fixed_rate: {
                                required: true,
                        },                                            
                        m_date: {
                                required: true,
                        },                                            
                        packing: {
                                required: true,
                        },                                            
                        exp_date: {
                                required: true,
                        },                                            
                        s_price: {
                                required: true,
                        },                                            
                        p_rate: {
                                required: true,
                        },                                            
                        p_tax: {
                                required: true,
                        },                                            
                        offer: {
                                required: true,
                        },                                            
                        combination: {
                                required: true,
                        },                                            
                        min_qty: {
                                required: true,
                        },                                            
                        max_qty: {
                                required: true,
                        },                                            
                        batch_no: {
                                required: true,
                        },                                            
                        mrp: {
                                required: true,
                        },                                            
                        s_tax: {
                                required: true,
                        }
                    }                                        
                });                                    

        </script><?php */?>    

