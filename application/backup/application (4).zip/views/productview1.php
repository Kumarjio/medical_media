<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     
                <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Product</h2>
                                                        <input class="btn btn-primary pull-right" value="Back" onClick="window.history.go(-1)" type="button">

                </div>
                <!-- END PAGE TITLE -->                
			<?php $product = $product[0]; ?>
                <!-- PAGE CONTENT WRAPPER -->
                
				<div class="page-content-wrap">
                    
<div class="row">

    <div class="col-md-12">
        <div class="panel panel-default form-horizontal">
            <div class="panel-body">
                <h3></span> Product Details</h3>
                <!--<p>Some quick info about this user</p>-->
            </div>
            <div class="panel-body form-group-separated"> 

<div class="col-md-6">                                   
    <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Product Name</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->pro_name;  ?></div>
    </div>
     <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Part No</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->part_no;  ?></div>
    </div>
    <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Description</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->description;  ?></div>
    </div>
    <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Qty</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->qty;  ?></div>
    </div>
    </div>

    <?php /*?><div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Cask Bottle No.</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->cbno;  ?></div>
    </div>
    <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Genre</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->genre;  ?></div>
    </div>

</div>
<div class="col-md-6"> 
     <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Distiller</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->distiller;  ?></div>
    </div><?php */?>
   
    <?php /*?> <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label"> Rate</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->fixed_rate;  ?></div>
    </div>
     <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Minimum Quantity</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->min_qty;  ?></div>
    </div>
     <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Maximum Quantity</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->max_qty;  ?></div>
    </div>
     <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Country</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->country;  ?></div>
    </div>
     <div class="form-group">
        <label class="col-md-4 col-xs-5 control-label">Region</label>
        <div class="col-md-8 col-xs-7 line-height-30"><?php echo $product->region;  ?></div>
    </div><?php */?>
</div>
            </div>

        </div>


    </div>

</div>
                    
                </div>
                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->  
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>



        
     

