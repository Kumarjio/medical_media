<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Storage</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3>Add Storage</h3>
                            
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Storage/addStorage');?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">
                                          
										  
										  
                                            <div class="form-group">
												<?php $query = $this->db->query("select cid from cb_storage")->num_rows(); ?>
                                                <label class="col-md-4 control-label">Storage ID<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">                                            
                                                    <input type="text" class="form-control uppercase" style="color:#000;" readonly name="Storage_code" placeholder="Enter Storage Code" id="Storage_code" value="<?php echo "STR00".$n=$query+1;;  ?>"> 
                                                        
                                    			<div class="error" ><?php echo form_error('Storage_code'); ?></div>                                       
                                                </div>
                                            </div>
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Storage Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="Storage_name"  placeholder="Enter Storage Name" id="Storage_name" value="<?php echo set_value('Storage_name');  ?>">
                                                    <div class="error" ><?php echo form_error('Storage_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Area Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase" name="area_name"  placeholder="Enter Area Name" id="Storage_name" value="<?php echo set_value('area_name');  ?>">
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">City Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="city_name"  placeholder="Enter City Name" id="Storage_name" value="<?php echo set_value('city_name');  ?>">
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>

                                           <div class="form-group" style="display:none">                                        
                                                <label class="col-md-4 control-label">State</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="state_name"  placeholder="Enter State Name" id="Storage_name" value="- - - - - -">
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                      </div>
									  <div class="col-md-6">                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Location</label>
                                                <div class="col-md-8">
                                                	<select name="Location" id="Location" class="selectpicker form-control uppercase bs-select-hidden">
                                                    <option value="1">Chennai</option>
                                                    <option value="2">Bangalore</option>
                                                    <option value="3">Hyderabad</option>
                                                    </select>
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">ZipCode</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="pincode"  placeholder="Enter Pincode" id="Storage_name" value="<?php echo set_value('pincode');  ?>">
                                                    <div class="error" ><?php echo form_error('pincode'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <?php /*?><div class="form-group">
                                            <label class="col-md-4 control-label">Joining Date<sup  style="color:#f00"> * </sup>  </label>  
                                            <div class="col-md-8">
                                             <div class="input-group">
                                             <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                <input type="text" class="mask_date form-control uppercase datepicker"  placeholder="Enter Joining Date" name="joining_date" id="joining_date" value="<?php if(set_value('joining_date')!="") { echo set_value('joining_date'); }else { echo date("Y-m-d"); }  ?>"/>
                                              <div class="error" ><?php echo form_error('joining_date'); ?></div>
                                              </div>

                                            </div>
                                        </div><?php */?>
                                           
                                            
                                            											
                                           <div class="form-group">                                        
                                                <!--<label class="col-md-4 control-label">Advance Amount<sup  style="color:#f00"> * </sup></label>-->
                                                <div class="col-md-8">
                                                	<input type="hidden" class="form-control uppercase"  name="advance"  placeholder="Enter Storage Name" id="Storage_name" value="0">
                                                    <div class="error" ><?php echo form_error('advance'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            
                                          
                                            
                                            
                                            
                                          	<div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                                            <input class="btn btn-primary" value="Submit" type="submit" name="submit"><input class="btn btn-warning" type="Reset">
</div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>
                                      </div>
                                        
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

