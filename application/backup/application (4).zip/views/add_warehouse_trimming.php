<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
               
                                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3 class="pull-left">Add Trimming Ware House Details</h3>
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Warehouse_stock/adddata');?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
<div class="col-md-6">

    <div class="form-group">                                        
        <label class="col-md-4 control-label">Part No<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
                <input type="text" class="form-control uppercase" required placeholder="Enter Part No" name="pa_no" id="i_name" value="<?php echo set_value('i_name');?>" />
            <div class="error" ><?php if(isset($i_name)){ echo $i_name;}else{ echo form_error('i_name');}  ?></div>                                               
        </div>
    </div>
	
    <div class="form-group">                                        
        <label class="col-md-4 control-label">Quantity<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
                <input type="text" class="form-control uppercase" style="color:#000;" required  placeholder="Enter Product Quantity" name="qty" id="part_no" value="<?php echo set_value('i_code');  ?>">
            <div class="error" ><?php echo form_error('i_code'); ?></div>                                               
        </div>
    </div>
    
    
    
    <?php /*?><div class="form-group" style="display:none">
        <label class="col-md-4 control-label">Genre</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Genre" name="genre" id="genre" value="<?php echo set_value('genre');  ?>"/>
          <div class="error" ><?php echo form_error('genre'); ?></div>	

        </div>
    </div><?php */?>
</div>
                                        
<?php /*?><div class="col-md-6">
<div class="form-group">
        <label class="col-md-4 control-label">Vintage</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Vintage" name="vintage" id="vintage" value="<?php echo set_value('vintage');  ?>"/>
          <div class="error" ><?php echo form_error('vintage'); ?></div>	
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-4 control-label">Strength</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Strength" name="strength" id="strength" value="<?php echo set_value('strength');  ?>"/>
          <div class="error" ><?php echo form_error('strength'); ?></div>	
        </div>
    </div>
    <div class="form-group" style="display:none">
        <label class="col-md-4 control-label">Distiller</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Distiller" name="distiller" id="distiller" value="<?php echo set_value('distiller');  ?>"/>
          <div class="error" ><?php echo form_error('distiller'); ?></div>
        </div>
    </div>
    
     <div class="form-group">
        <label class="col-md-4 control-label">Bottling</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Bottling" name="bottling" id="bottling" value="<?php echo set_value('bottling');  ?>"/>
            <span class="help-block"></span>
          <div class="error" ><?php echo form_error('bottling'); ?></div>	
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-4 control-label">Size</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Size" name="size1" id="size1" value="<?php echo set_value('size1');  ?>"/>
          <div class="error" ><?php echo form_error('size1'); ?></div>	

        </div>
    </div>
    <div class="form-group" style="display:none">                                        
        <label class="col-md-4 control-label">Rate</label>
        <div class="col-md-6">
                <input type="text" class="form-control uppercase" placeholder="Enter Rate" name="fixed_rate" id="fixed_rate" value="<?php echo set_value('fixed_rate');  ?>">
            <div class="error" ><?php echo form_error('fixed_rate'); ?></div>                                               
        </div>
    </div>
    <?php /*?><div class="form-group">                                        
        <label class="col-md-4 control-label">Min. Quantity<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-6">
                <input type="text"  class="form-control uppercase" placeholder="Enter Minimum Quantity" name="min_qty" id="min_qty" value="<?php echo set_value('min_qty');  ?>">
            <div class="error" ><?php echo form_error('min_qty'); ?></div>                                               
        </div>
    </div>
    <div class="form-group">                                        
        <label class="col-md-4 control-label">Max. Quantity<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-6">
                <input type="text" class="form-control uppercase" placeholder="Enter Maximum Quantity" name="max_qty" id="max_qty" value="<?php echo set_value('max_qty');  ?>">
            <div class="error" ><?php echo form_error('max_qty'); ?></div>                                               
        </div>
    </div>
    <div class="form-group" style="display:none">
        <label class="col-md-4 control-label">Country</label>  
        <div class="col-md-6">
            <input type="text" class="form-control uppercase" placeholder="Enter Country" name="country" id="country" value="<?php echo set_value('country');  ?>"/>
          <div class="error" ><?php echo form_error('country'); ?></div>	
        </div>
    </div>

    <div class="form-group" style="display:none">
        <label class="col-md-4 control-label">Region</label>  
        <div class="col-md-6">
            <input type="region" class="form-control uppercase" placeholder="Enter Region" name="region" id="region" value="<?php echo set_value('region');  ?>"/>
          <div class="error" ><?php echo form_error('region'); ?></div>
        </div>
    </div>
</div><?php */?>
                                        
</div>
                                    
<div class="form-group pull-right">                                        
    <div class="btn-group pull-right col-md-12"><input class="btn btn-primary" value="Submit" type="submit"><input class="btn btn-warning" type="Reset">
    </div>
</div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>
   

