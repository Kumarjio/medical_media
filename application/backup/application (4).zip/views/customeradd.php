<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Account</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3>Add Company</h3>
                            
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Customer/addCustomer');?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">
                                          
										  
										  
                                            <div class="form-group">
												<?php $query = $this->db->query("select cid from cb_customer")->num_rows(); ?>
                                                <label class="col-md-4 control-label">Customer ID<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">                                            
                                                    <input type="text" class="form-control uppercase" style="color:#000;" readonly name="customer_code" placeholder="Enter Company Code" id="customer_code" value="<?php echo "CU00".$n=$query+1;;  ?>">     
                                    			<div class="error" ><?php echo form_error('customer_code'); ?></div>                                       
                                                </div>
                                            </div>
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Customer Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="customer_name"  placeholder="Enter Company Name" id="customer_name" value="<?php echo set_value('customer_name');  ?>">
                                                    <div class="error" ><?php echo form_error('customer_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Mobile No<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="mobile"  placeholder="Enter Company Name" id="customer_name" value="<?php echo set_value('customer_name');  ?>">
                                                    <div class="error" ><?php echo form_error('customer_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Email Id<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="email"  placeholder="Enter Company Name" id="customer_name" value="<?php echo set_value('customer_name');  ?>">
                                                    <div class="error" ><?php echo form_error('customer_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Area Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase" name="area_name"  placeholder="Enter Area Name" id="customer_name" value="<?php echo set_value('area_name');  ?>">
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">City Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="city_name"  placeholder="Enter City Name" id="customer_name" value="<?php echo set_value('city_name');  ?>">
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>

                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">State</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="state_name"  placeholder="Enter State Name" id="customer_name" value="<?php echo set_value('state_name');  ?>">
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                      </div>
                                        <div class="col-md-6">                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Country</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="country_name"  placeholder="Enter Country Name" id="customer_name" value="<?php echo set_value('country_name');  ?>">
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Pincode</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="pincode"  placeholder="Enter Pincode" id="customer_name" value="<?php echo set_value('pincode');  ?>">
                                                    <div class="error" ><?php echo form_error('pincode'); ?></div>                                               
                                                </div>
                                            </div>
                                           
                                            											
                                           <?php /*?><div class="form-group">
                                            <label class="col-md-4 control-label">Joining Date<sup  style="color:#f00"> * </sup>  </label>  
                                            <div class="col-md-8">
                                             <div class="input-group">
                                             <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                <input type="text" class="mask_date form-control uppercase datepicker"  placeholder="Enter Joining Date" name="joining_date" id="joining_date" value="<?php if(set_value('joining_date')!="") { echo set_value('joining_date'); }else { echo date("Y-m-d"); }  ?>"/>
                                              <div class="error" ><?php echo form_error('joining_date'); ?></div>
                                              </div>

                                            </div>
                                        </div><?php */?>


                                    </div> 
            
                                </div>
                                        
                                      </div>
                                    
                                    
                                    <div class="row">
                                        <div class="form-group pull-right">
                                        <div class="btn-group pull-right col-md-12"><input class="btn btn-primary" value="Submit" type="submit" name="submit"><input class="btn btn-warning" type="Reset">
                                        </div>    
                                    </div>

                                    </div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

