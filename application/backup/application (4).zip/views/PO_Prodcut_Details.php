<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
 <?php
if(isset($inps['pono']) && !empty($inps))
{
     $pono = $inps['pono'];
	
}
else
{
	$pono = '';
	
	
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span>Warehouse Product lists</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                 <form action="<?=$this->config->item('base_url')?>index.php/Po_process" method="post" enctype="multipart/form-data" >
                                   <div class="col-md-12">
                                   
                                     <div class="col-md-3">
                                       <div class="form-group">
                                    <label class="col-md-4 control-label">PO NO.</label>
                                        <div class="col-md-8">   
                                  <?php $cusdt =  $this->db->select('*')->group_by('po_no')->get('tbl_leads')->result_array(); ?>
                            	
                                                        <select id="pono" name="pono" class="form-control selectpicker"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                                        <option value=''>Select All</option>
                                                        <?php foreach($cusdt as $det) { ?>
                                                        <option <?=($pono==$det['po_no'])?'selected':''?> value="<?=$det['po_no']?>"><?=$det['po_no']?> </option>
                                                        <?php } ?>	
														    </select> 
                                        </div>
                                      </div>
                                     </div>
                                    
                                    <div class="col-md-3">
                                       <div class="form-group">
                                          <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div><div class="col-md-4">
                                          </div>
                                        </div>
                                      </div>
                                      
                                  </div>
                                 </form>                           
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Part No</th>
                                                    <th>Description</th>
                                                    <th>Qty</th>
                                                    <th>Finished Goods Qty</th>
                                                    <th>Balance</th>
                                                    
                                                   
                                              </tr>
											</thead>
                                            <tbody>
                                        	 <?php if(is_array($item) && count($item) ) {
                                        		$cnt=1;
											   foreach($item as $loop){	
											   $sub1 = $loop['qty'] - $loop['quantity'];
											    ?>
											<tr>
												<td><?php echo $cnt; $cnt++; ?></td>
                                               <td><?=$loop['part_no']?></td>
												<td><?=$loop['description']?></td>
                                                <td><?=$loop['qty']?></td>
                                                <td><?=$loop['quantity']?></td>
                                                <td><?=$sub1?></td>
                                           </tr>
											<?php }} ?>
										</tbody>
                                        </table>
                                       
                                         
     								
                                        
                                            </div>
                                             
                    
                                              </div>
                                            
 										
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>

</body>
</html>