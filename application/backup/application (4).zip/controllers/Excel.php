<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Excel extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Leads_model');
     }
	
	public function index()
	{
		$data['title'] = 'New Order Upload';
		$this->load->view('excel_upload',$data);
	}
	public function import()
	{
		//echo '<pre>';print_r($_FILES);exit;
		$inps = $this->input->post();
		 
		
		
	  if(isset($_FILES["excel_file"]))
		{
			$filename=$_FILES["excel_file"]["tmp_name"];
			if($_FILES["excel_file"]["size"] > 0)
			  {
				$file = fopen($filename, "r");
				$i=0;
				 while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
				 {
					  if($i>0)
						 {
							/* $this->db->select('*');
							 $this->db->where('part_no',$emapData[1]);
							 $get_det = $this->db->get('tbl_leads');
							 if($get_det->num_rows()>0)
							 {
								 //update 
								 $data = array(
									'description' => $emapData[2],
									'qty' => $emapData[3],
									'cost' => $emapData[4],
									'expected_date' => date('Y-m-d', strtotime($emapData[5])),
									'created_date' => date('Y-m-d H:i:s'),
									'po_no' => $inps['pono'],
									'po_date' => date('d-m-Y', strtotime($inps['date'])),
									);
								$this->db->where('part_no',$emapData[1]);
								$this->db->update('tbl_leads', $data);
							 }
							 else
							 {*/
								 $data = array(
									'part_no' => $emapData[1],
									'description' => $emapData[2],
									'qty' => $emapData[3],
									'cost' => $emapData[4],
									'cost_inr'=>$emapData[5],
									'inr_rate'=>$emapData[6],
									'expected_date' => date('Y-m-d', strtotime($emapData[7])),
									'created_date' => date('Y-m-d H:i:s'),
									'po_no' => $inps['pono'],
									'po_date' => date('Y-m-d', strtotime($inps['date'])),
									
									);
								$this->db->insert('tbl_leads', $data);
								$this->db->insert_id();
							// }
						   
					 	//}
					 }
					 $i++;
				 }
				fclose($file);
				redirect('Excel/order_list');
			  }
		}
	}
	public function order_list()
	{
		$data['title'] = 'Purchase Details ';
		if($this->input->get())
		{
			$inps = $this->input->get();
		}
		else
		{
			$inps = $this->input->post();
		}	
		$data['list'] = $this->Leads_model->get_leads($inps);
	    //echo '<pre>';print_r($data['list']); exit;
	    if(isset($inps['export']))
		{
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
		}
		
		$this->load->view('leads_list',$data);
	}
	public function sel_p()
	{
		$data['title'] = 'New Order Upload';
		$this->load->view('excel_upload_sel',$data);
	}
	public function import_sel_p()
	{
		//echo '<pre>';print_r($_FILES);exit;
		$inps = $this->input->post();
		 
		
		
	  if(isset($_FILES["excel_file"]))
		{
			$filename=$_FILES["excel_file"]["tmp_name"];
			if($_FILES["excel_file"]["size"] > 0)
			  {
				$file = fopen($filename, "r");
				$i=0;
				 while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
				 {
						 if($i>0)
						 {
							 $this->db->select('*');
							 $this->db->where('part_no',$emapData[1]);
							 $get_det = $this->db->get('product_selling_price');
							 if($get_det->num_rows()>0)
							 {
								 //update 
								 $data = array(
									'price' => $emapData[2],
									'post_dt' => date('Y-m-d'),
									'cost_inr'=>$emapData[3],
									'inr_rates'=>$emapData[4],
									);
								$this->db->where('part_no',$emapData[1]);
								$this->db->update('product_selling_price', $data);
							 }
							 else
							 {
								 //insert
								 $data = array(
									'part_no' => $emapData[1],
									'price' => $emapData[2],
									'post_dt' => date('Y-m-d'),
									'cost_inr'=>$emapData[3],
									'inr_rates'=>$emapData[4],
									);
								$this->db->insert('product_selling_price', $data);
								$this->db->insert_id();
							 }
					 }
					 $i++;
				 }
				fclose($file);
				redirect('Excel/order_list');
			  }
		}
	}
}
