<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Po_process extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Warehouse_model');
     }
	 //get_rows used to get rows of table
	 //get_single_row used to get 
	 
	 public function index()
	 {
		$data['item'] = $this->Warehouse_model->get_po_diff_detsss();
		$data['title'] = 'Warehouse List:: Leyland ';
		$this->load->view('PO_Prodcut_Details', $data);
	 }
	
}