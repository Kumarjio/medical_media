<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Storage extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Storage_model');
//          $this->load->model('OtherMasters_model');
     }
	
	public function index(){		
		$query = $this->Storage_model->get_all_Storage();
		if($query){
			$data['Storage'] =  $query;
		} else {
			$data['Storage'] =  '';
		}
		$data['title'] = 'View All Storage :: Leyland ';
		$this->load->view('Storagelist', $data);
	}
	
	public function addStorage1(){
		 $data['title'] = 'Add Storage :: Leyland ';
		//  $data['head'] = $this->Storage_model->get_head();
		 $this->load->view('Storageadd',$data);
	}
	
	public function addStorage(){
		
		$this->form_validation->set_rules('Storage_code', 'Storage Code', 'required|trim|xss_clean');
		$this->form_validation->set_rules('Storage_name', 'Storage Name', 'required|trim|xss_clean');
		$this->form_validation->set_rules('area_name', 'Area Name', 'required|trim|xss_clean');
		$this->form_validation->set_rules('city_name', 'City Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('state_name', 'State', 'required|trim');
		$this->form_validation->set_rules('Location', 'Location', 'required|trim|xss_clean');
		$this->form_validation->set_rules('pincode', 'Pincode', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('joining_date', 'Joining Date', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('advance', 'Advance', 'required|numeric|trim|xss_clean');
		
		
		
		if ($this->form_validation->run() == FALSE) { 
			 $data['title'] = 'Add Storage :: Leyland ';
			// echo 'hi'; exit;
//			 $data['head'] = $this->Storage_model->get_head();
 			//$data['area'] = $this->OtherMasters_model->get_all_area();
 			//$data['salesman'] = $this->OtherMasters_model->get_all_salesman();
			 $this->load->view('Storageadd',$data);	
		} else {
			$muinput= $this->security->xss_clean($this->input->post());
			$manage_category=$this->Storage_model->add_Storage($muinput);
			//exit;
			echo "<script> alert('Successfully added');window.location= '".base_url('index.php/Storage')."'</script>";
			
		}
		
		//$this->load->view('productadd', $data);
	}
	
	public function viewStorage($id){
		 $data['title'] = 'View Storage :: Leyland ';
	   	 $data['Storage']=$this->Storage_model->view_Storage($id);
		 $this->load->view('Storageview',$data);
	}
	
	public function editStorage1($id){
		 $data['title'] = 'Edit Storage :: Leyland ';
		// $data['head'] = $this->Storage_model->get_head();
		 $data['Storage']=$this->Storage_model->edit_Storage($id);
		// echo '<pre>'; print_r($data); exit;
		 $this->load->view('Storageedit',$data);
	}
		
	public function updateStorage($id){
		
		
		$this->form_validation->set_rules('Storage_code', 'Storage Code', 'required|trim|xss_clean');
		$this->form_validation->set_rules('Storage_name', 'Storage Name', 'required|trim|xss_clean');
		$this->form_validation->set_rules('area_name', 'Area Name', 'required|trim|xss_clean');
		$this->form_validation->set_rules('city_name', 'City Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('state_name', 'State', 'required|trim');
		$this->form_validation->set_rules('Location', 'Location', 'required|trim|xss_clean');
		$this->form_validation->set_rules('pincode', 'Pincode', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('joining_date', 'Joining Date', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('advance', 'Advance', 'required|numeric|trim|xss_clean');
		
		if ($this->form_validation->run() == FALSE) { 
			 $data['title'] = 'Edit Storage :: Leyland  ';
			 //$data['head'] = $this->Storage_model->get_head();
			 $data['Storage']=$this->Storage_model->edit_Storage($id);
		 	 $this->load->view('Storageedit',$data);	
		} else {
			$muinput= $this->security->xss_clean($this->input->post());
			$manage_category=$this->Storage_model->update_Storage($id,$muinput);
			echo "<script> alert('Successfully updated');window.location= '".base_url('index.php/Storage')."'</script>";
			
		}
	}	

	
	public function deleteStorage($id){		
		 $data['delete']=$this->Storage_model->delete_Storage($id);
		 echo "<script> alert('Successfully deleted');window.location= '".base_url('index.php/Storage')."'</script>"; 
	}
}