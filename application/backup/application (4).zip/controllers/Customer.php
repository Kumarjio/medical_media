<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Customer extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Customer_model');
          //$this->load->model('OtherMasters_model');
		  //$this->load->model('dealer_model'); 
     }
	
	public function index(){		
		$query = $this->Customer_model->get_all_customer();
		if($query){
			$data['customer'] =  $query;
		} else {
			$data['customer'] =  '';
		}
		$data['title'] = 'View All Customer :: Leyland ';
		$this->load->view('customerlist', $data);
	}
	
	public function addCustomers(){
		 $data['title'] = 'Add Customer :: Leyland';
		//  $data['head'] = $this->Customer_model->get_head();
		 $this->load->view('customeradd',$data);
	}
	
	public function addCustomer(){
		
		$this->form_validation->set_rules('customer_code', 'Customer Code', 'required|trim|xss_clean');
		$this->form_validation->set_rules('customer_name', 'Customer Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('area_name', 'Area Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('city_name', 'City Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('state_name', 'State', 'required|trim');
		//$this->form_validation->set_rules('country_name', 'Country', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('pincode', 'Pincode', 'required|numeric|trim|xss_clean');
		//$this->form_validation->set_rules('joining_date', 'Joining Date', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('advance', 'Advance', 'required|numeric|trim|xss_clean');
		
		
		
		if ($this->form_validation->run() == FALSE) { 
			 $data['title'] = 'Add Customer :: Leyland ';
			 //$data['head'] = $this->Customer_model->get_head();
 			//$data['area'] = $this->OtherMasters_model->get_all_area();
 			//$data['salesman'] = $this->OtherMasters_model->get_all_salesman();
			 $this->load->view('customeradd',$data);	
		} else {
			$muinput= $this->security->xss_clean($this->input->post());
			$manage_category=$this->Customer_model->add_customer($muinput);
			echo "<script> alert('Successfully added');window.location= '".base_url('index.php/Customer')."'</script>";
			
		}
		
		//$this->load->view('productadd', $data);
	}
	
	public function viewCustomer($id){
		 $data['title'] = 'View Customer :: Leyland ';
	   	 $data['customer']=$this->Customer_model->view_customer($id);
		 $this->load->view('customerview',$data);
	}
	
	public function editCustomer1($id){
		 $data['title'] = 'Edit Customer :: Leyland ';
		 //$data['head'] = $this->Customer_model->get_head();
		 /*$data['salesman_rep'] = $this->Customer_model->get_salesman_rep();
		 $data['salesman_asm'] = $this->Customer_model->get_salesman_asm();
		 $data['salesman_rsm'] = $this->Customer_model->get_salesman_rsm();*/
		 $data['customer']=$this->Customer_model->edit_customer($id);
		 $this->load->view('customeredit',$data);
	}
		
	public function updateCustomer($id){
		
		
		$this->form_validation->set_rules('customer_code', 'Customer Code', 'required|trim|xss_clean');
		$this->form_validation->set_rules('customer_name', 'Customer Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('area_name', 'Area Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('city_name', 'City Name', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('state_name', 'State', 'required|trim');
		//$this->form_validation->set_rules('country_name', 'Country', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('pincode', 'Pincode', 'required|numeric|trim|xss_clean');
		//$this->form_validation->set_rules('joining_date', 'Joining Date', 'required|trim|xss_clean');
		//$this->form_validation->set_rules('advance', 'Advance', 'required|numeric|trim|xss_clean');
		
		if ($this->form_validation->run() == FALSE) { 
			 $data['title'] = 'Edit Customer :: Leyland  ';
			 //$data['head'] = $this->Customer_model->get_head();
			 $data['customer']=$this->Customer_model->edit_customer($id);
		 	 $this->load->view('customeredit',$data);	
		} else {
			$muinput= $this->security->xss_clean($this->input->post());
			$manage_category=$this->Customer_model->update_customer($id,$muinput);
			echo "<script> alert('Successfully updated');window.location= '".base_url('index.php/Customer')."'</script>";
			
		}
	}	

	
	public function deleteCustomer($id){		
		 $data['delete']=$this->Customer_model->delete_customer($id);
		 echo "<script> alert('Successfully deleted');window.location= '".base_url('index.php/Customer')."'</script>"; 
	}
}
