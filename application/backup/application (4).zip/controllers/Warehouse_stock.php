<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Warehouse_stock extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  }		  
          $this->load->model('Warehouse_model');
     }
	 //get_rows used to get rows of table
	 //get_single_row used to get 
	 
	 public function index()
	 {
		$data['item'] = $this->Warehouse_model->get_trimming();
		$data['title'] = 'Warehouse List:: Leyland ';
		$this->load->view('trimming_warehouse_list', $data);
	 }
	public function addwarehouse()
	{
		//$data['item'] = $this->Sales_model->get_rows1();
		$data['title'] = 'Add Warehouse:: Leyland ';
		$this->load->view('add_warehouse_trimming', $data);
	}
	public function adddata()
	{
		$inps = $this->input->post();
		$arr = array(
		'part_no' => $inps['pa_no'],
		'qty' => $inps['qty'],
		'created_date' => date('Y-m-d H:i:s'),
		); 
		$this->db->insert('trimming_warehouse',$arr); 
		 echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Warehouse_stock')."'</script>";  
	}
	public function Finished_Goods_Ware_House()
	 {
		$data['item'] = $this->Warehouse_model->get_finished_goods();
		$data['title'] = 'Warehouse List:: Leyland ';
		$this->load->view('finished_warehouse_list', $data);
	 }
	public function add_finished_goods_warehouse()
	{
		//$data['item'] = $this->Sales_model->get_rows1();
		$data['title'] = 'Add Warehouse:: Leyland ';
		$this->load->view('add_finished_goods_warehouse', $data);
	}
	public function addfinisheddata()
	{
		$inps = $this->input->post();
		$arr = array(
		'part_no' => $inps['pa_no'],
		'qty' => $inps['qty'],
		'created_date' => date('Y-m-d H:i:s'),
		); 
		$this->db->insert('finished_goods_warehouse',$arr); 
		 echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Warehouse_stock/Finished_Goods_Ware_House')."'</script>";  
	}
	public function Inspection_Ware_House()
	 {
		$data['item'] = $this->Warehouse_model->get_inspection();
		$data['title'] = 'Warehouse List:: Leyland ';
		$this->load->view('inspection_warehouse_list', $data);
	 }
	public function add_warehouse_inspection()
	{
		//$data['item'] = $this->Sales_model->get_rows1();
		$data['title'] = 'Add Warehouse:: Leyland ';
		$this->load->view('add_warehouse_inspection', $data);
	}
	public function addinspectiondata()
	{
		$inps = $this->input->post();
		$arr = array(
		'part_no' => $inps['pa_no'],
		'qty' => $inps['qty'],
		'created_date' => date('Y-m-d H:i:s'),
		); 
		$this->db->insert('inspection_warehouse',$arr); 
		 echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Warehouse_stock/Inspection_Ware_House')."'</script>";  
	}
	public function Rejection_Ware_house()
	 {
		$data['item'] = $this->Warehouse_model->get_rejection();
		$data['title'] = 'Warehouse List:: Leyland ';
		$this->load->view('rejection_warehouse_list', $data);
	 }
	public function add_warehouse_rejection()
	{
		//$data['item'] = $this->Sales_model->get_rows1();
		$data['title'] = 'Add Warehouse:: Leyland ';
		$this->load->view('add_warehouse_rejection', $data);
	}
	public function addrejectiondata()
	{
		$inps = $this->input->post();
		$arr = array(
		'part_no' => $inps['pa_no'],
		'qty' => $inps['qty'],
		'created_date' => date('Y-m-d H:i:s'),
		); 
		$this->db->insert('rejection_warehouse',$arr); 
		 echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Warehouse_stock/Rejection_Ware_House')."'</script>";  
	}
}