<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Product extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  } 
		  	  
                $this->load->model('Product_model');
     }
	
	public function index(){
		$query['title'] = 'Product List :: Leyland ';
            $session_data = $this->session->all_userdata();
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');

		$query['product'] = $this->Product_model->get_products();
		$query['acc'] = $this->Product_model->get_accessories();
		
                
		$data['title'] = 'View All Products :: '.$ccompany;
		$this->load->view('productlist', $query);
	}
	
	public function addproduct()
	  {
        $data['title'] = 'Add products :: Leyland ';
	   	$this->load->view('productadd',$data);   
      }
	  public function addaccessories()
	  {
        $data['title'] = 'Add Accessories :: Leyland ';
	   	$this->load->view('productadd1',$data);   
      }

	public function adddata(){
		   $session_data = $this->session->all_userdata();
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');
				$rows_exist= '';
			if($this->input->post())
			{
				$inps = $this->input->post();
				$this->db->select('*');
				$this->db->where('i_name',$inps['i_name']);
				$this->db->where('descr',$inps['descr']);
				$rows = $this->db->get('tbl_product')->num_rows();
				if($rows!=0)
				{
					$rows_exist = 'yes';
					$data['i_name'] = 'Product Already Exist';
				}
			}
            $this->form_validation->set_rules('i_name', 'Product Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('part_no', 'Product Code', 'required|trim|xss_clean|is_unique[tbl_product.i_code]');
            $this->form_validation->set_rules('descr', 'Description', 'required|trim|xss_clean');
           // $this->form_validation->set_rules('age', 'Age', 'required|trim|numeric|xss_clean');
           // $this->form_validation->set_rules('vintage', 'Vintage', 'required|trim|xss_clean');
           // $this->form_validation->set_rules('strength', 'Strenth', 'required|trim|xss_clean');
           // $this->form_validation->set_rules('cbno', 'Cask Bottle No.', 'required|trim|numeric|xss_clean');
           // $this->form_validation->set_rules('min_qty', 'Minimum Quantity', 'required|is_natural|trim|xss_clean');
           // $this->form_validation->set_rules('max_qty', 'Maximum Quantity', 'required|is_natural|trim|xss_clean');

            if ($this->form_validation->run() == FALSE || $rows_exist == 'yes') { 
                $data['title'] = 'Add product :: '.$ccompany;
                 $this->load->view('productadd',$data);

                } else {
                    $muinput= $this->security->xss_clean($this->input->post());
                    $manage_category=$this->Product_model->add_product($muinput);
                    echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Product')."'</script>";

                }
	}
	public function addacc(){
		  $session_data = $this->session->all_userdata();
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');
				$rows_exist= '';
			if($this->input->post())
			{
				$inps = $this->input->post();
				$this->db->select('*');
				$this->db->where('pro_name',$inps['i_name']);
				$this->db->where('description',$inps['descr']);
				$rows = $this->db->get('tbl_accessories')->num_rows();
				if($rows!=0)
				{
					$rows_exist = 'yes';
					$data['i_name'] = 'Product Already Exist';
				}
			}
            $this->form_validation->set_rules('i_name', 'Product Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('descr', 'Description', 'required|trim|xss_clean');
           // $this->form_validation->set_rules('age', 'Age', 'required|trim|numeric|xss_clean');
           // $this->form_validation->set_rules('vintage', 'Vintage', 'required|trim|xss_clean');
           // $this->form_validation->set_rules('strength', 'Strenth', 'required|trim|xss_clean');
           // $this->form_validation->set_rules('cbno', 'Cask Bottle No.', 'required|trim|numeric|xss_clean');
           // $this->form_validation->set_rules('min_qty', 'Minimum Quantity', 'required|is_natural|trim|xss_clean');
           // $this->form_validation->set_rules('max_qty', 'Maximum Quantity', 'required|is_natural|trim|xss_clean');

            if ($this->form_validation->run() == FALSE || $rows_exist == 'yes') { 
                $data['title'] = 'Add Accessories :: '.$ccompany;
                 $this->load->view('productadd1',$data);

                } else {
                    $muinput= $this->security->xss_clean($this->input->post());
                    $manage_category=$this->Product_model->add_accessories($muinput);
                    echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Product')."'</script>";

                }
	}
	public function productedit($id){
		$data['title'] = 'Edit product :: Unicom ';
		$data['product']=$this->Product_model->edit_product($id);
		$this->load->view('productedit',$data);
	}
		
	public function editproduct($id){
            $session_data = $this->session->all_userdata();
			$rows_exist = '';
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');

            $original_value = $this->db->query("SELECT part_no FROM tbl_product WHERE i_id = ".$id)->row()->part_no;
            if($this->input->post('part_no') != $original_value) {
               $is_unique_icode =  '|is_unique[tbl_product.part_no]';
            } else {
               $is_unique_icode =  '';
            }
            $original_value_name = $this->db->query("SELECT i_name FROM tbl_product WHERE i_id = ".$id)->row()->i_name;
            if($this->input->post('i_name') != $original_value_name) {
               if($this->input->post())
				{
					$inps = $this->input->post();
					$this->db->select('*');
					$this->db->where('i_name',$inps['i_name']);
					$this->db->where('descr',$inps['descr']);
					$rows = $this->db->get('tbl_product')->num_rows();
					if($rows!=0)
					{
						$rows_exist = 'yes';
						$data['i_name'] = 'Product Already Exist';
					}
				}
            } else {
               $is_unique_icode_name =  '';
            }
			
            $this->form_validation->set_rules('i_name', 'Product Name', 'required|trim|xss_clean');
           $this->form_validation->set_rules('descr', 'Description', 'required|trim|xss_clean');
            //$this->form_validation->set_rules('age', 'Age', 'required|trim|numeric|xss_clean');
            //$this->form_validation->set_rules('vintage', 'Vintage', 'required|trim|xss_clean');
            //$this->form_validation->set_rules('strength', 'Strenth', 'required|trim|xss_clean');
            //$this->form_validation->set_rules('cbno', 'Cask Bottle No.', 'required|trim|numeric|xss_clean');
            //$this->form_validation->set_rules('min_qty', 'Minimum Quantity', 'required|is_natural|trim|xss_clean');
            //$this->form_validation->set_rules('max_qty', 'Maximum Quantity', 'required|is_natural|trim|xss_clean');


            if ($this->form_validation->run() == FALSE || $rows_exist == 'yes') { 
                $data['title'] = 'Edit product :: '.$ccompany;
                $data['product']=$this->Product_model->edit_product($id);
                $this->load->view('productedit',$data);
            } else {
                $muinput= $this->security->xss_clean($this->input->post());
                //echo '<pre>'; print_r($muinput); exit;
                $manage_category=$this->Product_model->update_product($id,$muinput);
				//exit;
                echo "<script> alert('Successfully Updated');window.location= '".base_url('index.php/Product')."'</script>";
            }
	}	
	public function editaccessories($id){
            $session_data = $this->session->all_userdata();
			$rows_exist = '';
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
			
                redirect('login', 'refresh');

            $original_value = $this->db->query("SELECT part_no FROM tbl_accessories WHERE acc_id = ".$id)->row()->part_no;
            if($this->input->post('part_no') != $original_value) {
               $is_unique_icode =  '|is_unique[tbl_accessories.part_no]';
            } else {
               $is_unique_icode =  '';
            }
            $original_value_name = $this->db->query("SELECT pro_name FROM tbl_accessories WHERE acc_id = ".$id)->row()->pro_name;
            if($this->input->post('accname') != $original_value_name) {
               if($this->input->post())
				{
					$inps = $this->input->post();
					$this->db->select('*');
					$this->db->where('pro_name',$inps['accname']);
					$this->db->where('description',$inps['descr']);
					$rows = $this->db->get('tbl_accessories')->num_rows();
					if($rows!=0)
					{
						$rows_exist = 'yes';
						$data['pro_name'] = 'Product Already Exist';
					}
				}
            } else {
               $is_unique_icode_name =  '';
            }
			
            $this->form_validation->set_rules('accname', 'Product Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('descr', 'Description', 'required|trim|xss_clean');
           if ($this->form_validation->run() == FALSE || $rows_exist == 'yes') { 
                $data['title'] = 'Edit accessories :: '.$ccompany;
                $data['product']=$this->Product_model->edit_acc($id);
                $this->load->view('productedit1',$data);
            } else {
                $muinput= $this->security->xss_clean($this->input->post());
                //echo '<pre>'; print_r($muinput); exit;
                $manage_category=$this->Product_model->update_acc($id,$muinput);
				//exit;
                echo "<script> alert('Successfully Updated');window.location= '".base_url('index.php/Product')."'</script>";
            }
	}	
        
	
	
	public function ajaxgetproduct() {
		$data['customer'] = $this->Product_model->get_rows_product();
		//echo '<pre>'; print_r($data['customer']); exit;
		echo json_encode($data['customer']);
	}
	

        public function viewproduct($id)
		{
         $data['title'] = 'View product :: Unicom ';
         $data['product']=$this->Product_model->view_product($id);
         $this->load->view('productview',$data);
	    }
		public function viewaccessories($id)
		{
         $data['title'] = 'View product :: Unicom ';
         $data['product']=$this->Product_model->view_acc($id);
         $this->load->view('productview1',$data);
	    }
		
	
	public function deleteproduct($id){		
		 $data['delete']=$this->Product_model->delete_product($id);
		 echo "<script> alert('Successfully Deleted');window.location= '".base_url('index.php/Product')."'</script>";

	}
	public function statuschange(){
		$data = array('id' => $this->input->post('id'),'st'=>$this->input->post('st'));
		$statuschange=$this->Product_model->statuschange($data);	
	}
	public function check_avail()
	{
		
	}
	
}
//echo '<pre>'; print_r(); exit;