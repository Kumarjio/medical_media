<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Product extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  } 
		  	  
                $this->load->model('Product_model');
     }
	
	public function index(){
            $session_data = $this->session->all_userdata();
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');

		$query = $this->Product_model->get_products();

		if($query){
			$data['product'] =  $query;
		} else {
			$data['product'] =  '';
		}
                
		$data['title'] = 'View All Products ::Arrow18 ';
		$this->load->view('productlist', $data);
	}
	
	public function productadd(){
            $session_data = $this->session->all_userdata();
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');
        $data['title'] = 'Add products ::Arrow18 ';
	   	$this->load->view('productadd',$data);   
        }

	public function adddata(){
            $session_data = $this->session->all_userdata();
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');
				$rows_exist= '';
			if($this->input->post())
			{
				$inps = $this->input->post();
				$this->db->select('*');
				$this->db->where('i_name',$inps['i_name']);
				$this->db->where('descr',$inps['descr']);
				$rows = $this->db->get('tbl_product')->num_rows();
				if($rows!=0)
				{
					$rows_exist = 'yes';
					$data['i_name'] = 'Product Already Exist';
				}
			}
            $this->form_validation->set_rules('i_name', 'Product Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('descr', 'Description', 'required|trim|xss_clean');
            
            if ($this->form_validation->run() == FALSE || $rows_exist == 'yes') { 
                $data['title'] = 'Add product :: Arrow18';
                 $this->load->view('productadd',$data);

                } else {
                    $muinput= $this->security->xss_clean($this->input->post());
                    $manage_category=$this->Product_model->add_product($muinput);
                    echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/Product')."'</script>";

                }
	}
	
	public function productedit($id){
		$data['title'] = 'Edit product :: Arrow18 ';
		$data['product']=$this->Product_model->edit_product($id);
		$this->load->view('productedit',$data);
	}
		
	public function editproduct($id){
            $session_data = $this->session->all_userdata();
			$rows_exist = '';
            if(isset($session_data['company_name'])) {
                    $ccompany = $session_data['company_name'];
            }
            else
                redirect('login', 'refresh');

           // $original_value = $this->db->query("SELECT i_code FROM tbl_product WHERE i_id = ".$id)->row()->i_code;
           /* if($this->input->post('i_code') != $original_value) {
               $is_unique_icode =  '|is_unique[tbl_product.i_code]';
            } else {
               $is_unique_icode =  '';
            }*/
            $original_value_name = $this->db->query("SELECT i_name FROM tbl_product WHERE i_id = ".$id)->row()->i_name;
            if($this->input->post('i_name') != $original_value_name) {
               if($this->input->post())
				{
					$inps = $this->input->post();
					$this->db->select('*');
					$this->db->where('i_name',$inps['i_name']);
					$this->db->where('descr',$inps['descr']);
					$rows = $this->db->get('tbl_product')->num_rows();
					if($rows!=0)
					{
						$rows_exist = 'yes';
						$data['i_name'] = 'Product Already Exist';
					}
				}
            } else {
               $is_unique_icode_name =  '';
            }
			
            $this->form_validation->set_rules('i_name', 'Product Name', 'required|trim|xss_clean');
            $this->form_validation->set_rules('descr', 'Description', 'required|trim|xss_clean');
            


            if ($this->form_validation->run() == FALSE || $rows_exist == 'yes') { 
                $data['title'] = 'Edit product :: '.$ccompany;
                $data['product']=$this->Product_model->edit_product($id);
                $this->load->view('productedit',$data);
            } else {
                $muinput= $this->security->xss_clean($this->input->post());
                //echo '<pre>'; print_r($muinput); exit;
                $manage_category=$this->Product_model->update_product($id,$muinput);
				//exit;
                echo "<script> alert('Successfully Updated');window.location= '".base_url('index.php/Product')."'</script>";
            }
	}	
        
	public function productadd_old(){
		$categoryQuery = $this->Masters_model->get_all_category();

		if($categoryQuery){
			$data['category'] =  $categoryQuery;
		} else {
			$data['category'] =  '';
		}
		$packingQuery = $this->Masters_model->get_all_packing();
		if($packingQuery){
			$data['packing'] =  $packingQuery;
		} else {
			$data['packing'] =  '';
		}
		$salestaxQuery = $this->Masters_model->get_all_salestax();
		if($salestaxQuery){
			$data['salestax'] =  $salestaxQuery;
		} else {
			$data['salestax'] =  '';
		}
		$purchasetaxQuery = $this->Masters_model->get_all_purchasetax();
		if($purchasetaxQuery){
			$data['purchasetax'] =  $purchasetaxQuery;
		} else {
			$data['purchasetax'] =  '';
		}
		$manufacturerQuery = $this->Manufacturer_model->get_all_manufacturer();
		if($manufacturerQuery){
			$data['manufacturer'] =  $manufacturerQuery;
		} else {
			$data['manufacturer'] =  '';
		}
		$data['title'] = 'Add products :: Unicom ';
	   	$this->load->view('productadd',$data);
		
	}
	
	public function ajaxgetproduct() {
		$data['customer'] = $this->Product_model->get_rows_product();
		//echo '<pre>'; print_r($data['customer']); exit;
		echo json_encode($data['customer']);
	}
	

        public function viewproduct($id){
         $data['title'] = 'View product :: Banyan ';
         $data['product']=$this->Product_model->view_product($id);
         $this->load->view('productview',$data);
	}
	
	public function deleteproduct($id){		
		 $data['delete']=$this->Product_model->delete_product($id);
		 echo "<script> alert('Successfully Deleted');window.location= '".base_url('index.php/Product')."'</script>";

	}
	public function statuschange(){
		$data = array('id' => $this->input->post('id'),'st'=>$this->input->post('st'));
		$statuschange=$this->Product_model->statuschange($data);	
	}
	public function check_avail()
	{
		
	}
	
}
//echo '<pre>'; print_r(); exit;