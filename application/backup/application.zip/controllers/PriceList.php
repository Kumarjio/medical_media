<?php defined('BASEPATH') OR exit('No direct script access allowed');
class PriceList extends CI_Controller {
	
	public function __construct(){
          parent::__construct();         
          //load the login model  
		  $session_data = $this->session->all_userdata();
		  if(empty($session_data)) {
			   redirect('login', 'refresh');
		  } 
		  	  
                $this->load->model('Pricelist_model');
     }
	
	public function index()
	{
       
        $data['title'] = 'View All Products ::Arrow18 ';
		$data['list'] = $this->Pricelist_model->get_prices();
		$data['get_storage'] = $this->Pricelist_model->get_storage();
		$this->load->view('pricelist', $data);
	}
	
	public function addrate()
	{
        $data['title'] = 'Add Products Rate ::  Arrow18 ';
		$data['get_product'] = $this->Pricelist_model->get_product();
		$data['get_storage'] = $this->Pricelist_model->get_storage();
       	$this->load->view('product_price_add',$data);   
    }

	public function addprice()
	{
		$inps = $this->input->post();
		if($inps['type']== 1)
		{
			$arr = array(
			'type'=>$inps['type'],
			'po_id'=>$inps['pname'],
			'price'=>$inps['price'],
			//'storage'=>$inps['sname'],
			'created_date'=>date('Y-m-d H:i:s'),
			);
		}
		else 
		{
			$arr = array(
			'type'=>$inps['type'],
			'po_id'=>$inps['pname1'],
			'price'=>$inps['price'],
			//'storage'=>$inps['sname'],
			'created_date'=>date('Y-m-d H:i:s')
			);
		}
			
		
		$this->db->insert('tbl_pricelist',$arr);
		echo "<script> alert('Successfully Added');window.location= '".base_url('index.php/PriceList')."'</script>";
		//redirect('PriceList',refresh);
	}
	
}
