<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <!-- Title and other stuffs -->
  <title><?php echo $title;  ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
 <link rel="stylesheet" type="text/css" id="theme" href="<?php echo base_url('assets/css/theme-default.css'); ?>"/>
 <!--<link href="<?php //echo base_url('assets/css/multiple-select.css'); ?>" rel="stylesheet">-->
  <link href="<?php echo base_url('assets/css/bootstrap-select.css'); ?>" rel="stylesheet">
<style>.chkscroll { border:2px solid #ccc; width:265px; height: 110px; overflow-y: scroll; padding-left:10px; }</style>
  <?php /*?><!-- Stylesheets -->
  <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <!-- Bootstrap Core CSS -->
	
         <!-- DataTimePicker CSS -->
        <link href="<?php echo base_url('assets/css/bootstrap-datetimepicker.min.css'); ?>" rel="stylesheet">
        <!-- Font awesome icon -->
        <link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet">
        <!-- CLEditor -->
        <link href="<?php echo base_url('assets/css/jquery.cleditor.css'); ?>" rel="stylesheet">
        <!-- DataTables CSS -->
        <link href="<?php echo base_url('assets/css/jquery.dataTables.css'); ?>" rel="stylesheet">
         <!-- Bootstrap toggle -->
        <link href="<?php echo base_url('assets/css/jquery.onoff.css'); ?>" rel="stylesheet">
        <!-- jQuery UI -->
        <link href="<?php echo base_url('assets/css/jquery-ui.css'); ?>" rel="stylesheet">
        <!-- prettyPhoto -->
        <link href="<?php echo base_url('assets/css/prettyPhoto.css'); ?>" rel="stylesheet">
         <!-- Star rating -->
        <link href="<?php echo base_url('assets/css/rateit.css'); ?>" rel="stylesheet">
         <!-- Main stylesheet -->
        <link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet">
         <!-- Widgets stylesheet -->
        <link href="<?php echo base_url('assets/css/widgets.css'); ?>" rel="stylesheet"><?php */?>
  
  <!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <![endif]-->

  <!-- Favicon -->
  <!--<link rel="shortcut icon" href="img/favicon/favicon.png">-->
  </head>
<body class="page-container-boxed">