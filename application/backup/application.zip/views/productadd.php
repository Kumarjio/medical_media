<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> <a href="<?php echo base_url('index.php/Product'); ?>">Manage Product</a></h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3 class="pull-left">Add Product</h3>
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Product/adddata');?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
<div class="col-md-6">

    <div class="form-group">                                        
        <label class="col-md-4 control-label">Product Name<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
                <input type="text" class="form-control uppercase" required placeholder="Enter Product Name"   name="i_name" id="i_name" value="<?php echo set_value('i_name');?>" />
            <div class="error" ><?php if(isset($i_name)){ echo $i_name;}else{ echo form_error('i_name');}  ?></div>                                               
        </div>
    </div>
<div class="form-group">                                        
        <label class="col-md-4 control-label">Product Type<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
        <?php $cs_master = $this->db->query("select * from pro_type")->result_array(); ?>
                                                	<select name="type" id="type" class="selectpicker form-control uppercase bs-select-hidden" required data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                                    <option disabled selected value="">Select Product Type</option>
                                                    <?php foreach($cs_master as $val) { ?>
                                                    <option value="<?=$val['id']?>"><?=$val['type_name']?></option>
                                                    <?php } ?>
                                                  </select>
        
               <?php /*?> <select class="selectpicker form-control  uppercase bs-select-hidden" name="type" id="type">
                <option value="1">Laptop</option>
                <option value="2">Mobile</option>
                </select>  <?php */?>                                          
        </div>
    </div>
    <?php /*?><div class="form-group ime" style="display:none">                                        
        <label class="col-md-4 control-label">IME NO<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
                <input type="text" required class="form-control uppercase" style="color:#000;"   placeholder="Enter IME NO" name="ime" id="ime" >
            <div class="error" ><?php echo form_error('i_code'); ?></div>                                               
        </div>
    </div><?php */?>
    <div class="form-group serial">                                        
        <label class="col-md-4 control-label">IME/Serial No<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
                <input type="text" required class="form-control uppercase" style="color:#000;"   placeholder="Enter IME/Serial No" name="serial" id="serial" >
            <div class="error" ><?php echo form_error('i_code'); ?></div>                                               
        </div>
    </div>
    <?php /*?><div class="form-group">                                        
        <label class="col-md-4 control-label">Product Code<sup  style="color:#f00"> * </sup> </label>
        <div class="col-md-6">
                <input type="text"  class="form-control uppercase" style="color:#000;"   placeholder="Enter Product Code" name="i_code" id="i_code" value="<?php echo set_value('i_code');  ?>">
            <div class="error" ><?php echo form_error('i_code'); ?></div>                                               
        </div>
    </div><?php */?>
    <div class="form-group">
        <label class="col-md-4 control-label">Description</label>  
        <div class="col-md-6">
            <textarea type="text"  class="form-control uppercase" placeholder="Enter Description" name="descr" id="descr"><?php echo set_value('descr');  ?></textarea>
            <span class="help-block"></span>
          <div class="error" ><?php echo form_error('descr'); ?></div>	
        </div>
    </div>
    
    
    <!--<div class="form-group" >
        <label class="col-md-4 control-label">Amount</label>  
        <div class="col-md-6">
            <input type="number" class="form-control uppercase" placeholder="Enter the Amount" name="amount" id="amount" />
          <div class="error" ><?php echo form_error('amount'); ?></div>	
        </div>
    </div>-->
    
</div>
 

    
</div>
                                        
</div>
                                    
<div class="form-group ">                                        
    <div class="btn-group pull-right col-md-12"><input class="btn btn-primary" value="Submit" type="submit">	
    </div>
</div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>
<script type="text/javascript">
/*function productDetails(id) {
		var res = id.substring(0,3)
		$.ajax({
			url:"<?php echo base_url('index.php/Product/ajaxgetproduct')?>",
			type: "post",
			data: { id: id },
			success: function(data) {
				//alert(data);
				var json = JSON.parse(data);
					last_id=parseInt(json[0].i_id)+1;
					//alert(res+parseInt(last_id));
				$("#i_code").val(res+parseInt(last_id));
			}
		});
	}*/
/*$('#type').on('change',function()
{
	var val = $(this).val();
	if(val == '1')
	{ 
		$('.serial').show();
		$('.ime').hide();
	}
	else
	{
		$('.serial').hide();
		$('.ime').show();
	}
});*/
</script>   

