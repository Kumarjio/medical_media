<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Pricelist</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading"> 
                               <?php /*?> <?php if($session_data['user_type']=='1'){?>
                                                    <a href="<?php echo base_url('index.php/Product/productadd'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Add Product</button></a>
                                                    <?php }?>  
                                                    <?php if($session_data['user_type']=='5'){?>
                                                   <a href="<?php echo base_url('index.php/Product/productadd'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Add Product</button></a>
                                                    <?php }?>                               
                                     <?php if($session_data['user_type']=='2'){?><?php */?>
                                                    <a href="<?php echo base_url('index.php/PriceList/addrate'); ?>"><button class="btn btn-primary"><span class="fa fa-plus"></span>Add Product Rate</button></a>
                                                   <?php /*?> <?php }?>  <?php */?>
                                    <ul class="panel-controls">
                                    <!--<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span></a></li>-->
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
                                        <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                                    </ul>                                
                                </div>
                                <div class="panel-body">
<div class="table-responsive">
    <table class="table datatable">
    <thead>
        <tr>
            <th width="37">S. No</th>
            <th width="80">Product Name</th>
             <th width="80">Product Type</th>
           <?php /*?> <th width="105">Product Code</th><?php */?>
            <th width="80">Product Description</th>
            <th width="58">Product Rate</th>
           <?php /*?> <th width="58">Storage</th>
             <th width="58">Amount</th>
           <th width="42">Status</th><?php */?>
           <?php /*?>  <?php if($session_data['user_type']=='1') {?>
                                                    <th>Action</th>
                                                    <?php } ?>
                                                    <?php if($session_data['user_type']=='2') {?>
                                                    <th>Action</th>
                                                    <?php } ?>
                                                    <?php if($session_data['user_type']=='5') {?>
                                                    <th>Action</th>
                                                    <?php /*?><?php } ?><?php */?>
        </tr>
    </thead>
        <tbody>
            <?php
                $sno=1;
                                            if(is_array($list) && count($list) ) {
                                                    foreach($list as $loop){
                                                            ?>
            <tr>
                    <td><?php echo $sno++; ?></td>
                     <td><?php echo $loop->i_name; ?>
                      <td><?php if($loop->type ==1){
						  echo "Laptop";}
						  else {
							  echo "Mobile";
						  }?>
                     <?php /*?><td><?php echo $loop->i_code; ?></td><?php */?>
                     <td><?php echo $loop->descr; ?></td>
                    <td><?php echo $loop->price; ?></td>
                     <?php /*?> <td>
					 <?php foreach($get_storage as $row){ 
					 if($loop->storage==$row->cid){
					 
                    echo $row->storage_name;
                     
                    }}?>
                   </td>
                    <td>
            <a href="<?php echo base_url('index.php/Product/viewproduct/'.$loop->i_id); ?>"><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><span class="fa fa-eye"></span></button></a>
            <?php if($session_data['user_type']=='5'){?>
                                                  
                                                 <a href="<?php echo base_url('index.php/Product/editproduct/'.$loop->i_id);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
                                                 
                                                 <?php }?>
                                                  <?php if($session_data['user_type']=='1'){?>
                                                  
                                                 <a href="<?php echo base_url('index.php/Product/editproduct/'.$loop->i_id);?>">                                                        <button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><span class="fa fa-pencil"></span></button></a>
                                                 
                                                 <?php }?>
            
           
           
            </td><?php */?>

            </tr>
                                                    <?php }} ?>
        </tbody>
    </table>
</div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
     
<script type="text/javascript">
	
</script>
</body>
</html>