<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
 <?php
if(isset($inps['pname']) && !empty($inps))
{
     $pname = $inps['pname'];
}
else
{
	$pname = '';
	
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span>Stocks List</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading"> 
                                <a href="<?php echo base_url('index.php/Stocklist/addStocks'); ?>">
                                    <button class="btn btn-primary"><span class="fa fa-plus"></span>Add Stocks</button></a> 
                                <?php /*?><form action="<?=$this->config->item('base_url')?>index.php/Stocklist" method="post" enctype="multipart/form-data" >
                                   <div class="col-md-12">
                                   
                                     <div class="col-md-3">
                                       <div class="form-group">
                                    <label class="col-md-4 control-label">Product Name</label>
                                        <div class="col-md-8">   
                                   <?php $pnames =  $this->db->select('*')->get('tbl_product')->result_array(); ?>
                            	
                                                        <input type="text" class="form-control" name="pname" id="pname" value="<?=$pname?>" >
                                        </div>
                                      </div>
                                     </div>
                                    <div class="col-md-3">
                                       <div class="form-group">
                                          <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div><div class="col-md-4">
                                          </div>
                                        </div>
                                      </div>
                                      
                                  </div>
                                 </form><?php */?>                                       
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                    <h3>Stocks In Godown</h3>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Product Id</th>
                                                    <th>Product Name</th>
                                                    <th>Product Type</th>
                                                    <th>Hands In Quantity</th>
                                                    <th>Purchase Rate</th>
                                                   <th>Storage Name</th>
                                                   
                                                </tr>
											</thead>
                                            <tbody>
                                        	 <?php $god = 0; if(is_array($list) && count($list) ) {
                                        $cnt=1;
                                            foreach($list as $post){ 
											 $god += $post['qty'];
											 ?>
											<tr>
                                            <td><?php echo $cnt++; ?></td>
												<td><?php echo 'PRO000'.$post['i_id']?></td>
												<td><?php echo $post['i_name']?></td>
												<td><?php if($post['i_category'] == '1')
												{
													echo 'Laptop';
												}
												else if($post['i_category'] == '2')
												{
													echo 'Mobile';
												}
												else if($post['i_category'] == '3')
												{
													echo 'TABLETS';
												}
												else if($post['i_category'] == '4')
												{
													echo 'SOFTWARE';
												}
												else if($post['i_category'] == '5')
												{
													echo 'ACCESSORIES';
												}
												
												?></td>
                                                <td><?php echo $post['qtys']?></td>
                                                <?php /*?><td style="font-size:18px"><?php if($post['min_qty'] > $post['qtys']){?><font color="#FF0000"><?=$post['qtys']?></font><?php } else if($post['min_qty'] <= $post['qtys'] && $post['max_qty'] >= $post['qtys']){?><font color="#0000FF"><?=$post['qtys']?></font><?php } else if($post['max_qty'] < $post['qtys']){?><font color="#009900"><?=$post['qtys']?></font><?php } ?></td><?php */?>
                                                <td><?php echo $post['p_rate']?></td>
                                                
												<td><?php echo $post['location']?></td>
												<!--<td>
                                                    <a href="<?php echo base_url('index.php/Employee/viewCustomer/'.$loop->admin_id); ?>"><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><i class="fa fa-eye"></i> </button></a>
                                                    <a href="<?php echo base_url('index.php/Employee/editCustomer1/'.$loop->admin_id); ?>"><button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><i class="fa fa-pencil"></i> </button></a>
                                                    
                                                </td>-->
											</tr>
											<?php }} ?>
										</tbody>
                                        </table>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
<script type="text/javascript">
	function fndelete(id) {
		var deletopt=confirm('Are you sure, do you want to delete this record?');
	  	if(deletopt)  {
			window.location =  '<?php echo base_url('index.php/Employee/deleteCustomer/')?>/'+id;
		    return true;
	  	}  else  {
		  	return false;
	  	}
	}
	
</script>
<script>
function chStatus(id,st){
		if(st == 1) {
		var chst = 0; //change status value
		}
		else {
		var chst = 1;	
		}
	//alert(chst);	
		jQuery.ajax({
			type: "POST",
			url: "<?php echo base_url(); ?>" + "index.php/Employee/statuschange",
			dataType: 'json',
			data: {id: id, st: chst},
			success: function(res) {
			if(res == 0) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			if(res == 1) {
				$("#statusspande"+id).hide();	
				$("#statusspan"+id).show();	
				
			}
			
				//console.log(res);
				
			}
		});
}


	<!------------------------Status Activate End----------------------------!>

	
</script>
</body>
</html>