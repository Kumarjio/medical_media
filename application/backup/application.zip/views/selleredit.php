<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Vendor</h2>
                </div>
                <!-- END PAGE TITLE -->                
		<?php $seller = $seller[0]; ?>
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3>Edit Vendor</h3>
                            
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Seller/updateSeller/'.$seller->cid);?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        


									<div class="col-md-6">
                                          
										  
										  
                                            <div class="form-group">
												<?php $query = $this->db->query("select cid from cb_seller")->num_rows(); ?>
                                                <label class="col-md-4 control-label">Seller ID</label>
                                                <div class="col-md-8">                                            
                                                    <input type="text" class="form-control uppercase" style="color:#000;" readonly name="seller_code" placeholder="Enter Seller Code" id="seller_code" value="<?php echo "VEN00".$seller->cid;  ?>">     
                                    			<div class="error" ><?php echo form_error('seller_code'); ?></div>                                       
                                                </div>
                                            </div>
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Vendor Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="seller_name"  placeholder="Enter Vandor Name"  id="seller_name" value="<?php echo $seller->seller_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('seller_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <?php /*?><div class="form-group">                                        
                                                <label class="col-md-4 control-label">Area Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase" name="area_name"  placeholder="Enter Area Name" id="seller_name" value="<?php echo $seller->area_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div><?php */?>
                                            	<div class="form-group">                                        
                                                <label class="col-md-4 control-label">Location</label>
                                                <div class="col-md-8">
                                                 <?php $loc = $this->db->select('*')->get('master_location')->result_array(); ?>
                                                	<select class="form-control select align-left" name="Location" required id="Location">
                                                   <?php foreach($head as $locval)
                                                    { ?>
                                                    <option <?=($seller->vendor_location == $locval->location_name)?'selected':''?> value="<?=$locval->location_name?>"><?=$locval->location_name?></option>
                                                        
                                                        <?php
                                                    }
                                                    ?>
                                                    </select>
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>										
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">City Name</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="city_name"  placeholder="Enter City Name" id="seller_name" value="<?php echo $seller->city_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>

                                           <div class="form-group" >                                        
                                                <label class="col-md-4 control-label">State</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="state_name"  placeholder="Enter Seller Name" id="seller_name" value="<?php echo $seller->state_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Country</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="country_name"  placeholder="Enter Country" id="seller_name" value="<?php echo $seller->country_name;  ?>">   
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Tin No</label>
                                                <div class="col-md-8">
                                                	<input type="number"  class="form-control"  name="tin_no"  placeholder="Enter Tin No" id="tin_no" value="<?php echo  $seller->tin_no;  ?>">
                                               </div>
                                            </div>
                                      </div>
									  <div class="col-md-6">                                            											
                                           
                                           
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Zipcode</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="pincode"  placeholder="Enter ZipCode" id="seller_name" value="<?php echo $seller->pincode;  ?>">   
                                                    <div class="error" ><?php echo form_error('pincode'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Tele Phone</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="telephone"  placeholder="Enter Tele Phone" id="telephone" value="<?php echo  $seller->telephone;  ?>">
                                                    <div class="error" ><?php echo form_error('telephone'); ?></div>                                               
                                                </div>
                                            </div> 	
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Email</label>
                                                <div class="col-md-8">
                                                	<input type="email" class="form-control"  name="email"  placeholder="Enter Email" id="email" value="<?php echo  $seller->email;  ?>">
                                                    <div class="error" ><?php echo form_error('email'); ?></div>                                               
                                                </div>
                                            </div>	
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Credit Days</label>
                                                <div class="col-md-8">
                                                	<input type="number"  class="form-control"  name="days"  placeholder="Enter Total Credit Days" id="days" value="<?php echo  $seller->credit_days;  ?>">
                                               </div>
                                            </div>
                                            											
                                          <div class="form-group">                                        
                                                <label class="col-md-4 control-label">CST No</label>
                                                <div class="col-md-8">
                                                	<input type="number"  class="form-control"  name="cst_no"  placeholder="Enter CST No" id="cst_no" value="<?php echo  $seller->cst_no;  ?>">
                                               </div>
                                            </div>
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Service Tax</label>
                                                <div class="col-md-8">
                                                	<input type="number"  class="form-control"  name="service_tax"  placeholder="Enter Service Tax" id="service_tax" value="<?php echo  $seller->service_tax;  ?>">
                                               </div>
                                            </div>
                                            
                                            											

                                           
                                            
                                          
                                            
                                            
                                            
                                          	<div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                                            <input class="btn btn-primary" value="Submit" type="submit" name="submit">
</div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>										
										
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

<script type="text/javascript">
    function custrDetails(id) {
		var res = id.substring(0,3)
		var seller_code=$('#seller_code').val();
		var res_c = seller_code.substring(3)
		$("#seller_code").val(res+res_c);
		
	}
</script>

       
 <script type="text/javascript">
          /*  var jvalidate = $("#jvalidate").validate({
                ignore: [],
                rules: { 
						phone_no: {
                               required : true
                        },
						phone_no_one: {
                              required : true 
                        },
						email_id: {
                                required : true
                        },
						email_id_one: {
							required : true
                               
                        },
						fax: {
							required : true
                               
                        },
						to_add: {
							required : true,
							min: 0,
							max: 99.99
						}
                                                         
                       
                    }                                        
                });    */                                

        </script>
