<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2><span class="fa fa-arrow-circle-o-left"></span> Manage Customer</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-body">
                                <h3>Add Customer</h3>
                            
                            <form class="form-horizontal" id="jvalidate" role="form" action="<?php echo base_url('index.php/Customer/addCustomer');?>" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">
                                          
										  
										  
                                            <div class="form-group">
												<?php $query = $this->db->query("select cid from cb_customer order by cid desc")->result_array(); ?>
                                                <label class="col-md-4 control-label">Customer Code<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">                                            
                                                    <input type="text" class="form-control uppercase" style="color:#000;" readonly name="customer_code" placeholder="Enter Customer Code" id="customer_code" value="<?php echo "CUS00".$n=$query[0]['cid']+1;;  ?>">     
                                    			<div class="error" ><?php echo form_error('customer_code'); ?></div>                                       
                                                </div>
                                            </div>
                                            
                                            <?php /*?><div class="form-group">                                        
                                                <label class="col-md-4 control-label">Customer Type<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                <?php $cs_master = $this->db->query("select * from cb_customer_master")->result_array(); ?>
                                                	<select name="cus_type" id="cus_type" class="selectpicker form-control uppercase bs-select-hidden"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                                    <option disabled selected value="">Select Customer Type</option>
                                                    <?php foreach($head as $val) { ?>
                                                    <option value="<?=$val->id?>"><?=$val->type_name?></option>
                                                    <?php } ?>
                                                  </select>
                                                    <div class="error" ><?php echo form_error(''); ?></div>                                               
                                                </div>
                                            </div><?php */?>
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Customer Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="customer_name"  placeholder="Enter Customer Name" id="customer_name" value="<?php echo set_value('customer_name');  ?>">
                                                    <div class="error" ><?php echo form_error('customer_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Mobile No1<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="mob_no1"  placeholder="Enter Mobile No" id="mob_no" >
                                                    <div class="error" ><?php echo form_error('mob_no1'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                            
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Landline No</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="land_no"  placeholder="Enter Contact No" id="mob_no" >
                                                    <div class="error" ><?php echo form_error('land_no'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Email Id</label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="email"  placeholder="Enter Email Id" id="customer_name" value="<?php echo set_value('email');  ?>">
                                                    <div class="error" > <?php if( form_error('email') == '<p>The Email Id field must contain a unique value.</p>' ){ echo 'This Email ID Already Exist for an another customer';}else{ echo form_error('email');} ?></div>                                               
                                                </div>
                                            </div>
                                          <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Area Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase" name="area_name"  placeholder="Enter Area Name" required id="customer_name" value="<?php echo set_value('area_name');  ?>">
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div>
                                      </div>
									  <div class="col-md-6">    
                                      
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">City Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="city_name"  placeholder="Enter City Name" required id="customer_name" value="<?php echo set_value('city_name');  ?>">
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>

                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">State<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="state_name"  placeholder="Enter State Name" required id="customer_name" value="<?php echo set_value('state_name');  ?>">
                                                    <div class="error" ><?php echo form_error('state_name'); ?></div>                                               
                                                </div>
                                            </div>                                        											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Country<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="text" class="form-control uppercase"  name="country_name"  placeholder="Enter Country Name" required id="customer_name" value="<?php echo set_value('country_name');  ?>">
                                                    <div class="error" ><?php echo form_error('country_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Pincode<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="number" class="form-control uppercase"  name="pincode"  placeholder="Enter Pincode" required id="customer_name" value="<?php echo set_value('pincode');  ?>">
                                                    <div class="error" ><?php echo form_error('pincode'); ?></div>                                               
                                                </div>
                                            </div>
                                            											
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">NO.Of Credit Days<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                	<input type="number" class="form-control uppercase"  name="days"  placeholder="Enter NO.Of Credit Days" id="days" >
                                                 </div>
                                            </div>
                                           
                                            
                                          
                                            
                                            
                                            
                                          	<div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                                           <input class="btn btn-primary" value="Submit" type="submit" name="submit">
                                                
</div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>
                                      </div>
                                        
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
                             </div>
                        </div>
                

                    
                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
    
        
     
</body>
</html>
     <?php $this->load->view('include_js'); ?>

