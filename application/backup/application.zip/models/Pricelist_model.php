<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pricelist_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    
	 function get_prices(){
		$this->db->select('tbl_pricelist.*');
		$this->db->select('tbl_product.*');
		$this->db->select('cb_storage.*');
		
		$this->db->join('tbl_product','tbl_product.i_id=tbl_pricelist.po_id','left');
		$this->db->join('cb_storage','cb_storage.storage_name=tbl_pricelist.storage','left');
		//$this->db->order_by('id','desc');		
		//$this->db->where('is_delete =', 0);
        $query = $this->db->get('tbl_pricelist');	
		return $query->result();			
	 }
	  function get_product()
	  {
		 $this->db->select('*')->from('tbl_product');
		 $query = $this->db->get();		
         return $query->result();			
	  }
 function get_storage()
      {
		 $this->db->select('*')->from('cb_storage');
		 $query = $this->db->get();		
         return $query->result();			
	 }

}