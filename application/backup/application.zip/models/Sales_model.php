<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
//Public Functions
	 /**function get_rows($table,$fields,$where = NULL){
		if(!$where) {  $where = 'is_delete = 0'; }
		$this->db->select($fields)->from($cb_customer)->where($where);
        $query = $this->db->get();		
		return $query->result();	
		*/
		function get_rows(){
			$session_data = $this->session->all_userdata();	
		$this->db->select('cb_customer.*');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('location',$session_data['location']);
			}*/
		// $this->db->where('cb_customer.location',$session_data['location']);
		$this->db->from('cb_customer');
        $query = $this->db->get();	
		return $query->result_array();			
	 }	
	 function get_expenses(){
			$session_data = $this->session->all_userdata();	
		$this->db->select('expenses_master.*');
		$this->db->from('expenses_master');
        $query = $this->db->get();	
		return $query->result_array();			
	 }
	 function get_all_pro(){
			$session_data = $this->session->all_userdata();	
		$this->db->select('purchase_product.*');
		$this->db->select('tbl_product.*');
		$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		//$this->db->from('tbl_product');
        $query = $this->db->get('purchase_product');	
		return $query->result_array();			
	 }	
	 function get_pro_rows($inps){
			$session_data = $this->session->all_userdata();	
		$this->db->select('purchase_product.*');
		$this->db->select('tbl_product.*');
		$this->db->where('tbl_product.i_id',$inps['cus']);
		$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		//$this->db->from('tbl_product');
        $query = $this->db->get('purchase_product');	
		return $query->result_array();			
	 }	
	 function get_seller_rows1($inps){ 
	  $session_data = $this->session->all_userdata();
	 // $arr =array('4');
	    $this->db->select('product_total_allocation.*,product_total_allocation.admin_id');
		$this->db->select('cp_admin_login.name,cp_admin_login.admin_id as ids');
		$this->db->select('tbl_product.i_name,i_category,i_id');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cp_admin_login.employee_location',$session_data['location']);
			}*/
		
		$this->db->join('cp_admin_login','product_total_allocation.admin_id = cp_admin_login.admin_id','left');
		$this->db->join('tbl_product','product_total_allocation.tbl_product_id = tbl_product.i_id','left');
		$this->db->group_by('product_total_allocation.tbl_product_id');
		//$this->db->where_in('qty >=',0);
		$this->db->where('product_total_allocation.admin_id',$inps['cus']);
		
		$query = $this->db->get('product_total_allocation');	
		return $query->result_array();
	 }
	 function get_seller_rows(){ 
	  $session_data = $this->session->all_userdata();
	  $arr =array('4');
	    $this->db->select('product_total_allocation.*');
		$this->db->select('cp_admin_login.name,cp_admin_login.admin_id as ids');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cp_admin_login.employee_location',$session_data['location']);
			}*/
		$this->db->join('cp_admin_login','product_total_allocation.admin_id = cp_admin_login.admin_id','left');
		$this->db->group_by('product_total_allocation.admin_id');
		$this->db->where_in('user_type',$arr);
		$query = $this->db->get('product_total_allocation');	
		return $query->result_array();
	 }
	 function get_seller_rows_paym(){ 
	  $session_data = $this->session->all_userdata();
	  $arr =array('3','4');
	    $this->db->select('*');
		$this->db->from('cp_admin_login');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cp_admin_login.employee_location',$session_data['location']);
			}
		*/
		$this->db->where_in('user_type',$arr);
		$query = $this->db->get();	
		return $query->result_array();
	 }
	 function get_technician_rows(){ 
	 $session_data = $this->session->all_userdata();
	    $arr =array('3');
		$this->db->select('product_total_allocation.*');
		$this->db->select('cp_admin_login.name,cp_admin_login.admin_id as ids');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cp_admin_login.employee_location',$session_data['location']);
			}*/
		$this->db->join('cp_admin_login','product_total_allocation.admin_id = cp_admin_login.admin_id','left');
		$this->db->group_by('product_total_allocation.admin_id');
		$this->db->where_in('user_type',$arr);
		$query = $this->db->get('product_total_allocation');	
		return $query->result_array();
	 }
	 function get_cus_det($inps)
	 {
		$this->db->select('*');
		$this->db->where('cid',$inps['cus']);
		$query = $this->db->get('cb_customer')->result_array();
		//echo $this->db->last_query();
		return $query;
	 }
	 
	 function get_rowsdet(){
		$this->db->select('*');
		$this->db->from('cb_customer');
		$this->db->where('cid',$_POST['id']);
        $query = $this->db->get();	
		return $query->result_array();			
	 }	 
	 function get_rows1()
	 {
		 $session_data = $this->session->all_userdata();	
		$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('i_category','1');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('tbl_product.employees_location',$session_data['location']);
			}*/
        $query = $this->db->get();	
		return $query->result_array();				
	 }	
	 function get_rows2()
	 {
		$session_data = $this->session->all_userdata();	
		$this->db->select('purchase_product.*,tbl_product.i_id,tbl_product.i_name,i_category');
		$this->db->from('purchase_product');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('tbl_product.employees_location',$session_data['location']);
			}*/
	    $this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		$this->db->where('tbl_product.i_category','2');
        $query = $this->db->get();	
		return $query->result_array(); 
		 
					
	 }	
	 
	  function get_rows3()
	 {
		$session_data = $this->session->all_userdata();	
		$this->db->select('purchase_product.*,tbl_product.i_id,tbl_product.i_name,i_category');
		$this->db->from('purchase_product');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('purchase_product.location',$session_data['location']);
			}*/
	    $this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		$this->db->where('tbl_product.i_category','1');
        $query = $this->db->get();	
		return $query->result_array(); 
		 
					
	 }	
	 function get_rows_groupby($table,$fields,$where = NULL, $groupby) {
		if(!$where) {  $where = 'is_delete = 0'; }
		$this->db->select($fields)->from($table)
		 ->where($where);
		 $this->db->group_by($groupby);
		 $query = $this->db->get();
		 return $query->result();		 
	 }
	 
//Public Functions	 
	  function get_all_employee()
	 {
		$session_data = $this->session->all_userdata();	
		$arr =array('3','4');
		$this->db->select('product_allocation.*');
		$this->db->select('cp_admin_login.name,cp_admin_login.admin_id as ids');
		$this->db->select('tbl_product.*');
		/*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cp_admin_login.employee_location',$session_data['location']);
			}*/
		
		$this->db->join('cp_admin_login','product_allocation.admin_id = cp_admin_login.admin_id','left');
		$this->db->join('tbl_product','tbl_product.i_id = product_allocation.tbl_product_id','left');
		$this->db->group_by('product_allocation.admin_id');
		$this->db->where_in('user_type',$arr);
		$this->db->where('tbl_product.i_category=',1);
		//$this->db->where('user_type =',4);		
        $query = $this->db->get('product_allocation');	
		//echo $this->db->last_query();	
		return $query->result();			
	 }
	  function get_instal_id()
	 {
		/** $this->db->select('*');
		 $this->db->select('cb_customer.customer_name');
		 $this->db->select('products.prod_name');
		 if(!empty($inps))
		 {
		 	$this->db->where('customer_code',$inps['cus_code']);
		 }
		 $this->db->join('cb_customer','cb_customer.cid = tbl_installation.customer_code','left');
		 $this->db->join('products','products.id = tbl_installation.product_id','left');
		 $query = $this->db->get('tbl_installation')->result_array();
		 return $query;
		 */
		 $session_data = $this->session->all_userdata();	
		 $this->db->select('tbl_sales.*');
		 $this->db->select('cb_customer.customer_name,cb_customer.cid as ids,mob_no1');
		// $this->db->where('tbl_sales.s_no=',$inps['inst_id']);
		 $this->db->join('cb_customer','cb_customer.cid=tbl_sales.customer_code','left');
		  /*if($session_data['user_type'] !=  5)
		    {
				$this->db->where('location',$session_data['location']);
			}*/
		 $query = $this->db->get('tbl_sales')->result_array();
		 return $query;
	 }
	 
    function getDetails_cus($itemid, $cus_id, $batch_no) {
		
		$where = array('tbl_po_inv_item.item_code'=>$itemid,'tbl_po_inv_item.batch_no'=>$batch_no);
		$this->db->select('exp_date,batch_no,s_price,qty,selling_price, selling_percentage,s_tax')->from('tbl_po_inv_item')
		->join('tbl_partywiserate', 'tbl_partywiserate.item_code = tbl_po_inv_item.item_code', 'left')
		->where($where);
		// $this->db->group_by('batch_no'); selling_price,selling_percentage
		$query = $this->db->get();
		//return $this->db->last_query();
		return $query->result();	
		 
	 }
	 public function qtyCheck($item_code, $batch_no)
	{
		$pur_qty = $this->db->query('select qty as pur_qty from tbl_po_inv_item where item_code="'.$item_code.'" and  batch_no="'.$batch_no.'" ')->row()->pur_qty;
		 $ret_qty = $this->db->query('select sum(qty) as ret_qty from tbl_po_return_item where item_id="'.$item_code.'" and  batch_no="'.$batch_no.'"');
		 $num_rows = $ret_qty->num_rows();
		 if($num_rows > 0) {
			return $pur_qty - ($ret_qty->row()->ret_qty);
		 }
		 else {
			 return $pur_qty;
		 }
	}
	 
	 function getDetails($itemid, $batch_no) {
		 
		
		 $where = array('item_code'=>$itemid, 'batch_no'=>$batch_no);
		 $this->db->select('exp_date')->from('tbl_po_inv_item')
		 ->where($where);
		 $query2 = $this->db->get();
		 return $query2->result();		 
	 }
	 
	
	 
    
	
	  function add_sales_entry($post) {
		  extract($post);
		//  echo '<pre>'; print_r($post);exit;
		  $created_date=date('Y-m-d h:i:s');
		 
				     $array115 = array(
				  	'bill_no'=>$bill_no,'customer_code'=>$cus_code,'remarks'=>$remarks,'total_amount'=>$gtotal,'created_date'=>$created_date,'sales_status'=>1,'cst'=>$cst,'pan'=>$pan,'service_tax'=>$service_tax,'tin'=>$tin,'vendor_name'=>$vendor_name);
					 // echo '<pre>'; print_r($array115);exit;'expenses_type'=>$expenses
					$this->db->insert('tbl_sales',$array115);
					$insert_id = $this->db->insert_id();
		          
	     
		  for($i = 0; $i < count($item_name1); $i++) 
		  
		  {
			  
			      
				 
				  if($payment_method[$i] == 1)
				  {
					  $array1=array('tbl_sales_id'=>$insert_id,'discount'=>$discount,'tbl_product_id'=>$item_name1[$i],'serial_no'=>$seriel_no[$i],'model'=>$model_no[$i],'ime_no'=>$ime_no[$i],'sales_price'=>$purrate[$i],'quantity'=>$qty[$i],'pro_type'=>$payment_method[$i],'total_value'=>$gtotal,'tax_amt'=>$taxamount,'created_date'=>$created_date,'pro_type'=>$payment_method[$i],'si_status'=>1);
				  }
				  else
				  {
					 $array1=array('tbl_sales_id'=>$insert_id,'discount'=>$discount,'tbl_product_id'=>$item_name2[$i],'serial_no'=>$seriel_no[$i],'model'=>$model_no[$i],'ime_no'=>$ime_no[$i],'sales_price'=>$purrate[$i],'quantity'=>$qty[$i],'pro_type'=>$payment_method[$i],'total_value'=>$gtotal,'tax_amt'=>$taxamount,'created_date'=>$created_date,'pro_type'=>$payment_method[$i],'si_status'=>1);
				  }
		     //echo "<pre>";print_r($array);exit;'instcharges'=>$adcharges,'delivery'=>$addelivery,'freight'=>$freight,'discount'=>$discount,'serivcetax_amt'=>$serivcetax_amt,'serivcetax'=>$serivcetax,'commissioning'=>$commissioning,
			 $this->db->insert('tbl_sales_items',$array1);
			 
		   if($payment_method[$i] == 1)
			 {
				    $var1 = $this->db->select('qty,tbl_product_id')->where('tbl_product_id',$item_name1[$i])->get('purchase_product')->result_array();
							//echo '<pre>'; print_r($var1);exit;
							$proarray1 = array(
							'qty'  =>$var1[0]['qty']-$qty[$i],
							 );
			
							$this->db->where('tbl_product_id',$item_name1[$i]);
							$this->db->update('purchase_product',$proarray1);
			  }
			 else
			  {
					  $var3 = $this->db->select('qty,tbl_product_id')->where('tbl_product_id',$item_name2[$i])->get('purchase_product')->result_array();
							//echo '<pre>'; print_r($var1);exit;
							$proarray3 = array(
							'qty'  =>$var3[0]['qty']-$qty[$i],
							 );
			
							$this->db->where('tbl_product_id',$item_name2[$i]);
							$this->db->update('purchase_product',$proarray3);
		       }
		 
	   }
		  
		 		  $ins_ary = array('sales_id'=>$bill_no,'customer_code'=>$cus_code,'total_amount'=>$gtotal,'created_date'=>date('Y-m-d H:i:s'));
			$this->db->insert('tbl_invoice',$ins_ary);
			$invoice_id = $this->db->insert_id();
			//echo $this->db->last_query(); exit;
		return $invoice_id;
	}
	
	function sales_data($id) {
		$array = array('tbl_sales.s_no' => $id);		
		$this->db->select('tbl_sales.*,tbl_customer.c_code,tbl_customer.c_name,tbl_customer.address1,tbl_customer.address2')->from('tbl_sales')
	    ->join('tbl_customer','tbl_customer.c_id=tbl_sales.customer_code','left')
		 ->where($array); 
		$query = $this->db->get();		
		return $query->result();	 
	 }
	 
	  
	  function sales_item_data($id) {
		$array = array('tbl_sales_items.tbl_sales_id' => $id);		
		$this->db->select('tbl_sales_items.*, tbl_item.i_code')->from('tbl_sales_items')
		->join('tbl_item', 'tbl_item.i_id = tbl_sales_items.tbl_product_id', 'left')
         ->where($array); 
		$query = $this->db->get();		
		return $query->result();	 
	 }
	
	  public function sales_confirm($id)
	{
		$array=array('sales_confirm'=>1);	
	    $this->db->set($array);
	    $this->db->where('s_no',$id);
		$this->db->update('tbl_sales',$array);
		return true;
	}
	public function sales_cancel($id)
	{
		$this->db->where('s_id', $id);
   		$this->db->delete('tbl_sales_items');
		$this->db->where('s_no', $id);
   		$this->db->delete('tbl_sales');
		return true;
	}
	
	 
	  
	  
//******************************************************************Sales return starts here**********************************************************************//
	
  		function getSalesItems($c_id) {
		 $this->db->select('i_name, i_id')->from('tbl_sales_items as A')
		 ->join('tbl_sales as B', '`B`.`s_no` = `A`.`s_id`', 'LEFT')
		 ->join('tbl_item as C', '`C`.`i_id` = `A`.`item_code`', 'LEFT')
		 ->where('B.customer_code', $c_id);
		$this->db->group_by('i_id');
		$query = $this->db->get();
		 //$items = array();
		//return $this->db->last_query();
		 return $query->result();	
			
		}
	  
	   
	 
	 
	 function getSalesBatch($itemid, $c_id) {
		 $where = array('customer_code'=>$c_id, 'item_code'=>$itemid);
		 $this->db->select('batch')->from('tbl_sales_items')
		 ->join('tbl_sales', '`tbl_sales`.`s_no` = `tbl_sales_items`.`s_id`', 'LEFT')
		 ->where($where);
		 $this->db->group_by('batch');
		 $query = $this->db->get();
		 //return $this->db->last_query();
		 return $query->result();		 
	 }
	 function getSalesDetails($itemid, $c_id, $batch_no) {
		 $where = array('customer_code'=>$c_id, 'item_code'=>$itemid, 'batch'=>$batch_no);
		 $this->db->select('expiry, sales_price')->from('tbl_sales_items')
		 ->join('tbl_sales', '`tbl_sales`.`s_no` = `tbl_sales_items`.`s_id`', 'LEFT')
		 ->where($where);
		 $query = $this->db->get();
		 //return $this->db->last_query();
		 return $query->result();		 
	 }
	 public function qtySalesCheck($item_code, $batch_no)
	{
		$sal_qty = $this->db->query('select quantity as sal_qty from tbl_sales_items where item_code="'.$item_code.'" and  batch="'.$batch_no.'" ')->row()->sal_qty;
		 $ret_qty = $this->db->query('select sum(qty) as ret_qty from tbl_sales_return_items where item_name="'.$item_code.'" and  batch="'.$batch_no.'"');
		 $num_rows = $ret_qty->num_rows();
		 if($num_rows > 0) {
			return $sal_qty - ($ret_qty->row()->ret_qty);
		 }
		 else {
			 return $sal_qty;
		 }
		 
		

	}
	  function add_sales_return($post) {
		  extract($_REQUEST);
		  $created_date=date('Y-m-d h:i:s');
		  $array=array('cus_id'=>$c_name, 'return_date'=>$return_date, 'tot_amount'=>$gtotal, 'remarks'=>$remarks, 'date'=>$created_date,'status'=>1);
		  $this->db->set($array);
	    $this->db->insert('tbl_sales_return',$array);
		$insert_id = $this->db->insert_id();
		//$itemname one of the varible array
		for($i = 0; $i < count($item_name); $i++) {
			 $array=array('sr_id'=>$insert_id,'item_name'=>$item_name[$i],'batch'=>$batch[$i],'expiry'=>$expiry[$i],'type'=>$r_type[$i],'qty'=>$qty[$i],'price'=>$price[$i],'discount'=>$disc[$i],'value'=>$total[$i],'date'=>$created_date,'status'=>1);
		  $this->db->set($array);
	    $this->db->insert('tbl_sales_return_items',$array);
		}
		  
	  }
//******************************************************************Sales return ends here**********************************************************************//

//******************************************************************Sales payment starts here**********************************************************************//
	  
	  function rupeestowords1($number)
	{
		//$number = 190908100.25;
	
	   $no = round($number);
	   $point = round($number - $no, 2) * 100;
	   $hundred = null;
	   $digits_1 = strlen($no);
	   $i = 0;
	   $str = array();
	   $words = array('0' => '', '1' => 'one', '2' => 'two',
		'3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
		'7' => 'seven', '8' => 'eight', '9' => 'nine',
		'10' => 'ten', '11' => 'eleven', '12' => 'twelve',
		'13' => 'thirteen', '14' => 'fourteen',
		'15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
		'18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
		'30' => 'thirty', '40' => 'forty', '50' => 'fifty',
		'60' => 'sixty', '70' => 'seventy',
		'80' => 'eighty', '90' => 'ninety');
	   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
	   
	   while ($i < $digits_1) {
		 $divider = ($i == 2) ? 10 : 100;
		 $number = floor($no % $divider);
		 $no = floor($no / $divider);
		 $i += ($divider == 10) ? 1 : 2;
		 if ($number) {
			$plural = (($counter = count($str)) && $number > 9) ? 's' : null;
			$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
			$str [] = ($number < 21) ? $words[$number] .
				" " . $digits[$counter] . $plural . " " . $hundred
				:
				$words[floor($number / 10) * 10]
				. " " . $words[$number % 10] . " "
				. $digits[$counter] . $plural . " " . $hundred;
		 } else $str[] = null;
	  }
	  
	  $str = array_reverse($str);
	  $result = implode('', $str);
	  $points = ($point) ?
		" point " . $words[$point / 10] . " " . 
			  $words[$point = $point % 10] : '';
	  
	  if($result!='')
	  {
		  $ret1 =  "Rupees ".$result ." ";
	  }
	  else
	  {
		  $ret1 =  "Rupee Zero ";
	  }
	  if($points != '')
			  $ret1= $ret1. $points . " Paise";
	  //$ret1.=' Only';
	  
	  $ret1 = ucwords($ret1);
	  return $ret1.' Only/-';
	 
	}
	  function get_sales_pending_amount($customer_id){
		  //return $customer_id;
		 $tot_amount = $this->db->query('select sum(total_amount) as tot_amounts from tbl_sales where customer_code ="'.$customer_id.'"')->row()->tot_amounts;
		 $paid_amount = $this->db->query('select sum(r_amount) as r_amount from tbl_sales_payment where customer_id="'.$customer_id.'"');
		 $num_rows = $paid_amount->num_rows();
		 if($num_rows > 0) {
			return $tot_amount - ($paid_amount->row()->r_amount);
		 }
		 else {
			 return $tot_amount;
		 }
	  }
	  function get_sales_invoices($cus_id) {
		 /* SELECT A.bill_no, A.created_date, A.total_amount,  sum(paid_amount) as total from tbl_sales as A left join tbl_sales_payment_details on A.s_no = tbl_sales_payment_details.s_id  where customer_code  = 1 
 group by A.s_no HAVING  total is null OR total < total_amount*/
 $created_date=date('Y-m-d h:i:s');
		  $query = $this->db->query('SELECT A.bill_no, A.created_date, DATEDIFF( "'.$created_date.'" , A.created_date ) AS days, A.s_no, A.total_amount,  sum(paid_amount) as total from tbl_sales as A left join tbl_sales_payment_details on A.s_no = tbl_sales_payment_details.s_id  where customer_code  = "'.$cus_id.'" 
 group by A.s_no HAVING  total is null OR total < total_amount');
 		//return $query->db->last_query();
		return $query->result();
	  }
	   function getInvoicedbysearch($inps)
	 {
		 $this->db->select('tbl_invoice.*');
		 $this->db->select('cb_customer.customer_name');
		 $this->db->where('tbl_invoice.s_no=',$inps['id']);
		 $this->db->join('cb_customer','tbl_invoice.customer_code=cb_customer.cid','left');
		 $query = $this->db->get('tbl_invoice')->result_array();
		 return $query;
		 
	    $query = $this->db->get('tbl_invoice')->result_array();
		 //echo '<pre>'; print_r($query); exit;
		 return $query;
	 }
	 function getInvoicedbysearch1($inps){
	    $session_data = $this->session->all_userdata();	
		$this->db->select('*');
		$this->db->from('tbl_invoice_payment');
        $query = $this->db->get();	
		return $query->result_array();	
		 /**$this->db->select('tbl_invoice.*');
		 $this->db->select('tbl_invoice_payment.tbl_invoice_id,paid_amt');
		 $this->db->where('tbl_invoice.s_no=',$inps['id']);
		 $this->db->join('tbl_invoice_payment','tbl_invoice_payment.customer_code=cb_customer.cid','left');
		 $query = $this->db->get('tbl_invoice')->result_array();*/		
	 }	 
	  function getInvoiced()
	 {
		 $session_data = $this->session->all_userdata();
		 $this->db->select('tbl_invoice.*');
		 $this->db->select('cb_customer.customer_name,cid,mob_no1');
		 $this->db->join('cb_customer','tbl_invoice.customer_code=cb_customer.cid','left');
		/* if($session_data['user_type'] !=  5)
		    {
				$this->db->where('location', $session_data['location']);
			}*/
		 $this->db->order_by('tbl_invoice.s_no','desc');		
		 $query = $this->db->get('tbl_invoice')->result_array();
		 //echo $this->db->last_query();exit;
		 return $query;
	 }
	 function getinvoiceds($inps){
   $this->db->select('tbl_invoice.*,tbl_invoice.created_date as ds');
   $this->db->select('tbl_invoice_payment.*');
	$this->db->select('tbl_sales.total_amount as amt,tbl_sales.s_no as sno,tbl_sales.customer_code,bill_no,tbl_sales.cst as csts,pan,tbl_sales.service_tax as st,tbl_sales.tin,tbl_sales.insurance_amt');
	$this->db->select('cb_customer.customer_name,area_name,city_name,pincode,mob_no1,email_id,cid');
	$this->db->select('tbl_product.*');
	$this->db->select('tbl_sales_items.si_no as sno1,tbl_sales_items.tbl_sales_id,tbl_sales_items.tbl_product_id,tbl_sales_items.quantity,tbl_sales_items.sales_price,tax_amt,model,serivcetax,instcharges,delivery,freight,commissioning,total_value,discount');
	$this->db->select('tbl_statutory.cst as csts,tbl_statutory.vat as vats,tbl_statutory.service_tax as st');
	
	//$this->db->join('tbl_invoice', 'tbl_invoice.sales_id = tbl_sales.s_no', 'left');
	$this->db->join('tbl_invoice_payment', 'tbl_invoice.s_no = tbl_invoice_payment.tbl_invoice_id', 'left'); 
	$this->db->join('tbl_sales_items', 'tbl_sales_items.tbl_sales_id = tbl_invoice.sales_id', 'left'); 
	$this->db->join('tbl_sales', 'tbl_sales.s_no = tbl_sales_items.tbl_sales_id', 'left'); 
	$this->db->join('cb_customer', 'cb_customer.cid = tbl_sales.customer_code', 'left');
	$this->db->join('tbl_product', 'tbl_product.i_id = tbl_sales_items.tbl_product_id', 'left');
	$this->db->join('tbl_statutory', 'tbl_statutory.product_type = tbl_sales_items.pro_type', 'left');
	$this->db->where('tbl_invoice.s_no',$inps['id']);
	$query = $this->db->get('tbl_invoice');
	return $query->result_array();
	//$this->db->where('tbl_invoice.s_no',$inps['id']);
	//$query = $this->db->get();
	//return $query->result_array();
	
	}
	  function Getpaymentlist()
	 {
		  $session_data = $this->session->all_userdata();
		 $this->db->select('tbl_invoice_payment.*');
		 $this->db->select('cb_customer.customer_name,mob_no1,cid');
		// $this->db->select('cp_admin_login.*');
		 $this->db->join('cb_customer','tbl_invoice_payment.customer_code=cb_customer.cid','left');
		//  $this->db->join('cp_admin_login','cp_admin_login.admin_id = tbl_invoice_payment.sale_tec_id','left');
		/* if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cb_customer.location', $session_data['location']);
			}*/
		 $this->db->order_by('inoivce_id','desc');		
		 $query = $this->db->get('tbl_invoice_payment')->result_array();
		 return $query;
	 }
	  function get_sales_byid($inps)
	 {
		 $this->db->select('tbl_sales.*,tbl_sales.s_no as tid');
		 $this->db->select('tbl_sales_items.*,tbl_sales_items.si_no as no');
		 $this->db->select('tbl_product.i_name');
		 $this->db->select('cb_customer.customer_name');
		
		 $this->db->join('tbl_sales_items','tbl_sales_items.tbl_sales_id=tbl_sales.s_no','left');
		  $this->db->join('tbl_product','tbl_product.i_id=tbl_sales_items.tbl_product_id','left');
		 $this->db->join('cb_customer','tbl_sales.customer_code=cb_customer.cid','left');
		  $this->db->where('tbl_sales.s_no',$inps['id']);
		 $query = $this->db->get('tbl_sales')->result_array();
		 return $query;
	 }
	 function getList()
	 {
		 $session_data = $this->session->all_userdata();	
		 $this->db->select('tbl_sales.*,tbl_sales.s_no as tid');
		 $this->db->select('tbl_sales_items.*,tbl_sales_items.si_no as no');
		 $this->db->select('tbl_product.i_name');
		 $this->db->select('cb_customer.cid,customer_name,mob_no1');
		/* if($session_data['user_type'] !=  5)
		    {
				$this->db->where('cb_customer.location',$session_data['location']);
			}*/
		 $this->db->join('tbl_sales_items','tbl_sales_items.tbl_sales_id=tbl_sales.s_no','left');
		 $this->db->join('tbl_product','tbl_product.i_id=tbl_sales_items.tbl_product_id','left');
		 $this->db->join('cb_customer','tbl_sales.customer_code=cb_customer.cid','left');
		 $query = $this->db->get('tbl_sales')->result_array();
		 return $query;
	 }
	
	 function add_sales_payment($post) {
		  extract($_REQUEST);
		  $created_date=date('Y-m-d h:i:s');
		  $array=array('payment_type'=>$payment_type, 'r_no'=>$r_no,  'r_date'=>$r_date, 'r_type'=>$r_type, 'r_amount'=>$r_amount, 'customer_id'=>$customer_id, 'b_code'=>$b_code, 'cheque_no'=>$cheque_no, 'c_date'=>$c_date, 'date'=>$created_date);
		  $this->db->set($array);
	    $this->db->insert('tbl_sales_payment',$array);
		$insert_id = $this->db->insert_id();
		//$itemname one of the varible array
		for($i = 0; $i < count($pmt_amt); $i++) {
			if($pmt_amt[$i] > 0) {
				//'s_id'=>$s_no[$i],
				$array=array('payment_id'=>$insert_id,'s_id'=>$s_no[$i],'bill_no'=>$bill_no[$i],'paid_amount'=>$pmt_amt[$i],'date'=>$created_date);
				$this->db->set($array);
				$this->db->insert('tbl_sales_payment_details',$array);
			}
		}
		  
	  }
//******************************************************************Purchase payment ends here**********************************************************************//
	

}