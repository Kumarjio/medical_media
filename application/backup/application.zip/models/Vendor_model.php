<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Vendor_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
    function get_all_stocks()
	 {
		$session_data = $this->session->all_userdata();	
		$this->db->select('tbl_po_inv.*');
		//$this->db->select('cb_storage.storage_name,cb_storage.Location as loc');
		$this->db->select('tbl_po_inv_item.*');
		 $this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1');
		$this->db->select('cb_seller.seller_name,credit_days');
		$this->db->select('tbl_product.i_name,i_code,descr');
		$this->db->select('tbl_vendorpayment.purchase_id,amt');
		
		$this->db->join('tbl_po_inv_item','tbl_po_inv_item.po_inv_id=tbl_po_inv.po_id','left');
		 $this->db->join('tbl_purchase_request','tbl_purchase_request.id=tbl_po_inv_item.tbl_purchase_req_id','left');
		  $this->db->join('tbl_product','tbl_product.i_id=tbl_purchase_request.pro_id','left');
		$this->db->join('cb_seller','cb_seller.cid=tbl_po_inv_item.vname','left');
		$this->db->join('tbl_vendorpayment','tbl_vendorpayment.purchase_id=tbl_po_inv_item.pi_id','left');
		$this->db->group_by('tbl_po_inv.po_id','desc');
	    $query =$this->db->get('tbl_po_inv')->result_array();
		return $query;			
	 }
	 function get_paym_det()
	 {
		$session_data = $this->session->all_userdata();	
		$this->db->select('tbl_vendorpayment.*');
		$this->db->select('tbl_po_inv_item.*');
		 $this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1');
		$this->db->select('cb_seller.seller_name');
		$this->db->select('tbl_product.i_name,i_code,descr');
		
		$this->db->join('tbl_po_inv_item','tbl_po_inv_item.pi_id=tbl_vendorpayment.purchase_id','left');
		$this->db->join('cb_seller','cb_seller.cid=tbl_vendorpayment.vendor_id','left');
		 $this->db->join('tbl_purchase_request','tbl_purchase_request.id=tbl_po_inv_item.tbl_purchase_req_id','left');
		  $this->db->join('tbl_product','tbl_product.i_id=tbl_purchase_request.pro_id','left');
		 $query =$this->db->get('tbl_vendorpayment')->result_array();
		return $query;			
	 }
	 function get_stocks($inps){
		$session_data = $this->session->all_userdata();	
		$this->db->select('tbl_po_inv_item.*,,tbl_po_inv_item.total as total1');
		//$this->db->select('tbl_po_inv_item.pi_id,tbl_po_inv_item.item_code,tbl_po_inv_item.p_rate,tbl_po_inv_item.qty,tbl_po_inv_item.gtotal as tot');
		$this->db->select('tbl_po_inv.vinvno');
		$this->db->select('cb_seller.seller_name');
		 $this->db->select('tbl_purchase_request.*,tbl_purchase_request.id as ids1,tbl_purchase_request.total as total2');
		$this->db->select('tbl_product.i_name,i_code');
		$this->db->select('tbl_statutory.id as ids,tbl_statutory.product_type,vat as vats');
		$this->db->where('tbl_po_inv.vinvno=',$inps['id']);
		//$this->db->join('tbl_po_inv_item','tbl_po_inv_item.po_inv_id=tbl_po_inv.po_id','left');
		$this->db->join('tbl_po_inv','tbl_po_inv.po_id=tbl_po_inv_item.po_inv_id','left');
		$this->db->join('cb_seller','cb_seller.cid=tbl_po_inv_item.vname','left');
		 $this->db->join('tbl_purchase_request','tbl_purchase_request.id=tbl_po_inv_item.tbl_purchase_req_id','left');
		  $this->db->join('tbl_product','tbl_product.i_id=tbl_purchase_request.pro_id','left');
		$this->db->join('tbl_statutory','tbl_statutory.product_type=tbl_product.i_category','left');
		
		//$this->db->order_by('po_id','asc');
		//$this->db->group_by('po_id');
		$query =$this->db->get('tbl_po_inv_item')->result_array();
		return $query;			
	 }
	 
	 
}
?>