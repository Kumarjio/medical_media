-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 16, 2018 at 05:44 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_session`
--

DROP TABLE IF EXISTS `ci_session`;
CREATE TABLE IF NOT EXISTS `ci_session` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_session`
--

INSERT INTO `ci_session` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('ec86eb137c94fe619e12b50787e23ab9b574cecd', '::1', 1523265454, ''),
('0d07e0b09fa7c68e31ee66a73014ebe3878c641c', '::1', 1523265814, 0x5f5f63695f6c6173745f726567656e65726174657c693a313532333236353533313b),
('00c793c208ad95af86d2e4e0eb3d01c87177fc01', '::1', 1523262222, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235383934353b),
('25758e02aaf2737b4a4b68f905d51bb90a4ab979', '::1', 1523258942, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235383534393b),
('f1a75d4f6d6317469ef4a1bbf6a9d6e31f4968e7', '::1', 1523258544, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235373437343b),
('25164cc505733d74c328e0a5c866dc8d86f89376', '::1', 1523257469, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235363039393b),
('3f0ef80ff1dc3422934f775fc40d39644c540a37', '::1', 1523256096, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235353439363b),
('9985083b6eeff5fad1756b0f2a3b4c98a96e20ac', '::1', 1523255494, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235353134393b),
('eea2ff3af7d904b518ab5e9506c097cd4bfb00aa', '::1', 1523255145, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235343035353b),
('f8d749e675ac99c37e1c2eea1a46c693a989e06e', '::1', 1523254047, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235333635313b),
('16ffdab4c96807b1908810879444f122d7d7a751', '::1', 1523253642, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235333137343b),
('8f82ded4dd78b268a94c6a67b0f485b8e47a3587', '::1', 1523253018, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235323731343b),
('c24897f991cf1b5b299afc7aac6e51924a4b8d77', '::1', 1523252696, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235323332353b),
('9d92422aefa7ede91b63909b80a3de7ff8b16e7a', '::1', 1523248404, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333234373631343b),
('60910bd795742a3fe052b8d840beafb2c2746444', '::1', 1523249621, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333234383431313b),
('29183d3ca01b571796bf620d5a52ea1c454100d8', '::1', 1523250155, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333234393637343b),
('5aae235a2c3715f727e7a9d5a183c59082fdbc0a', '::1', 1523250649, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235303137333b),
('0d7ecdb22aead5b8d0a8d8701adc0017e3a625e6', '::1', 1523250977, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235303637363b),
('17372d801d9b8653f4b1a218650e80c8028641dc', '::1', 1523251316, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235303938333b),
('24522e304053d2d37229df0057b1d5f607b101fd', '::1', 1523251626, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235313333303b),
('2aa76d5f26678a1d925fcabb65c4e710172da423', '::1', 1523251977, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333235313633353b),
('4be3b36d504b89f1cd7a1c5da5a9c4b31e9f8b1b', '::1', 1523267429, 0x5f5f63695f6c6173745f726567656e65726174657c693a313532333236373432383b),
('b30ee9edf75060554fc5f7c64a9532561b4bddd1', '::1', 1523275346, ''),
('091371f380e030100d7f59f3d4f5ae824bd08bfa', '::1', 1523277522, 0x5f5f63695f6c6173745f726567656e65726174657c693a313532333237373530353b),
('632e6c5114e34d8a43798d0b1e7b0cff53545cf1', '::1', 1523511211, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531303330393b),
('4e6dcf4e2e910d65a0229bb421857538611004d2', '::1', 1523511765, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531313333383b),
('fd9f943f8a67f22cc66a9bf1a7ee6826c54e79c7', '::1', 1523512122, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531313737313b),
('d6b68e7c70dcb7bfd95550501b3740d86b12b8cb', '::1', 1523512561, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531323134363b),
('4c69813deedd2e096a7e0bcceeabba10d31009ea', '::1', 1523513275, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531323536383b),
('f4a77be2dfbc485ac8e6b7380803a2d0c77a7352', '::1', 1523514025, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531333238303b),
('b11bf0e1ba0a83d6e49adeee5d25cecf347b1831', '::1', 1523514361, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531343032393b),
('98ef6e8e888bde7223cdf5833c3114274ce3462b', '::1', 1523515101, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531343336343b),
('d7e1932a24886803a7f572f54bac6819a5682a9a', '::1', 1523515726, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531353130323b),
('79fb0b2e380db18bc100f7008519ecf40534fccb', '::1', 1523516035, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531353732383b),
('711ac04163a1023faca2819be4ae583a6b60b6cc', '::1', 1523516337, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531363033383b),
('fce6b607ab9226e0b2cda20d9428328c10ad780f', '::1', 1523516698, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531363333393b),
('7264eb51487c8c2a642b41836f2b3dcecb70593b', '::1', 1523517024, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531363730323b),
('8eed9c9991cdd684e0ea080c28639fcc9c96807f', '::1', 1523517325, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531373032363b),
('1971aea663a170743ba7dfd8da9ecc11567dd456', '::1', 1523517631, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531373333313b),
('b7cba5f6c2889917db6315563bfdafc573e021aa', '::1', 1523517954, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531373633333b),
('017fea4735451b45bec8815a4525fc0ed937740b', '::1', 1523518269, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531373935383b),
('df29314d302b15cb75d249a5dfa6dd89b312de4f', '::1', 1523518566, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b5f5f63695f6c6173745f726567656e65726174657c693a313532333531383237323b),
('3cb9e411350b0bd5b46913d03499da317b46f9af', '::1', 1523518727, ''),
('c146e9b86e06954dac8d2b5aa78b0f7a84a2251e', '::1', 1523856450, 0x636f6d70616e795f6e616d657c733a353a22486f74656c223b);

-- --------------------------------------------------------

--
-- Table structure for table `cp_admin_login`
--

DROP TABLE IF EXISTS `cp_admin_login`;
CREATE TABLE IF NOT EXISTS `cp_admin_login` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `emp_code` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `created_date` varchar(50) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  `user_type` int(11) NOT NULL DEFAULT '0' COMMENT '1-admin,2-user',
  `is_delete` int(10) NOT NULL COMMENT '1-delete,0-active',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cp_admin_login`
--

INSERT INTO `cp_admin_login` (`admin_id`, `username`, `password`, `name`, `emp_code`, `phone`, `email_id`, `area_name`, `created_date`, `status`, `user_type`, `is_delete`) VALUES
(1, 'admin', 'admin', 'HotelFASFASDFDSFDS', '1', '786868689', 'xyz@gmail.com', 'porur', '2017-11-22', 1, 1, 0),
(8, 'test', 'test', 'senthil', 'senthil', '9840268971', 'senthil@gmail.com', 'chennai', '2018-04-05', 1, 2, 1),
(9, '133', '131321', '131231', '31232', '31231', '3133', '31231', '2018-04-12', 1, 1, 1),
(10, 'wrwerw', 'rwrwr', 'server 1', 'server 1', '4', 'rwew', 'add', '2018-04-12', 1, 3, 0),
(11, '42342', '42423', '4242', '23421', '42342424234', '2424', '2423423', '2018-04-12', 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_type`
--

DROP TABLE IF EXISTS `emp_type`;
CREATE TABLE IF NOT EXISTS `emp_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_type`
--

INSERT INTO `emp_type` (`type_id`, `type_name`) VALUES
(1, 'admin'),
(2, 'User'),
(3, 'Supplier');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consumed`
--

DROP TABLE IF EXISTS `tbl_consumed`;
CREATE TABLE IF NOT EXISTS `tbl_consumed` (
  `consumed_id` int(11) NOT NULL AUTO_INCREMENT,
  `consumed_pro_ref_id` varchar(200) NOT NULL,
  `consumed_unit` varchar(200) NOT NULL,
  `previous_qty` varchar(200) NOT NULL,
  `consumed_qty` varchar(200) NOT NULL,
  `consumed_date` varchar(200) NOT NULL,
  `consumed_time` varchar(200) NOT NULL,
  `is_deleted` int(11) DEFAULT '0',
  PRIMARY KEY (`consumed_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

DROP TABLE IF EXISTS `tbl_item`;
CREATE TABLE IF NOT EXISTS `tbl_item` (
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(250) NOT NULL,
  `item_price` varchar(50) NOT NULL,
  `is_deleted` varchar(10) CHARACTER SET utf16 COLLATE utf16_bin DEFAULT '0',
  `item_date` varchar(50) CHARACTER SET utf16 COLLATE utf16_bin NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`item_id`, `item_name`, `item_price`, `is_deleted`, `item_date`) VALUES
(1, 'idly', '10', '0', '2018-04-12'),
(2, 'dosai', '25', '0', '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(200) NOT NULL,
  `product_unit` varchar(200) NOT NULL,
  `is_deleted` varchar(200) NOT NULL,
  `product_created` varchar(200) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `product_unit`, `is_deleted`, `product_created`) VALUES
(1, 'Oli', 'lit', '0', '2018-04-12'),
(2, 'Kadala Parupu', 'kgs', '0', '2018-04-12'),
(3, 'Red Chilly Powder', 'kgs', '0', '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase_inv`
--

DROP TABLE IF EXISTS `tbl_purchase_inv`;
CREATE TABLE IF NOT EXISTS `tbl_purchase_inv` (
  `purchase_inv_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_vendor_ref_id` varchar(200) NOT NULL,
  `purchase_invoice_no` varchar(200) NOT NULL,
  `purchase_invoice_date` varchar(200) NOT NULL,
  `purchase_stotal` varchar(200) NOT NULL,
  `purchase_gtotal` varchar(200) NOT NULL,
  `purchase_status` varchar(200) NOT NULL,
  `pending_payment` varchar(200) NOT NULL,
  `paid_payment` varchar(200) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `purchase_entry_date` varchar(200) NOT NULL,
  PRIMARY KEY (`purchase_inv_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_purchase_inv`
--

INSERT INTO `tbl_purchase_inv` (`purchase_inv_id`, `purchase_vendor_ref_id`, `purchase_invoice_no`, `purchase_invoice_date`, `purchase_stotal`, `purchase_gtotal`, `purchase_status`, `pending_payment`, `paid_payment`, `is_deleted`, `purchase_entry_date`) VALUES
(1, '1', '132', '2018-04-12', '670', '670.00', '0', '670.00', '0', 1, '2018-04-12'),
(2, '1', '11', '2018-04-12', '480', '480.00', '0', '480.00', '0', 1, '2018-04-12'),
(3, '1', '345', '2018-04-12', '740', '740.00', '0', '740.00', '0', 1, '2018-04-12'),
(4, '1', '234', '2018-04-12', '12100', '12100.00', '0', '12100.00', '0', 0, '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase_inv_item`
--

DROP TABLE IF EXISTS `tbl_purchase_inv_item`;
CREATE TABLE IF NOT EXISTS `tbl_purchase_inv_item` (
  `purchase_inv_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_inv_ref_id` varchar(200) NOT NULL,
  `purchase_product_id` varchar(200) NOT NULL,
  `purchase_unit` varchar(200) NOT NULL,
  `purchase_qty` varchar(200) NOT NULL,
  `purchase_rate` varchar(200) NOT NULL,
  `purchase_amount` varchar(200) NOT NULL,
  `purchase_sgst` varchar(200) NOT NULL,
  `purchase_cgst` varchar(200) NOT NULL,
  `purchase_igst` varchar(200) NOT NULL,
  `purchase_sgst_amt` varchar(200) NOT NULL,
  `purchase_cgst_amt` varchar(200) NOT NULL,
  `purchase_igst_amt` varchar(200) NOT NULL,
  `purchase_total` varchar(200) NOT NULL,
  PRIMARY KEY (`purchase_inv_item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_purchase_inv_item`
--

INSERT INTO `tbl_purchase_inv_item` (`purchase_inv_item_id`, `purchase_inv_ref_id`, `purchase_product_id`, `purchase_unit`, `purchase_qty`, `purchase_rate`, `purchase_amount`, `purchase_sgst`, `purchase_cgst`, `purchase_igst`, `purchase_sgst_amt`, `purchase_cgst_amt`, `purchase_igst_amt`, `purchase_total`) VALUES
(1, '1', '1', 'lit', '2', '95', '190', '0', '0', '0', '0', '0', '0', '190'),
(2, '1', '2', 'kgs', '4', '120', '480', '0', '0', '0', '0', '0', '0', '480'),
(3, '2', '1', 'lit', '2', '90', '180', '0', '0', '0', '0', '0', '0', '180'),
(4, '2', '3', 'kgs', '2', '150', '300', '0', '0', '0', '0', '0', '0', '300'),
(5, '3', '1', 'lit', '2', '100', '200', '0', '0', '0', '0', '0', '0', '200'),
(6, '3', '3', 'kgs', '2', '120', '240', '0', '0', '0', '0', '0', '0', '240'),
(7, '3', '2', 'kgs', '2', '150', '300', '0', '0', '0', '0', '0', '0', '300'),
(8, '4', '1', 'lit', '10', '10', '100', '0', '0', '0', '0', '0', '0', '100'),
(9, '4', '2', 'kgs', '10', '100', '1000', '0', '0', '0', '0', '0', '0', '1000'),
(10, '4', '3', 'kgs', '110', '100', '11000', '0', '0', '0', '0', '0', '0', '11000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_row`
--

DROP TABLE IF EXISTS `tbl_row`;
CREATE TABLE IF NOT EXISTS `tbl_row` (
  `row_id` int(11) NOT NULL AUTO_INCREMENT,
  `row_name` varchar(200) NOT NULL,
  `is_deleted` varchar(200) NOT NULL,
  `row_created` varchar(200) NOT NULL,
  PRIMARY KEY (`row_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_row`
--

INSERT INTO `tbl_row` (`row_id`, `row_name`, `is_deleted`, `row_created`) VALUES
(1, 'ROW 1', '0', '2018-04-12'),
(2, 'ROW 2', '0', '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales`
--

DROP TABLE IF EXISTS `tbl_sales`;
CREATE TABLE IF NOT EXISTS `tbl_sales` (
  `sal_id` int(10) NOT NULL AUTO_INCREMENT,
  `sale_bill_no` varchar(100) NOT NULL,
  `bill_date` varchar(100) NOT NULL,
  `server_name` varchar(200) NOT NULL,
  `bill_time` varchar(250) NOT NULL,
  `sale_table_row` varchar(250) NOT NULL,
  `sale_table_name` varchar(200) NOT NULL,
  `parcel_amt` varchar(50) NOT NULL,
  `sgst_per` varchar(50) NOT NULL,
  `cgst_per` varchar(50) NOT NULL,
  `sgst_amt` varchar(50) NOT NULL,
  `cgst_amt` varchar(50) NOT NULL,
  `sales_total` varchar(50) NOT NULL,
  `sales_grand_total` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `sales_date` varchar(50) NOT NULL,
  PRIMARY KEY (`sal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sales`
--

INSERT INTO `tbl_sales` (`sal_id`, `sale_bill_no`, `bill_date`, `server_name`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_per`, `cgst_per`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_deleted`, `sales_date`) VALUES
(1, 'SB1', '2018-04-12', '11', '11:20:51', '2', '2', '0', '0', '0', '0.00', '0.00', '125', '125.00', 0, 1, '2018-04-12'),
(2, 'SB2 - 2018-19', '2018-04-12', '11', '11:51:52', '1', '1', '0', '0', '0', '0.00', '0.00', '75', '75.00', 0, 0, '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sale_items`
--

DROP TABLE IF EXISTS `tbl_sale_items`;
CREATE TABLE IF NOT EXISTS `tbl_sale_items` (
  `sale_item_id` int(10) NOT NULL AUTO_INCREMENT,
  `sale_ref_id` varchar(50) NOT NULL,
  `sale_item_name` varchar(250) NOT NULL,
  `sale_price` varchar(250) NOT NULL,
  `sale_qty` varchar(250) NOT NULL,
  `sale_item_total` varchar(250) NOT NULL,
  PRIMARY KEY (`sale_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sale_items`
--

INSERT INTO `tbl_sale_items` (`sale_item_id`, `sale_ref_id`, `sale_item_name`, `sale_price`, `sale_qty`, `sale_item_total`) VALUES
(1, '1', '1', '10', '5', '50'),
(2, '1', '2', '25', '3', '75'),
(3, '2', '1', '10', '5', '50'),
(4, '2', '2', '25', '1', '25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stock`
--

DROP TABLE IF EXISTS `tbl_stock`;
CREATE TABLE IF NOT EXISTS `tbl_stock` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_reff_id` varchar(200) NOT NULL,
  `curr_qty` varchar(200) NOT NULL,
  `stock_status` varchar(200) DEFAULT '0',
  PRIMARY KEY (`stock_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_stock`
--

INSERT INTO `tbl_stock` (`stock_id`, `pro_reff_id`, `curr_qty`, `stock_status`) VALUES
(1, '1', '10', '0'),
(2, '2', '10', '0'),
(3, '3', '110', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

DROP TABLE IF EXISTS `tbl_table`;
CREATE TABLE IF NOT EXISTS `tbl_table` (
  `table_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(200) NOT NULL,
  `is_deleted` varchar(200) NOT NULL,
  `table_created` varchar(200) NOT NULL,
  PRIMARY KEY (`table_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`table_id`, `table_name`, `is_deleted`, `table_created`) VALUES
(1, 'TABLE 1', '0', '2018-04-12'),
(2, 'TABLE 2', '0', '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_value`
--

DROP TABLE IF EXISTS `tbl_value`;
CREATE TABLE IF NOT EXISTS `tbl_value` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_value` varchar(200) NOT NULL,
  `sales_value` varchar(200) NOT NULL,
  `value_date` varchar(200) NOT NULL,
  PRIMARY KEY (`value_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_value`
--

INSERT INTO `tbl_value` (`value_id`, `purchase_value`, `sales_value`, `value_date`) VALUES
(1, '12100', '75', '2018-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendor`
--

DROP TABLE IF EXISTS `tbl_vendor`;
CREATE TABLE IF NOT EXISTS `tbl_vendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(200) DEFAULT NULL,
  `vendor_mobile` varchar(400) DEFAULT NULL,
  `vendor_area` varchar(400) DEFAULT NULL,
  `vendor_city` varchar(200) DEFAULT NULL,
  `vendor_pincode` varchar(15) NOT NULL,
  `vendor_email` varchar(200) DEFAULT NULL,
  `vendor_state` varchar(200) DEFAULT NULL,
  `create_date` varchar(200) NOT NULL,
  `vendor_gst` varchar(50) NOT NULL,
  `is_deleted` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vendor`
--

INSERT INTO `tbl_vendor` (`vendor_id`, `vendor_name`, `vendor_mobile`, `vendor_area`, `vendor_city`, `vendor_pincode`, `vendor_email`, `vendor_state`, `create_date`, `vendor_gst`, `is_deleted`) VALUES
(1, 'vendor 1', '8124498572', 'chennai', 'Kandamangalam', '605102', 'musthakcse@gmail.com', 'Tamilnadu', '2018-04-12', '7894656123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_year`
--

DROP TABLE IF EXISTS `tbl_year`;
CREATE TABLE IF NOT EXISTS `tbl_year` (
  `year_id` int(10) NOT NULL,
  `from_year` varchar(50) NOT NULL,
  `to_year` varchar(50) NOT NULL,
  `year_value` varchar(50) NOT NULL,
  PRIMARY KEY (`year_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_year`
--

INSERT INTO `tbl_year` (`year_id`, `from_year`, `to_year`, `year_value`) VALUES
(1, '2018/04/06', '2019/04/06', '2018-19');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
