<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Inventory_master extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          //load the login model
          $this->load->model('Inventory_model');
		  
		  
     }
     public function index(){
		$data['title']="Product Management";
		$data['product']=$this->Inventory_model->get_all_product();
		//print_r($data['emp']);exit;
		$this->load->view('inventory/product_list',$data);
	}
	
	public function item_list(){
		$data['title']="Inventory Management";
		$data['item']=$this->Inventory_model->get_all_item();
		//print_r($data['item']);exit;
		$this->load->view('inventory/add_item',$data);
	}
	
	public function add_item()
	{

		$data=$this->Inventory_model->add_item();
		
		echo json_encode($data);
		
	}
	public function edit_item($id)
	{

		$data=$this->Inventory_model->item_edit($id);
		
		echo json_encode($data);
		
	}
		public function delete_item($id)
	{

		$data=$this->Inventory_model->item_delete($id);
		
		echo json_encode($data);
		
	}

	public function add_product()
	{
		
		$data = $this->Inventory_model->add_product();	
		echo json_encode($data);
		
	}
	public function edit_product($id){
		$data = $this->Inventory_model->edit_product($id);
		echo json_encode($data);
	}
	public function delete_product($id){
		$data = $this->Inventory_model->delete_product($id);
		echo json_encode($data);
	}
	public function table_master(){
		$data['title']="Hotel Management";
		$data['table']=$this->Inventory_model->get_all_table();
		$data['row']=$this->Inventory_model->get_all_row();
		//print_r($data['emp']);exit;
		$this->load->view('inventory/table_list',$data);
	}
	public function add_row()
	{
		
		$data = $this->Inventory_model->add_row();	
		echo json_encode($data);
		
	}
	public function add_table()
	{
		
		$data = $this->Inventory_model->add_table();	
		echo json_encode($data);
		
	}
	public function edit_row($id){
		$data = $this->Inventory_model->edit_row($id);
		echo json_encode($data);
	}
	public function edit_table($id){
		$data = $this->Inventory_model->edit_table($id);
		echo json_encode($data);
	}
	public function delete_row($id){
		$data = $this->Inventory_model->delete_row($id);
		echo json_encode($data);
	}
	public function delete_table($id){
		$data = $this->Inventory_model->delete_table($id);
		echo json_encode($data);
	}
	
}
