<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Purchase extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          //load the login model
          $this->load->model('Purchase_model');
          $this->load->model('Purchase_model');
		  
		  
     }
	
	public function index(){
		$data['title']="Employee Management";
		$data['vendor']=$this->Purchase_model->get_all_vendor();
		$data['product']=$this->Purchase_model->get_all_product();
		//print_r($data['emp']);exit;
		$this->load->view('purchase/purchase_entry',$data);
	}
	public function get_unitofproduct($id){
		$data = $this->Purchase_model->get_unitofproduct($id);
		echo json_encode($data);
	}
	public function add_purchase(){
		$data = $this->Purchase_model->add_purchase();
		echo json_encode($data);
	}
	public function purchase_list()
	{
		
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		//print_r($inps);exit();
		$data['title'] = 'Purchase list';
		//$data['style'] = $this->Reports_model->get_style($inps);
		$data['purchase'] = $this->Purchase_model->get_all_purchsae($inps);
		
		//echo '<pre>';print_r($data); exit;
		
		//export
		if(isset($inps['export']))
		{
			
			$heading = Array ('S.NO','Invoice Number','Invoice Date','Vendor Name','Invoice Amount') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Purchase Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true;
			}
			foreach($data['purchase'] as $loop) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = $loop['purchase_invoice_no'];
				$newrow[2] = date('d-m-Y',strtotime($loop['purchase_invoice_date']));
				$newrow[3] = $loop['vendor_name'];
				$newrow[4] = number_format($loop['purchase_gtotal'],2);
				// filter data
				array_walk($newrow, 'filterData');
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
			
			exit;
		}
		$data['inps'] = $inps;
		$this->load->view('purchase/purchase_list', $data);
	}
	public function edit_purchase($id)
	{
		$data['vendor']=$this->Purchase_model->get_all_vendor();
		$data['product']=$this->Purchase_model->get_all_product();
    $data['puredit']=$this->Purchase_model->edit_purchase($id);
    $data['title']='Parchase Edit';
    //echo "<pre>";print_r($data['puredit']);exit;
    $this->load->view('purchase/purchase_edit',$data);
	}
	public function editPurchaseEntry()
	{
		$data=$this->Purchase_model->purchase_edit_update();

		redirect(base_url('Purchase/purchase_list'));
	}
	public function purchase_delete($id)
	{
	$purch_valu = $this->db->select('*')->from('tbl_purchase_inv')->where('tbl_purchase_inv.purchase_inv_id',$id)->get()->result_array();
	$current_valu = $this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$purch_valu[0]['purchase_entry_date'])->get()->result_array();

	$min = $current_valu[0]['purchase_value']-$purch_valu[0]['purchase_gtotal'];
	$array_values = array('purchase_value'=>$min);
	$up = $this->db->where('tbl_value.value_date',$current_valu[0]['value_date'])->update('tbl_value',$array_values);

	$purch_inv = $this->db->select('*')->from('tbl_purchase_inv')->where('tbl_purchase_inv.purchase_inv_id',$id)->join('tbl_purchase_inv_item','tbl_purchase_inv_item.purchase_inv_ref_id=tbl_purchase_inv.purchase_inv_id')->get()->result_array();
	foreach ($purch_inv as $key) {
		$stock = $this->db->select('*')->from('tbl_stock')->where('tbl_stock.pro_reff_id',$key['purchase_product_id'])->get()->result_array();
		$red = $stock[0]['curr_qty']-$key['purchase_qty'];
		$uparr = array('curr_qty'=>$red);
		$this->db->where('tbl_stock.stock_id',$stock[0]['stock_id'])->update('tbl_stock',$uparr);
	}

	$array=array('is_deleted'=>'1');
	//print_r($array);exit;
	$data = $this->db->where('purchase_inv_id',$id)->update('tbl_purchase_inv',$array);
	 
    echo json_encode($data);
	}
}
