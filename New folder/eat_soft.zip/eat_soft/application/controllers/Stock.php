<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Stock extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          //load the login model
          $this->load->model('Stock_model');
		  
		  
     }
     public function index()
	{
		
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		//print_r($inps);exit();
		$data['title'] = 'Stock list';
		//$data['style'] = $this->Reports_model->get_style($inps);
		$data['stock'] = $this->Stock_model->get_all_stock($inps);
		
		//echo '<pre>';print_r($data); exit;
		
		//export
		if(isset($inps['export']))
		{
			
			$heading = Array ('S.NO','Product Name','Unit','Qty') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Purchase Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true;
			}
			foreach($data['stock'] as $loop) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = $loop['product_name'];
				$newrow[2] = $loop['product_unit'];
				$newrow[3] = number_format($loop['curr_qty']);
				// filter data
				array_walk($newrow, 'filterData');
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
			
			exit;
		}
		$data['inps'] = $inps;
		$this->load->view('stock/stock_list', $data);
	}
	
	public function add_consumed_stock(){
		$data['title']="Stock";
		$data['vendor']=$this->Stock_model->get_all_vendor();
		$data['product']=$this->Stock_model->get_all_product();
		//print_r($data['emp']);exit;
		$this->load->view('stock/consumed_stock_entry',$data);
	}
	public function get_unitofproduct($id){
		$data = $this->Stock_model->get_unitofproduct($id);
		echo json_encode($data);
	}
	public function add_stock(){
		$data = $this->Stock_model->add_stock();
		echo json_encode($data);
	}
	    public function consumed_list()
	{
		
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		//print_r($inps);exit();
		$data['title'] = 'Consumed Stock list';
		//$data['style'] = $this->Reports_model->get_style($inps);
		$data['consume'] = $this->Stock_model->get_all_consumed_stock($inps);
		
		//echo '<pre>';print_r($data); exit;
		
		//export
		if(isset($inps['export']))
		{
			
			$heading = Array ('S.NO','Product Name','Unit','Consumed Qty','Consumed Date','Consumed Time') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Consumed Stock Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true;
			}
			foreach($data['consume'] as $loop) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = $loop['product_name'];
				$newrow[2] = $loop['consumed_unit'];
				$newrow[3] = number_format($loop['consumed_qty']);
				$newrow[4] = date('d-m-Y',strtotime($loop['consumed_date']));
				$newrow[5] = $loop['consumed_time'];
				// filter data
				array_walk($newrow, 'filterData');
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
			
			exit;
		}
		$data['inps'] = $inps;
		$this->load->view('stock/consumed_stock_list', $data);
	}
	
}
