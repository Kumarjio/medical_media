<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Report extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          $this->load->model('Report_model');
		  
		  
     }
	
	
	public function index()
	{
		
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		//print_r($inps);exit();
		$data['title'] = 'Purchase Report';
		//$data['style'] = $this->Reports_model->get_style($inps);
		$data['purchase'] = $this->Report_model->get_all_purchsae($inps);
		
		//echo '<pre>';print_r($data); exit;
		
		//export
		if(isset($inps['export']))
		{
			
			$heading = Array ('S.NO','Invoice Number','Invoice Date','Vendor Name','Product Name','Unit','Unit Rate','Purchase Qty','Total','Invoice Amount','Purchase Entry Date') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Purchase Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true;
			}
			foreach($data['purchase'] as $loop) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = $loop['purchase_invoice_no'];
				$newrow[2] = date('d-m-Y',strtotime($loop['purchase_invoice_date']));
				$newrow[3] = $loop['vendor_name'];
				$newrow[4] = $loop['product_name'];
				$newrow[5] = $loop['purchase_unit'];
				$newrow[6] = $loop['purchase_rate'];
				$newrow[7] = $loop['purchase_qty'];
				$newrow[8] = number_format($loop['purchase_total'],2);
				$newrow[9] = number_format($loop['purchase_gtotal'],2);
				$newrow[10] = date('d-m-Y',strtotime($loop['purchase_entry_date']));
				// filter data
				array_walk($newrow, 'filterData');
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
			
			exit;
		}
		$data['inps'] = $inps;
		$this->load->view('reports/purchase_report', $data);
	}
	public function sales_report()
	{
		
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		//print_r($inps);exit();
		$data['title'] = 'Purchase list';
		//$data['style'] = $this->Reports_model->get_style($inps);
		$data['sales'] = $this->Report_model->get_all_sales($inps);
		
		//echo '<pre>';print_r($data); exit;
		
		//export
		if(isset($inps['export']))
		{
			
			$heading = Array ('S.NO','Bill No','Bill Date','Server Name','Row Name','Table Name','Item Name','Item Rate','Item Qty','Total','SGST','CGST','SGST AMT','CGST AMT','Packing Charge','Sub Total','Grand Total') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Sales Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true;
			}
			foreach($data['sales'] as $loop) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = $loop['sale_bill_no'];
				$newrow[2] = date('d-m-Y',strtotime($loop['bill_date']));
				$newrow[3] = $loop['name'];
				$newrow[4] = $loop['row_name'];
				$newrow[5] = $loop['table_name'];
				$newrow[6] = $loop['item_name'];
				$newrow[7] = $loop['sale_price'];
				$newrow[8] = $loop['sale_qty'];
				$newrow[9] = number_format($loop['sale_item_total'],2);
				$newrow[10] = $loop['sgst_per'].'%';
				$newrow[11] = $loop['cgst_per'].'%';
				$newrow[12] = number_format($loop['sgst_amt'],2);
				$newrow[13] = number_format($loop['cgst_amt'],2);
				$newrow[14] = number_format($loop['parcel_amt'],2);
				$newrow[15] = number_format($loop['sales_total'],2);
				$newrow[16] = number_format($loop['sales_grand_total'],2);
				// filter data
				array_walk($newrow, 'filterData');
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
			
			exit;
		}
		$data['inps'] = $inps;
		$this->load->view('reports/sales_report', $data);
	}
	public function value_report()
	{
		
		if($this->input->post())
		{
			$inps = $this->input->post();
		}
		else
		{
			$inps = '';
		}
		//print_r($inps);exit();
		$data['title'] = 'Purchase & Sales value Report';
		//$data['style'] = $this->Reports_model->get_style($inps);
		$data['value_list'] = $this->Report_model->get_all_values($inps);
		
		//echo '<pre>';print_r($data); exit;
		
		//export
		if(isset($inps['export']))
		{
			
			$heading = Array ('S.NO','Purchase & Sales Date','Purchsae Value','Sales Value','Profit / Loss') ;
			$blankrow = Array('');
			
			function filterData(&$str)
			{
				$str = preg_replace("/\t/", "\\t", $str);
				$str = preg_replace("/\r?\n/", "\\n", $str);
				if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
			}
			
			// file name for download
			$fileName = "Purchase & Sales Value Report" . date('Ymd') . ".xls";
			header("Content-Disposition: attachment; filename=\"$fileName\"");
			header("Content-Type: application/vnd.ms-excel");
			
			$flag = false;
			$cnt = 1;
			$totalamount = 0;
			
			if(!$flag) 
			{
			// display column names as first row
			echo implode("\t", array_values($heading)) . "\n";
			$flag = true;
			}
			foreach($data['value_list'] as $loop) 
			{
				$newrow[0] = $cnt;
				$newrow[1] = date('d-m-Y',strtotime($loop['value_date']));
				$newrow[2] = $loop['purchase_value'];
				$newrow[3] = $loop['sales_value'];
				$newrow[4] = $loop['sales_value']-$loop['purchase_value'];
				// filter data
				array_walk($newrow, 'filterData');
				echo implode("\t", array_values($newrow)) . "\n";
				$cnt++;
			}
			
			exit;
		}
		$data['inps'] = $inps;
		$this->load->view('reports/value_report',$data);
	}
}
