<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Employee_master extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          //load the Employee_model
          $this->load->model('Employee_model');
		  
		  
     }
	public function index(){
		$data['title']="Employee Management";
		$data['emp']=$this->Employee_model->get_all_employee();
		$this->load->view('employee/employee_list',$data);
	}
	public function add_employee()
	{

		$data=$this->Employee_model->add_employee();
		$data['emp']=$this->Employee_model->get_all_employee();
		echo json_encode($data);
		
	}
	public function edit_employee($id)
	{
		$data=$this->Employee_model->employee_edit($id);
		echo json_encode($data);
		
	}
	public function emp_delete($id)
	{
		$data=$this->Employee_model->emp_delete($id);
		echo json_encode($data);
		
	}
}
