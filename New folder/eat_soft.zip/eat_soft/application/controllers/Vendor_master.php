<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Vendor_master extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          //load the login model
          $this->load->model('Vendor_model');
		  
		  
     }
	
	public function index(){
		$data['title']="Vendor Management";
		$data['vendor']=$this->Vendor_model->get_all_vendor();
		//print_r($data['emp']);exit;
		$this->load->view('Vendor/vendor_list',$data);
	}
	
	public function add_vendor()
	{

		$data=$this->Vendor_model->add_vendor();
		$data['emp']=$this->Vendor_model->get_all_vendor();
		echo json_encode($data);
		
	}
	public function edit_vendor($id)
	{

		$data=$this->Vendor_model->vendor_edit($id);
		
		echo json_encode($data);
		
	}
	public function listView(){
		$data['title']="Vendor Management";
		$data=$this->Vendor_model->get_all_vendor();
		//print_r($data['emp']);exit;
		echo json_encode($data);
	}
	public function vendor_delete($id)
	{
		$data=$this->Vendor_model->vendor_delete($id);
		echo json_encode($data);
		
	}
}
