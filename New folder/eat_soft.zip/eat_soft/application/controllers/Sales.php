<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Sales extends CI_Controller {
	public function __construct(){
          parent::__construct();
		  $this->load->library('session');
          //load the login model
          $this->load->model('Sales_model');
		  
		  
     }
	
	public function index(){
		$data['title']="Sales Management";
		$data['item']=$this->Sales_model->get_all_item();
		//echo "<pre>";print_r($data['item']);exit;
		$this->load->view('sales/add_sales',$data);
	}
	
	public function sale_list()
	{
		$data['title']='Sales List';
		$data['list']=$this->Sales_model->total_sales_list();
		//echo "<pre>";print_r($data['list']);exit;
		$this->load->view('sales/sales_list',$data);
	}
	
	public function get_item_price($item_id)
	{
		$data=$this->Sales_model->get_item_price($item_id);
		echo json_encode($data);
	}

	public function add_sales()
	{
		$data=$this->Sales_model->add_sales();

		echo json_encode($data);
	}
	public function getInvoice($id)
	{
		$data['invoice']=$this->Sales_model->get_invoice($id);
		//echo "<pre>";print_r($data['invoice']);exit;
		$this->load->view('sales/sales_invoice',$data);
	}
	public function sales_invoice_list($id)
	{
        $data['invoice']=$this->Sales_model->get_invoice_list($id);
		//echo "<pre>";print_r($data['invoice']);exit;
		$this->load->view('sales/sales_invoice_list',$data);
	}
	public function edit_sales($id)
	{
		$data['item']=$this->Sales_model->get_all_item();
		$data['edit']=$this->Sales_model->sales_edit($id);
		//echo "<pre>";print_r($data['edit']);exit;
		$this->load->view('sales/sales_edit',$data);
	}
	public function edit_sales_update()
	{
		$data=$this->Sales_model->edit_sales_update();

		echo json_encode($data);
	}
	public function sales_delete($id)
	{
	$sales_valu = $this->db->select('*')->from('tbl_sales')->where('tbl_sales.sal_id',$id)->get()->result_array();
	$current_valu = $this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$sales_valu[0]['bill_date'])->get()->result_array();
	$min = $current_valu[0]['sales_value']-$sales_valu[0]['sales_grand_total'];
	$array_values = array('sales_value'=>$min);
	$up = $this->db->where('tbl_value.value_date',$current_valu[0]['value_date'])->update('tbl_value',$array_values);
	$array=array('is_deleted'=>'1');
	//print_r($array);exit;
	$this->db->where('sal_id',$id);
	$data=$this->db->update('tbl_sales',$array);
    echo json_encode($data);
	}
	
}
