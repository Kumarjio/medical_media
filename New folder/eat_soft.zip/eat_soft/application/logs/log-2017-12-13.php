<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-13 06:02:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:02:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:03:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:03:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:03:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:03:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:06:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:06:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:06:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:06:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:06:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:06:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:07:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:07:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:07:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:07:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:12:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:12:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:12:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:12:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:47:01 --> Severity: Notice --> Undefined variable: list D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 47
ERROR - 2017-12-13 06:17:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:17:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:48:26 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 53
ERROR - 2017-12-13 10:48:26 --> Severity: Notice --> Undefined index: brand_id D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 54
ERROR - 2017-12-13 10:48:26 --> Severity: Notice --> Undefined index: brand_id D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 56
ERROR - 2017-12-13 10:48:26 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 53
ERROR - 2017-12-13 10:48:26 --> Severity: Notice --> Undefined index: brand_id D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 54
ERROR - 2017-12-13 10:48:26 --> Severity: Notice --> Undefined index: brand_id D:\xampp\htdocs\duty\mathewgarments\application\views\brand_list.php 56
ERROR - 2017-12-13 06:18:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:18:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:19:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:19:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:27:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:27:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:28:12 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:28:12 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:28:38 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:28:38 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:28:43 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:28:43 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:28:50 --> 404 Page Not Found: Brand/edit_unit
ERROR - 2017-12-13 06:29:12 --> 404 Page Not Found: Brand/edit_unit
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Undefined property: stdClass::$unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2017-12-13 10:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2017-12-13 10:59:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2017-12-13 10:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2017-12-13 10:59:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2017-12-13 10:59:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2017-12-13 10:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2017-12-13 10:59:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2017-12-13 10:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2017-12-13 10:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2017-12-13 06:29:51 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:29:51 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-13 06:29:59 --> 404 Page Not Found: Brand/delete_unit
ERROR - 2017-12-13 06:30:09 --> 404 Page Not Found: Brand/delete_unit
ERROR - 2017-12-13 06:31:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:31:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:31:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:31:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:31:23 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-13 06:31:23 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-13 06:31:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:31:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:31:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:31:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 11:02:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''admin\'  and is_delete = 0' at line 1 - Invalid query: select * from cp_admin_login where username = 'admin' and password = 'admin\'  and is_delete = 0
ERROR - 2017-12-13 06:34:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:34:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:34:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:34:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:34:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:34:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:42:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:42:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:42:42 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-13 06:42:42 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-13 06:42:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:42:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:42:46 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-13 06:42:46 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-13 06:42:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:42:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:42:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:42:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:43:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:43:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:43:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-13 06:43:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-13 06:43:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:43:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:43:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:43:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:43:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:43:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:43:37 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-13 06:43:37 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-13 06:43:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:43:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:44:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:44:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:44:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:44:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:48:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 06:48:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 06:48:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-13 06:48:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-13 11:20:39 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 11:20:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 06:50:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:50:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:26:07 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 11:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 06:56:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:56:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:26:24 --> Severity: Notice --> Undefined index: productcreation_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 11:26:24 --> Severity: Notice --> Undefined index: productcreation_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 06:56:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:56:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:27:12 --> Severity: Notice --> Undefined index: productcreation_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 41
ERROR - 2017-12-13 06:57:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:57:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:57:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:57:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:59:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 06:59:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:00:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:00:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:01:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:01:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 47
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 48
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 49
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 62
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 63
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 64
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined index: color D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 65
ERROR - 2017-12-13 11:31:53 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 66
ERROR - 2017-12-13 07:01:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:01:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:03:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:03:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:03:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:03:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:04:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:04:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:04:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:04:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:34:25 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 47
ERROR - 2017-12-13 11:34:25 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 48
ERROR - 2017-12-13 11:34:25 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 49
ERROR - 2017-12-13 07:04:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:04:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:05:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:05:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:35:41 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 47
ERROR - 2017-12-13 11:35:41 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 48
ERROR - 2017-12-13 11:35:41 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 49
ERROR - 2017-12-13 07:05:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:05:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:05:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:05:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:08:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:08:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:08:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:08:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:08:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:08:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:08:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:08:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 11:44:55 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 175
ERROR - 2017-12-13 07:15:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:15:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:15:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:15:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:15:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:15:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:45:43 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 07:15:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:15:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:17:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:17:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:18:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:18:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:18:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:18:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:48:51 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 11:48:51 --> Severity: Notice --> Undefined variable: pname D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 180
ERROR - 2017-12-13 11:48:51 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 181
ERROR - 2017-12-13 11:48:51 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 182
ERROR - 2017-12-13 07:18:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:18:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:19:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:19:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:19:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:19:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:49:18 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 07:19:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:19:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:19:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:19:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 11:55:05 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 61
ERROR - 2017-12-13 11:55:25 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 61
ERROR - 2017-12-13 11:55:50 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 61
ERROR - 2017-12-13 11:55:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 61
ERROR - 2017-12-13 11:55:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 61
ERROR - 2017-12-13 11:56:15 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 62
ERROR - 2017-12-13 11:56:28 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 66
ERROR - 2017-12-13 07:26:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:26:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:26:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:26:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:57:03 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 07:27:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:27:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:27:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:27:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:57:37 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 07:27:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:27:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:58:21 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 07:28:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 11:58:58 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 54
ERROR - 2017-12-13 07:28:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:28:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:29:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:29:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:30:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:30:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:00:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 68
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 68
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 68
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 68
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 68
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 68
ERROR - 2017-12-13 12:03:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 82
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 82
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 95
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 82
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 82
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 95
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 82
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 82
ERROR - 2017-12-13 12:03:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 95
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 57
ERROR - 2017-12-13 12:04:32 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 12:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 71
ERROR - 2017-12-13 07:35:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:35:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:35:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:35:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:39:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:39:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:09:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 12:10:05 --> Query error: Table 'db_methew_gar.master_location' doesn't exist - Invalid query: SELECT *
FROM `master_location`
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:10:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Undefined index: location_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:52 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:11:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:14:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 07:47:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 07:47:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 07:47:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 07:47:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:17:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$color D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 72
ERROR - 2017-12-13 12:20:31 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 85
ERROR - 2017-12-13 12:21:29 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:21:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:21:29 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:21:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:21:29 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:21:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:23:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:24:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 56
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 63
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:25:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:26:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:31:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:32:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 12:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 43
ERROR - 2017-12-13 08:08:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:08:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 12:40:34 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:40:42 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:04 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:25 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:25 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:25 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:41 --> Severity: Notice --> Undefined index: pro_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:41 --> Severity: Notice --> Undefined index: pro_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:41:41 --> Severity: Notice --> Undefined index: pro_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:42:01 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:42:01 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:42:01 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:43:16 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:43:17 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:43:17 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:02 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:02 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:02 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:18 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:19 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:19 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:56 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:56 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:44:56 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:45:47 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:45:47 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:45:47 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:18 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:28 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:28 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:28 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:55 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:55 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:46:55 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:47:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:47:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:47:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:48:07 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:48:07 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:48:07 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:48:15 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:48:15 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:48:15 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:49:25 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:49:25 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:49:25 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:50:07 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:50:07 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:50:07 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 12:51:51 --> Severity: Notice --> Undefined variable: print_r D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 63
ERROR - 2017-12-13 12:51:51 --> Severity: Error --> Function name must be a string D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 63
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Undefined index: p_create D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:01:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:02:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:02:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:03:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:03:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:03:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:03:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:04:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:04:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:05:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:06:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-13 13:07:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 81
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:08:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:33 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 13:09:33 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 56
ERROR - 2017-12-13 08:39:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:39:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:09:49 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 13:09:49 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 56
ERROR - 2017-12-13 08:39:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:39:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:40:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:40:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:10:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:10:13 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 08:40:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:40:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:16 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 08:42:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:42:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:28 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 08:42:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:42:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:47 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 08:42:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:42:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:12:53 --> Severity: Notice --> Undefined variable: 7 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 84
ERROR - 2017-12-13 08:42:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:42:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:43:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:43:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:13:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:43:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:43:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:43:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:43:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:13:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:43:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:43:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:46:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:46:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:16:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:46:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:46:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:16:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:46:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:46:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:47:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:47:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:47:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:47:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:50:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:50:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:50:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:50:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:50:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:50:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:50:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:50:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:50:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:50:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:51:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:51:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:51:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:51:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:22:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:23:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:53:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:53:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:53:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:53:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:54:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:54:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:27 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 54
ERROR - 2017-12-13 13:24:27 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 55
ERROR - 2017-12-13 13:24:27 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 56
ERROR - 2017-12-13 08:54:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:54:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:54:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:54:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:24:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:54:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:54:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:54:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:54:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:54:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:54:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:54:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:54:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:54:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:54:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:54:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:54:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:25:17 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 54
ERROR - 2017-12-13 08:55:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:55:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:25:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:55:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:55:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:55:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:55:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:55:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 08:55:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:58:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:58:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:58:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 08:58:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:28:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 08:59:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 08:59:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:02:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:02:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:02:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:02:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:02:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:02:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:03:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:03:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:03:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:03:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:33:53 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:03:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:03:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:04:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:04:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:04:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:04:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:04:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:04:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:35:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:05:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:05:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:07:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:07:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:07:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:07:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:10:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:10:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:10:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:10:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:10:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:10:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:10:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:10:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:10:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:10:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:41:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:11:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:11:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:13:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:13:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:13:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:13:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:13:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:13:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:13:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:13:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:13:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:13:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:13:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:13:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:14:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:14:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:15:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:15:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:15:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:15:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:45:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:15:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:15:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:15:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:15:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:15:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:15:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:15:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:15:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:46:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:17:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:17:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:17:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:17:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:18:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:18:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:18:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:18:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:48:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:18:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:18:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:18:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:18:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:18:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:18:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:18:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:18:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:18:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:18:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:19:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:19:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:20:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:20:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:50:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:20:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:20:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:20:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:20:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:50:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:20:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:20:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:21:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:21:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:21:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:21:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:21:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:21:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:51:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:21:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:21:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:22:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:22:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:24:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:24:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:28:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:28:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:28:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:28:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:28:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:28:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:28:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:28:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:28:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:28:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:58:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 13:59:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 09:29:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 09:29:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 09:29:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:29:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:29:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:29:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:30:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 09:30:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:05:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:05:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:05:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:05:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:05:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:05:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:06:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:06:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:09:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:09:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 14:42:51 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT max(cus_ref_no)
FROM `cb_customer`
ERROR - 2017-12-13 14:43:09 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT max(cus_ref_no)
FROM `cb_customer`
ERROR - 2017-12-13 14:43:30 --> Severity: Notice --> Undefined index: max(cus_ref_no) D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 90
ERROR - 2017-12-13 10:13:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:13:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:13:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:13:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:14:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:14:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:14:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:14:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:14:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:14:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:14:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:14:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:15:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:15:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:16:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:16:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:16:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:16:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:19:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 14:50:48 --> Severity: Parsing Error --> syntax error, unexpected 'max' (T_STRING), expecting ',' or ';' D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 90
ERROR - 2017-12-13 10:20:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:20:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:21:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:21:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:21:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:21:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:22:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:22:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:22:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:22:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:23:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:23:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:23:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:23:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:23:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:23:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:28:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:28:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:28:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:28:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:30:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:30:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 92
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:01:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:02:43 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:03:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:04:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 10:34:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:34:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 15:05:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 76
ERROR - 2017-12-13 10:35:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:35:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:37:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:37:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 10:37:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:37:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 10:37:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:37:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 15:07:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-13 10:37:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:37:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-13 10:44:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:44:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:44:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:44:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:46:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:46:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:46:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:46:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:46:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 10:46:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-13 15:21:09 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-13 10:51:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-13 10:51:09 --> 404 Page Not Found: Audio/fail.mp3
