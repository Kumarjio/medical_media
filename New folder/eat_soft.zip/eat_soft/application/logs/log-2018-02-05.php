ERROR - 2018-02-05 04:06:20 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-05 04:06:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:06:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:06:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:06:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:06:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:06:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:06:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:06:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:06:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:07:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:07:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:07:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:07:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:07:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:07:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:07:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:07:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:12:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:12:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:12:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:12:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:12:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:12:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:12:38 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-05 04:12:38 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-05 04:13:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:13:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:13:36 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-05 04:13:36 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-05 04:14:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:14:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:14:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:14:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:14:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:14:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:14:35 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:14:35 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:14:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:14:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:14:54 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:14:54 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:14:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:14:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:15:00 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:00 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:15:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:15:13 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:13 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:15:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:15:20 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:20 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:15:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 09:45:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2018-02-05 09:45:34 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2018-02-05 09:45:34 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2018-02-05 09:45:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2018-02-05 09:45:34 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2018-02-05 09:45:34 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2018-02-05 04:15:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:15:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:15:44 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:44 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-02-05 04:15:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:15:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:16:02 --> 404 Page Not Found: Brand/audio
ERROR - 2018-02-05 04:16:02 --> 404 Page Not Found: Brand/audio
ERROR - 2018-02-05 04:16:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:16:14 --> 404 Page Not Found: Brand/audio
ERROR - 2018-02-05 04:16:14 --> 404 Page Not Found: Brand/audio
ERROR - 2018-02-05 04:16:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:16:19 --> 404 Page Not Found: Brand/audio
ERROR - 2018-02-05 04:16:19 --> 404 Page Not Found: Brand/audio
ERROR - 2018-02-05 04:16:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:16:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:16:30 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:16:30 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:16:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:16:38 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:16:38 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:16:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:16:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:01 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:17:01 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:17:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:19 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:17:19 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-05 04:17:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:30 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:30 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:38 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:38 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:43 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:43 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 09:47:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 14
ERROR - 2018-02-05 09:47:48 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 24
ERROR - 2018-02-05 09:47:48 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 38
ERROR - 2018-02-05 09:47:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 14
ERROR - 2018-02-05 09:47:48 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 24
ERROR - 2018-02-05 09:47:48 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 38
ERROR - 2018-02-05 04:17:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:17:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:17:55 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:17:55 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:18:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:18:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:18:05 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:18:05 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:18:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:18:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:18:10 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:18:10 --> 404 Page Not Found: Color/audio
ERROR - 2018-02-05 04:18:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:18:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:18:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:18:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:18:26 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-05 04:18:26 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-05 04:22:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:22:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:22:09 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-05 04:22:09 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-05 04:22:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:22:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 09:53:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 04:23:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:23:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:23:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:23:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:23:28 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:23:28 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:23:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:23:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:23:48 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:23:48 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:03 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:03 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:05 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:05 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:24:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:20 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:20 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:52 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:52 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:53 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:25:53 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:07 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:07 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:08 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:08 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:35 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:35 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:51 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:51 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:58 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:26:58 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 04:27:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:27:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:27:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:27:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:29:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:29:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:32:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:32:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 10:02:47 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:02:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 04:35:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:35:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:35:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:35:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:35:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:35:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:35:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:35:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:35:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:35:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:35:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:35:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:36:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:36:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 10:06:52 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:52 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 90
ERROR - 2018-02-05 10:06:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\helpers\url_helper.php 561
ERROR - 2018-02-05 10:07:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:38:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:38:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:08:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:45:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 04:45:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:52:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:52:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:52:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:52:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:22:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:53:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:53:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:23:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined index: hsn_code E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 221
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:24:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:24:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:37 --> Query error: Unknown column 'tbl_product.hsn_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_hold`
JOIN `tbl_grn_hold` ON `tbl_grn_hold`.`po_ref_id`=`tbl_po_inv_hold`.`po_hold_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_grn_hold`.`color_ref_id`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_grn_hold`.`product_img_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_grn_hold`.`size_ref_id`
LEFT JOIN `tbl_hsn` ON `tbl_hsn`.`hsn_id`=`tbl_product`.`hsn_ref_id`
WHERE `po_hold_id` = '2'
ERROR - 2018-02-05 10:25:37 --> Query error: Unknown column 'po_hold_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1517806537
WHERE `po_hold_id` = '2'
AND `id` = '5cf9e6939ab24ac8aff5caec98797dcf7604cad1'
ERROR - 2018-02-05 10:25:58 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:25:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:56:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:56:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:56:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:56:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:56:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:56:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 10:26:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:56:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:56:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:26:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:58:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:58:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:58:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:58:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:58:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:58:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:58:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:58:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:28:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:59:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 04:59:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:59:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:59:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 10:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-05 04:59:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:59:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:59:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 04:59:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:59:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 04:59:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 05:00:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:00:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:02:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:02:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:02:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:02:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:03:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:03:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:03:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:03:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:03:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:03:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:04:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:04:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:05:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:05:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:05:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:05:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:09:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:09:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:11:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:11:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:11:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:11:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:12:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:12:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:13:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:13:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:14:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:14:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:16:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:16:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:17:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:17:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:19:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:19:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:21:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:21:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:27:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:27:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:28:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:28:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:28:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:28:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:29:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:29:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:30:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:31:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:31:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:31:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:31:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:31:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:31:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:32:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:32:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:32:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:32:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:32:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:32:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:33:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:33:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:33:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:33:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:33:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:33:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:34:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:35:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:35:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:35:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:35:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:35:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 05:35:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 11:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 05:35:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 05:35:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 05:38:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 05:38:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 11:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 05:38:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 05:38:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-05 11:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-05 05:38:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 05:38:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 05:38:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 05:38:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 05:38:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:38:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:39:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:39:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:40:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:40:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:45:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:45:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:47:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:47:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:48:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:48:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:49:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 05:49:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:06:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:06:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:06:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:06:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:06:43 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-05 06:06:43 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-05 06:08:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:08:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:08:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:08:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:08:57 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 06:08:57 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-05 06:09:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:09:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:09:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:09:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:10:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:10:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:10:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:10:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:10:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:10:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:10:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:10:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:10:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:10:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:11:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:11:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:12:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:12:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:12:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:12:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:13:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:13:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:14:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:14:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:14:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:14:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:14:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:14:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:15:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:15:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:15:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:15:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:15:48 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:15:48 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:17:37 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:17:37 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:17:42 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:17:42 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:22:34 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:22:34 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:22:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:22:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-05 06:25:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:25:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:25:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:25:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:28:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:28:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:29:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:29:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:29:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:29:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:29:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:29:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:30:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:30:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:31:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:31:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:31:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:31:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:31:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:31:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:38:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:38:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-05 06:38:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 06:38:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 06:38:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:38:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:43:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:43:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:44:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:44:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:44:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:44:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:44:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:44:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:45:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:45:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:46:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:46:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:46:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:46:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:47:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:47:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:47:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:47:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:48:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:48:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:49:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:49:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:49:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:49:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:50:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:50:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:51:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:51:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:54:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 06:54:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:03:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:03:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:03:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:03:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:05:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:05:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:06:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:06:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:06:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:06:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:07:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:07:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:09:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:09:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:09:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:09:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:10:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:10:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:10:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:10:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:10:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:10:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:13:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:13:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:13:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:13:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:13:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:13:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:14:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:14:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:15:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:15:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:16:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:17:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:17:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:18:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:18:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:19:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:19:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:20:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:20:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:20:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:20:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:22:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:22:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:23:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:23:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:24:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:24:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:24:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:24:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:24:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:24:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:25:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:25:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:25:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:25:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:25:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:25:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:26:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:26:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:26:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 07:26:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 08:44:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 08:44:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 08:44:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-05 08:44:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-05 08:44:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-05 08:44:23 --> 404 Page Not Found: Goodsreceived/audio
