<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-06 05:05:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:05:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:05:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:05:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:06:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:06:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:06:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:06:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:06:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:06:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:06:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:06:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:07:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:07:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:07:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:07:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:30:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:30:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:30:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:30:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:30:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:30:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:30:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:30:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:31:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:31:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 10:02:18 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 55
ERROR - 2017-12-06 05:32:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:32:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:38:46 --> Severity: Parsing Error --> syntax error, unexpected '$locationdata' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 46
ERROR - 2017-12-06 05:39:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:39:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:40:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:40:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:40:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:40:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:40:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:40:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:40:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:40:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:41:33 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:41:33 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:42:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:42:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:18:09 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 64
ERROR - 2017-12-06 10:18:20 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 64
ERROR - 2017-12-06 10:18:21 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\xampp\htdocs\duty\mathewgarments\application\views\product_list.php 64
ERROR - 2017-12-06 05:50:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:50:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:51:11 --> 404 Page Not Found: Images/15125352358803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 05:51:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:51:11 --> 404 Page Not Found: Images/15125352118803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 05:51:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:51:36 --> 404 Page Not Found: Images/.15125352358803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 05:51:36 --> 404 Page Not Found: Images/.15125352118803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 05:51:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:51:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:52:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:52:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:52:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:52:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:53:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:53:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:53:41 --> 404 Page Not Found: 15125352358803-tecasafe-plus-pantjpg/index
ERROR - 2017-12-06 05:53:41 --> 404 Page Not Found: 15125352118803-tecasafe-plus-pantjpg/index
ERROR - 2017-12-06 05:53:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:53:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:54:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:54:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:54:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:54:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 05:56:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:56:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 05:57:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 05:57:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:00:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:00:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:07:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:07:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:07:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:07:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:07:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:07:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:07:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:07:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:11:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:11:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:11:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:11:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:12:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:12:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:12:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:12:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:13:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:13:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 06:13:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:13:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:13:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:13:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:14:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:14:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:14:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:14:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:15:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:15:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:15:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:15:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:15:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:15:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:15:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:15:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:47:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 06:18:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:18:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:53:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:53:26 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 68
ERROR - 2017-12-06 10:53:26 --> You did not select a file to upload.
ERROR - 2017-12-06 06:23:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:23:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:53:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 06:24:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:24:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:25:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:25:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:25:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:25:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:25:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:25:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:56:16 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 68
ERROR - 2017-12-06 10:56:16 --> You did not select a file to upload.
ERROR - 2017-12-06 06:26:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:26:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:56:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:56:44 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 68
ERROR - 2017-12-06 10:56:44 --> You did not select a file to upload.
ERROR - 2017-12-06 06:26:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:26:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:28:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:28:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:29:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:29:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 10:59:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 10:59:28 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 10:59:28 --> You did not select a file to upload.
ERROR - 2017-12-06 06:29:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:29:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:30:55 --> Severity: Parsing Error --> syntax error, unexpected '".jpg"' (T_CONSTANT_ENCAPSED_STRING) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 06:31:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:31:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:31:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:31:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:31:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:31:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:01:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 11:01:30 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 11:01:30 --> You did not select a file to upload.
ERROR - 2017-12-06 06:31:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:31:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:02:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-06 11:02:18 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 11:02:18 --> You did not select a file to upload.
ERROR - 2017-12-06 06:32:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:32:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:33:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:33:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:04:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:04:05 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 11:04:05 --> You did not select a file to upload.
ERROR - 2017-12-06 06:34:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:34:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:04:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:04:19 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 11:04:19 --> You did not select a file to upload.
ERROR - 2017-12-06 06:34:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:34:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:04:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:04:29 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 61
ERROR - 2017-12-06 11:04:29 --> You did not select a file to upload.
ERROR - 2017-12-06 06:34:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:34:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:35:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:35:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:35:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:35:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:36:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:36:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:06:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:36:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:36:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:36:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:36:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:36:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:36:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:06:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:37:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:37:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:46:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:46:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:47:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:47:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:47:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:47:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:47:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:47:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:47:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:47:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:47:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:47:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:47:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:47:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:48:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:48:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:48:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:48:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-06 06:48:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:48:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:19:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:49:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:49:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:49:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:49:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-06 11:19:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-06 06:49:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:49:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:50:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:50:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:50:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:50:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:50:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 06:50:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 06:54:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:54:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:55:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:55:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:27:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 11:27:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 11:27:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 11:27:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 06:57:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:57:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:28:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 11:28:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 11:28:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 11:28:12 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 06:58:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:58:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:58:32 --> 404 Page Not Found: Goodsreceived/1512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 06:58:32 --> 404 Page Not Found: Goodsreceived/15125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 06:58:32 --> 404 Page Not Found: Goodsreceived/15125392811.jpg
ERROR - 2017-12-06 06:58:32 --> 404 Page Not Found: Goodsreceived/15125393912.jpg
ERROR - 2017-12-06 06:58:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:58:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:59:38 --> 404 Page Not Found: Goodsreceived/1512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 06:59:38 --> 404 Page Not Found: Goodsreceived/15125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 06:59:38 --> 404 Page Not Found: Goodsreceived/15125392811.jpg
ERROR - 2017-12-06 06:59:38 --> 404 Page Not Found: Goodsreceived/15125393912.jpg
ERROR - 2017-12-06 06:59:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 06:59:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:00:07 --> 404 Page Not Found: Goodsreceived/1512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 07:00:07 --> 404 Page Not Found: Goodsreceived/15125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 07:00:07 --> 404 Page Not Found: Goodsreceived/15125392811.jpg
ERROR - 2017-12-06 07:00:07 --> 404 Page Not Found: Goodsreceived/15125393912.jpg
ERROR - 2017-12-06 07:00:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:00:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:00:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:00:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:04:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:04:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:05:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:05:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:05:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:05:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:08:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:08:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:40:00 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:10:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:10:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:11:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:11:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:12:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:12:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:48:35 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:19:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:19:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:19:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:19:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:21:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:21:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:23:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:23:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:24:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:24:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:24:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:24:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:27:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:27:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:35:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:35:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:27 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:28 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:28 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:28 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:28 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:59 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:59 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:59 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:05:59 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:35:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:35:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:36:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:36:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:36:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:36:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:30 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:31 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:31 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:31 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:06:31 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 07:36:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:36:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:36:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:36:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:38:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:38:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:41:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:41:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:41:51 --> 404 Page Not Found: Goodsreceived/1.jpg
ERROR - 2017-12-06 07:43:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:43:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 07:43:04 --> 404 Page Not Found: Goodsreceived/Images
ERROR - 2017-12-06 08:05:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:05:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:05:08 --> 404 Page Not Found: Goodsreceived/Images
ERROR - 2017-12-06 08:11:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:11:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:13:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:13:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:13:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:13:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:15:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:15:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:16:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:16:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:16:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:16:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:17:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:17:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:18:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:18:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:22:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:22:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:24:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:24:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:24:14 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:24:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:24:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:24:41 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:30:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:30:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:30:08 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:30:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:30:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:30:27 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:30:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:30:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:30:44 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:31:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:31:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:31:02 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:31:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:31:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:31:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:31:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:31:27 --> 404 Page Not Found: Goodsreceived/images
ERROR - 2017-12-06 08:32:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:32:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:32:16 --> 404 Page Not Found: Goodsreceived/images%E2%88%95audi.png
ERROR - 2017-12-06 08:33:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:33:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:33:33 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95images%E2%88%95audi.png
ERROR - 2017-12-06 13:04:53 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:04:53 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:04:53 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:04:53 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 08:34:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:34:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 08:36:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:36:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:36:06 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%95
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 13:06:06 --> Severity: Notice --> Undefined index: image D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 08:36:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:36:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:36:47 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%95
ERROR - 2017-12-06 08:37:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:37:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:37:12 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%95
ERROR - 2017-12-06 08:37:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:37:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:37:43 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%95
ERROR - 2017-12-06 08:38:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:38:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:38:26 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:38:26 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 08:38:26 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:38:26 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:38:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:38:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:38:48 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:38:48 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 08:38:48 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:38:48 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:39:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:39:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:39:24 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:39:24 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 08:39:24 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:39:24 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:40:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:40:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:40:53 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:40:53 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:40:53 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 08:40:53 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:41:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:41:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:41:17 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:41:17 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:41:17 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:41:17 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 08:42:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 08:42:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 08:42:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:42:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:42:18 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:42:18 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:42:18 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 08:42:18 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:57:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 08:57:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 08:57:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 08:57:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 08:57:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:57:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 08:57:30 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%951512539241padmashree-cotton-sarees-500x500.jpg
ERROR - 2017-12-06 08:57:30 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125393912.jpg
ERROR - 2017-12-06 08:57:30 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392811.jpg
ERROR - 2017-12-06 08:57:30 --> 404 Page Not Found: Goodsreceived/%E2%88%95%E2%88%95localhost%E2%88%95duty%E2%88%95mathewgarments%E2%88%95Images%E2%88%9515125392608803-tecasafe-plus-pant.jpg
ERROR - 2017-12-06 09:27:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:27:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:27:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:27:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:28:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:28:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:30:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:30:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:30:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:30:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:35:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:35:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:36:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:36:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:36:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:36:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:37:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:37:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:44:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:44:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:44:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:44:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:44:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:44:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:44:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:44:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:45:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:45:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:45:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:45:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:46:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:46:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:46:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:46:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:46:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:46:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:46:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:46:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:46:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:46:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:46:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:46:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 14:17:20 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 47
ERROR - 2017-12-06 14:17:20 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 109
ERROR - 2017-12-06 14:17:20 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 124
ERROR - 2017-12-06 09:47:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:47:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:47:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:47:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:47:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:47:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:49:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:49:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:51:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:51:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:54:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:54:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:54:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:54:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:54:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:54:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:54:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:54:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:55:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:55:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:55:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:55:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:55:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:55:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 09:56:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:56:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:56:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:56:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:56:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:56:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:58:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:58:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:59:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:59:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 09:59:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 09:59:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:00:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:00:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:00:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:00:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:02:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:02:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:03:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:03:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:03:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:03:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:04:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:04:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:04:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:04:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:05:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:05:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:05:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:05:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:06:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:06:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:06:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:06:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:06:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:06:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:07:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:07:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:07:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:07:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:07:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:07:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:08:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:08:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:09:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:09:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:09:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:09:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:12:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:12:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:12:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:12:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:15:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:15:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 14:46:16 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 47
ERROR - 2017-12-06 14:46:16 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 109
ERROR - 2017-12-06 14:46:16 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 124
ERROR - 2017-12-06 10:16:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:16:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:16:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:16:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:18:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:18:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:19:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:19:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:19:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:19:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:20:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:20:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:20:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:20:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 14:51:08 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 14:51:08 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 10:21:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:21:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 14:51:19 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 14:51:19 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 10:21:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:21:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 14:51:54 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 14:51:54 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 10:21:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:21:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 15:04:20 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 15:04:20 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-12-06 10:34:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:34:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:34:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:34:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:35:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:35:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:35:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:35:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:35:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:35:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:44:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:44:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:44:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:44:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:44:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:44:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:45:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:45:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:45:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:45:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:46:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-06 10:46:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-06 10:54:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:54:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:55:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 10:55:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:02:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:02:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:02:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:02:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:04:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:04:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:04:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:04:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:05:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:05:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:43:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:43:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:44:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:44:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:45:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:45:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:45:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:45:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:45:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:45:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:46:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:46:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:46:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:46:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:51:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 11:51:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:00:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:00:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 16:31:01 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:01:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:01:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 16:31:29 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:01:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:01:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 16:31:40 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:01:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:01:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:02:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:02:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:06:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 16:38:39 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:08:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:08:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 16:38:57 --> Severity: Notice --> Undefined index: product_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 192
ERROR - 2017-12-06 12:08:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:08:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:09:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:09:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:13:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:13:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:14:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:14:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:14:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:14:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:16:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:16:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:18:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:18:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:20:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:20:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:21:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:21:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:21:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:21:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:22:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:22:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:36:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:36:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:37:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:37:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:37:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:37:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 17:07:56 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 24
ERROR - 2017-12-06 12:38:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:38:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 17:08:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 24
ERROR - 2017-12-06 12:39:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:39:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:41:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:41:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:41:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:41:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:42:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:42:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:42:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:42:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:43:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:44:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:44:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:46:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:46:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:47:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:48:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:48:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:48:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:48:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:50:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:50:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:52:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:52:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:52:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:52:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:55:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:55:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:55:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:55:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:56:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:56:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:58:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 12:58:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:01:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:01:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:02:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:02:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:03:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:03:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:05:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:05:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:06:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:06:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:06:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:06:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:07:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:07:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:13:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:13:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:13:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:13:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:21:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:21:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:22:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:22:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:26:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:26:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:28:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:28:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:30:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:30:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:30:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:30:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:32:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:32:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:33:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:33:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:33:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:33:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:34:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:34:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:34:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:34:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:37:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:37:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:38:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:38:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:38:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:38:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:39:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:39:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:40:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:40:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:42:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:42:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:43:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:43:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:43:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:43:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:44:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:44:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:44:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:44:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:45:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:45:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:46:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:46:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:48:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:48:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:52:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:52:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:52:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:52:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:53:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:53:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:53:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:53:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:55:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-06 13:55:31 --> 404 Page Not Found: Goodsreceived/audio
