<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-12 05:05:23 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-12 05:05:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 05:06:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 05:06:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 05:06:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 05:06:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 05:07:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 05:07:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 05:07:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-12 05:07:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-12 05:08:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-12 05:08:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-12 05:22:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 05:22:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 06:16:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 06:16:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 06:16:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 06:16:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 06:16:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-12 06:16:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-12 13:49:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 13:49:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 13:51:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 13:51:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 13:58:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 13:58:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 13:58:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 13:58:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 13:58:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 13:58:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:01:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 14:01:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:01:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 14:01:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:01:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:01:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 14:01:59 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:01:59 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:02:18 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:02:18 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:02:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:02:24 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:02:24 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:02:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 18:32:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:32:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:32:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:32:55 --> Severity: Notice --> Undefined variable: prodcut D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:32:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:32:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:32:56 --> Severity: Notice --> Undefined variable: prodcut D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:32:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:32:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:32:56 --> Severity: Notice --> Undefined variable: prodcut D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:32:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:32:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:33:04 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:33:05 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:33:05 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:34:51 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:34:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:34:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:34:53 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:34:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:34:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:34:53 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:34:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:34:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:35:31 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:35:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:35:32 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:35:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:35:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:35:32 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:35:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:35:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:39:00 --> Severity: Compile Error --> Cannot redeclare Product_model::edit_unit() D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 180
ERROR - 2017-12-12 18:39:15 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:39:17 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:39:17 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:42:39 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:42:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:42:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:42:40 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:42:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:42:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:42:40 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:42:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:42:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:43:01 --> Severity: Notice --> Undefined property: stdClass::$unit_name D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:43:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:43:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:43:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:43:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:43:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:43:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:43:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:43:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:43:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:43:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:43:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:43:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 14:13:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 14:13:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:14:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:14:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 14:14:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 14:14:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:14:48 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:14:48 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-12 14:14:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:14:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-12 18:44:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:44:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:45:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 18:45:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2017-12-12 18:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2017-12-12 18:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2017-12-12 14:15:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-12 14:15:28 --> 404 Page Not Found: Audio/alert.mp3
