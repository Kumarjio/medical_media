<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-26 04:08:34 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-26 04:08:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:08:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:08:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:09:42 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:09:42 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:09:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:09:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 09:39:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 04:11:56 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:11:56 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:16:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:16:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:16:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:16:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:17:14 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:17:14 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:22:56 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:22:56 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:23:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:23:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 09:53:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 04:23:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:23:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:23:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:23:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:27:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:27:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:27:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:27:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:27:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:27:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:27:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 04:27:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 04:27:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:27:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:28:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:28:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:28:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 04:28:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 09:58:54 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-26 09:58:54 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-26 04:28:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:28:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:59:20 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-26 09:59:20 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-26 04:29:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:29:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:59:26 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-26 09:59:26 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-26 04:29:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:29:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:31:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:31:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:31:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:31:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:31:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:31:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:31:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:31:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:31:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:31:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:01:39 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2018-01-26 10:01:39 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516941099
WHERE `id` = 'ba36bb04a1b609cbc6f29ef7390bf7a242654846'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2018-01-26 04:32:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:32:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:32:05 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:32:05 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:32:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:32:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:33:16 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:33:16 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 10:03:19 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2018-01-26 10:03:19 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516941199
WHERE `id` = 'ba36bb04a1b609cbc6f29ef7390bf7a242654846'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2018-01-26 04:33:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:33:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:33:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:33:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:33:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:33:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:33:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:33:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:33:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:33:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:33:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:33:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:33:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:33:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:34:03 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:34:03 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:34:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:34:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:34:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:34:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:34:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:34:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:34:21 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:34:21 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:34:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:34:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:34:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:34:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:34:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:34:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:34:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:34:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 04:34:47 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:34:47 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:35:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:35:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 04:35:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:35:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:35:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:35:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:36:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:36:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:37:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:37:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:40:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:40:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:40:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:40:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:43:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:43:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:43:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:43:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 49
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 58
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 65
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 73
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 85
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 85
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 114
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-01-26 10:14:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 144
ERROR - 2018-01-26 04:44:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:44:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:45:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:45:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:45:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:45:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:45:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:45:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:45:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:45:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:45:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 04:45:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 04:46:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 04:46:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 04:46:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:46:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:46:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:46:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 04:48:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:48:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:48:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 04:48:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 04:56:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 04:56:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-26 10:26:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-26 04:57:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 04:57:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:00:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:00:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:00:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:00:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:20:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:20:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:50:26 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 10:50:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 10:50:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 10:50:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 10:51:21 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 68
ERROR - 2018-01-26 10:51:21 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 74
ERROR - 2018-01-26 10:51:21 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 78
ERROR - 2018-01-26 10:58:04 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 91
ERROR - 2018-01-26 05:28:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:28:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:28:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:28:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:30:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:30:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:30:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:30:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:30:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:30:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:30:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 05:30:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 05:35:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:35:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:35:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 05:35:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 05:36:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:36:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:36:23 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 05:36:23 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 05:40:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:40:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:40:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:40:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:40:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:40:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:40:44 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 05:40:44 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 05:40:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:40:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:41:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:41:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:41:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:41:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:41:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:41:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:41:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:41:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:42:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:42:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:42:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 05:42:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 05:42:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 05:42:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 05:44:03 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 05:44:03 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 11:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-26 05:46:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:46:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:47:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:47:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:48:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:48:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:48:38 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 05:48:38 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 05:51:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:51:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:51:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:51:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:53:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:53:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:53:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:53:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:53:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:53:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:54:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:54:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:54:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:54:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:54:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:54:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:54:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:54:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:55:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 05:55:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 05:55:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:55:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 05:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:00:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:00:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:01:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:01:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 11:31:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-26 11:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-26 06:02:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:02:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:02:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:02:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:05:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:05:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:05:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:05:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:05:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:05:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:06:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:06:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:06:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:06:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:06:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:06:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:36:26 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 11:36:26 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 11:36:29 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 11:36:29 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 11:36:56 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 11:36:56 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 11:37:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 11:37:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 11:37:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 11:37:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 06:07:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:07:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:07:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:07:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:38:40 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-26 11:38:40 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-26 06:08:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:08:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:18:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:18:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:18:40 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-26 06:18:40 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-26 06:20:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:20:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:20:10 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:20:10 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:23:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:23:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:24:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:24:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:24:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:24:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:27:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:27:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:28:08 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:28:08 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:28:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:28:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:29:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:29:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:30:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:30:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:30:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:30:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:30:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:30:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:34:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:34:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:34:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:34:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:34:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:34:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:34:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:34:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:37:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:37:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:37:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:37:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:37:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:37:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:38:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:38:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:38:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:38:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:38:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:38:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:39:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:39:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:39:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:39:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:39:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 06:39:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 06:40:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:40:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:40:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:40:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:40:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:40:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:40:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 06:40:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 06:43:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:43:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:44:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:44:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:44:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:44:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:45:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:45:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:45:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:45:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:45:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:45:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 06:45:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:45:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:46:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:46:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:46:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:46:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:51:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:51:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:51:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:51:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:51:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:51:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:51:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:51:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 06:55:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:55:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:25:00 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:55:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:55:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:25:07 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:55:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:55:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:25:14 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:55:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:55:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:25:23 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:55:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:55:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:25:26 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:55:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:55:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:25:30 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:55:32 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 06:55:32 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 12:25:32 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:56:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:56:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:26:10 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:56:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 06:56:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:26:19 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:57:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 06:57:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:27:18 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:57:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:57:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:27:21 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:59:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:59:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:29:01 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 12:29:06 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 06:59:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 06:59:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:29:30 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:00:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 07:00:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:30:10 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:00:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 07:00:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:30:54 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:02:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 07:02:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:32:06 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:02:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 07:02:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:32:15 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:03:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 07:03:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 12:33:29 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:03:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 07:03:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:33:36 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 07:03:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 07:03:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 07:03:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 07:03:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 07:03:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 07:03:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 07:04:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 07:04:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 07:05:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 07:05:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 07:05:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 07:05:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 07:05:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 07:05:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 07:07:53 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 07:07:53 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-26 07:08:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 07:08:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 08:54:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 08:54:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 08:54:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 08:54:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 08:54:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 08:54:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 08:54:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 08:54:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 08:56:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 08:56:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 08:56:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 08:56:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:27:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:27:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 08:59:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 08:59:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:00:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:00:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:30:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:30:56 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 424
ERROR - 2018-01-26 09:00:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:00:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:01:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:01:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:01:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:01:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 09:01:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:01:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:02:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:02:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:02:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:02:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:32:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:33:05 --> Severity: Notice --> Undefined offset: 2 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 424
ERROR - 2018-01-26 09:03:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:03:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:03:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:03:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:03:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:03:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:34:06 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 145
ERROR - 2018-01-26 14:34:06 --> Severity: Notice --> Undefined variable: style E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 146
ERROR - 2018-01-26 14:34:17 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 424
ERROR - 2018-01-26 09:04:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:04:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:08:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:08:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 14:38:42 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:08:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:08:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 14:38:43 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:08:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:08:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:38:46 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:09:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:09:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:39:43 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 14:44:11 --> Severity: Notice --> Undefined variable: probes E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 104
ERROR - 2018-01-26 14:44:11 --> Severity: Notice --> Undefined variable: material E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 105
ERROR - 2018-01-26 14:44:11 --> Severity: Notice --> Undefined variable: brand E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 106
ERROR - 2018-01-26 14:44:11 --> Severity: Notice --> Undefined variable: probes E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 104
ERROR - 2018-01-26 14:44:11 --> Severity: Notice --> Undefined variable: material E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 105
ERROR - 2018-01-26 14:44:11 --> Severity: Notice --> Undefined variable: brand E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 106
ERROR - 2018-01-26 09:14:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:14:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:44:12 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:14:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:14:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:44:38 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:45:54 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 14:46:26 --> Severity: Notice --> Undefined offset: 2 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 424
ERROR - 2018-01-26 09:16:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:16:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:46:26 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:18:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:18:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:48:39 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:19:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:19:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:49:50 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:20:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:20:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:50:26 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:26:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:26:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:56:05 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-26 14:56:08 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:27:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:27:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 14:57:45 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:29:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:29:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 14:59:28 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:29:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:29:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 14:59:30 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:30:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:30:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:00:13 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:00:45 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:00:51 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:31:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:31:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:01:37 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:01:41 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:01:48 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:32:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:32:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:02:55 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:02:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:02:57 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:33:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:33:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 15:03:07 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:33:09 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 09:33:09 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-26 15:03:09 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:33:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:33:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:03:42 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:33:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:33:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:03:47 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:03:49 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:04:20 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 426
ERROR - 2018-01-26 09:34:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:34:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:04:21 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-26 15:05:41 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:06:40 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 426
ERROR - 2018-01-26 09:36:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:36:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:06:40 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:38:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:38:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:08:27 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:38:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:38:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:08:32 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:39:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:39:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:09:05 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 09:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-26 15:09:06 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:39:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:39:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:09:24 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-26 15:09:33 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:09:42 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:39:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 09:39:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 15:09:48 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:40:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 09:40:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-26 15:10:28 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:40:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:40:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:10:37 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:41:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:41:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:11:15 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:41:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:41:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:41:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:41:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:41:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:41:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:41:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:41:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:11:29 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:33 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:34 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:36 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:11:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 15:11:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 15:11:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 09:42:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:42:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:12:04 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:42:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:42:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:12:11 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:42:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:42:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:12:29 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:42:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:42:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:12:32 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:12:35 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:35 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:36 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:36 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:38 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:38 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:39 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:39 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:40 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:40 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:41 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:41 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:42 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:42 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:43 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:43 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:44 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:44 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:46 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:12:46 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:12:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 15:12:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 09:43:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:43:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:13:04 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:43:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:43:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 15:13:20 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:43:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:43:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:13:36 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:43:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:43:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:13:38 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:13:40 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-26 15:13:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-26 09:43:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:43:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:13:45 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:43:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:43:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:13:52 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:13:54 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:13:54 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 09:44:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:44:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:14:54 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:44:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:44:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:14:57 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:15:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 15:15:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 09:45:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:45:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:15:06 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:45:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:45:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:15:10 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:45:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:45:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:15:12 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:45:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 09:45:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 15:15:16 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:58:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 09:58:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:28:58 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:59:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:59:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:29:02 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:59:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:59:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:29:04 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:29:06 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:29:06 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:29:09 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 15:29:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 09:59:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:59:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:29:20 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:59:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:59:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:29:52 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 09:59:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 09:59:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:29:56 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:29:58 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:29:58 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:01 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:01 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:03 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:03 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:05 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:05 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:06 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:06 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:09 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:09 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:10 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:10 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:11 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:11 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:12 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:12 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:15 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:15 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:17 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:30:17 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:30:21 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 15:30:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 10:00:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:00:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:30:32 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 10:01:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:01:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:31:00 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 10:01:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:01:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:31:03 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 15:31:07 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:07 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:09 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:09 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:10 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:10 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:11 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:11 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:12 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:12 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:14 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:14 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:15 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:15 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:17 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:17 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:20 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 15:31:20 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 15:31:21 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 15:31:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 10:01:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:01:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:31:30 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 10:01:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:01:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 15:31:44 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 10:05:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:05:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 10:05:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:05:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:10:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:11:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:11:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:11:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:11:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:12:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:12:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:13:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:13:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:14:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:14:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:14:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:14:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:15:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:15:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:15:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:15:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:16:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:16:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 15:46:48 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer.php 130
ERROR - 2018-01-26 10:17:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:17:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:18:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:18:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:21:14 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 10:21:14 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-26 10:21:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 10:21:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:21:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:21:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 10:26:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:26:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 10:26:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 10:26:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 10:26:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:26:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:28:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:28:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:29:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:29:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:34:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:34:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:36:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:36:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:36:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:36:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:36:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:36:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:37:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:37:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:39:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:39:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:39:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:39:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:48:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 10:48:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:03:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:03:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:07:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:07:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 16:38:03 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 120
ERROR - 2018-01-26 16:38:03 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 138
ERROR - 2018-01-26 16:38:03 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 156
ERROR - 2018-01-26 16:38:03 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 179
ERROR - 2018-01-26 16:39:02 --> Query error: Unknown column 'tbl_transfer_out.transfer_to' in 'on clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
JOIN `tbl_branch` ON `tbl_transfer_out`.`transfer_to` = `tbl_branch`.`branch_id`
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:39:02 --> Query error: Unknown column 'transfer_out_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516964942
WHERE `id` = '88e044c95d2ee9326a5d40a7129f1185e99073af'
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:40:40 --> Query error: Unknown column 'tbl_transfer_out.transfer_to' in 'on clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
JOIN `tbl_branch` ON `tbl_transfer_out`.`transfer_to` = `tbl_branch`.`branch_id`
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:40:40 --> Query error: Unknown column 'transfer_out_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516965040
WHERE `id` = '88e044c95d2ee9326a5d40a7129f1185e99073af'
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 11:10:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:10:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:10:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:10:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 16:40:58 --> Query error: Unknown column 'tbl_transfer_out.transfer_to' in 'on clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
JOIN `tbl_branch` ON `tbl_transfer_out`.`transfer_to` = `tbl_branch`.`branch_id`
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:40:58 --> Query error: Unknown column 'transfer_out_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516965058
WHERE `id` = '88e044c95d2ee9326a5d40a7129f1185e99073af'
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:42:10 --> Query error: Unknown column 'tbl_transfer_out.transfer_to' in 'on clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
JOIN `tbl_branch` ON `tbl_transfer_out`.`transfer_to` = `tbl_branch`.`branch_id`
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:42:10 --> Query error: Unknown column 'transfer_out_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516965130
WHERE `id` = '88e044c95d2ee9326a5d40a7129f1185e99073af'
ORDER BY `transfer_out_id` DESC
ERROR - 2018-01-26 16:42:41 --> Severity: Notice --> Undefined index: procudt_count E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 58
ERROR - 2018-01-26 11:12:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:12:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:14:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:14:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:18:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:18:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:18:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:18:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:19:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:19:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:20:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:20:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:20:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:20:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:20:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:20:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:21:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:21:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:22:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:22:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:25:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 11:25:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 11:25:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:25:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:26:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:26:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 16:56:24 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:26:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:26:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 16:56:54 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 16:58:27 --> Severity: Notice --> Undefined index: procudt_count E:\wamp\www\duty\mathewgarments\application\views\transfer_in.php 67
ERROR - 2018-01-26 16:58:27 --> Severity: Notice --> Undefined index: procudt_count E:\wamp\www\duty\mathewgarments\application\views\transfer_in.php 67
ERROR - 2018-01-26 11:28:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:28:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 16:58:28 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 16:59:04 --> Severity: Notice --> Undefined index: procudt_count E:\wamp\www\duty\mathewgarments\application\views\transfer_in.php 67
ERROR - 2018-01-26 16:59:04 --> Severity: Notice --> Undefined index: procudt_count E:\wamp\www\duty\mathewgarments\application\views\transfer_in.php 67
ERROR - 2018-01-26 11:29:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:29:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 16:59:05 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:29:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:29:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 16:59:19 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:30:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:30:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:00:06 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:31:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:31:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:01:02 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:31:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:31:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:01:53 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:31:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:31:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:01:56 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:36:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:36:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:06:18 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:37:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:37:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:07:12 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 17:07:19 --> Query error: Unknown column 'tbl_transfer_out.transfer_to' in 'on clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_transfer_out`.`transfer_to`
WHERE `tbl_transfer_out`.`dcno` = 'TO0001'
ERROR - 2018-01-26 17:07:19 --> Query error: Unknown column 'tbl_transfer_out.dcno' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516966639
WHERE `tbl_transfer_out`.`dcno` = 'TO0001'
AND `id` = 'b9353e22cddcda30babb97a0c71dcbcc12cca88b'
ERROR - 2018-01-26 17:08:26 --> Query error: Unknown column 'tbl_transfer_out_item.pro_bar_code' in 'on clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
LEFT JOIN `tbl_transfer_out_item` ON `tbl_transfer_out_item`.`transfer_out_ref_id`=`tbl_transfer_out`.`transfer_out_id`
LEFT JOIN `tbl_single_po_entry` ON `tbl_single_po_entry`.`single_po_entry_id`=`tbl_transfer_out_item`.`pro_bar_code`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
WHERE `tbl_transfer_out`.`dcno` = 'TO0001'
ERROR - 2018-01-26 17:08:26 --> Query error: Unknown column 'tbl_transfer_out.dcno' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516966706
WHERE `tbl_transfer_out`.`dcno` = 'TO0001'
AND `id` = 'b9353e22cddcda30babb97a0c71dcbcc12cca88b'
ERROR - 2018-01-26 17:09:21 --> Severity: Notice --> Undefined index: transfer_date E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 66
ERROR - 2018-01-26 11:39:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:39:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:09:22 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:40:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:40:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:10:38 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 17:10:41 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 17:10:41 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 17:10:43 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-26 17:10:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-26 17:10:49 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-26 17:10:49 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-26 11:40:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:40:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:10:53 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 11:44:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 11:44:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 17:14:15 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 12:05:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:05:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 17:35:28 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 17:35:38 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-26 17:35:38 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-26 12:05:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:05:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 17:35:38 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 12:07:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 12:07:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 17:37:09 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 12:27:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 12:27:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 17:57:20 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 17:57:24 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 18:04:46 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 224
ERROR - 2018-01-26 18:05:48 --> Query error: Unknown column 'sales_ref_id' in 'field list' - Invalid query: SELECT DISTINCT `sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `dcno`, `sales_ref_id`
FROM `tbl_transfer_out`
JOIN `tbl_transfer_out_item` ON `tbl_transfer_out_item`.`transfer_out_ref_id`=`tbl_transfer_out`.`transfer_out_id`
WHERE `tbl_transfer_out`.`transfer_out_id` = '1'
ERROR - 2018-01-26 18:05:48 --> Query error: Unknown column 'tbl_transfer_out.transfer_out_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516970148
WHERE `tbl_transfer_out`.`transfer_out_id` = '1'
AND `id` = 'd1300c9897f8fb533ca0f9d0242cb567120dcb17'
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 148
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 164
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 164
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 164
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 164
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 165
ERROR - 2018-01-26 18:32:45 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 165
ERROR - 2018-01-26 18:33:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 148
ERROR - 2018-01-26 18:38:53 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 18:39:07 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:20:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 13:20:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-26 18:50:32 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:20:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 13:20:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 18:50:38 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:20:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 13:20:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 18:50:39 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:20:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 13:20:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 18:50:44 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:25:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 13:25:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 18:55:52 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:26:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 13:26:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 18:56:22 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:28:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 13:28:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 18:58:44 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:31:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 13:31:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 19:01:47 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:32:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 13:32:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-26 19:02:28 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-26 13:32:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-26 13:32:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-26 19:02:36 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
