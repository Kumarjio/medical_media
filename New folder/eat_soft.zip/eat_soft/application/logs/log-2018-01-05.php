<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-05 04:08:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 04:08:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 04:09:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 04:09:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 04:09:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:09:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:16:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:16:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:18:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:18:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:18:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:18:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:19:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:19:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:20:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:20:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:20:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:20:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:22:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:22:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:22:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:22:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:22:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:22:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:24:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:24:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:24:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:24:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:29:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:29:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:33:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:33:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:34:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:34:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:37:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:37:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:39:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:39:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:39:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:39:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:45:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:45:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:46:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:46:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:47:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:47:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:48:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:48:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:50:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:50:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:51:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:51:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:52:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:52:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:54:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:54:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:55:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:55:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:56:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:56:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:57:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 04:57:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:00:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:00:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:05:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:05:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:10:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:10:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:12:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:12:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:12:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:12:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:13:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:13:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:17:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:17:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:18:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:18:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:18:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:18:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:20:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:20:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:21:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:21:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:21:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:21:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:22:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:22:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:22:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:22:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:23:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:23:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:25:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:25:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:26:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:26:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:30:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:30:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:31:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:31:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:37:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:37:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:39:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:39:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:41:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:41:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:42:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 05:42:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 05:45:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 05:45:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 05:45:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 05:45:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 05:54:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 05:54:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 05:54:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:54:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 11:25:08 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 158
ERROR - 2018-01-05 05:55:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:55:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:56:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 05:56:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 05:56:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 05:56:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 05:56:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:56:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 11:28:37 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 158
ERROR - 2018-01-05 05:58:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:58:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 05:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:00:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:00:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:00:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:00:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:00:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:00:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 11:31:00 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 11:31:00 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 11:31:00 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 11:31:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 11:31:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 11:31:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:01:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:01:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:01:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:01:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:01:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:01:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 11:33:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 191
ERROR - 2018-01-05 06:03:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:03:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:07:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:07:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:08:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:08:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:08:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:08:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:08:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:08:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:08:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:08:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 11:38:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 11:38:30 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 11:38:30 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 11:38:30 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 11:38:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 11:38:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 06:08:30 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:08:30 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 11:38:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:08:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:08:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 11:38:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:08:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:08:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:09:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:09:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:09:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:09:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 11:40:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 191
ERROR - 2018-01-05 06:10:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:10:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:13:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:13:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:13:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:13:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 11:44:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 191
ERROR - 2018-01-05 11:45:25 --> Severity: Parsing Error --> syntax error, unexpected ')' E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 192
ERROR - 2018-01-05 11:45:57 --> Severity: Error --> Call to undefined function isempty() E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 192
ERROR - 2018-01-05 06:19:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:19:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:19:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:19:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:33:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:33:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 12:04:04 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:04:04 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:04:04 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:04:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 12:04:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 12:04:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:34:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:34:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:04:12 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:04:12 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:04:12 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:04:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 12:04:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 12:04:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:34:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:34:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:04:21 --> Severity: Notice --> Undefined variable: prev_amount E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 185
ERROR - 2018-01-05 12:04:43 --> Severity: Notice --> Undefined variable: prev_amount E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 185
ERROR - 2018-01-05 12:05:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:35:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:35:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:05:26 --> Severity: Warning --> Missing argument 2 for Returndet::update_return_details() E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 108
ERROR - 2018-01-05 12:05:26 --> Severity: Notice --> Undefined variable: return_qty E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 109
ERROR - 2018-01-05 12:06:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:36:03 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:36:03 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:06:08 --> Severity: Notice --> Undefined variable: prev_amount E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 185
ERROR - 2018-01-05 12:06:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:36:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:36:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:06:20 --> Severity: Notice --> Undefined variable: prev_amount E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 185
ERROR - 2018-01-05 12:06:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:36:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:36:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:06:54 --> Severity: Notice --> Undefined variable: prev_amount E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 185
ERROR - 2018-01-05 12:07:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:37:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:37:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:07:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:37:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:37:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:07:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:37:31 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:37:31 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:08:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:38:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:38:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:08:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:38:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:38:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:12:34 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 180
ERROR - 2018-01-05 12:12:46 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) E:\wamp\www\duty\mathewgarments\application\models\Returndet_model.php 180
ERROR - 2018-01-05 12:13:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:43:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:43:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:13:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:43:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:43:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:13:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:43:31 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:43:31 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:13:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:43:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:43:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:44:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:44:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:44:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:44:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:44:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:44:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:44:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:44:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:44:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:44:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:44:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:44:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:14:54 --> Severity: Warning --> Missing argument 2 for Returndet::update_return_details() E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 108
ERROR - 2018-01-05 12:14:54 --> Severity: Notice --> Undefined variable: return_qty E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 109
ERROR - 2018-01-05 12:15:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:45:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:45:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:15:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:45:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:45:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:15:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:45:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:45:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:16:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:46:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:46:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:17:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:47:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:47:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:51:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 06:51:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:51:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:51:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:52:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:52:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:56:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:56:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:56:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:56:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:57:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:57:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 06:57:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 06:57:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 12:27:59 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:27:59 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:27:59 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:27:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 12:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 12:27:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 06:57:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 06:57:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:30:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 07:00:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:00:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:31:02 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:31:02 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:31:02 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:31:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 12:31:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 07:01:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:01:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:01:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:01:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:01:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:01:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 12:31:24 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:31:24 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:31:24 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 12:31:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 12:31:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 12:31:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 07:01:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:01:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:32:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 07:02:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:02:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:33:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 07:03:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:03:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:33:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 07:03:38 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:03:38 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 12:33:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 07:03:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:03:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 07:05:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:05:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:06:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:06:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:06:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:06:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:08:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:08:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:10:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:10:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:12:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:12:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:12:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:12:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 07:14:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:14:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:14:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:14:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:14:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:14:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 12:45:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 12:45:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 12:45:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 07:15:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:15:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:15:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:15:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 12:47:39 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 12:47:39 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 12:47:39 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 07:17:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:17:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:17:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:17:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:18:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:18:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 12:50:04 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 12:50:04 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 12:50:04 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 07:20:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:20:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:20:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:20:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:22:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:22:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:22:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:22:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 12:52:22 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:52:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:52:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:52:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:52:26 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:52:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:52:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:52:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:53:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:53:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:53:45 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:53:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:54:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:54:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:54:16 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:54:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:54:21 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 12:54:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 07:27:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:27:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:28:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:28:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:29:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:29:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:29:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:29:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:29:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:29:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:29:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:29:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:29:42 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:29:42 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:29:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:29:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 12:59:49 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 12:59:49 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 12:59:49 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 07:29:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:29:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:29:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:29:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:00:21 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 13:00:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 07:34:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:34:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:34:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:34:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:36:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:36:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:36:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:36:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:36:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:36:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:37:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:41:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:41:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:41:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-05 07:41:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-05 07:42:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:42:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:45:45 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 07:45:46 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 13:15:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 13:15:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:15:59 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 13:15:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:16:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 13:16:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:16:11 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 13:16:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 07:46:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:46:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 07:50:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 07:50:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 07:50:20 --> 404 Page Not Found: Employee/audio
ERROR - 2018-01-05 07:50:20 --> 404 Page Not Found: Employee/audio
ERROR - 2018-01-05 13:55:13 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 13:55:13 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 13:55:13 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-05 13:55:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-05 13:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-05 08:25:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 08:25:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-05 08:25:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 08:25:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:55:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 13:55:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 13:55:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 08:25:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 08:25:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 08:25:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:25:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:29:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 08:29:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 08:29:40 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 08:29:40 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 13:59:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 13:59:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 13:59:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 08:29:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 08:29:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:59:47 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 13:59:47 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 13:59:47 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 08:29:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 08:29:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 08:29:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:29:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:35:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:35:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:46:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 08:46:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 14:16:14 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:16:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:16:16 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:16:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 14:16:34 --> Severity: Notice --> Undefined variable: sname E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 44
ERROR - 2018-01-05 14:16:34 --> Severity: Notice --> Undefined variable: invoice E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 45
ERROR - 2018-01-05 14:20:46 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 67
ERROR - 2018-01-05 14:21:04 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 52
ERROR - 2018-01-05 14:25:42 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:25:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:25:46 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:25:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:25:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:25:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:25:51 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:25:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 14:27:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:27:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:27:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:27:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:27:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:27:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:27:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:27:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 09:00:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 09:00:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 09:00:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 09:00:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 14:34:15 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 14:34:15 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 14:34:15 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 09:04:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 09:04:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 09:04:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:04:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 14:34:25 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:34:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:34:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:34:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:34:33 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:34:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:34:34 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:34:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 14:36:02 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:36:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:36:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:36:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:36:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:36:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:36:09 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:36:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 14:38:58 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:38:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:39:02 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:39:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:39:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:39:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:39:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:39:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 14:42:03 --> Severity: Error --> Call to undefined function toUppercase() E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 49
ERROR - 2018-01-05 14:42:16 --> Severity: Error --> Call to undefined function toUpper() E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 49
ERROR - 2018-01-05 09:20:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 09:20:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 14:51:16 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 14:51:16 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 14:51:16 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 09:21:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 09:21:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 09:21:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:21:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 14:51:53 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:51:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:52:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:52:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:52:08 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:52:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:52:12 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 14:52:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 14:52:14 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 14:52:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 14:52:23 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 14:52:23 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 14:52:23 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 09:22:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:22:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 14:56:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-05 14:56:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-05 14:56:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-05 09:26:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:26:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:35:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:35:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:38:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:38:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 15:09:15 --> Query error: Not unique table/alias: 'tbl_branch' - Invalid query: SELECT *
FROM `tbl_transfer_out`
JOIN `tbl_branch` ON `tbl_transfer_out`.`transfer_to` = `tbl_branch`.`branch_id`
JOIN `tbl_branch` ON `tbl_transfer_out`.`transfer_from` = `tbl_branch`.`branch_id`
ERROR - 2018-01-05 09:39:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:39:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:49:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:49:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:49:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:49:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:50:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 09:50:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 09:51:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 09:51:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 09:51:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 09:51:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 09:51:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:51:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 15:21:33 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:21:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:21:34 --> Query error: Data truncated for column 'pro_bar_code' at row 1 - Invalid query: INSERT INTO `tbl_transfer_out_item` (`transfer_out_ref_id`, `pro_bar_code`) VALUES (2, '')
ERROR - 2018-01-05 15:21:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:21:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:22:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:22:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:22:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:22:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:23:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 15:23:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 09:53:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:53:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 15:23:38 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:23:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:24:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:24:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 09:54:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:54:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:55:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:55:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 15:25:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:25:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:25:45 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:25:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:27:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 15:27:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 09:57:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:57:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:57:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:57:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 15:27:39 --> Query error: Data truncated for column 'pro_bar_code' at row 1 - Invalid query: INSERT INTO `tbl_transfer_out_item` (`transfer_out_ref_id`, `pro_bar_code`) VALUES (5, '')
ERROR - 2018-01-05 15:27:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:27:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:28:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:28:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:28:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:28:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:28:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 15:28:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 09:58:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:58:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:58:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:58:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 15:29:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:29:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 15:29:18 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 15:29:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 09:59:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:59:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:59:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 09:59:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:20:22 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:20:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:20:29 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:20:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:20:29 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:20:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:20:34 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:20:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 11:50:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:50:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:50:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:50:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:21:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:21:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:21:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 17:21:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 17:21:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:21:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:21:33 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:21:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 11:51:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:51:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:51:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:51:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:21:59 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:21:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:22:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:22:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 11:52:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:52:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:54:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:54:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:55:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:55:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:25:21 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:25:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:25:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:25:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:25:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:25:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:25:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:25:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 11:55:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:55:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:55:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:55:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:25:47 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:25:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:25:58 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:25:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:26:09 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:26:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:26:15 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:26:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:26:15 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:26:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:26:27 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:26:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 11:56:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:56:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:56:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:56:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:57:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:57:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:27:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:27:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 11:57:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:57:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:57:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 11:57:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:17:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:17:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:55:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:55:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:25:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:25:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:25:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:25:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:56:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:56:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 17:56:16 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:56:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:26:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 12:26:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 12:26:50 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 12:26:50 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-05 12:27:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:27:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 17:57:10 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 17:57:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:27:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:27:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:27:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:27:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:30:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:30:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:00:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:00:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:00:43 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:00:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 12:31:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:31:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:01:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:01:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:01:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:01:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:01:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:01:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:01:34 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:01:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 12:31:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:31:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:31:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:31:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:01:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:01:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:02:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:02:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:02:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:02:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:02:20 --> Query error: Incorrect integer value: 'ff' for column 'dcno' at row 1 - Invalid query: INSERT INTO `tbl_transfer_out` (`transfer_from`, `transfer_to`, `dcno`, `pdate`, `remarks`, `emp_id`, `procudt_count`, `transfer_date`) VALUES ('1', '1', 'ff', '2018-01-05', 'xdd', 'EMP', 3, '2018-01-05 06:02:20')
ERROR - 2018-01-05 18:02:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:02:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:02:58 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:02:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:33:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:33:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:37:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:37:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:37:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:37:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:38:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:38:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:38:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:38:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:38:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:38:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:39:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:39:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:39:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:39:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:40:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:40:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:10:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:10:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:10:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:10:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:41:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:41:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:11:54 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:11:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:11:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:11:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:12:12 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:12:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:42:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:42:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:46:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:46:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:46:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:46:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:47:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:47:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:47:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:47:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:50:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:50:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:52:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:52:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:53:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:53:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:54:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:54:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:24:27 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:24:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:24:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:24:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:24:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:24:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:24:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:24:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:24:42 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:24:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 18:25:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:25:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:25:12 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:25:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 12:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:55:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:55:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:25:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:25:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 12:55:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:55:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:55:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:55:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:56:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:56:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:26:26 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:26:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:26:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:26:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:26:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:26:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:26:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:26:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:26:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:26:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:26:51 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:26:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:27:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:27:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 12:57:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:57:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:58:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:58:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:28:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:28:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:28:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:28:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:29:15 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:29:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 12:59:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 12:59:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:29:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:29:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:29:22 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:29:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:29:29 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:29:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:29:36 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:29:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:29:43 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:29:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:29:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:29:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 18:30:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:30:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:30:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:30:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:02:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:02:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:32:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:32:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:03:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:03:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:33:13 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:33:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:03:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:03:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:33:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:33:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 13:04:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:04:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:15:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:15:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:16:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:17:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:17:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:17:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:17:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:18:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:18:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:21:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:21:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 18:51:45 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-05 18:51:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-05 18:51:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-05 18:51:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-05 13:22:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:22:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:24:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:24:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:28:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:28:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:29:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:29:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:31:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:31:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:32:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:32:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:35:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:35:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-05 13:35:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:35:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:35:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:35:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:36:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:36:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:37:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:37:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:38:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:38:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-05 13:40:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:40:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:40:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:40:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:42:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:42:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:42:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:42:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:43:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:43:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:48:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:48:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:48:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:48:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:51:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:51:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:52:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:52:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:52:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:52:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:53:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:53:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:54:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:54:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:54:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:54:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:54:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:54:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:57:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:57:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:57:26 --> 404 Page Not Found: Employee/audio
ERROR - 2018-01-05 13:57:26 --> 404 Page Not Found: Employee/audio
ERROR - 2018-01-05 13:57:46 --> 404 Page Not Found: Customer/choose_sales_rep
ERROR - 2018-01-05 13:57:46 --> 404 Page Not Found: Customer/choose_sales_rsm
ERROR - 2018-01-05 13:57:46 --> 404 Page Not Found: Customer/choose_sales_asm
ERROR - 2018-01-05 13:58:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:58:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 13:58:25 --> 404 Page Not Found: Employee/audio
ERROR - 2018-01-05 13:58:25 --> 404 Page Not Found: Employee/audio
ERROR - 2018-01-05 13:58:39 --> 404 Page Not Found: Customer/choose_sales_rep
ERROR - 2018-01-05 13:58:39 --> 404 Page Not Found: Customer/choose_sales_asm
ERROR - 2018-01-05 13:58:39 --> 404 Page Not Found: Customer/choose_sales_rsm
ERROR - 2018-01-05 13:58:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 13:58:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-01-05 19:29:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-01-05 19:29:17 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-01-05 19:29:23 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-01-05 19:29:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-01-05 14:03:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 14:03:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 14:05:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 14:05:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 14:05:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 14:05:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-05 14:07:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-05 14:07:42 --> 404 Page Not Found: Audio/alert.mp3
