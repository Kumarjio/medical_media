<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-27 04:37:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:37:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:07:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:07:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:07:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:37:33 --> 404 Page Not Found: Dashboard/get_color
ERROR - 2018-02-27 04:37:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 04:37:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:07:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:07:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:07:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:38:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 04:38:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:39:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:39:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:09:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:09:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:09:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:41:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 04:41:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:11:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:11:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:11:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:46:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:46:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:16:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:16:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:16:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:47:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 04:47:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:17:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:17:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:17:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:49:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 04:49:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:19:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:19:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:19:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:49:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:49:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:19:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:19:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:19:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:50:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:50:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:20:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:20:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:20:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:52:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 04:52:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:59:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:59:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:29:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:29:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:29:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 04:59:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 04:59:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:29:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:29:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:29:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 05:00:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 05:00:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:30:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:30:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:30:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 05:01:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 05:01:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 10:31:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:31:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:31:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 05:02:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 05:02:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:32:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:32:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:32:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:24:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:24:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 15:54:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 15:54:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 15:54:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:24:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 10:24:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 15:54:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 15:54:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 15:54:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:24:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 10:24:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 15:54:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 15:54:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 15:54:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:34:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 10:34:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 16:04:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:04:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:04:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:34:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 10:34:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 16:04:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:04:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:04:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:36:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 10:36:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 16:06:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:06:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:06:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:36:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 10:36:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 16:06:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:06:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:06:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 10:37:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 10:37:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 16:07:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:07:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 16:07:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:31:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 11:31:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 17:01:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:31:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:01:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 11:31:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 17:01:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:31:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:31:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:31:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:31:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:01:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:01:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:35:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 11:35:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 17:05:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:05:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:05:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:35:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:35:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:05:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:05:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:05:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 11:46:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 11:46:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 17:16:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:16:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 17:16:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:45:58 --> Severity: Error --> Call to undefined method Dashboard_model::get() E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 91
ERROR - 2018-02-27 18:45:58 --> Query error: Unknown column 'tbl_product_img.produt_img_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519737358
WHERE `tbl_product_img`.`produt_img_id` IS NULL
AND `id` = '7181a1e60f7a83eeb6e7ae2cf0952dfc5e8d8d65'
ERROR - 2018-02-27 18:45:58 --> Severity: Warning --> Cannot modify header information - headers already sent E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-02-27 13:16:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-27 13:16:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-27 18:46:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:46:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:46:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:17:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:17:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 18:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:28:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:28:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 18:58:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:58:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:58:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:59:00 --> Severity: Error --> Call to undefined method Dashboard_model::get() E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 91
ERROR - 2018-02-27 18:59:00 --> Query error: Unknown column 'tbl_product_img.produt_img_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519738140
WHERE `tbl_product_img`.`produt_img_id` IS NULL
AND `id` = '48ca1df0530154f5434a344320e8d901331d0d22'
ERROR - 2018-02-27 18:59:00 --> Severity: Warning --> Cannot modify header information - headers already sent E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-02-27 13:29:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 13:29:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 18:59:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:59:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 18:59:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:00:07 --> Severity: Error --> Call to undefined method Dashboard_model::get() E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 91
ERROR - 2018-02-27 19:00:07 --> Query error: Unknown column 'tbl_product_img.produt_img_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519738207
WHERE `tbl_product_img`.`produt_img_id` = '1'
AND `id` = '48ca1df0530154f5434a344320e8d901331d0d22'
ERROR - 2018-02-27 19:00:07 --> Severity: Warning --> Cannot modify header information - headers already sent E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-02-27 13:30:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 13:30:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:00:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:00:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:00:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:34:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:34:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:04:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:04:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:04:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:34:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:34:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:04:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:04:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:04:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:40:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 13:40:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:10:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:40:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:40:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:10:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:40:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 13:40:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:10:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:40:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 13:40:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-27 19:10:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:10:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:47:02 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-27 13:47:02 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-27 19:17:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:17:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:17:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:47:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:47:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:17:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:17:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:17:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:55:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:55:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:25:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:25:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:25:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:56:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:56:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:26:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:26:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:26:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:56:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:56:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:26:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:26:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:26:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:57:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:57:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:27:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:27:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:27:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:57:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:57:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:27:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:27:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:27:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:57:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 13:57:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:59:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 13:59:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:29:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:29:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:29:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 13:59:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 13:59:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:29:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:29:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:29:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:00:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:00:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:30:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:30:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:30:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:01:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:01:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:31:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:31:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:31:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:18:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:18:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:48:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:48:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:48:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:21:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:21:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:51:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:51:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:51:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:22:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:22:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:23:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:23:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:53:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:53:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:53:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:24:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:24:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:54:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:54:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:54:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:25:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:25:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:55:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:55:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:55:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:25:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:25:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:26:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:26:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:56:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:56:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:56:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:26:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:26:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 19:56:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:56:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:56:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:27:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:27:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:57:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:57:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:57:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:27:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:27:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:57:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:57:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:57:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:28:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:28:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 19:58:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:58:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 19:58:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:35:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:35:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 20:05:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:05:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:05:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:36:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 14:36:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 20:06:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:06:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:06:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:37:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:37:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 20:07:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:07:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:07:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 14:39:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-27 14:39:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-27 20:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-27 20:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
