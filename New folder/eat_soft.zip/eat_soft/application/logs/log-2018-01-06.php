<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-06 09:21:29 --> 404 Page Not Found: Audio/fail.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-06 09:21:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:23:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:23:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:23:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:23:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:23:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:23:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:23:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:23:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:25:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:25:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:31:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:31:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:31:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:31:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:31:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:31:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:31:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-06 09:31:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-06 15:01:34 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-06 15:01:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-06 15:01:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-06 15:01:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-06 09:31:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:31:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:36:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:36:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:39:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:39:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:56:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:56:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:56:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:56:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:57:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 09:57:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:58:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 09:58:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:00:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:00:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:01:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:01:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:02:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:02:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:04:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:04:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:09:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:09:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:09:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:09:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:10:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:10:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:12:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:12:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:13:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:13:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:14:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:14:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:21:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:21:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:33:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:33:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:33:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:33:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:37:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:37:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:37:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:37:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 10:40:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 10:40:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:05:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:05:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:08:15 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-06 11:08:15 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-06 11:08:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:08:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:14:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:14:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:14:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:14:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:14:25 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-06 11:14:25 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-06 11:14:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:14:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 16:44:51 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 16:44:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:17:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:17:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 16:47:59 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 16:47:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:18:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:18:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 16:48:14 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 16:48:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:21:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:21:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:22:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:22:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:22:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:22:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:23:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:23:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:30:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:30:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:30:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:30:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:30:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:30:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:31:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:31:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 17:01:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:01:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:36:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:36:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 17:06:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:06:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:40:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:40:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 17:11:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:11:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:11:15 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:11:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:43:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:43:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 17:13:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:13:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:43:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:43:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 17:13:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:13:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:14:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:14:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:47:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:47:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 17:17:14 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:17:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:17:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:17:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:17:21 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:17:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:17:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:17:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:17:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:17:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:18:35 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:18:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:49:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:49:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 17:19:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:19:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:19:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:19:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:19:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:19:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:19:22 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:19:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:49:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:49:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 17:19:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:19:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:50:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:50:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:50:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:50:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:51:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 11:51:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 17:21:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:21:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 11:52:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-06 11:52:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-06 17:22:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:16 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:47 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:50 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:53 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:55 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:57 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:22:59 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:22:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:05 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-06 17:23:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-06 17:23:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
