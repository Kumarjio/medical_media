<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-25 04:15:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 04:15:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 04:15:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 04:15:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 04:15:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 04:15:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 09:46:39 --> Query error: Incorrect integer value: 'guj' for column 'dcno' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('9', '456767', 'guj', '2017-12-25', '1', '3', '578', 'rtyhgh', '15000', '15750.00')
ERROR - 2017-12-25 09:47:03 --> Query error: Incorrect integer value: 'fhfhfh' for column 'lot' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('9', '456767', '47', '2017-12-25', '1', '3', 'fhfhfh', 'rtyhgh', '15000', '15750.00')
ERROR - 2017-12-25 04:18:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 04:18:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 04:18:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 04:18:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-25 04:19:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 04:19:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-25 09:49:30 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-25 04:19:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 04:19:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 04:30:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 04:30:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 04:32:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 04:32:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 04:32:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 04:32:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 04:32:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 04:32:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 04:32:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 04:32:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 10:03:11 --> Severity: Notice --> Undefined variable: rate /home/sureshshivsai/public_html/mathewgarments/application/models/Goodsreceived_model.php 129
ERROR - 2017-12-25 10:03:11 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('3', 'dfg', 'sdfg', '2017-12-25', '1', NULL, 'sfgsf', 'srtfg', '', '')
ERROR - 2017-12-25 10:03:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-25 10:04:15 --> Severity: Notice --> Undefined variable: rate /home/sureshshivsai/public_html/mathewgarments/application/models/Goodsreceived_model.php 129
ERROR - 2017-12-25 10:04:15 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('3', 'dfg', 'sdfg', '2017-12-25', '1', NULL, 'erf', 'srtfg', '', '')
ERROR - 2017-12-25 10:04:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-25 10:06:47 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('3', 'dfg', 'sdfg', '2017-12-25', '1', '4', 'dryt', 'srtfg', '', '')
ERROR - 2017-12-25 05:03:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:03:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:33:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:33:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:39:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:39:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:40:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:40:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 05:40:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:40:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:40:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:40:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:43:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:43:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:43:31 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:43:31 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:43:59 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:43:59 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:45:49 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:45:49 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:46:37 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:46:37 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:48:18 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:48:18 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 05:49:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:49:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:49:50 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-25 05:49:50 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-25 05:50:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:50:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:50:05 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-25 05:50:05 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-25 05:50:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:50:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:50:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:50:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:50:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:50:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:50:12 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-12-25 05:50:12 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-12-25 05:50:23 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-25 05:50:23 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-25 05:50:28 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-25 05:50:28 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-25 05:50:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:50:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:50:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:50:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:50:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:50:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:51:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 05:51:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 05:51:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:51:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:52:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:52:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:53:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 05:53:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-25 06:01:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:01:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:01:45 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-25 06:01:45 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-25 06:01:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:01:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:01:50 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-25 06:01:50 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-25 06:01:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:01:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:01:55 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-25 06:01:55 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-25 06:01:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:01:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:02:00 --> 404 Page Not Found: Unit/audio
ERROR - 2017-12-25 06:02:00 --> 404 Page Not Found: Unit/audio
ERROR - 2017-12-25 06:02:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:02:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:02:05 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-25 06:02:05 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-25 06:02:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:02:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:02:12 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-25 06:02:12 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-25 11:32:17 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 140
ERROR - 2017-12-25 11:32:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 169
ERROR - 2017-12-25 11:32:17 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-25 11:32:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-25 11:35:52 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 140
ERROR - 2017-12-25 11:35:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 169
ERROR - 2017-12-25 11:35:52 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-25 11:35:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-25 11:35:53 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 140
ERROR - 2017-12-25 11:35:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 169
ERROR - 2017-12-25 11:35:53 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-25 11:35:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-25 06:05:54 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-25 06:05:54 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-25 11:35:57 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 140
ERROR - 2017-12-25 11:35:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 169
ERROR - 2017-12-25 11:35:57 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-25 11:35:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-25 06:56:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:56:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:57:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 06:57:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 06:57:10 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 06:57:10 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 06:57:32 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 06:57:32 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:00:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:00:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:00:28 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:00:28 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:07:22 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:07:22 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:08:25 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:08:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:10:55 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:10:55 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:11:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:11:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:12:52 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:12:52 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:15:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:15:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:15:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:15:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:18:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:18:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:18:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:18:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:18:36 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:18:36 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-25 07:27:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 07:27:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 07:27:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:27:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:28:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:28:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:30:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:30:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:49:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:49:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:49:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 07:49:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-25 13:59:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'shivsai'@'localhost' (using password: YES) D:\xampp\htdocs\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-12-25 13:59:19 --> Unable to connect to the database
ERROR - 2017-12-25 09:30:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:30:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 09:30:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 09:30:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:31:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 09:31:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:31:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:31:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 09:31:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 09:31:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:36:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:36:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 09:39:34 --> 404 Page Not Found: Hsn/index
ERROR - 2017-12-25 09:39:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 09:39:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:04:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:04:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 14:36:04 --> Severity: Notice --> Undefined index: hsn_code D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_list.php 53
ERROR - 2017-12-25 14:36:04 --> Severity: Notice --> Undefined index: hsn_id D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_list.php 54
ERROR - 2017-12-25 14:36:04 --> Severity: Notice --> Undefined index: hsn_id D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_list.php 56
ERROR - 2017-12-25 10:06:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:06:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:06:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:06:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:09:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:09:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:09:33 --> 404 Page Not Found: Hsn/add_hsn
ERROR - 2017-12-25 10:13:13 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:13:13 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:13:17 --> 404 Page Not Found: Hsn/hsn_add
ERROR - 2017-12-25 10:14:34 --> 404 Page Not Found: Hsn/hsn_add
ERROR - 2017-12-25 10:14:38 --> 404 Page Not Found: Hsn/hsn_add
ERROR - 2017-12-25 10:15:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:15:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:15:52 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:15:52 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:15:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:15:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:16:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:16:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:16:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:16:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:16:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:16:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:16:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:16:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Undefined property: stdClass::$branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Undefined property: stdClass::$branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-25 14:46:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-25 14:47:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 14
ERROR - 2017-12-25 14:47:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 24
ERROR - 2017-12-25 14:47:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 38
ERROR - 2017-12-25 14:47:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 14
ERROR - 2017-12-25 14:47:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 24
ERROR - 2017-12-25 14:47:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 38
ERROR - 2017-12-25 10:17:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:17:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 14:47:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 14
ERROR - 2017-12-25 14:47:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 24
ERROR - 2017-12-25 14:47:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 38
ERROR - 2017-12-25 14:47:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 14
ERROR - 2017-12-25 14:47:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 24
ERROR - 2017-12-25 14:47:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\hsn_edit.php 38
ERROR - 2017-12-25 10:17:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:17:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:18:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:18:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:18:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:18:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:18:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:18:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:18:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:18:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:44:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 10:44:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-25 10:44:37 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:44:37 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:44:54 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:44:54 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:45:25 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 10:45:25 --> 404 Page Not Found: Hsn/audio
ERROR - 2017-12-25 11:06:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-25 11:06:47 --> 404 Page Not Found: Audio/fail.mp3
