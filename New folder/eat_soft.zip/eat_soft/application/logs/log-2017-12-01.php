<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-01 07:19:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 07:19:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 07:19:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 07:19:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 07:19:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 07:19:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 07:19:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:19:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:26:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:26:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:27:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:27:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:29:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:29:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-12-01 12:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-12-01 12:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-12-01 12:01:02 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 255
ERROR - 2017-12-01 12:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 255
ERROR - 2017-12-01 07:31:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:31:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:31:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:31:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:08:51 --> Severity: Notice --> Undefined variable: sname D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 96
ERROR - 2017-12-01 12:08:52 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 109
ERROR - 2017-12-01 07:38:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:38:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:39:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:39:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:40:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:40:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:40:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:40:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:41:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:41:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:47:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:47:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:48:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:48:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:49:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 07:49:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:03:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:03:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:04:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:04:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:05:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:05:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:08:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:08:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:13:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:13:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:15:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:15:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:15:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:15:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:16:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:16:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:17:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:17:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:18:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:18:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:18:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:18:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:20:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:20:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:22:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:22:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:23:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:23:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:24:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:24:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:25:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:25:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:28:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:28:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:30:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:30:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:30:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:30:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:30:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:30:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:56:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:56:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:56:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:56:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:56:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:56:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:59:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:59:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 08:59:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:59:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:59:11 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-01 08:59:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:59:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:29:15 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:29:15 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:29:15 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:29:15 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 08:59:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 08:59:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 08:59:20 --> 404 Page Not Found: Stockreturn/index
ERROR - 2017-12-01 13:29:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:29:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:29:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:29:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 09:05:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:05:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:05:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:05:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:35:29 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:35:29 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:35:29 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:35:29 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 09:05:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:05:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:21:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:21:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:21:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:21:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:25:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:25:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:56:11 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:56:11 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:56:11 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 13:56:11 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-01 09:26:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:26:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:28:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:28:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:28:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:28:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:29:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:29:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:29:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:29:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:29:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:29:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:29:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:29:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:30:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:30:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:37:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:37:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:37:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:37:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:37:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:37:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:37:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:37:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:37:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:37:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:37:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:37:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:38:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:38:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-01 14:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-01 14:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-01 14:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 14:08:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-01 09:38:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:38:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:43:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:43:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:44:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:44:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:44:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:44:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:45:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:45:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:46:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:46:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 14:19:10 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-01 14:19:10 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512118150
WHERE `id` = '4f9d90e585a69019908b0f1da1c6148875f9e5cd'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-01 09:50:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:50:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:50:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:50:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:50:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:50:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:50:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:50:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:51:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:51:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 09:51:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:51:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:52:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:52:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 09:59:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 09:59:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:00:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:00:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:01:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:01:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:01:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:01:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:01:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:01:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:02:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:02:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:02:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:02:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:03:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:03:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:03:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:03:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:05:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:05:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:05:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:05:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:05:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:05:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 14:37:17 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-01 14:37:17 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-01 14:37:17 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-01 10:07:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:07:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 14:38:48 --> Query error: Unknown column 'tbl_po_inv.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`branch_ref_id`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-01 14:38:48 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512119328
WHERE `id` = '4f9d90e585a69019908b0f1da1c6148875f9e5cd'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-01 10:09:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:09:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:09:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:09:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:10:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:10:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:11:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:11:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:12:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:12:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:14:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:14:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:15:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:15:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:18:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:18:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:18:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:18:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:19:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:19:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:19:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:19:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:20:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:20:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:20:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:20:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:22:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:22:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:22:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:22:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:22:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:22:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:22:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:22:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:23:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:23:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:23:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:23:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 14:53:47 --> Query error: Unknown column 'tbl_po_inv.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`branch_ref_id`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-01 14:53:47 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512120227
WHERE `id` = '4f9d90e585a69019908b0f1da1c6148875f9e5cd'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-01 14:55:08 --> Query error: Not unique table/alias: 'tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`branch_ref_id`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-01 14:55:08 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512120308
WHERE `id` = '4f9d90e585a69019908b0f1da1c6148875f9e5cd'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-01 14:55:43 --> Query error: Unknown column 'tbl_po_inv.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-01 14:55:43 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512120343
WHERE `id` = '4f9d90e585a69019908b0f1da1c6148875f9e5cd'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-01 15:02:58 --> Query error: Unknown column 'tbl_po_inv.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-01 15:02:58 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512120778
WHERE `id` = '4f9d90e585a69019908b0f1da1c6148875f9e5cd'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-01 10:33:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 10:33:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:38:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:38:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:39:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 10:39:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 15:20:38 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 61
ERROR - 2017-12-01 15:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 61
ERROR - 2017-12-01 15:20:38 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-12-01 15:21:36 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-12-01 15:22:28 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-12-01 10:52:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:52:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 15:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:24:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 166
ERROR - 2017-12-01 15:24:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 166
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:24:06 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 300
ERROR - 2017-12-01 15:24:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 300
ERROR - 2017-12-01 10:54:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:54:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 162
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 166
ERROR - 2017-12-01 15:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 166
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 299
ERROR - 2017-12-01 15:28:50 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 300
ERROR - 2017-12-01 15:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 300
ERROR - 2017-12-01 10:58:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:58:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:59:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 10:59:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:01:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:01:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:02:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:02:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:04:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:04:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:05:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:05:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:07:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:07:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:11:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 11:11:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 11:11:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:11:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:12:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:12:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:25:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:25:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:25:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:25:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:27:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:27:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:37:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:37:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:38:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:38:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:46:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 11:46:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:06:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:06:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:07:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:07:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:09:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:09:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:10:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:10:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:10:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:10:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 16:41:21 --> Severity: Notice --> Undefined variable: i D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 103
ERROR - 2017-12-01 16:41:21 --> Severity: Notice --> String offset cast occurred D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 103
ERROR - 2017-12-01 12:11:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:11:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:12:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:12:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 16:42:43 --> Severity: Notice --> Undefined variable: i D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 103
ERROR - 2017-12-01 16:42:43 --> Severity: Notice --> String offset cast occurred D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 103
ERROR - 2017-12-01 12:12:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:12:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:13:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:13:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 16:44:11 --> Severity: Notice --> Undefined variable: i D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 103
ERROR - 2017-12-01 16:44:11 --> Severity: Notice --> String offset cast occurred D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 103
ERROR - 2017-12-01 12:14:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:14:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:14:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:14:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:15:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:15:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:24:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:24:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:26:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:26:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:27:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:27:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 16:58:02 --> Query error: Unknown column 'tbl_po_inv.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`branch_ref_id`
ERROR - 2017-12-01 12:28:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:28:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:29:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:29:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:29:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:29:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:29:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:29:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:30:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:30:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 17:04:38 --> Query error: Not unique table/alias: 'tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id` = `tbl_po_inv_item`.`po_inv_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id` = `tbl_po_inv_item`.`po_inv_id`
ERROR - 2017-12-01 17:08:41 --> Query error: Not unique table/alias: 'tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id` = `tbl_po_inv_item`.`po_inv_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id` = `tbl_po_inv_item`.`po_inv_id`
ERROR - 2017-12-01 12:39:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:39:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:39:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:39:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:40:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:40:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 17:10:38 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-12-01 17:10:38 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-12-01 17:10:38 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-12-01 17:10:38 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-12-01 12:40:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:40:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:41:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:41:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:41:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:41:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:41:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:41:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:42:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:42:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:42:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:42:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:42:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:42:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:43:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:43:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:43:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:43:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:59:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 12:59:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 12:59:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 12:59:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:06:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:06:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:06:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:06:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:06:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:06:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:06:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:06:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:06:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:06:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:08:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:08:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:08:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:08:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:09:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:09:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:11:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:11:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:11:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:11:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:13:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:13:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:13:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:13:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:17:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:17:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:17:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:17:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:22:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:22:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:23:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:23:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:23:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:23:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:23:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:23:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:26:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:26:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:27:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:27:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:27:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:27:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:27:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:27:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:38:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:38:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:38:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:38:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:49:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:49:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:49:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:49:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:55:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-01 13:55:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:55:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:55:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:55:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:55:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-01 13:56:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-01 13:56:00 --> 404 Page Not Found: Audio/fail.mp3
