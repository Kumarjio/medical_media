<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-04 12:14:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-04 12:14:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-04 12:14:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-04 12:14:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-04 12:14:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-04 12:14:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-04 12:24:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-04 12:24:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-04 12:25:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-04 12:25:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-04 12:25:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-04 12:25:03 --> 404 Page Not Found: Goodsreceived/audio
