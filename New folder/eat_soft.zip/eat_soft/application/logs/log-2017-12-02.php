<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-02 05:41:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 05:41:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 05:41:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 05:41:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 05:55:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 05:55:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 05:56:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 05:56:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 05:56:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 05:56:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 11:16:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 11:16:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 11:16:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-02 11:16:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-02 15:46:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-02 15:46:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-02 15:46:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-02 15:46:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-02 15:46:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2017-12-02 15:46:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 109
