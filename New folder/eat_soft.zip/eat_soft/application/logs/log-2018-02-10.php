<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-10 11:09:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-10 11:09:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-10 16:39:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 11:09:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-10 11:09:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-10 16:39:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:22 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-02-10 16:39:22 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-02-10 11:09:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-10 11:09:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-10 16:39:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 11:09:43 --> 404 Page Not Found: Reports/audio
ERROR - 2018-02-10 11:09:43 --> 404 Page Not Found: Reports/audio
ERROR - 2018-02-10 16:39:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-10 16:39:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
