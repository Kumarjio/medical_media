<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-22 05:50:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-22 05:50:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-22 11:25:55 --> Severity: Notice --> Undefined variable: arr /home/sureshshivsai/public_html/mathewgarments/application/models/Dashboard_model.php 99
ERROR - 2017-12-22 11:25:55 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `pro_ref_id` = '1'
ERROR - 2017-12-22 11:25:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-22 11:25:56 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513922156, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:6:\"mathew\";name|s:15:\"Mathew Garments\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513922155;'
WHERE `pro_ref_id` = '1'
AND `id` = '74e801e3f670a09f80059df5bf12dbee4dba32ca'
ERROR - 2017-12-22 11:25:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-22 06:02:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-22 06:02:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-22 06:02:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-22 06:02:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-22 06:16:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-22 06:16:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-22 06:18:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-22 06:18:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-22 06:19:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-22 06:19:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-22 06:19:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-22 06:19:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-22 11:49:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-22 11:49:46 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-22 06:19:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-22 06:19:54 --> 404 Page Not Found: Product/audio
