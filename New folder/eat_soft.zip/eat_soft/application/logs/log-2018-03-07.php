<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-07 09:09:05 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-07 09:09:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 13:39:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 09:09:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 09:09:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 13:39:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 09:09:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 09:09:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 13:39:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 09:09:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 09:09:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 13:39:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 10:11:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 14:41:20 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 10:11:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 14:41:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:26 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-03-07 10:11:26 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-03-07 14:41:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 10:11:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 14:41:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 10:11:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 14:41:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 10:11:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 14:41:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:11:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 10:11:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 14:41:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:12:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 10:12:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 14:42:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:12:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 10:12:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 14:42:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 14:42:36 --> Severity: Notice --> Undefined index: r_percent D:\xampp\htdocs\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-07 14:42:36 --> Severity: Notice --> Undefined index: wholesale_tax D:\xampp\htdocs\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-07 10:12:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-07 10:12:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-07 14:42:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:12:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 10:12:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 14:42:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:12:49 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-07 10:12:49 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-07 14:42:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:13:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 10:13:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 14:43:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:13:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 10:13:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 14:43:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:58:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 10:58:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 15:28:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:59:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-07 10:59:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-07 15:29:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-07 10:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 10:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-07 15:29:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
