<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-22 07:09:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 07:09:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 07:09:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 07:09:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:39:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 07:09:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 07:09:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:39:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:39:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 07:12:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 07:12:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 12:42:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 07:12:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 07:12:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:42:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 07:12:52 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-22 07:12:52 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-22 07:12:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 07:12:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 07:12:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-22 07:12:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-22 12:42:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 08:32:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 08:32:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 14:02:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 08:32:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 08:32:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 14:02:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 08:32:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 08:32:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 14:02:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:02:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 08:42:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 08:42:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 14:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:23:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:23:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 16:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:23:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:23:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 16:53:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:53:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:53:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:53:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:24:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:24:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 16:54:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:54:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:54:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:54:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:24:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-22 11:24:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-22 11:24:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:24:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 16:54:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:54:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:54:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:54:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:55:12 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 193
ERROR - 2018-02-22 16:55:13 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 193
ERROR - 2018-02-22 16:55:13 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 193
ERROR - 2018-02-22 11:25:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-22 11:25:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-22 16:55:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:55:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:55:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:25:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-22 11:25:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-22 11:26:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:26:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 16:56:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:26:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-22 11:26:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-22 16:56:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 172
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 177
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 178
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 172
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 177
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 178
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 246
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:27:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:27:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 16:57:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:27:30 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-22 11:27:30 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-22 11:27:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:27:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 16:57:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 16:57:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:29:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:29:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:29:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:29:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:29:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:29:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:29:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:29:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:29:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:29:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:36:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:36:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:37:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:37:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:37:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:37:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:39:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:39:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:39:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:39:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:39:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:39:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:40:12 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-22 11:40:12 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-22 17:10:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:10:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:10:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:41:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-22 11:41:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-22 17:11:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:11:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:11:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:41:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:41:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:11:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:11:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:11:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:42:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:42:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:12:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:12:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:12:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:42:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:42:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:49:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:49:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:19:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:49:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:49:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:49:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:49:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:19:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:49:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:49:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:19:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:19:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:50:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:20:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:50:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:20:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:50:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:20:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:50:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:50:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:50:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:20:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 11:50:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:20:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:50:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:20:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:22 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-22 11:50:22 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-22 17:20:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-22 11:50:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-22 17:20:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:44 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-22 11:50:44 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-22 17:20:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:50:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:50:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:20:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:20:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:51:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:51:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:51:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:51:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:21:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:21:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:21:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:52:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:52:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:22:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:22:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:22:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:52:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:52:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:53:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 11:53:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:23:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:23:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:23:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:53:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 11:53:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:23:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:23:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:23:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:53:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 11:53:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:57:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 11:57:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:27:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:27:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:27:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:57:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 11:57:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:27:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:27:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:27:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:57:41 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 11:57:41 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:27:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:27:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:27:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 11:59:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 11:59:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:29:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:29:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:29:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:02:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 12:02:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-02-22 17:32:27 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2018-02-22 17:32:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:02:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:02:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:32:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:02:35 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 12:02:35 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:32:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:02:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:02:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:32:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:02:58 --> 404 Page Not Found: Employee/audio
ERROR - 2018-02-22 12:02:58 --> 404 Page Not Found: Employee/audio
ERROR - 2018-02-22 17:32:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:32:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:33:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:23:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 12:23:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:53:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:53:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:53:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:23:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:23:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:53:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:53:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:53:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:23:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:23:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:53:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:24:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 12:24:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:54:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:54:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:54:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:25:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 12:25:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 17:55:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:55:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:55:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:25:06 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 12:25:06 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-22 17:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:25:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 12:25:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:55:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:55:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:55:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:26:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 12:26:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 17:56:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:56:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:56:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:26:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:26:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:56:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:56:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:56:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:26:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:26:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:56:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:56:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:56:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:29:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:29:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 17:59:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:59:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 17:59:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:30:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:30:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:00:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:00:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:00:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:33:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:33:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:34:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:34:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:04:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:04:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:04:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:35:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:35:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:05:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:05:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:05:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:36:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:36:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:06:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:06:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:06:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:37:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:37:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:07:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:07:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:07:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:38:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:38:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:08:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:08:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:08:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:40:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:40:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:10:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:10:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:10:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:42:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:42:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:12:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:12:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:12:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:44:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:44:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:14:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:14:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:14:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 12:47:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 12:47:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:17:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:17:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:17:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:20:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:20:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:20:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:20:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:20:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:20:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:32:16 --> Severity: Notice --> Undefined variable: wholesale_percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 228
ERROR - 2018-02-22 18:32:16 --> Severity: Notice --> Undefined variable: percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 231
ERROR - 2018-02-22 18:32:16 --> Query error: Unknown column 'lot_placed' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `lot_placed`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '1', '1', '1', '6001', '1', '1/2/120', NULL, '110', '120', NULL, '10', '100', '121/121', '1050', 0, 0, '5', 0, 0, '50', 1)
ERROR - 2018-02-22 18:33:41 --> Severity: Notice --> Undefined variable: wholesale_percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 228
ERROR - 2018-02-22 18:33:41 --> Severity: Notice --> Undefined variable: percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 231
ERROR - 2018-02-22 18:33:41 --> Query error: Unknown column 'lot_placed' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `lot_placed`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (2, '1', '1', '1', '6001', '1', '1/2/120', NULL, '110', '120', NULL, '10', '100', '121/121', '1050', 0, 0, '5', 0, 0, '50', 1)
ERROR - 2018-02-22 18:34:39 --> Query error: Unknown column 'lot_placed' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `lot_placed`, `wholesale_amt`, `r_rate`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (3, '1', '1', '1', '6001', '1', '1/2/120', '110', '120', '10', '100', '121/121', '1050', 0, 0, '5', 0, 0, '50', 1)
ERROR - 2018-02-22 18:35:43 --> Query error: Unknown column 'lot_palced' in 'field list' - Invalid query: INSERT INTO `tbl_grn` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `lot_palced`, `wholesale_amt`, `r_rate`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (4, '1', '1', '1', '6001', '1', '1/2/120', '110', '120', '10', '100', '121/121', '1050', 0, 0, '5', 0, 0, '50', 1)
ERROR - 2018-02-22 13:06:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:06:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:36:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:36:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:36:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:06:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:06:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:36:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:36:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:36:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:06:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:06:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:36:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:36:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:36:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:08:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:08:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:38:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:38:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:38:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:08:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:08:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:38:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:38:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:38:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:14:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:14:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:45:07 --> Severity: Notice --> Undefined variable: wholesale_percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 310
ERROR - 2018-02-22 18:45:07 --> Severity: Notice --> Undefined variable: percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 313
ERROR - 2018-02-22 18:45:07 --> Query error: Column 'wholesale_tax' cannot be null - Invalid query: INSERT INTO `tbl_grn_hold` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `lot_pl`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '1', '1', '1', '6001', 'g1001', '1', NULL, '120', '120', NULL, '10', '100', '12/12/12', '1050', 0, 0, '5', 0, 0, '50', 1)
ERROR - 2018-02-22 13:16:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:16:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:46:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:46:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:46:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 229
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 235
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 229
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 235
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 229
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 235
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-22 18:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:48:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:48:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:48:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:48:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:48:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:49:52 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:49:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:49:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:49:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:49:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:49:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:50:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:50:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:50:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:50:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:50:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:50:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:21:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:21:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:51:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:51:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:51:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:21:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:21:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:51:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:51:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:51:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:22:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:22:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 18:52:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:52:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:52:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:56:44 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:56:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:59:44 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 18:59:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:00:12 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:00:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:00:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:00:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:31:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:31:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 19:01:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:01:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:01:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:31:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:31:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 19:01:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:01:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:01:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:32:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:32:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 19:02:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:02:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:02:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:02:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:02:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:33:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:33:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 19:03:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:33:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:33:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 19:03:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-22 19:03:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-22 19:03:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:33:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 13:33:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-22 19:03:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:33:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 13:33:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:03:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:33:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 13:33:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 19:03:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 144
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 231
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 237
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 231
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 237
ERROR - 2018-02-22 13:33:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:33:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:03:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:34:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 13:34:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:04:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 144
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 231
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 237
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 231
ERROR - 2018-02-22 19:04:52 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 237
ERROR - 2018-02-22 13:34:52 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:34:52 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:04:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:04:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:36:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:36:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:06:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:06:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:06:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:06:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:06:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:36:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:36:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:07:49 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:07:49 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:07:49 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:07:49 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:37:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:37:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:07:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:07:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:07:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:08:08 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:08:08 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:08:08 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:08:08 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:38:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:38:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:08:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:08:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:08:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:11:15 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:11:15 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:11:15 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:11:15 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:41:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:41:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:11:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:11:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:11:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:11:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:11:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:11:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:11:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:41:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:41:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:11:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:11:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:11:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:12:39 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:12:39 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:12:39 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:12:39 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:42:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:42:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:12:52 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:12:52 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:12:52 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:12:52 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:42:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:42:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:12:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:12:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:12:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:13:25 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:13:25 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:13:25 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:13:25 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:43:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:43:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:13:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:13:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:13:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:43:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:43:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:13:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:14:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:14:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:14:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:14:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:44:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:44:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:14:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:14:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:14:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:15:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:15:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:15:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:45:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:45:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:15:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-22 13:45:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:45:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:45 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 795
ERROR - 2018-02-22 19:15:45 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 802
ERROR - 2018-02-22 19:15:45 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 803
ERROR - 2018-02-22 13:45:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 13:45:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-22 19:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:45:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 13:45:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:45:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 13:45:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:15:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:15:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:46:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 13:46:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 19:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:46:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 13:46:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:16:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:46:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 13:46:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:16:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:46:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 13:46:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 19:16:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 13:46:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 13:46:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 19:16:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:46 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:46 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:46 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 60
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 67
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\barcode_gen.php 69
ERROR - 2018-02-22 13:46:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 13:46:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:16:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 14:01:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-22 14:01:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-22 19:31:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:31:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-22 19:31:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
