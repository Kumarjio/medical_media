<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-28 10:03:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-11-28 10:03:24 --> Unable to connect to the database
ERROR - 2017-11-28 05:44:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 05:44:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 05:44:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 05:44:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 05:44:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 05:44:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 05:44:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 05:44:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 05:47:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 05:47:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 05:47:37 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-28 05:47:37 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-28 05:48:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-28 05:48:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 10:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 10:18:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 10:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 06:30:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:30:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:30:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:30:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:32:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:32:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:32:35 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:32:35 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:32:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:32:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:33:02 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:02 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:33:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:33:08 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:08 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:33:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:33:14 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:14 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:33:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:33:41 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:41 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:33:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:33:49 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:49 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:33:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:33:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:34:29 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:34:29 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:34:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:34:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:34:36 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:34:36 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:34:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:34:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:34:48 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:34:48 --> 404 Page Not Found: Size/audio
ERROR - 2017-11-28 06:34:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:34:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:35:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:35:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:35:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:35:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:35:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:35:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:35:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:35:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:36:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:36:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:37:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:37:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:37:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:37:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:38:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 06:38:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 06:38:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:38:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:11:08 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 11:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 06:41:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:41:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:11:31 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 11:11:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 06:41:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:41:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:13:08 --> Severity: Notice --> Undefined variable: vendor D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 11:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 06:43:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:43:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:29:00 --> Severity: Notice --> Undefined variable: vendor D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 11:29:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 06:59:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:59:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:29:01 --> Severity: Notice --> Undefined variable: vendor D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 11:29:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 06:59:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 06:59:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:30:08 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 11:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 37
ERROR - 2017-11-28 07:00:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:00:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 11:33:03 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 11:33:03 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 11:33:03 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 11:33:03 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:03:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:03:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:03:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:03:45 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-28 07:03:45 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-28 07:03:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:03:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:47 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-28 07:03:47 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-28 07:03:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:03:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:03:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-28 07:03:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-28 07:03:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:03:54 --> 404 Page Not Found: Unit/audio
ERROR - 2017-11-28 07:03:54 --> 404 Page Not Found: Unit/audio
ERROR - 2017-11-28 07:03:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:03:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:03:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:04:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:04:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:04:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:04:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:04:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:04:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:04:04 --> 404 Page Not Found: Employee/audio
ERROR - 2017-11-28 07:04:04 --> 404 Page Not Found: Employee/audio
ERROR - 2017-11-28 07:04:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:04:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:34:13 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 11:34:13 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 11:34:13 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 11:34:13 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:04:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:04:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:11:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:11:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:11:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:11:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:16:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:16:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:16:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:16:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:34:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:34:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:34:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:34:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:34:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:34:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:38:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:38:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:38:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:38:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:09:49 --> Severity: Notice --> Undefined index: rate D:\xampp\htdocs\duty\mathewgarments\application\views\rate_list.php 53
ERROR - 2017-11-28 12:09:49 --> Severity: Notice --> Undefined index: rate D:\xampp\htdocs\duty\mathewgarments\application\views\rate_list.php 53
ERROR - 2017-11-28 07:39:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:39:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:42:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:42:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:42:03 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:42:03 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:42:35 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:42:35 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 12:13:01 --> Severity: Notice --> Undefined index: branch D:\xampp\htdocs\duty\mathewgarments\application\controllers\Rate.php 32
ERROR - 2017-11-28 07:43:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:43:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:44:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:44:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:22 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:45:22 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:45:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:45:32 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:45:32 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:45:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:45:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Undefined property: stdClass::$branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Undefined property: stdClass::$branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:16:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:16:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:16:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:16:32 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:16:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:16:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 07:46:40 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:46:40 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:46:58 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:46:58 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:47:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:47:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:47:09 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:47:09 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:47:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:47:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:47:18 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:47:18 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 07:47:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:47:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:47:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:47:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:47:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:47:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:47:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:47:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 12:17:53 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:17:53 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:17:53 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:17:53 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:47:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:47:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:48:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:48:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 07:48:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:48:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:18:58 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:18:58 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:18:58 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:18:58 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:48:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:48:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:50:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:50:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:22:48 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:22:48 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:22:48 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:22:48 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:52:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:52:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:23:07 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:07 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:07 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:07 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:53:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:53:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:23:13 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:13 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:13 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:13 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:53:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:23:14 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:14 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:14 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:14 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:23:15 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:15 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:15 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:23:15 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:53:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:53:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:53:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 07:53:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:24:02 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:24:02 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:24:02 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:24:02 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 07:54:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 07:54:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:31:16 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 08:01:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:01:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:31:49 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 08:01:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:01:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:02:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 08:02:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:32:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:32:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 08:02:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 08:02:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:32:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:32:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 08:02:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 08:02:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:32:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:32:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:32:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 12:32:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-11-28 12:32:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-11-28 12:32:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-11-28 08:02:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 08:02:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 08:03:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 08:03:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:33:32 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 08:03:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:03:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: size_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 12:40:33 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 149
ERROR - 2017-11-28 08:10:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:10:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:42:53 --> Query error: Table 'db_methew_gar.size_id' doesn't exist - Invalid query: SELECT `tbl_sizefix`.*
FROM `size_id`
ERROR - 2017-11-28 12:43:30 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:43:30 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:43:30 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:43:30 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 08:13:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:13:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:45:42 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:45:42 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:45:42 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:45:42 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 08:15:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:15:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:46:04 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:46:04 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:46:04 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:46:04 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 08:16:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:16:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:59:47 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:59:47 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:59:47 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 12:59:47 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 08:29:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:29:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:01:41 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 13:01:41 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 13:01:41 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 13:01:41 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 08:31:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 08:31:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:19:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:19:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:19:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:19:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:19:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:19:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:19:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:19:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 14:49:46 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:49:46 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:49:46 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:49:46 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 10:19:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:19:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 14:50:35 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:50:35 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:50:35 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:50:35 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 10:20:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:20:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:21:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:21:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:21:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:21:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:21:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:21:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:22:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:22:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:22:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:22:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:22:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:22:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 14:52:06 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:52:06 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:52:06 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:52:06 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 10:22:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:22:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 14:54:17 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:54:17 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:54:17 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:54:17 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 10:24:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:24:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 14:54:45 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:54:45 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:54:45 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:54:45 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 10:24:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:24:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 14:59:17 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:59:17 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:59:17 --> Severity: Notice --> Undefined index: vendor_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 14:59:17 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 40
ERROR - 2017-11-28 10:29:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:29:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:29:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:29:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:29:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:29:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 14:59:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:30:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:30:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-11-28 15:00:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-11-28 10:30:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:30:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:30:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:30:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:30:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:30:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:31:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:31:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:32:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:32:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:32:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:32:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:32:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:32:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:33:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:33:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:34:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:34:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:34:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:34:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:35:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:35:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:35:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:35:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:35:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:35:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 10:36:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:36:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:36:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:36:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:40:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:40:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:40:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:40:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:40:12 --> 404 Page Not Found: Statutory/index
ERROR - 2017-11-28 10:40:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:40:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:42:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:42:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:42:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:42:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:42:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:42:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:43:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:43:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:43:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:43:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:44:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:44:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 55
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 56
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 57
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 55
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 56
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 57
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 55
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 56
ERROR - 2017-11-28 15:14:27 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_list.php 57
ERROR - 2017-11-28 10:44:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:44:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:46:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:46:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:46:12 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 10:46:12 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 10:46:55 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 10:46:55 --> 404 Page Not Found: Rate/audio
ERROR - 2017-11-28 10:47:25 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:47:26 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:48:23 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:48:23 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:15 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:15 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:16 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:16 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:49:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:49:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:49:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:49:20 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:20 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 10:49:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:49:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:19:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:20:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:21:41 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:21:55 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:22:05 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:22:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:23:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:24:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:25:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:26:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:26:33 --> Severity: Notice --> Undefined variable: rate D:\xampp\htdocs\duty\mathewgarments\application\models\Statutory_model.php 29
ERROR - 2017-11-28 10:56:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:56:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:58:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:58:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:28:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 10:58:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:58:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:58:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:58:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:58:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:58:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:59:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:59:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:59:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:59:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 10:59:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 10:59:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:00:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:02 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 11:00:02 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 11:00:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:00:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:06 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 11:00:06 --> 404 Page Not Found: Statutory/audio
ERROR - 2017-11-28 11:00:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:00:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 14
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 24
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 38
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 45
ERROR - 2017-11-28 15:30:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\statutory_edit.php 52
ERROR - 2017-11-28 11:00:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:00:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:00:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:00:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:00:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:06:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:06:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:06:24 --> 404 Page Not Found: Return/index
ERROR - 2017-11-28 11:18:11 --> 404 Page Not Found: Return/index
ERROR - 2017-11-28 11:18:12 --> 404 Page Not Found: Return/index
ERROR - 2017-11-28 11:18:31 --> 404 Page Not Found: Return/index
ERROR - 2017-11-28 11:18:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 11:18:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 11:18:58 --> 404 Page Not Found: Returndet/index
ERROR - 2017-11-28 15:50:16 --> Severity: Notice --> Undefined property: Returndet::$Reports_model D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 1662
ERROR - 2017-11-28 15:50:16 --> Severity: Error --> Call to a member function get_cus_history_det() on null D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 1662
ERROR - 2017-11-28 15:51:22 --> Severity: Notice --> Undefined property: Returndet::$Reports_model D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 1411
ERROR - 2017-11-28 15:51:22 --> Severity: Error --> Call to a member function get_cus_history_det() on null D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 1411
ERROR - 2017-11-28 15:51:49 --> Query error: Table 'db_methew_gar.tbl_invoice_item' doesn't exist - Invalid query: SELECT `tbl_invoice_item`.*, `tbl_invoice`.*, `tbl_gr_details`.*, `tbl_lr_item_details`.*, `tbl_lr_details`.*, `cb_customer`.*, `cb_customer`.`gst` as `gsts`, `tbl_product`.*, `tbl_purchase_request`.*, `tbl_dispatch`.*
FROM `tbl_invoice_item`
LEFT JOIN `tbl_invoice` ON `tbl_invoice`.`invoice_id` =`tbl_invoice_item`.`tbl_ref_inv_id` 
LEFT JOIN `tbl_gr_details` ON `tbl_gr_details`.`tbl_ref_inv_no` =`tbl_invoice`.`invoice_id`
LEFT JOIN `tbl_lr_item_details` ON `tbl_lr_item_details`.`tbl_ref_invoice_no` =`tbl_invoice`.`invoice_id`
LEFT JOIN `tbl_lr_details` ON `tbl_lr_details`.`lr_id` =`tbl_lr_item_details`.`tbl_ref_lr_id`
LEFT JOIN `cb_customer` ON `cb_customer`.`cid`=`tbl_invoice`.`inv_cus_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`part_no` =`tbl_invoice_item`.`tbl_ref_part_no` 
LEFT JOIN `tbl_purchase_request` ON `tbl_purchase_request`.`po_no` = `tbl_invoice_item`.`tbl_ref_po_no`
LEFT JOIN `tbl_dispatch` ON `tbl_dispatch`.`dispatch_id` = `tbl_purchase_request`.`despatch_type`
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 15:51:49 --> Query error: Unknown column 'tbl_invoice.inv_sess_company' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1511864509
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
AND `id` = '63a759c614e5af99639971b327b363a1dff48fed'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 15:52:25 --> Severity: Notice --> Undefined variable: query D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 1010
ERROR - 2017-11-28 15:52:25 --> Severity: Notice --> Undefined property: Returndet::$Reports_model D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 1596
ERROR - 2017-11-28 15:52:25 --> Severity: Error --> Call to a member function get_customer() on null D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 1596
ERROR - 2017-11-28 15:52:25 --> Query error: Unknown column 'tbl_invoice.inv_sess_company' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1511864545
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
AND `id` = '63a759c614e5af99639971b327b363a1dff48fed'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 15:52:25 --> Severity: Warning --> Cannot modify header information - headers already sent D:\xampp\htdocs\duty\mathewgarments\system\core\Common.php 569
ERROR - 2017-11-28 15:53:09 --> Query error: Table 'db_methew_gar.tbl_invoice' doesn't exist - Invalid query: SELECT `tbl_invoice_item`.*, `tbl_invoice`.*, `tbl_gr_details`.*, `tbl_lr_item_details`.*, `tbl_lr_details`.*, `cb_customer`.*, `cb_customer`.`gst` as `gsts`, `tbl_product`.*, `tbl_purchase_request`.*, `tbl_dispatch`.*
FROM `tbl_return`
LEFT JOIN `tbl_invoice` ON `tbl_invoice`.`invoice_id` =`tbl_invoice_item`.`tbl_ref_inv_id` 
LEFT JOIN `tbl_gr_details` ON `tbl_gr_details`.`tbl_ref_inv_no` =`tbl_invoice`.`invoice_id`
LEFT JOIN `tbl_lr_item_details` ON `tbl_lr_item_details`.`tbl_ref_invoice_no` =`tbl_invoice`.`invoice_id`
LEFT JOIN `tbl_lr_details` ON `tbl_lr_details`.`lr_id` =`tbl_lr_item_details`.`tbl_ref_lr_id`
LEFT JOIN `cb_customer` ON `cb_customer`.`cid`=`tbl_invoice`.`inv_cus_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`part_no` =`tbl_invoice_item`.`tbl_ref_part_no` 
LEFT JOIN `tbl_purchase_request` ON `tbl_purchase_request`.`po_no` = `tbl_invoice_item`.`tbl_ref_po_no`
LEFT JOIN `tbl_dispatch` ON `tbl_dispatch`.`dispatch_id` = `tbl_purchase_request`.`despatch_type`
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 15:53:09 --> Query error: Unknown column 'tbl_invoice.inv_sess_company' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1511864589
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
AND `id` = '63a759c614e5af99639971b327b363a1dff48fed'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 15:55:42 --> Query error: Table 'db_methew_gar.tbl_invoice' doesn't exist - Invalid query: SELECT `tbl_invoice_item`.*, `tbl_invoice`.*, `tbl_gr_details`.*, `tbl_lr_item_details`.*, `tbl_lr_details`.*, `cb_customer`.*, `cb_customer`.`gst` as `gsts`, `tbl_product`.*, `tbl_purchase_request`.*, `tbl_dispatch`.*
FROM `tbl_return`
LEFT JOIN `tbl_invoice` ON `tbl_invoice`.`invoice_id` =`tbl_invoice_item`.`tbl_ref_inv_id` 
LEFT JOIN `tbl_gr_details` ON `tbl_gr_details`.`tbl_ref_inv_no` =`tbl_invoice`.`invoice_id`
LEFT JOIN `tbl_lr_item_details` ON `tbl_lr_item_details`.`tbl_ref_invoice_no` =`tbl_invoice`.`invoice_id`
LEFT JOIN `tbl_lr_details` ON `tbl_lr_details`.`lr_id` =`tbl_lr_item_details`.`tbl_ref_lr_id`
LEFT JOIN `cb_customer` ON `cb_customer`.`cid`=`tbl_invoice`.`inv_cus_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`part_no` =`tbl_invoice_item`.`tbl_ref_part_no` 
LEFT JOIN `tbl_purchase_request` ON `tbl_purchase_request`.`po_no` = `tbl_invoice_item`.`tbl_ref_po_no`
LEFT JOIN `tbl_dispatch` ON `tbl_dispatch`.`dispatch_id` = `tbl_purchase_request`.`despatch_type`
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 15:55:42 --> Query error: Unknown column 'tbl_invoice.inv_sess_company' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1511864742
WHERE `tbl_invoice`.`inv_sess_company` = 'admin'
AND `tbl_purchase_request`.`po_sess_company` = 'admin'
AND `tbl_dispatch`.`despatch_sess_comp` = 'admin'
AND `id` = '63a759c614e5af99639971b327b363a1dff48fed'
ORDER BY `tbl_invoice`.`invoice_no` DESC
ERROR - 2017-11-28 11:42:57 --> 404 Page Not Found: Returndet/cus_history_det
ERROR - 2017-11-28 11:43:38 --> 404 Page Not Found: Returndet/cus_history_det
ERROR - 2017-11-28 11:43:39 --> 404 Page Not Found: Returndet/cus_history_det
ERROR - 2017-11-28 16:14:13 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:14:43 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:14:58 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:14:59 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:14:59 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:14:59 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:15:58 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:15:59 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:00 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:00 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:01 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:14 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:15 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:15 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:15 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:15 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:16 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:16 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:17 --> Severity: Error --> Class 'Returndet_model' not found D:\xampp\htdocs\duty\mathewgarments\system\core\Loader.php 305
ERROR - 2017-11-28 16:16:43 --> Query error: Table 'db_methew_gar.tbl_sales' doesn't exist - Invalid query: SELECT `tbl_sales`.*, `tbl_sales`.`created_date` as `cds`, `tbl_sales_items`.*, `tbl_sales_items`.`si_no` as `no`, `tbl_product`.`i_name`, `i_category`, `cb_customer`.`customer_name`, `mob_no1`, `area_name`, `cid`
FROM `tbl_sales`
LEFT JOIN `tbl_sales_items` ON `tbl_sales_items`.`tbl_sales_id`=`tbl_sales`.`s_no`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
LEFT JOIN `cb_customer` ON `tbl_sales`.`customer_code`=`cb_customer`.`cid`
ERROR - 2017-11-28 16:16:44 --> Query error: Table 'db_methew_gar.tbl_sales' doesn't exist - Invalid query: SELECT `tbl_sales`.*, `tbl_sales`.`created_date` as `cds`, `tbl_sales_items`.*, `tbl_sales_items`.`si_no` as `no`, `tbl_product`.`i_name`, `i_category`, `cb_customer`.`customer_name`, `mob_no1`, `area_name`, `cid`
FROM `tbl_sales`
LEFT JOIN `tbl_sales_items` ON `tbl_sales_items`.`tbl_sales_id`=`tbl_sales`.`s_no`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
LEFT JOIN `cb_customer` ON `tbl_sales`.`customer_code`=`cb_customer`.`cid`
ERROR - 2017-11-28 16:17:17 --> Query error: Table 'db_methew_gar.tbl_sales_items' doesn't exist - Invalid query: SELECT `tbl_sales`.*, `tbl_sales`.`created_date` as `cds`, `tbl_sales_items`.*, `tbl_sales_items`.`si_no` as `no`, `tbl_product`.`i_name`, `i_category`, `cb_customer`.`customer_name`, `mob_no1`, `area_name`, `cid`
FROM `tbl_return`
LEFT JOIN `tbl_sales_items` ON `tbl_sales_items`.`tbl_sales_id`=`tbl_sales`.`s_no`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
LEFT JOIN `cb_customer` ON `tbl_sales`.`customer_code`=`cb_customer`.`cid`
ERROR - 2017-11-28 16:17:18 --> Query error: Table 'db_methew_gar.tbl_sales_items' doesn't exist - Invalid query: SELECT `tbl_sales`.*, `tbl_sales`.`created_date` as `cds`, `tbl_sales_items`.*, `tbl_sales_items`.`si_no` as `no`, `tbl_product`.`i_name`, `i_category`, `cb_customer`.`customer_name`, `mob_no1`, `area_name`, `cid`
FROM `tbl_return`
LEFT JOIN `tbl_sales_items` ON `tbl_sales_items`.`tbl_sales_id`=`tbl_sales`.`s_no`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
LEFT JOIN `cb_customer` ON `tbl_sales`.`customer_code`=`cb_customer`.`cid`
ERROR - 2017-11-28 16:17:54 --> Query error: Unknown column 'tbl_product.i_name' in 'field list' - Invalid query: SELECT `tbl_product`.`i_name`, `i_category`
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 16:17:56 --> Query error: Unknown column 'tbl_product.i_name' in 'field list' - Invalid query: SELECT `tbl_product`.`i_name`, `i_category`
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 16:18:26 --> Query error: Unknown column 'tbl_product.i_id' in 'on clause' - Invalid query: SELECT `tbl_product`.*
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 16:19:10 --> Query error: Unknown column 'tbl_product.i_id' in 'on clause' - Invalid query: SELECT `tbl_product`.*
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 16:34:41 --> Query error: Unknown column 'tbl_product.i_id' in 'on clause' - Invalid query: SELECT `tbl_product`.*
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:28 --> Query error: Unknown column 'tbl_product.i_id' in 'on clause' - Invalid query: SELECT `tbl_product`.*
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:39:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 12:09:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:09:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 16:40:28 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 16:40:28 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 16:40:28 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 16:40:28 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 12:10:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:10:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 16:40:31 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 16:40:31 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 16:40:31 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 16:40:31 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-28 12:10:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:10:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 12:12:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 12:12:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 16:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 12:13:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:13:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 12:13:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:13:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:14:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:14:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 40
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 249
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 250
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 251
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 256
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 257
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 258
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:05:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:10:28 --> Query error: Unknown column 'tbl_product.i_id' in 'on clause' - Invalid query: SELECT `tbl_product`.*
FROM `tbl_return`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_sales_items`.`tbl_product_id`
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 40
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 249
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 250
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 251
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 256
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 257
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 258
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:12:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:13:44 --> Severity: Parsing Error --> syntax error, unexpected '<' D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 311
ERROR - 2017-11-28 17:15:36 --> Severity: Notice --> Undefined variable: query D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 29
ERROR - 2017-11-28 17:15:36 --> Severity: Notice --> Undefined property: Returndet::$Stock_model D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 34
ERROR - 2017-11-28 17:15:36 --> Severity: Error --> Call to a member function get_all_stocks() on null D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 34
ERROR - 2017-11-28 17:16:50 --> Query error: Table 'db_methew_gar.cb_storage' doesn't exist - Invalid query: SELECT *
FROM `cb_storage`
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 40
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:23:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 249
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 250
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 251
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 256
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 257
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 258
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:23:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:23:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 17:23:59 --> Severity: Error --> Call to undefined method Returndet_model::get_all_vendor() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 17
ERROR - 2017-11-28 17:24:34 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:24:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:24:34 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:25:39 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:25:39 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:26:06 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:06 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:26:17 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:17 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:26:49 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 61
ERROR - 2017-11-28 17:26:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 61
ERROR - 2017-11-28 17:26:49 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:26:56 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:56 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:26:57 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:57 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:26:58 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:26:58 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 109
ERROR - 2017-11-28 17:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 109
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:27:37 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 627
ERROR - 2017-11-28 12:57:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:57:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 109
ERROR - 2017-11-28 17:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 109
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-28 17:28:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 607
ERROR - 2017-11-28 12:58:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:58:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:28:33 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 12:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 12:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:58:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 12:58:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:58:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 12:58:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:28:54 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 12:58:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:58:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:29:06 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 12:59:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:59:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:29:14 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 12:59:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:59:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:29:28 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 12:59:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:59:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:29:35 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 12:59:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 12:59:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 13:00:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:00:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:30:07 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 593
ERROR - 2017-11-28 13:00:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:00:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:30:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 190
ERROR - 2017-11-28 17:30:33 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 608
ERROR - 2017-11-28 13:00:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:00:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:31:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 190
ERROR - 2017-11-28 17:31:32 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 608
ERROR - 2017-11-28 13:01:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:01:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 183
ERROR - 2017-11-28 17:31:41 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:01:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:01:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 183
ERROR - 2017-11-28 17:32:01 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:02:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:02:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:02:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:02:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:40 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:02:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:02:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:02:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:02:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:41 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:02:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:02:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 250
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: age D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: vintage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: bottling D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: strength D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: size1 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: lot_pur D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: rotateno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: stordate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 259
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: cbno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: duty_paid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 262
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 263
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 264
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 265
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 271
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 274
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 275
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 278
ERROR - 2017-11-28 17:32:42 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 601
ERROR - 2017-11-28 13:02:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:02:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:30 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:03:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:03:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:03:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:03:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: purchase_type D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:33:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:03:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:03:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:33:44 --> Severity: Parsing Error --> syntax error, unexpected 'case' (T_CASE) D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 177
ERROR - 2017-11-28 17:33:57 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 261
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: omv_date D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:07 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:04:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:04:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined variable: from D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:23 --> Severity: Warning --> date_diff() expects parameter 2 to be DateTimeInterface, null given D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined variable: from D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:23 --> Severity: Warning --> date_diff() expects parameter 2 to be DateTimeInterface, null given D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:23 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:04:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:04:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined variable: to D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined variable: from D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:31 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, null given D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined variable: to D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined variable: from D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:31 --> Severity: Warning --> date_diff() expects parameter 1 to be DateTimeInterface, null given D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:04:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:04:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:34:59 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:04:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:04:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 255
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 258
ERROR - 2017-11-28 17:35:01 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 581
ERROR - 2017-11-28 13:05:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:05:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:05:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:05:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 242
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 253
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 254
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 256
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 257
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 260
ERROR - 2017-11-28 17:35:46 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 583
ERROR - 2017-11-28 13:05:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:05:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:36:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 227
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 228
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 227
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 228
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:36:39 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 570
ERROR - 2017-11-28 13:06:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:06:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:06:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:06:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:06:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:06:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:37:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 227
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 228
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 227
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 228
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 229
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 240
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 241
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 243
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:37:07 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 570
ERROR - 2017-11-28 13:07:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:07:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:07:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:07:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:07:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:07:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined variable: Storage D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 62
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 95
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 110
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 236
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 230
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 236
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 244
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 247
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 251
ERROR - 2017-11-28 17:38:47 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 574
ERROR - 2017-11-28 13:08:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:08:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:42:56 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT *
FROM `cb_customer`
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:30 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 236
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 236
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pdate D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 238
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 248
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: po_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 249
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:43:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 575
ERROR - 2017-11-28 13:13:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:13:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:45:27 --> Severity: Error --> Call to undefined method Returndet_model::get_det() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 18
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 96
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:45:38 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 575
ERROR - 2017-11-28 13:15:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:15:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 111
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:46:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 575
ERROR - 2017-11-28 13:16:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:16:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:47:02 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 575
ERROR - 2017-11-28 13:17:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:17:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:48:42 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 575
ERROR - 2017-11-28 13:18:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:18:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 252
ERROR - 2017-11-28 17:48:43 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 575
ERROR - 2017-11-28 13:18:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:18:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: Location D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 234
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: i_code D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: descr D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: currency D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 237
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: total D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 239
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 245
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 246
ERROR - 2017-11-28 17:49:16 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 574
ERROR - 2017-11-28 13:19:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:19:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 235
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined variable: CARG D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 236
ERROR - 2017-11-28 17:49:40 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 564
ERROR - 2017-11-28 13:19:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:19:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:50:00 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:50:00 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:50:00 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:50:00 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 563
ERROR - 2017-11-28 13:20:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:20:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:51:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 231
ERROR - 2017-11-28 17:51:21 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 232
ERROR - 2017-11-28 17:51:21 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 233
ERROR - 2017-11-28 17:51:21 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 563
ERROR - 2017-11-28 13:21:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:21:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 177
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:54:30 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:24:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:24:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 175
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 177
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:54:32 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:24:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:24:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: seller_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 176
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 177
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:56:12 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:26:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:26:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 177
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:56:30 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:26:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:26:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 177
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:56:48 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:26:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:26:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:58:13 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-28 17:58:13 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:58:13 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:58:13 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:58:13 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:58:13 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:28:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:28:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 17:58:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:58:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:58:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:58:48 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:58:48 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:28:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:28:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 17:59:43 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-28 17:59:43 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 17:59:43 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 17:59:43 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 17:59:43 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:29:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:29:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:00:04 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-28 18:00:04 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 18:00:04 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 18:00:04 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:30:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:30:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:00:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-28 18:00:32 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 18:00:32 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:30:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:30:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:00:47 --> Severity: Notice --> Undefined index: acc_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 182
ERROR - 2017-11-28 18:00:47 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:30:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:30:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:00:57 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:30:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:30:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:02:49 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:32:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:32:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:04:28 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:34:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:34:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:34:35 --> 404 Page Not Found: Stock/editstock
ERROR - 2017-11-28 18:04:40 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:34:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:34:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 18:04:44 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:35:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:35:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:05:20 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:35:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:35:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:36:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:36:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:06:50 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:36:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:36:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:06:53 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:36:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:36:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:06:54 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:36:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:36:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:38:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:38:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 40
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 18:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 249
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 250
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 251
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: sgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 256
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: cgst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 257
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: igst D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 258
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 18:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 18:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 18:08:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-11-28 13:38:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:38:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:38:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:38:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:38:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 13:38:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-28 18:08:40 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 512
ERROR - 2017-11-28 13:38:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:38:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:11:42 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 333
ERROR - 2017-11-28 13:41:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:41:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:12:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 334
ERROR - 2017-11-28 13:42:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:42:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:24:04 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:54:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:24:05 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:54:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:54:08 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-11-28 18:24:08 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:54:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:54:09 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-11-28 18:24:09 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:54:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:54:10 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-11-28 18:24:10 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:54:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:54:11 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-11-28 18:24:11 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:54:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:54:11 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-11-28 18:24:11 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 355
ERROR - 2017-11-28 13:54:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 13:54:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:27:23 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 356
ERROR - 2017-11-28 13:57:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:57:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:27:34 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 357
ERROR - 2017-11-28 13:57:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:57:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:28:23 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 357
ERROR - 2017-11-28 13:58:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:58:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:28:35 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 357
ERROR - 2017-11-28 13:58:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 13:58:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:30:56 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:30:56 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:30:56 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:30:56 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:30:56 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 359
ERROR - 2017-11-28 14:00:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 14:00:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:33:00 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:33:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:33:00 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:33:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:33:00 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 359
ERROR - 2017-11-28 14:03:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 14:03:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 18:34:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:34:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-28 18:34:18 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 359
ERROR - 2017-11-28 14:04:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 14:04:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:34:29 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 359
ERROR - 2017-11-28 14:04:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 14:04:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:35:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-28 18:35:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-28 18:35:42 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 364
ERROR - 2017-11-28 14:05:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 14:05:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-28 18:35:55 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 364
ERROR - 2017-11-28 14:05:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-28 14:05:55 --> 404 Page Not Found: Audio/fail.mp3
