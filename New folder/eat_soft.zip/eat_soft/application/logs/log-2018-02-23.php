<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-23 14:28:00 --> Query error: Unknown column 'lot' in 'field list' - Invalid query: SELECT DISTINCT `lot`
FROM `tbl_po_inv`
ERROR - 2018-02-23 14:29:13 --> Severity: Notice --> Undefined variable: lot_no E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-23 14:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-23 08:59:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 08:59:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:29:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 08:59:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 08:59:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:29:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 08:59:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 08:59:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:29:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 08:59:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 08:59:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:29:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:29:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:16 --> Severity: Notice --> Undefined variable: lot_no E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-23 14:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-23 09:03:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:03:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:03:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:33:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:03:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:03:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:33:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:05:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 09:05:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:05:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 09:05:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:06:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:06:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:36:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:36:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:36:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:08:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:08:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:38:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:38:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:38:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:09:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:09:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:10:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:10:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:40:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:40:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:40:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:11:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:11:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:11:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:11:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:41:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:41:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:41:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:12:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:12:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:42:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:42:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:42:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:12:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:12:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:13:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:13:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:43:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:43:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:43:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:13:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:13:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:43:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:43:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:43:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:13:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:13:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:43:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:43:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:43:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:15:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:15:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:45:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:45:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:45:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:16:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:16:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:46:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:46:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:46:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:17:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:17:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:47:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:47:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:47:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:19:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:19:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:49:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:49:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:49:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:20:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:20:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:21:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:21:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:51:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:51:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:51:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:24:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:24:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:54:35 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:54:35 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:54:35 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:54:35 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:54:35 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 289
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 307
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:54:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:57:01 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:57:01 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:57:01 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:57:01 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:57:01 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:57:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:58:29 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:58:29 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:58:29 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:58:29 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:58:29 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:58:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:32:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:32:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:02:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:38 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:02:38 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:02:38 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:38 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:38 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:32:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:32:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:02:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:02:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:10:09 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:10:09 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:10:09 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:10:09 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:10:09 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:10:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:40:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:40:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:53:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:53:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:55:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:55:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:25:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:25:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:25:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:56:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:56:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:26:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:26:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:26:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 09:57:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 09:57:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:27:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:27:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:27:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:33:18 --> Severity: Notice --> Undefined index: po_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 112
ERROR - 2018-02-23 10:03:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:03:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:33:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:33:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:33:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:04:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:04:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:34:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:34:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:34:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:05:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:05:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:35:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:35:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:35:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:06:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:06:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:36:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:36:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:36:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:36:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:36:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:36:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:07:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:07:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:37:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:37:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:37:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:07:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:07:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:07:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:07:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:37:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:37:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:37:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:14:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:14:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:44:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:44:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:44:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:15:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:15:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:45:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:45:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:45:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:19:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:19:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:49:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:49:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:49:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:20:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:20:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:21:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:21:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:22:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:22:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:23:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:23:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:24:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:24:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:24:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:24:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 15:54:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:54:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 15:54:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:25:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:25:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:26:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:26:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:26:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:26:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:26:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:26:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:28:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:28:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:29:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:29:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:01:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:01:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:01:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:31:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:31:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:32:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:32:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:02:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:02:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:02:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:32:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:32:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 10:32:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:32:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:33:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:33:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:03:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:03:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:03:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:33:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:33:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:04:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:04:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:04:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:04:04 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 70
ERROR - 2018-02-23 10:34:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:34:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:35:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:35:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:06:07 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 53
ERROR - 2018-02-23 10:36:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:36:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:06:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:06:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:06:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:06:52 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 61
ERROR - 2018-02-23 10:36:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:36:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:37:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:37:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:38:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:38:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:08:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:08:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:08:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:38:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:38:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:38:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:38:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:39:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:39:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:39:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:39:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:40:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:40:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:10:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:10:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:10:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:40:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:40:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:40:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:40:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:10:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:10:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:10:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:40:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:40:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:41:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:41:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:11:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:11:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:11:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:42:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:42:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:42:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:42:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:42:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:42:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:43:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:43:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:13:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:13:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:13:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:43:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:43:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:44:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:44:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:14:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:14:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:14:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:44:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:44:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:45:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:45:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:15:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:15:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:15:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:46:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:46:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:16:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:16:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:16:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:47:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:47:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:17:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:17:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:17:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:48:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:48:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:48:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:48:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:18:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:18:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:18:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:50:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:50:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:51:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:51:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:52:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:52:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:52:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:52:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:52:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:52:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:22:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:22:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:22:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:53:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:53:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:23:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:23:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:23:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:53:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:53:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:23:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:53:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:53:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:53:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:53:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:23:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:23:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:23:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:54:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:54:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:54:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:54:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:24:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:24:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:24:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:54:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:54:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:55:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:55:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:25:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:25:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:25:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 10:58:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:58:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:28:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:28:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:28:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:28:35 --> Query error: Unknown column 'tbl_grn_hold.po_ref_id' in 'where clause' - Invalid query: DELETE FROM `tbl_po_inv_hold`
WHERE `tbl_grn_hold`.`po_ref_id` = '1'
ERROR - 2018-02-23 10:59:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 10:59:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:59:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 10:59:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:00:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 11:00:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:00:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 11:00:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:01:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:01:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 11:01:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:01:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:31:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:31:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:31:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:01:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 11:01:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 16:31:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:31:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:31:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:01:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:01:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:31:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:31:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:31:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:02:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:02:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:32:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:32:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:32:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:02:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:02:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 16:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:04:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:04:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:34:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:34:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:34:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:07:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:07:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:37:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:37:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:37:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:19:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:19:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:20:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:20:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:50:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:50:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:50:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:20:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:20:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 16:50:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:50:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 16:50:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:29:53 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 164
ERROR - 2018-02-23 11:30:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:30:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:00:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:00:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:00:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:34:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:34:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:04:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:04:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:04:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:04:46 --> Severity: Notice --> Undefined index: sup E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 164
ERROR - 2018-02-23 17:04:46 --> Severity: Notice --> Undefined index: inv E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 164
ERROR - 2018-02-23 11:35:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:35:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:05:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:05:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:05:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:37:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:37:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:38:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:38:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:08:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:08:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:08:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:39:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:39:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:09:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:09:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:09:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:47:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:47:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:17:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:17:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:17:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:48:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:48:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:18:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:18:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:18:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:48:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:48:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:18:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:18:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:18:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:49:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 11:49:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:19:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:19:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:19:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:49:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:49:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 17:19:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:19:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:19:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:54:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 11:54:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 17:24:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:24:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:24:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 11:55:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 11:55:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:13:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 12:13:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 17:43:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:43:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:43:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:44:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:44:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:44:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:44:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:44:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:44:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:16:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 12:16:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 17:46:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:46:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:46:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:46:27 --> Query error: Unknown column 'tbl_grn.style_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_ref_id`=`tbl_po_inv`.`po_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
WHERE `tbl_po_inv`.`po_id` = '31'
ERROR - 2018-02-23 17:46:27 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519388187
WHERE `tbl_po_inv`.`po_id` = '31'
AND `id` = '946e47d4d553cde5de022a75758fe0bd3100e570'
ERROR - 2018-02-23 17:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:17:58 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-23 12:17:58 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-23 17:47:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:47:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:21:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-23 12:21:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-02-23 17:51:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:51:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:51:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:21:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 12:21:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 17:51:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:51:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:51:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:53:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:53:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:53:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:23:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 12:23:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 17:53:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:53:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:53:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 12:29:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 12:29:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 17:59:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:59:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 17:59:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 18:41:01 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 237
ERROR - 2018-02-23 13:14:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 13:14:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 18:44:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:44:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:44:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:14:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 13:14:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 18:44:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:44:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:44:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:14:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:14:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 18:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:15:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:15:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 18:45:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:45:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:45:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:17:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:17:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 18:47:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:47:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:47:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:47:12 --> Severity: Warning --> array_walk() expects parameter 1 to be array, null given E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 205
ERROR - 2018-02-23 13:20:15 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 180
ERROR - 2018-02-23 13:22:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 13:22:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 18:52:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:52:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:52:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:23:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:23:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 18:53:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:53:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 18:53:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:09:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:09:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:09:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:09:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:09:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:09:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:40:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:40:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:10:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:10:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:10:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:48:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:48:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:18:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:18:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:18:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:51:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:51:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:21:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:21:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:21:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:53:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:53:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 13:53:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 13:53:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:23:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:23:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:23:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:03:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:03:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 19:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:06:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:06:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:36:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:06:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:06:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:06:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:06:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 19:36:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:06:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:06:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:36:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:36:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:21:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:21:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 19:51:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:51:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 19:51:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:32:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-23 14:32:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-23 20:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:33:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 20:03:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:33:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 20:03:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:33:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:03:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:33:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:33:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:03:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:03:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:34:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:34:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:04:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:34:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:34:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:04:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:34:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:34:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:04:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:04:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:35:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:35:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:36:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:36:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:06:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:06:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:06:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:36:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 14:36:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 20:06:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:06:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:06:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:38:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-23 14:38:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-23 20:08:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:38:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:38:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:08:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:38:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:38:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:08:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:08:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:39:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:39:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:05 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:09:05 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:09:05 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:09:05 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:09:05 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:39:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:39:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:09:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:09:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 14:40:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 14:40:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-23 20:10:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:10:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-23 20:10:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
