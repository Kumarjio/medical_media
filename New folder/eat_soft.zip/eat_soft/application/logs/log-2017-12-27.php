<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-27 07:47:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-27 07:47:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-27 07:47:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-27 07:47:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-27 07:47:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-27 07:47:32 --> 404 Page Not Found: Product/audio
