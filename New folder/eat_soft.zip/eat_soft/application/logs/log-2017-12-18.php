<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:12 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 05:12:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:12:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:42:36 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 05:12:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:12:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 05:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:47:46 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 05:17:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 05:17:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 09:48:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 05:18:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:18:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 09:48:40 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 05:18:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:18:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:54:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 05:24:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:24:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:54 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:55 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:55 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:00:55 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 05:30:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:30:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:00:57 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 05:30:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:30:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-18 10:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-18 10:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-18 10:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-18 10:04:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-18 05:35:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:35:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:05:21 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 05:35:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:35:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:24 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 05:38:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:38:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 198
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:08:53 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 05:38:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:38:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:09:37 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 05:39:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:39:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 324
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 10:10:04 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 325
ERROR - 2017-12-18 05:40:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:40:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:40:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:40:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 05:42:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:42:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:12:30 --> Severity: Notice --> Undefined variable: color D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 202
ERROR - 2017-12-18 10:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 202
ERROR - 2017-12-18 10:12:30 --> Severity: Notice --> Undefined variable: color D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 326
ERROR - 2017-12-18 10:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 326
ERROR - 2017-12-18 05:42:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:42:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:44:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:44:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:45:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:45:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:47:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:47:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:48:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 05:48:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:48:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:48:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 10:19:27 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 05:49:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 05:49:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:54:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:54:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 05:54:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:54:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:54:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:54:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:54:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:54:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 05:54:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:54:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:24:33 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-18 05:55:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 05:55:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 05:55:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 05:55:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:00:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:00:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:01:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:01:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:31:29 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = '1'
ERROR - 2017-12-18 10:31:29 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513573289, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513573289;'
WHERE `product_id` = '1'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:05:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:05:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:05:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:05:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:16:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:16:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:16:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:16:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:17:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:17:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:17:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:17:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:19:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:19:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:20:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:20:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:20:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:20:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:21:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:21:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:22:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:22:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:22:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:22:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:23:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:23:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:24:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:24:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:25:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:25:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:26:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:26:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:56:50 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = '1'
ERROR - 2017-12-18 10:56:50 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513574810, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513574810;'
WHERE `product_id` = '1'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:29:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:29:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:29:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:29:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:59:49 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = '5'
ERROR - 2017-12-18 10:59:49 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513574989, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513574989;'
WHERE `product_id` = '5'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 11:00:35 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = '1'
ERROR - 2017-12-18 11:00:35 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575035, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575035;'
WHERE `product_id` = '1'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:30:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:30:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:00:53 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = '5'
ERROR - 2017-12-18 11:00:53 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575053, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575053;'
WHERE `product_id` = '5'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:32:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:32:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:32:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:32:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:02:48 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:02:48 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575168, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575168;'
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:33:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:33:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:37 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:03:37 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575217, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575217;'
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:34:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:34:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:35:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:35:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:05:43 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:05:43 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575343, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575343;'
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:36:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:36:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:06:33 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:06:33 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575393, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575393;'
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:36:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:36:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:36:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:36:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:06:39 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:06:39 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575399, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575399;'
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 11:06:42 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS002'
ERROR - 2017-12-18 11:06:42 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513575402, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513575402;'
WHERE `product_id` = 'TS002'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:36:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 06:36:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 06:48:25 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 74
ERROR - 2017-12-18 06:48:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:48:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:18:45 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:18:45 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513576125, `data` = 'user_id|s:1:\"1\";location|s:5:\"porur\";user_type|s:1:\"1\";user_name|s:5:\"admin\";name|s:8:\"santhiya\";mailid|s:13:\"xyz@gmail.com\";phone|s:9:\"786868689\";loginuser|b:1;company_name|s:14:\"MethewGarments\";__ci_last_regenerate|i:1513576125;'
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 11:18:45 --> Severity: Notice --> Undefined variable: style D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 75
ERROR - 2017-12-18 06:49:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:49:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:19:58 --> Severity: Notice --> Undefined variable: style D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 75
ERROR - 2017-12-18 11:19:58 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:19:58 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513576198
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:52:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:52:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:22:49 --> Severity: Notice --> Undefined variable: style D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 75
ERROR - 2017-12-18 11:22:49 --> Query error: Unknown column 'images' in 'field list' - Invalid query: SELECT `images`
FROM `tbl_product`
WHERE `product_id` = 'TS001'
ERROR - 2017-12-18 11:22:49 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513576369
WHERE `product_id` = 'TS001'
AND `id` = 'ed18c5ea31481a73533fa8a0530dc23fb3413e9d'
ERROR - 2017-12-18 06:55:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:55:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:25:14 --> Severity: Notice --> Undefined variable: style D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 75
ERROR - 2017-12-18 06:57:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:57:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:28:02 --> Severity: Notice --> Undefined variable: style D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 75
ERROR - 2017-12-18 06:59:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 06:59:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:00:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:00:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:03:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:03:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:04:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:04:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:07:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:07:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:18:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 07:18:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 07:18:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 07:18:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 07:18:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 07:18:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 07:18:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 07:18:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 07:18:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:18:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:27:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:27:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:31:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:31:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:32:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:32:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:02:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_id`
W' at line 2 - Invalid query: SELECT `tbl_product_img`.*, `tbl_color`.*
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_id`
WHERE `style_name` = 'TS001'
ERROR - 2017-12-18 07:33:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:33:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:04:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_i' at line 2 - Invalid query: SELECT `tbl_product_img`.*, `tbl_color`.*
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
WHERE `style_name` = 'TS001'
ERROR - 2017-12-18 12:04:00 --> Query error: Unknown column 'style_name' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513578840
WHERE `style_name` = 'TS001'
AND `id` = '41e4859daf72d03dfc0c2cf9b2820085cd394d56'
ERROR - 2017-12-18 07:34:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:34:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:04:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_i' at line 2 - Invalid query: SELECT `tbl_product_img`.*, `tbl_color`.*
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
WHERE `style_name` = 'TS001'
ERROR - 2017-12-18 12:04:45 --> Query error: Unknown column 'style_name' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513578885
WHERE `style_name` = 'TS001'
AND `id` = '41e4859daf72d03dfc0c2cf9b2820085cd394d56'
ERROR - 2017-12-18 07:36:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:36:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:06:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_i' at line 2 - Invalid query: SELECT `tbl_product_img`.*, `tbl_color`.*
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
WHERE `style_name` = 'TS001'
ERROR - 2017-12-18 12:06:10 --> Query error: Unknown column 'style_name' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513578970
WHERE `style_name` = 'TS001'
AND `id` = '41e4859daf72d03dfc0c2cf9b2820085cd394d56'
ERROR - 2017-12-18 07:37:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:37:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:07:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_i' at line 2 - Invalid query: SELECT `tbl_product_img`.*, `tbl_color`.*
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
WHERE `style_name` = 'TS001'
ERROR - 2017-12-18 12:07:05 --> Query error: Unknown column 'style_name' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513579025
WHERE `style_name` = 'TS001'
AND `id` = '41e4859daf72d03dfc0c2cf9b2820085cd394d56'
ERROR - 2017-12-18 07:38:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:38:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:38:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:38:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:42:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:42:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:43:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:43:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:44:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:44:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:46:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:46:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:47:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:47:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:49:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:49:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:50:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:50:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:50:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:50:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:51:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:51:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:51:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:51:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:52:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:52:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:59:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 07:59:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:00:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:00:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:01:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:04:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:04:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:04:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:04:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:13:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:13:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:14:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:14:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:14:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:14:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:19:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:19:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:22:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:22:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:23:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:23:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:23:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:23:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:24:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:24:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:24:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:24:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:24:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:24:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:25:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:25:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:25:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:25:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:26:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:26:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:27:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:27:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:27:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:27:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:30:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:30:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:31:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:31:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:32:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:32:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:32:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:32:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:33:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:33:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:36:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:36:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:36:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:36:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:37:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:37:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:39:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:39:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:39:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:39:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:39:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:39:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:41:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:44:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:44:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:45:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:45:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:45:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:45:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:46:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:46:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:47:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:47:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:47:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:47:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:47:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:47:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:48:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:48:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:49:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 08:49:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:44:51 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:14:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:14:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:14:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:14:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:14:57 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-18 09:14:57 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-18 13:45:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-18 09:15:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-18 09:15:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-18 09:15:28 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-18 09:15:28 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 13:46:15 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:16:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:16:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:16:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:16:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 13:46:23 --> Query error: Unknown column 'tbl_product_img.color_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_product_img`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_img`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_id`
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 14:12:37 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 09:42:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:42:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 14:12:39 --> Query error: Unknown column 'tbl_product_img.color_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_product_img`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_img`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_id`
ERROR - 2017-12-18 09:43:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:43:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:43:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:43:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:43:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:43:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:43:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:43:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:43:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:43:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:43:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:43:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:44:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:44:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:44:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 09:44:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 09:44:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 09:44:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 10:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 10:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:54:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 10:54:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 10:54:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:54:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 10:54:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 10:54:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 10:54:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 10:54:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 10:54:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:54:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:57:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:57:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:57:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 10:57:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:01:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:01:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:01:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:01:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:02:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:02:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:02:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:02:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:03:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:04:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:04:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:05:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 11:05:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:44:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 12:14:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:14:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 16:44:08 --> Query error: Unknown column 'tbl_po_inv_item.style_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 16:46:46 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 12:16:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:16:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:16:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:16:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:16:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:16:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:23:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:23:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:23:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:23:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:23:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:23:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:23:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:23:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:24:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:24:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:24:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:24:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:24:39 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-18 12:24:39 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-18 12:24:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:24:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:24:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:24:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:25:02 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-18 12:25:02 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-18 12:25:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:25:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:26:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:26:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:26:21 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-18 12:26:21 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-18 12:26:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:26:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:26:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:26:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:26:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:26:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:26:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:26:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:26:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:26:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:27:07 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-18 12:27:07 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-18 12:27:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:27:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:27:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:27:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:27:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:27:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:28:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:28:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:28:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:28:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:29:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:29:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:29:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:29:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:29:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:29:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 16:59:55 --> Query error: Unknown column 'color_id' in 'field list' - Invalid query: INSERT INTO `tbl_product_img` (`style_name`, `color_id`, `image_url`) VALUES ('SH009', '1', '1513596594RS_MOCK_1024x1024.jpg')
ERROR - 2017-12-18 12:30:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:30:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:31:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:31:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:32:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:32:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 12:32:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:32:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:32:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:32:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:34:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:34:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 17:05:16 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-18 12:35:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:35:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:42:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 12:42:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 12:43:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:43:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:52:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:52:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:53:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:53:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:54:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:54:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:55:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 12:55:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:01:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:01:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:01:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:01:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:02:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:02:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:03:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:03:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:04:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:04:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:04:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:04:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:05:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:05:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:05:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:05:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:07:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:07:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:12:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:12:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:15:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:15:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:15:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:15:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:16:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:16:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:17:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:17:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:17:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:17:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:20:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:20:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:21:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:21:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:22:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:22:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:24:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:24:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:25:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:25:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:25:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:25:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:26:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:26:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:26:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:26:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:29:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:29:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:31:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:31:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:33:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:33:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:33:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:33:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:34:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:34:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:34:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:34:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:35:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:35:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:38:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:38:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:38:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:38:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:39:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:39:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:40:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:40:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:41:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:41:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:43:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:44:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:44:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:48:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:48:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:48:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:48:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:49:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:49:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:51:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:51:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:52:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:52:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:52:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:52:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:53:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:53:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:53:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:53:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:54:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:54:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:54:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 13:54:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 13:54:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 13:54:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 13:55:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 13:55:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-18 13:55:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-18 13:55:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-18 13:55:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 13:55:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:02:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:02:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:03:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:03:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:03:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:03:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:05:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:05:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:05:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:05:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:06:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:06:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:06:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:06:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:08:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:08:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:15:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:15:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:19:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:19:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:19:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-18 14:19:30 --> 404 Page Not Found: Goodsreceived/audio
