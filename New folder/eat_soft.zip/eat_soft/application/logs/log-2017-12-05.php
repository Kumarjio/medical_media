<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-05 05:18:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:18:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:20:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:20:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:20:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:20:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:20:40 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-05 05:20:40 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2017-12-05 09:50:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2017-12-05 09:50:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2017-12-05 05:21:06 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 05:21:06 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 09:51:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 09:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 09:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 09:51:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 09:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 09:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 05:22:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:22:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:22:29 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-05 05:22:29 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-05 09:52:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-05 05:24:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:24:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:24:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 05:24:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 09:54:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 09:55:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 05:25:59 --> 404 Page Not Found: Unit/audio
ERROR - 2017-12-05 05:25:59 --> 404 Page Not Found: Unit/audio
ERROR - 2017-12-05 09:56:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\unit_edit.php 14
ERROR - 2017-12-05 09:56:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\unit_edit.php 24
ERROR - 2017-12-05 09:56:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\unit_edit.php 38
ERROR - 2017-12-05 09:56:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\unit_edit.php 14
ERROR - 2017-12-05 09:56:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\unit_edit.php 24
ERROR - 2017-12-05 09:56:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\unit_edit.php 38
ERROR - 2017-12-05 05:26:13 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-05 05:26:13 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-05 09:56:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 14
ERROR - 2017-12-05 09:56:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 24
ERROR - 2017-12-05 09:56:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 38
ERROR - 2017-12-05 09:56:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 14
ERROR - 2017-12-05 09:56:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 24
ERROR - 2017-12-05 09:56:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 38
ERROR - 2017-12-05 05:27:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:27:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:27:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:27:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:27:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:27:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:28:08 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-05 05:28:08 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-05 05:28:27 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-05 05:28:27 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-05 09:58:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 14
ERROR - 2017-12-05 09:58:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 24
ERROR - 2017-12-05 09:58:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 38
ERROR - 2017-12-05 09:58:30 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 14
ERROR - 2017-12-05 09:58:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 24
ERROR - 2017-12-05 09:58:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 38
ERROR - 2017-12-05 09:58:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 14
ERROR - 2017-12-05 09:58:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 24
ERROR - 2017-12-05 09:58:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 38
ERROR - 2017-12-05 09:58:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 14
ERROR - 2017-12-05 09:58:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 24
ERROR - 2017-12-05 09:58:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\size_edit.php 38
ERROR - 2017-12-05 05:29:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:29:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:29:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:29:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:29:31 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-05 05:29:31 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-05 09:59:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-12-05 09:59:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-12-05 09:59:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-12-05 09:59:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 14
ERROR - 2017-12-05 09:59:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 24
ERROR - 2017-12-05 09:59:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\rate_edit.php 38
ERROR - 2017-12-05 05:36:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:36:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:36:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:36:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:38:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:38:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:38:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:38:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:39:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:39:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:39:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:39:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:39:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:39:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:44:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:44:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:46:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:46:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:46:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:46:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:47:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:47:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:47:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:47:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:47:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:47:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:48:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:48:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:48:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:48:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:49:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:49:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:49:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:49:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 05:49:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:49:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:49:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:49:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:51:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:51:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:51:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:51:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:52:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:52:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:52:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:52:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:52:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:52:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:52:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:52:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:53:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 05:53:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:54:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 05:54:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:03:24 --> 404 Page Not Found: Materials/index
ERROR - 2017-12-05 06:04:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:04:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:04:17 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:17 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:33 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:33 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:36 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:36 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:36 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:36 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:37 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:37 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:37 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:37 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:37 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:37 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:04:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:04:50 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:04:50 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:05:06 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:05:06 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:05:07 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:05:07 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-05 06:06:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:06:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:07:31 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:07:31 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 10:37:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:36 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:54 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:54 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:37:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:37:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:37:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:23 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-05 10:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-05 06:08:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:08:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:09:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:09:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:11:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:11:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:11:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:11:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:12:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:12:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:12:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:12:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:12:43 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:12:43 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:18:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:18:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:18:15 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:18:15 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:18:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:18:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:18:23 --> 404 Page Not Found: Material/edit_branch
ERROR - 2017-12-05 06:20:43 --> 404 Page Not Found: Material/edit_branch
ERROR - 2017-12-05 06:21:02 --> 404 Page Not Found: Material/edit_branch
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 10:52:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:52:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:52:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 10:52:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:52:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:52:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 10:52:20 --> Severity: Error --> Call to undefined method Material_model::update_material() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Material.php 50
ERROR - 2017-12-05 06:22:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:22:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 10:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:52:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:52:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 10:52:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 10:52:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 10:52:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 06:23:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:23:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:23:06 --> 404 Page Not Found: Material/delete_branch
ERROR - 2017-12-05 10:53:31 --> Severity: Error --> Call to undefined method Material_model::delete_material() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Material.php 57
ERROR - 2017-12-05 06:24:06 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:24:06 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:24:11 --> 404 Page Not Found: Material/material_add
ERROR - 2017-12-05 06:24:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:24:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:27:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:27:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 06:27:33 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:27:33 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 06:27:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 06:27:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:02:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:02:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 07:02:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 07:02:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:02:09 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 07:02:09 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-05 11:32:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 11:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 11:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 11:32:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 11:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 11:32:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 11:32:18 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 11:32:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 11:32:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 11:32:18 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2017-12-05 11:32:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2017-12-05 11:32:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2017-12-05 07:02:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:02:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:11:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:11:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:20:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:20:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:23:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:23:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:24:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:24:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:25:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:25:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:26:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:26:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:10:05 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 295
ERROR - 2017-12-05 07:40:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:40:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:40:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:40:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:41:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:41:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:42:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 07:42:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:45:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 07:45:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:50:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 07:50:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:50:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 07:50:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 07:50:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:50:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:51:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 07:51:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:14:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:14:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:14:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:14:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:15:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:15:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:16:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:16:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:16:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:16:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:17:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:17:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:18:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:18:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:18:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:18:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:18:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:18:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:21:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:25:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:25:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:25:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:25:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:26:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:26:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:29:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:29:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:32:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:32:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:33:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:33:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:34:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:34:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:35:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:35:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:35:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:35:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:36:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:36:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 108
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 108
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-12-05 13:06:01 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 108
ERROR - 2017-12-05 08:36:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:06:28 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:28 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:28 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 08:36:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 08:36:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 08:36:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:30 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 08:36:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:06:31 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:31 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:31 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 08:36:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:36:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:48 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 08:36:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:49 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 08:36:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:36:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-12-05 13:06:50 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 109
ERROR - 2017-12-05 08:36:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:36:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:36:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:07:09 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-12-05 08:37:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:37:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:37:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:37:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:07:31 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-12-05 13:07:31 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-12-05 13:07:31 --> Severity: Notice --> Undefined variable: qty D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-12-05 08:37:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:37:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:37:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 08:37:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 08:38:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:38:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:38:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:38:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:38:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:38:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:42:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 08:42:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 10:27:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 10:27:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 10:27:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 10:27:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 10:28:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 10:28:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 10:28:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 10:28:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 10:28:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 10:28:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 10:54:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 10:54:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 10:55:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 10:55:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 10:58:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 10:58:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 11:06:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:06:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:11:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:11:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:11:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 11:11:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 11:11:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 11:11:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 11:12:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:12:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:12:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:12:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:39:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:39:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 11:44:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 11:44:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 11:48:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 11:48:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 11:49:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 11:49:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 16:38:14 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 141
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: s_no D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-05 16:38:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 83
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 84
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 86
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 87
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 83
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 84
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 86
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 87
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 83
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 84
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 86
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 87
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 83
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 84
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 86
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 87
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 83
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 84
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 86
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 87
ERROR - 2017-12-05 16:38:22 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 12:08:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:08:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 66
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:15 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 12:09:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:09:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 12:09:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:09:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 89
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 90
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 92
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 16:39:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 95
ERROR - 2017-12-05 12:09:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:09:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:09:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:09:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:10:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:10:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:11:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:11:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:11:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:11:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:13:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:13:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:13:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:13:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:16:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:16:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:16:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:16:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:20:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:20:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:21:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:21:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:21:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:21:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 16:52:50 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-05 12:22:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:22:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:23:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:23:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:43:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:43:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 17:15:13 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-05 12:45:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:45:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:45:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:45:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:46:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:46:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:46:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:46:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:47:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:47:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:47:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:47:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:47:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:47:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:49:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:49:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 12:49:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:49:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:49:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:49:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:51:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:51:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-05 17:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-05 17:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-05 17:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 17:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-05 12:51:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:51:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:52:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:52:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:52:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:52:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:53:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:53:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:54:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:54:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:54:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:54:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 17:25:36 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-12-05 12:55:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:55:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 17:27:07 --> Query error: Table 'db_methew_gar.tbl_brand' doesn't exist - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_brand`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id`=`tbl_po_inv_item`.`brand_ref_id`
ERROR - 2017-12-05 17:27:58 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_product` ON `tbl_product`.`brand_name`=`tbl_po_inv_item`.`brand_ref_id`
ERROR - 2017-12-05 17:28:27 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-12-05 12:58:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 12:58:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 17:29:33 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-12-05 12:59:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:59:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 17:29:34 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-12-05 12:59:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:59:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 17:29:41 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-12-05 12:59:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 12:59:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 17:30:04 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-12-05 13:00:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:00:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:00:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:00:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:00:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:00:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:01:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:01:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:01:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:01:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:01:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:01:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:01:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:01:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:02:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:02:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:03:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:03:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:03:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 13:03:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 13:03:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:03:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:07:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:07:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:07:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:07:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:13:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:13:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:14:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:14:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:15:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:15:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:16:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:16:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:16:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 13:16:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 13:26:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:26:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:26:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:26:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:27:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:27:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:27:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:27:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:27:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:27:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:27:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 13:27:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 13:32:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:32:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:32:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:32:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:37:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:37:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:37:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:37:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:49:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:49:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:50:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:50:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:20:53 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 33
ERROR - 2017-12-05 18:20:53 --> Query error: Column 'images' cannot be null - Invalid query: INSERT INTO `tbl_product` (`product_name`, `brand_name`, `material_name`, `images`) VALUES ('', '', '', NULL)
ERROR - 2017-12-05 13:58:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:58:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:58:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 13:58:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:28:55 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 37
ERROR - 2017-12-05 18:28:55 --> Query error: Column 'images' cannot be null - Invalid query: INSERT INTO `tbl_product` (`product_name`, `brand_name`, `material_name`, `images`) VALUES ('', '', '', NULL)
ERROR - 2017-12-05 18:32:29 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 37
ERROR - 2017-12-05 14:02:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:02:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:02:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:02:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:32:41 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 37
ERROR - 2017-12-05 14:02:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:02:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:09:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:09:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:09:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:09:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:09:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:09:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:09:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:09:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:39:52 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 47
ERROR - 2017-12-05 14:09:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:09:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:12:09 --> Severity: Compile Error --> Cannot redeclare Product::upload_file() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 39
ERROR - 2017-12-05 14:12:10 --> Severity: Compile Error --> Cannot redeclare Product::upload_file() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 39
ERROR - 2017-12-05 14:12:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:12:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:12:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:12:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:42:50 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 50
ERROR - 2017-12-05 14:12:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:12:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:12:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:12:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:43:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:43:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:43:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-05 18:45:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-05 14:16:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:16:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:16:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:16:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:17:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:17:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:48:04 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 47
ERROR - 2017-12-05 14:18:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:18:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:25:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:25:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:25:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:25:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:25:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 14:25:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-05 18:55:48 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 55
ERROR - 2017-12-05 14:25:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:25:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:28:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:28:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:28:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:28:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:28:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:28:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:28:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-05 14:28:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-05 14:28:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-05 14:28:41 --> 404 Page Not Found: Goodsreceived/audio
