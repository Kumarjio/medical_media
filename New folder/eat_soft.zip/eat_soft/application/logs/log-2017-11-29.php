<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-29 05:19:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:19:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:19:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:19:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:49:29 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 364
ERROR - 2017-11-29 05:19:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:19:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:20:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:20:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:50:31 --> Severity: Notice --> Undefined variable: stock D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 364
ERROR - 2017-11-29 05:20:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:20:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:21:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:21:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:23:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:23:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:24:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:24:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:24:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:24:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:24:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:24:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:24:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:24:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:25:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:25:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:25:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:25:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:25:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:25:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:27:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:27:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 10:00:42 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:00:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:00:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-29 10:00:42 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:00:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:00:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 186
ERROR - 2017-11-29 05:30:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:30:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 10:01:00 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 10:01:00 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:00 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 05:31:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:31:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 10:01:01 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:01 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:01 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 10:01:01 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:01 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:01 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 05:31:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:31:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 10:01:43 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:43 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:43 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 10:01:43 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:43 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:01:43 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 05:31:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:31:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 10:13:29 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:29 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:29 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 10:13:29 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:29 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:29 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 05:43:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:43:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 10:13:31 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:31 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:31 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 10:13:31 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:31 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:13:31 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 187
ERROR - 2017-11-29 05:43:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:43:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:56:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 05:56:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 05:56:47 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 06:02:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:02:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:02:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:02:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:02:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:02:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:02:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:02:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:02:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:02:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:08:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:08:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:11:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:11:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:11:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:11:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:11:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:11:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:11:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:11:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:12:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:12:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:12:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:12:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:13:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:13:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:13:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:13:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:13:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:13:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:14:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:14:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:14:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:14:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:14:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:14:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:15:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:15:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:15:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:15:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:15:16 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-29 06:15:16 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-29 06:15:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:15:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:15:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:15:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:15:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:15:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:16:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:16:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 06:16:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:16:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:16:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:16:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:18:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:18:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:18:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:18:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:27:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:27:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:27:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:27:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 10:59:46 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:59:46 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:59:46 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 06:29:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:29:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 10:59:52 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:59:52 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 10:59:52 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 06:29:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:29:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:02:19 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-29 11:02:19 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-29 11:02:19 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-29 11:02:19 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-29 11:02:19 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-29 11:02:19 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-29 06:32:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:32:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:02:40 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-29 11:02:40 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-29 11:02:40 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-29 11:02:40 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-29 11:02:40 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 179
ERROR - 2017-11-29 11:02:40 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 181
ERROR - 2017-11-29 06:32:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:32:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:32:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:32:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:33:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:33:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:37:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:37:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:37:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:37:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:37:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:37:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:07:57 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 11:07:57 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 11:07:57 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 06:37:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:37:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:07:58 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 11:07:58 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 11:07:58 --> Severity: Notice --> Undefined variable: sellprice D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 06:37:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:37:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:38:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:38:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:38:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:38:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 185
ERROR - 2017-11-29 11:08:54 --> Severity: Notice --> Undefined variable: loop23 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 189
ERROR - 2017-11-29 06:38:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:38:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:40:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:40:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:40:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:40:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:40:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:40:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:46:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:46:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:54:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:54:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 06:57:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 06:57:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:01:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:01:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:29:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:29:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:32:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:32:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:43:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:43:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:44:10 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:10 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:11 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:11 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:11 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:11 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:15 --> 404 Page Not Found: Stock/update_amt
ERROR - 2017-11-29 07:44:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:44:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:14:54 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 07:44:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:44:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:13 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 07:45:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:45:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: postdt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:15:14 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 07:45:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:45:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 178
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tot_omv_dt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 180
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 211
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 212
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 214
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 215
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 216
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 217
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 218
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 219
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 220
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 221
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 222
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 223
ERROR - 2017-11-29 12:16:05 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 226
ERROR - 2017-11-29 07:46:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:46:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 198
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 199
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 200
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 201
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 202
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 203
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 204
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 205
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:18 --> Severity: Notice --> Undefined variable: loop D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 213
ERROR - 2017-11-29 07:46:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:46:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:16:40 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 07:46:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:46:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:24 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 07:49:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:49:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:25 --> Severity: Notice --> Undefined index: tbl_purid D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 210
ERROR - 2017-11-29 07:49:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:49:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:44 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 07:49:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:49:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 206
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:19:45 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 07:49:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:49:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:20:24 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:20:24 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:20:24 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:20:24 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:20:24 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:20:24 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 07:50:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:50:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:20:25 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:20:25 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:20:25 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:20:25 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 12:20:25 --> Severity: Notice --> Undefined index: pur_remarks D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 207
ERROR - 2017-11-29 12:20:25 --> Severity: Notice --> Undefined index: pur_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 208
ERROR - 2017-11-29 07:50:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:50:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:51:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:51:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:52:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:52:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:52:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:52:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:57:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 07:57:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:57:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 07:57:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:30:22 --> Severity: Notice --> Undefined variable: ret_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:30:22 --> Severity: Notice --> Undefined variable: ret_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 12:30:22 --> Severity: Notice --> Undefined variable: ret_qty D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 209
ERROR - 2017-11-29 08:00:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:00:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:00:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:00:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:01:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:01:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:01:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:01:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:01:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:01:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:01:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:01:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:15:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:15:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:15:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:15:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:16:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:16:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:17:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:17:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:18:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:18:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:18:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:18:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:18:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:18:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:18:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 08:18:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 08:19:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 08:19:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 08:19:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:19:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:22:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:22:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:24:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:24:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:24:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:24:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:24:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:24:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:24:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:24:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:25:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:25:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:26:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 08:26:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:26:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 08:26:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:12:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:12:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:45:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 13:45:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 13:45:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 13:45:42 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 184
ERROR - 2017-11-29 09:15:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:15:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 09:15:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:15:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 09:16:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 09:16:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 09:16:17 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-11-29 09:16:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 09:16:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 10:58:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 10:58:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:56:19 --> 404 Page Not Found: Stocksummary/index
ERROR - 2017-11-29 11:56:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 11:56:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:24:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:24:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:35:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:35:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:43:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:43:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:43:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:43:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:43:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 12:43:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:43:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 12:43:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:00:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:00:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:01:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:01:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:01:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:01:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:02:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:02:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:02:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:02:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:02:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:02:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:02:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:02:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:02:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:02:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:03:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:03:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:03:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:03:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:04:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:04:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:04:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:04:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:04:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:04:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:05:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:05:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 17:35:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-11-29 17:35:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-11-29 17:35:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-11-29 17:35:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-11-29 17:35:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-11-29 17:35:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-11-29 13:05:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:05:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:05:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:05:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:06:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:06:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 17:47:08 --> Severity: Warning --> Missing argument 1 for Stocksummary_model::getstockdetails(), called in D:\xampp\htdocs\duty\mathewgarments\application\controllers\Stocksummary.PHP on line 19 and defined D:\xampp\htdocs\duty\mathewgarments\application\models\Stocksummary_model.php 37
ERROR - 2017-11-29 13:17:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:17:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 17:48:01 --> Severity: Warning --> Missing argument 1 for Stocksummary_model::getstockdetails(), called in D:\xampp\htdocs\duty\mathewgarments\application\controllers\Stocksummary.PHP on line 27 and defined D:\xampp\htdocs\duty\mathewgarments\application\models\Stocksummary_model.php 37
ERROR - 2017-11-29 13:18:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:18:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:18:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:18:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:20:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:20:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:20:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:20:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 13:20:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 13:21:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:21:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:21:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:21:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:21:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:21:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:22:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:22:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:23:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:23:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:23:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:23:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:24:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:24:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:31:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:31:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 13:31:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 13:31:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-29 13:31:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-29 13:31:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-29 18:20:22 --> Severity: Warning --> Missing argument 1 for Branch::edit_branch() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Branch.php 37
ERROR - 2017-11-29 18:20:22 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Branch.php 39
ERROR - 2017-11-29 18:20:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-11-29 18:20:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-11-29 18:20:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-11-29 13:50:23 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-29 13:50:23 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-29 18:20:29 --> Severity: Warning --> Missing argument 1 for Branch::edit_branch() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Branch.php 37
ERROR - 2017-11-29 18:20:29 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Branch.php 39
ERROR - 2017-11-29 18:20:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-11-29 18:20:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-11-29 18:20:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-11-29 13:50:29 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-29 13:50:29 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-29 18:20:35 --> Severity: Warning --> Missing argument 1 for Branch::delete_branch() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Branch.php 57
ERROR - 2017-11-29 18:20:35 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Branch.php 58
