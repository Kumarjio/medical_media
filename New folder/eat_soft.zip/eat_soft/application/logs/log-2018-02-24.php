<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-24 09:42:41 --> Severity: Notice --> Undefined variable: lot_no E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-24 09:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-24 09:42:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:42:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:12:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 04:12:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 09:42:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:13:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 04:13:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 09:43:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:13:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 04:13:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 09:43:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:13:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 04:13:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 09:43:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:13:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 04:13:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 09:43:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:43:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:15:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 04:15:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 09:45:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:45:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:46:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-02-24 09:46:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-02-24 04:16:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-24 04:16:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-02-24 09:46:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:46:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:46:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:46:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:46:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:46:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 04:17:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 04:17:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 09:47:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:47:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 09:47:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 12:26:45 --> Severity: Notice --> Undefined variable: lot_no E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-24 12:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-24 06:56:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 06:56:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 12:26:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 12:26:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 12:26:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 13:29:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 13:29:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 13:29:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 19:45:39 --> Severity: Notice --> Undefined variable: lot_no E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-24 19:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\dashboard.php 81
ERROR - 2018-02-24 14:15:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-24 14:15:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-24 19:45:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 19:45:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 19:45:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-24 19:45:45 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv`
WHERE `lot` = 'null'
AND `storage_name` = '1'
ERROR - 2018-02-24 19:45:45 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519481745
WHERE `lot` = 'null'
AND `storage_name` = '1'
AND `id` = 'a60cb1ff90297a576470f50987d19791e8d68f5c'
ERROR - 2018-02-24 19:45:48 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv`
WHERE `lot` = 'null'
AND `storage_name` = '1'
ERROR - 2018-02-24 19:45:48 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519481748
WHERE `lot` = 'null'
AND `storage_name` = '1'
AND `id` = 'a60cb1ff90297a576470f50987d19791e8d68f5c'
