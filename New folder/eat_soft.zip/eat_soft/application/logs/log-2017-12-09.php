<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-09 05:07:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:07:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:08:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:08:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:16:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:16:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:37:09 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:37:09 --> 404 Page Not Found: Stockreturn/get_stock_details
ERROR - 2017-12-09 05:37:14 --> 404 Page Not Found: Stockreturn/get_stock_details
ERROR - 2017-12-09 05:37:14 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:37:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:37:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:37:52 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:38:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:38:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:38:25 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:38:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:38:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:38:45 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:39:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:39:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:39:27 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:40:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:40:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:41:01 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:42:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:42:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:42:18 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:44:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:44:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:44:25 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 05:46:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:46:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:46:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:46:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:46:53 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-09 10:16:54 --> Severity: Warning --> Missing argument 2 for Returndet::get_stock_details() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 89
ERROR - 2017-12-09 10:16:54 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 90
ERROR - 2017-12-09 10:16:54 --> Severity: Notice --> Undefined variable: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 90
ERROR - 2017-12-09 10:16:54 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 136
ERROR - 2017-12-09 05:49:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:49:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 10:19:07 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 90
ERROR - 2017-12-09 10:19:07 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 136
ERROR - 2017-12-09 05:49:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:49:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:51:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:51:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:51:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:51:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:52:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:52:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:52:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:52:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:58:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 05:58:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:59:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 05:59:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:00:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:00:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:01:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:01:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:01:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:01:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:09:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:09:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:10:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:10:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:10:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:10:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:11:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:11:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:11:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:11:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:11:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:11:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:12:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:12:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:12:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:12:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:14:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:14:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 10:45:45 --> Severity: Notice --> Undefined variable: cnt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 134
ERROR - 2017-12-09 10:45:45 --> Severity: Notice --> Undefined variable: cnt D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 134
ERROR - 2017-12-09 06:15:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:15:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:19:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:19:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:20:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:20:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:25:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:25:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:35:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:35:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:06:39 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 142
ERROR - 2017-12-09 06:36:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:36:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:40:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:40:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:41:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:41:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:11:58 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 91
ERROR - 2017-12-09 06:42:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:42:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:43:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:43:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:45:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:45:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:47:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:47:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:48:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:48:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:48:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:48:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:51:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:51:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:53:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:53:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:58:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 06:58:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 06:58:22 --> 404 Page Not Found: Indexphp/Returndet
ERROR - 2017-12-09 11:28:23 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:28:23 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:28:23 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:28:23 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:28:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 06:59:09 --> 404 Page Not Found: Indexphp/Returndet
ERROR - 2017-12-09 06:59:20 --> 404 Page Not Found: Indexphp/Returndet
ERROR - 2017-12-09 11:29:21 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:29:21 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:29:21 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:29:21 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:29:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 06:59:42 --> 404 Page Not Found: Indexphp/Returndet
ERROR - 2017-12-09 11:29:55 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:29:55 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:29:55 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:29:55 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:29:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:29:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 06:59:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 06:59:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:31:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:01:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:01:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:02:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:02:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 133
ERROR - 2017-12-09 07:02:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:02:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:32:53 --> Severity: Notice --> Undefined variable: search_details D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 133
ERROR - 2017-12-09 11:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 133
ERROR - 2017-12-09 07:02:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:02:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 133
ERROR - 2017-12-09 07:03:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:03:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:34:05 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 133
ERROR - 2017-12-09 07:04:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:04:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:34:36 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:34:36 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:34:36 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:34:36 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:34:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:34:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:04:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:04:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:04:47 --> 404 Page Not Found: Returndet/Returndet
ERROR - 2017-12-09 11:34:48 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:34:48 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:34:48 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:34:48 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:34:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:05:27 --> 404 Page Not Found: Returndet/Returndet
ERROR - 2017-12-09 11:35:41 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:35:41 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:35:41 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:35:41 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:35:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:35:58 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:35:58 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:35:58 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:35:58 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:35:58 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:35:58 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:05:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:05:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:06:07 --> 404 Page Not Found: Returndet/Returndet
ERROR - 2017-12-09 11:36:08 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:36:08 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:36:08 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:36:08 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:36:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:06:43 --> 404 Page Not Found: Returndet/Returndet
ERROR - 2017-12-09 11:36:50 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:36:50 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:36:50 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:36:50 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:36:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:37:05 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:05 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:05 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:05 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:37:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:37:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:07:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:07:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:07:13 --> 404 Page Not Found: Returndet/Returndet
ERROR - 2017-12-09 11:37:14 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:14 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:14 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:14 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:37:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:37:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:38:07 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:38:07 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:38:07 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:38:07 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:38:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:38:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:08:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:08:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:38:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:08:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:08:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:38:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:08:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:08:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:39:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:09:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:09:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:09:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:09:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:09:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:09:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:39:56 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:39:56 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:39:56 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:39:56 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:39:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:39:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:09:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:09:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:10:02 --> 404 Page Not Found: Returndet/Returndet
ERROR - 2017-12-09 11:40:03 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:40:03 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:40:03 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:40:03 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:40:03 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:11:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:11:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:12:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:12:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:13:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:13:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:14:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:14:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:44:29 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:44:29 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:44:29 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:44:29 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:44:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:44:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:14:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:14:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:44:36 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:44:36 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:44:36 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:44:36 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:44:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:44:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:14:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:14:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:45:31 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:15:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:15:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:45:39 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:45:39 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:45:39 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 11:45:39 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 11:45:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:45:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:15:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:15:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:46:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:46:04 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 139
ERROR - 2017-12-09 11:46:04 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 139
ERROR - 2017-12-09 11:46:04 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 139
ERROR - 2017-12-09 11:46:04 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 139
ERROR - 2017-12-09 07:16:05 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:16:05 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:47:43 --> Query error: Unknown column 'tbl_po_inv_item.storage_name' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`storage_name`
WHERE `po_ref_id` IN('1', '2')
ERROR - 2017-12-09 11:47:43 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512800263
WHERE `po_ref_id` IN('1', '2')
AND `id` = 'd66db4be599c34609d89921d1459e0e587aa92c1'
ERROR - 2017-12-09 11:54:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`branch_id`
WHERE `po_ref_id` IN('1', '2')' at line 6 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = 
		` `
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = $`branch_id`
WHERE `po_ref_id` IN('1', '2')
ERROR - 2017-12-09 11:54:53 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512800693
WHERE `po_ref_id` IN('1', '2')
AND `id` = 'd66db4be599c34609d89921d1459e0e587aa92c1'
ERROR - 2017-12-09 11:55:19 --> Query error: Unknown column ' ' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = 
		` `
JOIN `tbl_branch` ON `tbl_branch`.`branch_id`
WHERE `po_ref_id` IN('1', '2')
ERROR - 2017-12-09 11:55:19 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512800719
WHERE `po_ref_id` IN('1', '2')
AND `id` = 'd66db4be599c34609d89921d1459e0e587aa92c1'
ERROR - 2017-12-09 11:58:16 --> Query error: Unknown column ' ' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = 
		` `
WHERE `po_ref_id` IN('1', '2')
ERROR - 2017-12-09 11:58:16 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512800896
WHERE `po_ref_id` IN('1', '2')
AND `id` = 'd66db4be599c34609d89921d1459e0e587aa92c1'
ERROR - 2017-12-09 11:58:31 --> Query error: Unknown column ' ' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = 
		` `
WHERE `po_ref_id` IN('1', '2')
ERROR - 2017-12-09 11:58:31 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512800911
WHERE `po_ref_id` IN('1', '2')
AND `id` = 'd66db4be599c34609d89921d1459e0e587aa92c1'
ERROR - 2017-12-09 07:31:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:31:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:31:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:31:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:31:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:31:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:33:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:33:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:33:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:33:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:36:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:36:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:36:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:36:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:38:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:38:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:38:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:38:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 12:09:51 --> Severity: Notice --> Undefined variable: rate D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 117
ERROR - 2017-12-09 12:09:51 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 133
ERROR - 2017-12-09 12:09:51 --> Query error: Column 'unit_ref_id' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `pro_ref_id`, `brand_ref_id`, `size_ref_id`, `unit_ref_id`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`) VALUES (2, '6', '1', '5', NULL, '12', '100', '1200', '0', '0', '0', '0', '0', '0')
ERROR - 2017-12-09 07:41:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:41:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:11:41 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:11:41 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:11:41 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:11:41 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 07:42:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:42:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:42:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:42:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:42:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 07:42:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:42:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:42:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 12:14:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 133
ERROR - 2017-12-09 12:14:04 --> Query error: Column 'unit_ref_id' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `pro_ref_id`, `branch_ref_id`, `size_ref_id`, `unit_ref_id`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`) VALUES (1, '5', '1', '4', NULL, '12', '100', '1200', '0', '0', '0', '0', '0', '0')
ERROR - 2017-12-09 12:14:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 133
ERROR - 2017-12-09 12:14:48 --> Query error: Column 'unit_ref_id' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `pro_ref_id`, `branch_ref_id`, `size_ref_id`, `unit_ref_id`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`) VALUES (2, '5', '1', '4', NULL, '12', '100', '1200', '0', '0', '0', '0', '0', '0')
ERROR - 2017-12-09 07:45:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:45:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:47:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:47:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:47:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:47:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 12:18:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 133
ERROR - 2017-12-09 12:18:28 --> Query error: Column 'unit_ref_id' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `pro_ref_id`, `branch_ref_id`, `size_ref_id`, `unit_ref_id`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`) VALUES (2, '8', '1', '6', NULL, '21212', '12121', '257110652', '0', '0', '0', '0', '0', '0')
ERROR - 2017-12-09 07:49:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:49:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 07:50:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 07:50:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:20:51 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:20:51 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:20:51 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:20:51 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 12:21:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:51:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:51:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:23:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_r' at line 2 - Invalid query: SELECT *
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
WHERE `po_ref_id` IN('1', '2')
ERROR - 2017-12-09 12:23:59 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512802439
WHERE `po_ref_id` IN('1', '2')
AND `id` = 'bd79a2d6d44795b1e45d61126b99378163449288'
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:15 --> Severity: Notice --> Undefined index: lot D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 07:58:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:58:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 12:28:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2017-12-09 07:58:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:58:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:28:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:58:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:58:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:29:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 07:59:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 07:59:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:31:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:01:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:01:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:32:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:02:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:02:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:33:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:03:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:03:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:33:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:03:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:03:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:05:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 08:05:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 08:05:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 08:05:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:35:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:35:48 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:35:48 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:35:48 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:35:48 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 12:35:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:05:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:05:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:39:43 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:09:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:09:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 137
ERROR - 2017-12-09 12:43:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:45:50 --> Severity: Parsing Error --> syntax error, unexpected 'search_details' (T_STRING) D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:46:30 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:46:52 --> Severity: Warning --> Illegal string offset 'details' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:46:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:46:52 --> Severity: Warning --> Illegal string offset 'details' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:46:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:16:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 08:16:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:47:06 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:47:06 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:47:06 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:47:06 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 135
ERROR - 2017-12-09 12:47:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:47:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:17:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:17:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 135
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:47:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 135
ERROR - 2017-12-09 12:47:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:47:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:17:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:17:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:48:21 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 135
ERROR - 2017-12-09 12:48:36 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 135
ERROR - 2017-12-09 12:48:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:48:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:18:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:18:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:49:38 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 139
ERROR - 2017-12-09 12:49:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:50:07 --> Severity: Warning --> Illegal string offset 'details' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:50:07 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:50:07 --> Severity: Warning --> Illegal string offset 'details' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:50:07 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:20:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:20:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:50:14 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:50:14 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:50:14 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:50:14 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 138
ERROR - 2017-12-09 12:50:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:50:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:20:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:20:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 138
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Returndet_model.php 138
ERROR - 2017-12-09 12:50:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:53:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:23:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:23:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:53:58 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:53:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:23:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:23:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:54:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:24:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:24:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:54:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:24:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:24:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:55:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:26:00 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:26:00 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:56:08 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:56:08 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:56:08 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:56:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:56:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:56:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:56:08 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:26:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:26:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:56:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:56:28 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:26:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:26:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:56:32 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:56:32 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:56:32 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:56:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:56:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:56:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:56:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 08:26:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:26:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:56:57 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:57:03 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 136
ERROR - 2017-12-09 12:57:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:27:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:27:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:57:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:57:19 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:19 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:19 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:27:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:27:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:57:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:57:26 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:26 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:26 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:27:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:27:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:57:29 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:29 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:29 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:57:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:27:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:27:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:57:42 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:42 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:42 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 12:57:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:57:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:27:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:27:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:03:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:33:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:33:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:22 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 08:33:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:33:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 13:03:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 144
ERROR - 2017-12-09 08:33:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:33:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:05:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:35:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:35:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:07:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:37:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:37:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:08:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:38:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:38:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:11:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:41:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:41:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:12:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:42:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:42:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:14:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 08:44:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 08:44:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:51:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:21:55 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:21:55 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:22:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 09:22:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 09:22:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 09:22:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 09:22:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 09:22:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 09:22:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 09:22:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 09:22:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 09:22:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 09:23:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 09:23:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:53:20 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 13:53:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 13:53:20 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 13:53:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 13:53:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:23:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:23:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:58:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:28:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:28:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:58:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:28:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:28:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:58:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:28:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:28:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:58:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:28:40 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:28:40 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:59:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:29:05 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:29:05 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:00:10 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:00:10 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:10 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:10 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:10 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:30:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:30:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:00:15 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:15 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:15 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:00:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:30:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:30:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:00:20 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:20 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:00:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:00:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:30:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:30:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:01:25 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:01:25 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:01:25 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:01:25 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:01:25 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:31:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:31:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:02:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:32:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:32:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:05:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:35:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:35:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:11:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:41:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:41:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:11:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:41:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:41:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:12:10 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:42:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:42:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:13:37 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:43:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:43:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:13:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:43:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:43:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:14:58 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:44:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:44:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:15:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:45:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:45:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:15:37 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:45:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:45:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:18:31 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:48:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:48:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:19:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:49:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:49:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 14:19:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:49:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:49:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:20:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:20:02 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:20:02 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:20:02 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 92
ERROR - 2017-12-09 14:20:02 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 14:20:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 14:20:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 09:50:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:50:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:20:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:50:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:50:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:21:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:51:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:51:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:26:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:56:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:56:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:26:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:56:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:56:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:28:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:58:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:58:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:28:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 09:58:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 09:58:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:30:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:00:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:00:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:48:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:18:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:18:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:49:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:19:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:19:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:49:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:19:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:19:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:55:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:25:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:25:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:57:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:27:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:27:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:58:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:28:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:28:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:02:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:32:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:32:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:03:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:33:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:33:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:08:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:38:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:38:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:08:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:38:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:38:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:09:11 --> Severity: Warning --> Missing argument 2 for Returndet::update_return_details() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 96
ERROR - 2017-12-09 15:09:11 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 97
ERROR - 2017-12-09 15:09:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:39:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:39:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:09:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:39:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:39:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:09:41 --> Severity: Warning --> Missing argument 2 for Returndet::update_return_details() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 96
ERROR - 2017-12-09 15:09:41 --> Severity: Notice --> Undefined variable: return_qty D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 97
ERROR - 2017-12-09 15:10:31 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:40:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:40:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:12:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:42:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:42:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:13:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:43:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:43:58 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:15:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:45:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:45:15 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:15:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:45:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:45:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:16:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:46:17 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:46:17 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:16:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:46:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:46:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:17:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:47:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:47:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:17:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:47:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:47:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:18:02 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:48:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:48:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:18:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:48:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:48:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:18:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:48:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:48:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:19:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:49:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:49:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:19:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:49:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:49:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:20:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:50:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:50:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:21:02 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:51:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:51:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:21:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:51:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:51:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:22:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:52:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:52:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:22:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:52:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:52:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:28:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:58:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:58:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:28:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:58:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:58:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:28:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:58:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:58:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:28:47 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:58:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:58:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:29:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:59:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:59:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:29:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:59:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:59:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:29:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 10:59:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 10:59:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:30:31 --> Severity: Warning --> Illegal string offset 'supplier' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Warning --> Illegal string offset 'vendor_name' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Warning --> Illegal string offset 'branch' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Warning --> Illegal string offset 'branch_name' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Warning --> Illegal string offset 'lot' D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 15:30:31 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2017-12-09 11:00:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:00:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:03:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:03:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 15:34:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:04:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:04:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 15:34:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 11:04:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:04:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 11:04:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:04:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:04:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:04:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:05:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 11:05:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 11:05:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:05:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:05:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:05:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:05:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:05:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:06:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:06:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:06:45 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-09 11:06:45 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-09 11:06:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:06:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:06:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:06:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:07:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:07:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:13:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:13:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:13:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:13:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:13:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:13:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:15:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:15:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 15:45:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 11:16:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:16:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 15:46:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-09 15:49:49 --> You did not select a file to upload.
ERROR - 2017-12-09 11:19:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:19:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 15:49:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 15:49:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 15:49:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 15:49:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 15:49:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 15:49:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-09 15:49:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 15:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 15:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 15:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 15:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 15:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-09 11:20:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:20:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:23:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:23:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 15:57:43 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 62
ERROR - 2017-12-09 15:57:43 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 64
ERROR - 2017-12-09 15:57:43 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 64
ERROR - 2017-12-09 15:57:43 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 64
ERROR - 2017-12-09 15:57:43 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\product_add.php 64
ERROR - 2017-12-09 11:27:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:27:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:29:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:29:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:30:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:30:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:30:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:30:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:30:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:30:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:32:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:32:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:35:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:35:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:36:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:36:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 11:37:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:37:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:39:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:39:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:11:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 59
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:12:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 38
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 45
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 52
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 61
ERROR - 2017-12-09 16:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 74
ERROR - 2017-12-09 11:45:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 11:45:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 11:45:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 11:45:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 11:45:40 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 11:45:40 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:09:34 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:09:34 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:13:41 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:13:41 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:14:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:14:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:15:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:15:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:16:51 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:16:51 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:17:30 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:17:30 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:18:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:18:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:18:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:18:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:19:15 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:19:15 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:19:40 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:19:40 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:20:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:20:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:20:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:20:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:20:35 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:20:35 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:21:40 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:21:40 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:22:49 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:22:49 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:23:08 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:23:08 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:23:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:23:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:25:00 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:25:00 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:25:32 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:25:32 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:25:45 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:25:45 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:29:52 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:29:52 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:30:11 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:30:11 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:30:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:30:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:31:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:31:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:31:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:31:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:31:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:31:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:32:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:32:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:34:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:34:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 17:04:25 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-09 12:34:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:34:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:34:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:34:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:35:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:35:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:36:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:36:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:36:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:36:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:37:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:37:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:37:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 12:37:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 12:38:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:38:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:38:41 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-09 12:38:41 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-09 12:38:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:38:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:38:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:38:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:39:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 12:39:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 12:39:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:39:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:39:25 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:39:25 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-09 12:41:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:41:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 12:57:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 12:57:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 17:27:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 12:57:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:57:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 17:28:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 12:58:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 12:58:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 13:06:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:06:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:07:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:07:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:08:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:08:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:08:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:08:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:10:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:10:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:10:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:10:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:11:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:11:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:12:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:12:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:15:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:15:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:15:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 13:15:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 13:15:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:15:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:21:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:21:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:21:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 13:21:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 13:50:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:50:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:51:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 13:51:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 13:51:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 13:51:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 14:02:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 14:02:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 14:02:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 14:02:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 14:02:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 14:02:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 18:32:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-09 14:02:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:02:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-09 14:05:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 14:05:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 14:05:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 14:05:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-09 14:10:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-09 14:10:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-09 14:10:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-09 14:10:26 --> 404 Page Not Found: Goodsreceived/audio
