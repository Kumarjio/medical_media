<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-24 05:49:03 --> 404 Page Not Found: Audio/fail.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-24 05:49:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:49:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:49:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 05:49:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-24 05:49:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-24 05:50:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 05:50:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:50:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 05:50:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:50:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 05:50:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 05:51:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:51:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 05:51:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:51:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 49
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 58
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 65
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 73
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 85
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 85
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 114
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-01-24 11:21:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 144
ERROR - 2018-01-24 05:51:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 05:51:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 05:51:40 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 05:51:40 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 05:52:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:52:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 05:57:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-24 05:57:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-24 05:57:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 05:57:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 06:02:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 06:02:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 08:21:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 08:21:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 08:21:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 08:21:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 08:21:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 08:21:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 08:21:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 08:21:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 08:23:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 08:23:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 09:47:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 09:47:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 09:48:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 09:48:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 09:48:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 09:48:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 09:48:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 09:48:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 10:14:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 10:14:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 10:30:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 10:30:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 10:30:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:30:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:31:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:31:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:32:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 10:32:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 10:32:48 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:32:48 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:34:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:34:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:35:39 --> 404 Page Not Found: Barcode/set_barcode
ERROR - 2018-01-24 10:35:39 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:35:39 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:57:23 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:57:23 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-24 10:57:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 10:57:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 10:57:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 10:57:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 10:57:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:57:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:58:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:58:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:58:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:58:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:58:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:58:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:59:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 10:59:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-24 11:00:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:00:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:32:09 --> Severity: Compile Error --> Cannot redeclare random_string() (previously declared in E:\wamp\www\duty\mathewgarments\application\views\retail_add.php:48) E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 331
ERROR - 2018-01-24 11:02:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:02:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:33:37 --> Severity: Compile Error --> Cannot redeclare random_string() (previously declared in E:\wamp\www\duty\mathewgarments\application\views\retail_add.php:48) E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 313
ERROR - 2018-01-24 11:03:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:03:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:04:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:04:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:04:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:04:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:05:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:05:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:06:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:06:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:07:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:07:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:07:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:07:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:08:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:08:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:08:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:08:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:09:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:09:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:39:55 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:39:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:10:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:10:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:10:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:10:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:10:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:10:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:10:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:10:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:10:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:10:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:40:24 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:45 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:47 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:40:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:40:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:18 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:41:30 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:41:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:41:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:41:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:41:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:41:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:41:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:11:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:11:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:11:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:11:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:41:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:41:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:16 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:42:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:42:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:42:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:42:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:42:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:42:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:12:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:12:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:12:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:12:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:42:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:34 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:42:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:42:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:42:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:42:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:42:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:42:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:12:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:12:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:12:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:12:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:42:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:42:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:42:53 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:42:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:42:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:12:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:12:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:12:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:12:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:43:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:43:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:43:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:43:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:43:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:43:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:43:14 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:43:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:13:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:13:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:43:17 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:43:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:43:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:43:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:43:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:43:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:43:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:13:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:13:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:14:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:14:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:44:30 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:44:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:44:33 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:44:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:44:36 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:44:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:44:45 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:44:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:15:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:15:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:45:28 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:45:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:45:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:45:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:15:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:15:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:16:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:16:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:46:30 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:46:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:46:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:46:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:46:34 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:46:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:46:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:16:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:16:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:46:37 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:46:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:46:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:46:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:46:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:46:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:46:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:16:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:16:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:46:37 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:46:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:46:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:46:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:46:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:46:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:46:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:16:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:16:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:18:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:18:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:48:50 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:48:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:48:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:48:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:19:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:19:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:19:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:19:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:19:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:19:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:50:01 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:50:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:50:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:50:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:20:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:20:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:50:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:50:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:20:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:20:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:50:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:50:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:20:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:20:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:50:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:50:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:20:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:20:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:21:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:21:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:21:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:21:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:21:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:21:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:51:52 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:51:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:51:53 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:51:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:51:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:51:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:22:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:22:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:52:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:52:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:22:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:22:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:52:47 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:52:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:52:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:52:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:52:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:52:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:52:53 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:52:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:52:54 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:52:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:56:05 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:56:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:26:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:26:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 16:56:08 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 16:56:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 16:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 16:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 16:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 16:56:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 11:26:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:26:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:27:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:27:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:28:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:28:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:28:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:28:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:28:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:28:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:58:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:58:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 16:58:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:58:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:28:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:28:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 16:59:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 16:59:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 11:29:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:29:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:29:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:29:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:30:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:30:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:30:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:30:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:31:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:31:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:32:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:32:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:32:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:32:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:33:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:33:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:33:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:33:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:34:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:34:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:34:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:34:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:34:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:34:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:35:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:35:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:35:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:35:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:35:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:35:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:35:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:36:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:36:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:36:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:36:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:36:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:36:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:36:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:36:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:36:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:36:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:36:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:36:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:37:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:37:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 11:38:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 11:38:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 17:38:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:38:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:38:13 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:38:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:38:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:38:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:38:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:38:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:38:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 12:08:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:08:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:08:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:08:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:09:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:09:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:10:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:10:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:10:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:10:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:10:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:10:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:10:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:10:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:11:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:11:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:12:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:12:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:13:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:13:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:14:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:14:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:15:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:15:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:16:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:16:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:16:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:16:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 17:47:47 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:47:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:47:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:47:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:47:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:47:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:47:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:47:49 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:47:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 12:17:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:17:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 17:48:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:48:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:48:10 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:48:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:48:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:48:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:48:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:48:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:48:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:48:16 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:48:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 12:18:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:18:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 17:48:22 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:48:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:48:25 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:48:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:48:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:48:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:48:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:48:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:48:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 12:24:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:24:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 17:55:26 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:55:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:55:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:55:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:55:51 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:55:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 12:25:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:25:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:26:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:26:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 17:56:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:56:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:56:16 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:56:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 12:27:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:27:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:27:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:27:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 17:57:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:57:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 12:27:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:27:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 17:57:59 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:57:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 12:28:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:28:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 17:58:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:58:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:58:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:58:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:58:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-24 17:58:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-24 17:58:21 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 17:58:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 17:58:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:58:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 17:58:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 17:58:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 17:58:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 12:28:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:28:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:29:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:29:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:30:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:30:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:30:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:30:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:30:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:30:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:30:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:30:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:31:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:31:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:32:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:32:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:32:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:32:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:41:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:41:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:41:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:41:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:44:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:44:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:44:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:44:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:45:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:45:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:45:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:45:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:45:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:45:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:45:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:45:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:46:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:46:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:49:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:49:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:50:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:50:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:55:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:55:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:55:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:55:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:56:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 12:56:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:58:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 12:58:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:00:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:00:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:02:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:02:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:32:24 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:32:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:32:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:32:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:32:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:32:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:32:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:32:25 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:32:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:32:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:02:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:02:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:36:48 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:36:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:36:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:36:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:36:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:36:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:36:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:36:49 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:36:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:36:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:36:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:36:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:36:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:36:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:06:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:06:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:06:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:06:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:06:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:06:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:37:20 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:37:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:37:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:37:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:37:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:37:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:37:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:37:23 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:37:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:37:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:37:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:37:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:37:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:37:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:07:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:07:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:07:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:07:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:08:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:08:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 18:38:53 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:38:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:38:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:38:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:38:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:38:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:38:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:38:54 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:38:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:38:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:38:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:38:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:38:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:38:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:08:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:08:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:09:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:09:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:41:04 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:41:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:06 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:41:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:41:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:41:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:41:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:41:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:41:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:09 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:41:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:41:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:41:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:41:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:41:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:11:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:11:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:42:27 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:42:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:42:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:42:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:28 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:28 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:29 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:42:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:42:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:42:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:42:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:42:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:12:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:12:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:17:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:17:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:17:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:17:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:47:53 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:47:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:47:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:47:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:47:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:47:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:47:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:47:54 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:47:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:47:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:47:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:47:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:47:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:47:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:17:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:17:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:19:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:19:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 18:50:06 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:50:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:50:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:50:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:50:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:50:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:50:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:50:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:50:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:50:11 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:50:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:20:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:20:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:20:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:20:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:24:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:24:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 18:54:49 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:54:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:54:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:54:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:54:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:54:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:54:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:24:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:24:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:24:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:24:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 18:55:08 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:55:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:55:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:55:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:09 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:09 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:25:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:25:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 18:55:23 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:23 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:24 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:55:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:55:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:55:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:55:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:55:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:25:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:25:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:26:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:26:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 18:56:23 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:23 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:26 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:56:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:26:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:26:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:26:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:26:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 18:56:36 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:56:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:37 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 18:56:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 18:56:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 18:56:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 18:56:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 18:56:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:26:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:26:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:27:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:27:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:45:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:45:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 19:16:01 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 19:16:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 19:16:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 19:16:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:02 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:02 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:03 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-24 19:16:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-24 19:16:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-24 19:16:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-24 19:16:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 19:16:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-24 13:46:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:46:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:48:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:48:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:48:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:48:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:50:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:50:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:51:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:51:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:51:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:51:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:52:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:52:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:52:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:52:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:53:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:53:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:54:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:54:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:57:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-24 13:57:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:58:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-24 13:58:19 --> 404 Page Not Found: Audio/alert.mp3
