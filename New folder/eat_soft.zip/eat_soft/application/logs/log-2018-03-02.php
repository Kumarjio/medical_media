<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-02 10:09:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2018-03-02 10:09:55 --> Unable to connect to the database
ERROR - 2018-03-02 04:40:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:40:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:10:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:10:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:10:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:50:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:20:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:50:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:20:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:50:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:20:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:50:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:20:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:50:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 14
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 24
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\productcreation_edit.php 38
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:20:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:50:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:50:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:20:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2018-03-02 10:20:58 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2018-03-02 10:20:58 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2018-03-02 10:20:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\brand_edit.php 14
ERROR - 2018-03-02 10:20:58 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\brand_edit.php 24
ERROR - 2018-03-02 10:20:58 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\brand_edit.php 38
ERROR - 2018-03-02 10:21:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:51:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:51:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:21:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2018-03-02 10:21:04 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2018-03-02 10:21:04 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2018-03-02 10:21:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\material_edit.php 14
ERROR - 2018-03-02 10:21:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\material_edit.php 24
ERROR - 2018-03-02 10:21:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\material_edit.php 38
ERROR - 2018-03-02 10:21:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:51:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:51:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:51:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:51:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 14
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 24
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 38
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 14
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 24
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\color_edit.php 38
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:51:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:51:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:51:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:51:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:51:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 04:51:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 10:21:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:51:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:51:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:52:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:52:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:52:34 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 04:52:34 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-03-02 10:22:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2018-03-02 04:52:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:52:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:22:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:23:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:23:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:23:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 04:53:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 10:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:55:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:55:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:25:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:25:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:25:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:55:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:55:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:25:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:25:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:25:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:58:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 04:58:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:28:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:28:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:28:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 04:58:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 04:58:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:28:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:28:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:28:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:45:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 05:45:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:47:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 05:47:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:17:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:17:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:17:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:47:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 05:47:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:17:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:17:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:17:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:51:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 05:51:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:51:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 05:51:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:21:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:51:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 05:51:48 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 11:21:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:57:22 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 05:57:22 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 11:27:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:27:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:27:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 05:58:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 05:58:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:28:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:28:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:28:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 06:03:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 06:03:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Undefined variable: customer E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:33:31 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:33:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 57
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 65
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 77
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 84
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 91
ERROR - 2018-03-02 11:34:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:34:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:34:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:35:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:35:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:35:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:36:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:36:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:36:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:36:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:36:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 101
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 101
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 110
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 110
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 101
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 101
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 110
ERROR - 2018-03-02 11:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 110
ERROR - 2018-03-02 11:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:17:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:24:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:24:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:24:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:24:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 06:55:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 06:55:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 71
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 72
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 73
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 74
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 75
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 76
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 77
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 78
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 79
ERROR - 2018-03-02 12:26:08 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 80
ERROR - 2018-03-02 06:56:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 06:56:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:26:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:26:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:26:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 06:57:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 06:57:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:27:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:27:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:27:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:27:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:28:18 --> Severity: Notice --> Undefined variable: dist E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 78
ERROR - 2018-03-02 06:58:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 06:58:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:28:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:28:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:28:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:04 --> Severity: Notice --> Undefined variable: dist E:\wamp\www\duty\mathewgarments\application\models\Vendor_model.php 78
ERROR - 2018-03-02 06:59:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 06:59:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:29:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:29:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:03:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 07:03:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:33:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 26
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 37
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 44
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 51
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 58
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 79
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 86
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 93
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 100
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\vendor_edit.php 107
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:03:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 07:03:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:33:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:03:55 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 07:03:55 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 12:33:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:39:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:39:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:39:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:12:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 07:12:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:42:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:42:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:42:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:14:56 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 07:14:56 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-03-02 12:44:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:44:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:52:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 55
ERROR - 2018-03-02 07:22:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 07:22:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:52:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:52:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:52:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:22:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 07:22:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:52:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:52:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:52:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:25:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 07:25:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:55:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-03-02 07:25:06 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 07:25:06 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 12:55:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:55:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:55:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:56:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-03-02 07:26:56 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 07:26:56 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 12:56:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:56:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:56:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:28:42 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\controllers\Customer.php 32
ERROR - 2018-03-02 07:28:48 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\controllers\Customer.php 32
ERROR - 2018-03-02 12:58:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:58:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:58:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:58:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:58:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:58:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:29:04 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\controllers\Customer.php 32
ERROR - 2018-03-02 12:59:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:29:14 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 07:29:14 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 12:59:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:59:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 07:30:29 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 07:30:29 --> 404 Page Not Found: Customer/audio
ERROR - 2018-03-02 13:00:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:00:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:00:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 61
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 62
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_mobile E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 63
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_email E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 64
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_area E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 65
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_city E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 66
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_dist E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 67
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_state E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 68
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_pincode E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 69
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 70
ERROR - 2018-03-02 13:07:10 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 72
ERROR - 2018-03-02 07:37:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 07:37:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:07:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:07:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:07:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:35:19 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 68
ERROR - 2018-03-02 14:35:19 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\customerlist.php 70
ERROR - 2018-03-02 09:05:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:05:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:35:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:35:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:35:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:05:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:05:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:35:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:35:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:35:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:06:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:06:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:36:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:36:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:36:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_mobile E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 44
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_email E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 51
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_gstin E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 58
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_type E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 66
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_type E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 66
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_area E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 79
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_city E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 86
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_pincode E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 93
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_state E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 100
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined index: vendor_dist E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 107
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 44
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 51
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 58
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 66
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 66
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 79
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 86
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 93
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 100
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 107
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 44
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 51
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 58
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 66
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 66
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 79
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 86
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 93
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 100
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 107
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:37:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined index: customer_type E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined index: vendor_type E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:40:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:40:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:40:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:40:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:41:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:41:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:42:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:14:03 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\controllers\Customer.php 58
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:44:14 --> Query error: Unknown column 'customer_name' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `customer_name` = 'cusrtomer 1', `customer_mobile` = '8124498572', `customer_area` = 'Kamraj Street', `customer_city` = 'Kandamangalam', `customer_pincode` = '605102', `customer_email` = 'musthakcse@gmail.com', `customer_state` = 'Tamil Nadu', `customer_dist` = 'Villupuram1', `customer_gstin` = '789456123', `customer_tax` = '2'
WHERE `vendor_id` = '1'
ERROR - 2018-03-02 14:44:38 --> Query error: Unknown column 'customer_name' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `customer_name` = 'cusrtomer 1', `customer_mobile` = '8124498572', `customer_area` = 'Kamraj Street', `customer_city` = 'Kandamangalam', `customer_pincode` = '605102', `customer_email` = 'musthakcse@gmail.com', `customer_state` = 'Tamil Nadu', `customer_dist` = 'Villupuram1', `customer_gstin` = '789456123', `customer_tax` = '2'
WHERE `vendor_id` = '1'
ERROR - 2018-03-02 09:15:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:15:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:45:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:15:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:45:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:15:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:45:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 26
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 37
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 43
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 50
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 57
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 65
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 78
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 85
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 92
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 99
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\customeredit.php 106
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:15:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:45:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:15:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:45:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:15:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:15:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:45:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:15:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:15:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:15:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:45:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:45:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:16:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:16:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:46:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:46:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:46:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:46:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:46:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:46:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:17:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:47:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:17:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:17:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:17:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:47:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 20
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 40
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 46
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 53
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 59
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_view.php 67
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:18:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:18:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:48:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:48:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:19:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:49:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:19:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:49:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:19:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:49:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:19:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:49:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:19:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:49:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:19:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:49:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:19:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:19:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:20:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:20:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:20:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:20:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:50:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:20:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:20:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:50:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:20:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:20:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:50:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:20:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:20:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:50:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:20:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:20:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:50:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:50:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:21:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:21:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:21:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:21:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:51:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:51:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:51:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:21:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:21:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:21:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:21:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:22:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:22:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:22:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:22:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:22:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 09:22:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 14:52:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:22:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 09:22:45 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 09:22:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:22:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:22:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:22:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:52:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:22:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:22:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:52:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:52:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:23:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:23:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:53:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:23:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:23:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:23:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:23:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:53:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:23:07 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 09:23:07 --> 404 Page Not Found: Product/audio
ERROR - 2018-03-02 14:53:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:23:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:23:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:53:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:23:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:23:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 14:53:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:53:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:25:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:25:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 14:55:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:55:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:55:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:25:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:25:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 14:55:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:55:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:55:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:26:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:26:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 14:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:43:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:43:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:13:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:43:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:43:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:13:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:43:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:43:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:43:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:43:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:13:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:13:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:44:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:44:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:14:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:14:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:14:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:44:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:44:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:14:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:14:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:14:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:12 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `cus_location`, `invoice`, `dcno`, `pdate`, `storage_name`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `grn_date`, `allqty`) VALUES ('1', 'Chennai-Tamil Nadu', '1', '1', '2018-03-02', '1', '1', '9,500.00', '9,975.00', '237.50', '237.50', '0.00', '2018-03-02', '38')
ERROR - 2018-03-02 15:15:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:45:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:45:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:46:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-03-02 09:46:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-03-02 09:46:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:46:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:16:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:16:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:16:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:47:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-03-02 09:47:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-03-02 09:47:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:47:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:17:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:17:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:17:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:47:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:47:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:17:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:17:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:17:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:47:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:47:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:18:41 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `cus_location`, `invoice`, `dcno`, `pdate`, `storage_name`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `grn_date`, `allqty`) VALUES ('1', 'Chennai-Tamil Nadu', '1', '1', '2018-03-02', '1', '1', '9,500.00', '9,975.00', '237.50', '237.50', '0.00', '2018-03-02', '38')
ERROR - 2018-03-02 15:19:13 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `cus_location`, `invoice`, `dcno`, `pdate`, `storage_name`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `grn_date`, `allqty`) VALUES ('1', 'Chennai-Tamil Nadu', '1', '1', '2018-03-02', '1', '1', '9,500.00', '9,975.00', '237.50', '237.50', '0.00', '2018-03-02', '38')
ERROR - 2018-03-02 15:19:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:19:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:50:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:50:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:20:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:20:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:20:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:50:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:50:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:20:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:20:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:20:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:21:37 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `cus_location`, `invoice`, `dcno`, `pdate`, `storage_name`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `grn_date`, `allqty`) VALUES ('1', 'Chennai-Tamil Nadu', '1', '1', '2018-03-02', '1', '1', '9,500.00', '9,975.00', '237.50', '237.50', '0.00', '2018-03-02', '38')
ERROR - 2018-03-02 15:23:21 --> Query error: Data truncated for column 'total' at row 1 - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `lot_pl`, `wholesale_amt`, `r_rate`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '1', '1', '2', '6211', '1', 'g100', '450', '500', '19', '250', '1', '4,987.50', '2.50', '2.50', '0.00', '118.75', '118.75', '0.00', 1)
ERROR - 2018-03-02 15:24:26 --> Query error: Data truncated for column 'total' at row 1 - Invalid query: INSERT INTO `tbl_grn` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `lot_pl`, `wholesale_amt`, `r_rate`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (2, '1', '1', '2', '6211', '1', 'g100', '450', '500', '19', '250', '1', '4,987.50', '2.50', '2.50', '0.00', '118.75', '118.75', '0.00', 1)
ERROR - 2018-03-02 09:56:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-03-02 09:56:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-03-02 09:56:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:56:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:26:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:26:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:26:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:56:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 09:56:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:26:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:56:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:56:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:26:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:26:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:26:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:57:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 09:57:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 15:27:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:27:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:27:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 09:58:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 09:58:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:28:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:03:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:03:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:34:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:04:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:04:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:34:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:10 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 15:34:10 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 15:34:10 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 15:34:10 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 10:04:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 10:04:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 15:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:09:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:09:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:39:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:20:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:20:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:21:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:51:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:51:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:51:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:21:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:21:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:51:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:51:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:51:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:22:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:22:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:52:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:52:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:52:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:23:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:23:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 15:53:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:53:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:53:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:28:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:28:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:29:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:29:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 15:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 15:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:30:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:30:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 16:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:00:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:34:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:34:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 16:04:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:04:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:04:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:58:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:28:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 16:28:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:58:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:28:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:58:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 16:28:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:58:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:28:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 10:58:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 16:28:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 10:58:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 10:58:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:28:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 10:58:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 10:58:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:28:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:41:55 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:41:55 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:41:55 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:41:55 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:11:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:11:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:42:31 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:42:31 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:42:31 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:42:31 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:12:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:12:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:42:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:42:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:42:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:42:53 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 800
ERROR - 2018-03-02 16:42:53 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 807
ERROR - 2018-03-02 16:42:53 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 808
ERROR - 2018-03-02 11:12:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:12:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:42:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:42:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:42:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:20:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:20:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:50:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:50:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:50:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:20:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:20:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:50:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:21:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:21:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:51:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:51:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:51:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:51:56 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:51:56 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:51:56 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:51:56 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:21:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:21:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:51:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:51:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:51:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:03 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 800
ERROR - 2018-03-02 16:52:03 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 807
ERROR - 2018-03-02 16:52:03 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 808
ERROR - 2018-03-02 11:22:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:22:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:52:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:10 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:52:10 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:52:10 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:52:10 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:22:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:22:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:52:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:40 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 800
ERROR - 2018-03-02 16:52:40 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 807
ERROR - 2018-03-02 16:52:40 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 808
ERROR - 2018-03-02 16:52:40 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_return` (`supplier_ref_id`, `cus_location`, `invoice`, `dcno`, `pdate`, `storage_name`, `lot`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `lot_placed`, `purchase_mode`, `grn_date`) VALUES ('1', 'Chennai-Tamil Nadu', '1', '1', '2018-03-02', '1', NULL, '1', '8,500.00', '8,925.00', '212.50', '212.50', '0.00', '', NULL, '2018-03-02')
ERROR - 2018-03-02 16:52:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:52:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:53:02 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 800
ERROR - 2018-03-02 16:53:02 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 807
ERROR - 2018-03-02 16:53:02 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 808
ERROR - 2018-03-02 16:53:02 --> Query error: Data truncated for column 'stotal' at row 1 - Invalid query: INSERT INTO `tbl_po_return` (`supplier_ref_id`, `cus_location`, `invoice`, `dcno`, `pdate`, `storage_name`, `lot`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `lot_placed`, `purchase_mode`, `grn_date`) VALUES ('1', 'Chennai-Tamil Nadu', '1', '1', '2018-03-02', '1', NULL, '1', '1,000.00', '1,050.00', '25.00', '25.00', '0.00', '', NULL, '2018-03-02')
ERROR - 2018-03-02 16:55:05 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 800
ERROR - 2018-03-02 16:55:05 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 807
ERROR - 2018-03-02 16:55:05 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 808
ERROR - 2018-03-02 11:25:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:25:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:55:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:25:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:25:14 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:25:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:25:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 16:55:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:25:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:25:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 16:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 16:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:32:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:32:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 17:02:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:02:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:02:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:32:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:32:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 17:02:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:02:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:02:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:32:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 11:32:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 11:33:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:03:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:33:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:33:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 17:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:46 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:03:46 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:03:46 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:03:46 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:33:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:33:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:03:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:03:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:04:33 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:04:33 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:04:33 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:04:33 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:34:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:34:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:04:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:04:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:04:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:06:34 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:06:34 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:06:34 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:06:34 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:36:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:36:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:06:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:06:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:06:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:08:05 --> Severity: Notice --> Undefined variable: lot E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 800
ERROR - 2018-03-02 17:08:05 --> Severity: Notice --> Undefined variable: lot_placed E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 807
ERROR - 2018-03-02 17:08:05 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 808
ERROR - 2018-03-02 17:08:05 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 854
ERROR - 2018-03-02 17:08:05 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 854
ERROR - 2018-03-02 17:08:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\helpers\url_helper.php 561
ERROR - 2018-03-02 11:41:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:41:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:11:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:11:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:11:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:11:42 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:11:42 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:11:42 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:11:42 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:41:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:41:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:44:05 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:44:05 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:14:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:14:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:14:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:44:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:44:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:14:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:47:17 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:47:17 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:19:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:19:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:19:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:19:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:49:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:49:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:19:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:19:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:19:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:22:49 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 17:22:49 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 11:52:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:52:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:22:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:22:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:22:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:52:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:52:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:22:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:53:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:53:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 17:23:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:23:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:23:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:23:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:53:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:53:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:23:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:41 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 858
ERROR - 2018-03-02 17:23:41 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 858
ERROR - 2018-03-02 11:53:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:53:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:23:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:44 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:23:44 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:23:44 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:23:44 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:53:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:53:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:23:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:23:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:54:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:54:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 17:24:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:24:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:24:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:54:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 11:54:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:24:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:24:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:24:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:55:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 11:55:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:25:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:25:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:25:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:25:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-03-02 17:25:45 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-03-02 17:25:45 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 17:25:45 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 17:25:45 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:25:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:56:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 11:56:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 17:26:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:26:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:57:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 11:57:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:27:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:57:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:57:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 17:27:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:31 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:27:31 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:27:31 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:27:31 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:57:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:57:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:27:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:39 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 17:27:39 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 11:57:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:57:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:57:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:57:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:27:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:58:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 11:58:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 17:28:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:28:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:28:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 11:58:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:58:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:28:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 11:59:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 11:59:08 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:29:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:29:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:29:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 12:01:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 12:01:35 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:31:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:32:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:32:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:32:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:03:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:03:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 17:33:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:33:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:33:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:03:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:03:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:33:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:33:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:33:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:04:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:04:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 17:34:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:04:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:04:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 17:34:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 17:34:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 12:04:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 12:04:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 17:34:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 17:34:27 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 17:34:44 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 17:35:14 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 853
ERROR - 2018-03-02 18:01:22 --> Severity: Parsing Error --> syntax error, unexpected ',' E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 471
ERROR - 2018-03-02 18:01:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:01:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:01:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:33:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 18:03:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:33:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 18:03:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:33:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:03:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:33:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:03:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:33:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 18:03:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:33:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 12:33:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 18:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:46 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 18:03:46 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 12:33:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 12:33:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 18:03:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:03:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:04:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:04:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:04:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 18:05:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 12:35:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 12:35:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 18:05:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:35:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 12:35:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:25 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 203
ERROR - 2018-03-02 18:05:25 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 209
ERROR - 2018-03-02 12:35:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 12:35:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-03-02 18:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:05:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:36:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 12:36:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 18:06:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:06:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:06:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:36:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:36:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:41:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:41:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:11:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:11:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:11:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:43:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:43:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:13:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:13:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:13:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:45:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:45:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:15:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:15:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:15:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-03-02 18:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 79
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 108
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 116
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 126
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 138
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 146
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 269
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 274
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 279
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 284
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 288
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:15:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:46:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:46:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:16:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:16:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 12:49:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 12:49:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-02 18:19:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:19:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:19:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:19:40 --> Query error: Unknown column 'tbl_po_inv_item.color_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv`
LEFT JOIN `tbl_grn` ON `tbl_grn`.`po_ref_id`=`tbl_po_inv`.`po_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_hsn` ON `tbl_hsn`.`hsn_id`=`tbl_product`.`hsn`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
WHERE `tbl_po_inv`.`po_id` = '2'
ERROR - 2018-03-02 18:19:40 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519994980
WHERE `tbl_po_inv`.`po_id` = '2'
AND `id` = 'e67beb1d882e470f11e658527f25f9209ebd8bb9'
ERROR - 2018-03-02 18:20:17 --> Query error: Unknown column 'tbl_grn.supplier_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv`
LEFT JOIN `tbl_grn` ON `tbl_grn`.`po_ref_id`=`tbl_po_inv`.`po_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_grn`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_grn`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_hsn` ON `tbl_hsn`.`hsn_id`=`tbl_product`.`hsn`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_grn`.`color_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_grn`.`size_ref_id`
WHERE `tbl_po_inv`.`po_id` = '2'
ERROR - 2018-03-02 18:20:17 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519995017
WHERE `tbl_po_inv`.`po_id` = '2'
AND `id` = 'e67beb1d882e470f11e658527f25f9209ebd8bb9'
ERROR - 2018-03-02 18:20:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:20:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:20:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:01:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:01:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 18:31:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:31:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:31:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:01:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:01:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 18:31:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:31:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 18:31:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:51:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:51:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:21:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:51:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:51:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:21:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:51:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:51:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:21:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:51:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:51:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:21:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:21:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:52:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:52:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:52:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:52:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:22:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:52:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:52:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:22:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:52:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:52:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:22:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:52:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:52:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:22:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:22:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:54:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:54:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:24:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:54:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:54:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:24:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:54:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:54:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:24:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:54:30 --> 404 Page Not Found: Employee/audio
ERROR - 2018-03-02 13:54:30 --> 404 Page Not Found: Employee/audio
ERROR - 2018-03-02 19:24:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:24:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:54:41 --> 404 Page Not Found: Customer/choose_sales_rep
ERROR - 2018-03-02 13:54:41 --> 404 Page Not Found: Customer/choose_sales_rsm
ERROR - 2018-03-02 13:54:41 --> 404 Page Not Found: Customer/choose_sales_asm
ERROR - 2018-03-02 19:25:04 --> Severity: Notice --> Undefined variable: emp_type E:\wamp\www\duty\mathewgarments\application\models\Employee_model.php 190
ERROR - 2018-03-02 19:25:04 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('musthak', 'musthak', 'musthak', 'musthak', '8124498572', NULL, 'cheannik', '2018-03-02 07:25:04', 'musthakcse@gmail.com', 0)
ERROR - 2018-03-02 19:25:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:55:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:55:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:25:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:55:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:55:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:25:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:55:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:55:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:57:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:57:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:27:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:57:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:57:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:27:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:57:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:57:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:27:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:57:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:57:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:27:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:27:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:59:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:59:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:29:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:59:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:59:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:29:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:59:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 13:59:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 13:59:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 13:59:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:29:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:29:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:00:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:00:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:00:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:00:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:00:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:00:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:30:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:00:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:00:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:30:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:00:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:00:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:30:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:00:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:00:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:30:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:30:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:01:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:31:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-02 14:01:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-02 19:31:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-02 14:01:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-02 19:31:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:01:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:31:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:01:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:31:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:24 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:01:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:31:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:01:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:31:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:01:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:31:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:01:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:01:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:31:55 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:31:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:31:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:02:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:02:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:32:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:02:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:02:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:32:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:02:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:02:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:02:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:02:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:32:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:02:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:02:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:32:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:02:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:02:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:32:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:32:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:03:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:03:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:33:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:03:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 14:03:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 19:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:03:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:03:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:33:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 15
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 24
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 38
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 46
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 53
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 63
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 72
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 81
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 89
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 97
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\employee_edit.php 109
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:03:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:03:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:33:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:03:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:03:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:33:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:33:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 14:04:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-02 14:04:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-02 19:34:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:34:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-02 19:34:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
