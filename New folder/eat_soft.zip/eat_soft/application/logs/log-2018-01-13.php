<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-13 05:32:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:32:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:45:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:45:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:15:42 --> Severity: Parsing Error --> syntax error, unexpected ';' E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 05:45:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:45:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:20:56 --> Severity: Error --> Call to undefined function random() E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:21:38 --> Severity: Error --> Call to undefined function random() E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:21:45 --> Severity: Error --> Call to undefined function random() E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:21:51 --> Severity: Error --> Call to undefined function random() E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:22:00 --> Severity: Error --> Call to undefined function random() E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 05:52:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:52:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:22:43 --> Severity: Notice --> Use of undefined constant a - assumed 'a' E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 05:52:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:52:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:22:47 --> Severity: Notice --> Use of undefined constant a - assumed 'a' E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:22:47 --> Severity: Notice --> Use of undefined constant c - assumed 'c' E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 05:52:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:52:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:52:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:52:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:52:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:52:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:53:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:53:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:53:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:53:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:53:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:53:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:25:15 --> Severity: Error --> Class 'RandomStringGenerator' not found E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:25:51 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 11:26:09 --> Severity: Error --> Undefined constant 'Utils\RandomStringGenerator' E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 50
ERROR - 2018-01-13 05:57:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:57:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:57:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:57:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 05:58:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 05:58:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:00:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:00:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:00:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:00:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:00:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:00:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:00:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:02:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-13 06:02:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-13 06:02:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:02:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:06:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:06:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:06:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:06:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:07:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-13 06:07:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-13 11:40:54 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-13 11:40:54 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-13 11:40:55 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-13 11:40:55 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-13 06:10:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-13 06:10:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-13 06:11:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:11:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:11:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:11:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:41:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-13 11:41:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-13 11:41:55 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-13 11:41:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-13 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-13 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-13 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-13 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-13 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-13 06:11:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:11:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:42:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:18 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:42 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:45 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:49 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:52 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:42:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:42:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:11 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:25 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:32 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:42 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:43 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:45 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:52 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:53 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:55 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:43:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:43:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:04 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:44:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:44:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:08 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:25 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:29 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:43 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:52 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:45:59 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:45:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:10 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:14 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:49 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:46:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:46:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:06 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:11 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:14 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:16 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:21 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:29 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:32 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:47:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:47:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:21 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:25 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:48:57 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:48:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:08 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:34 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:42 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:49:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:49:52 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 11:49:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 11:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-13 11:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-13 11:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 307
ERROR - 2018-01-13 11:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-13 11:49:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-13 11:50:30 --> Severity: Error --> Call to undefined method Wholesale::retail_bill() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 45
ERROR - 2018-01-13 06:22:49 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-13 06:22:49 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-13 06:23:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:23:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:53:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:53:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:53:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:53:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:54:04 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:54:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:54:08 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:54:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 06:24:21 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:24:21 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:24:30 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:24:30 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:26:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:26:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:26:47 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 06:26:47 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 11:57:16 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:42 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:53 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:57 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:57:59 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:57:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:06 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:10 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:16 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:21 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:25 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:31 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:49 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:53 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:57 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:58:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:58:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:04 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:06 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:11 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:21 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:29 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:32 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:34 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:49 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:55 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:57 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 11:59:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 11:59:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:16 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:43 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:45 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:49 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:52 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:53 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:00:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:00:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:29 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:01:55 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:01:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:04 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:14 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:29 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:39 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:55 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:02:59 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:02:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:04 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:06 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:10 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:25 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:31 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:45 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:52 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:55 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:57 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:03:59 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:03:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:11 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:16 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:18 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:21 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:24 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:29 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:31 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:35 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:44 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:48 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:04:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:04:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:10 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:25 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:34 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:43 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:45 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:47 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:50 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:05:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:05:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:02 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:06 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:11 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:13 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:18 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:19 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:27 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:30 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:32 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:34 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 12:06:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 12:06:40 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 12:06:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 12:06:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-13 12:06:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-13 12:06:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 307
ERROR - 2018-01-13 12:06:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-13 12:06:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: stotal E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 126
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: gtotal E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 127
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: comm_cgst E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 128
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: comm_sgst E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 129
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: emp_id E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 130
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: get_payment E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 132
ERROR - 2018-01-13 12:07:06 --> Severity: Notice --> Undefined variable: bal_payment E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 133
ERROR - 2018-01-13 12:07:06 --> Query error: Column 'stotal' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`invoice`, `cus_name`, `cus_no`, `purchase_mode`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `emp_id`, `sale_type`, `get_pay`, `bal_pay`, `pdate`) VALUES ('WB004', 'MUSTHAK', '8124498572', 'cash', NULL, NULL, NULL, NULL, '', 'WP', NULL, NULL, '2018-01-13')
ERROR - 2018-01-13 12:07:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-13 12:07:54 --> Severity: Notice --> Undefined variable: get_payment E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 132
ERROR - 2018-01-13 12:07:54 --> Severity: Notice --> Undefined variable: bal_payment E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 133
ERROR - 2018-01-13 06:37:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-13 06:37:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-13 12:08:48 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 120
ERROR - 2018-01-13 12:08:48 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 137
ERROR - 2018-01-13 12:08:48 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 156
ERROR - 2018-01-13 06:40:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:40:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:51:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:51:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:53:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 06:53:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:54:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 06:54:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:05:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:05:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:07:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:07:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:16:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:16:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:17:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:17:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:19:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:19:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:19:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:19:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:33:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:33:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:34:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 07:34:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:34:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-13 07:34:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-13 07:34:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 07:34:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:12:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:12:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:13:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:13:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:14:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:14:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:16:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:16:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:17:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:17:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:22:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:22:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:25:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:25:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:26:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:26:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:26:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:26:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:27:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:27:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:29:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:29:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 13:59:34 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 13:59:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 13:59:45 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 13:59:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 13:59:49 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 13:59:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:00:08 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:00:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 08:33:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:33:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:38:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:38:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:38:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:38:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:38:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:38:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:38:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:38:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:39:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:39:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:39:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:39:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:40:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:40:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:41:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:41:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:41:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:41:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 14:11:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:11:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:11:47 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:11:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:11:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:11:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:11:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:11:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:11:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 08:41:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:41:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:42:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:42:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:12:38 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:12:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:12:40 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:12:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:12:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 08:42:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:42:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:43:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:43:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:43:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:43:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:44:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:44:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:44:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:44:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:45:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:45:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:15:31 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:15:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:15:34 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:15:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:15:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 08:45:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:45:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:45:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:45:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:46:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:46:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:46:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:46:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:17:14 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:17:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:17:17 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:17:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:17:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 08:47:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:47:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:47:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:47:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:47:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:47:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:48:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:48:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:51:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:51:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:52:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:52:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 14:22:41 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:22:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:22:46 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:22:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:22:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:22:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:22:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:22:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:22:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 08:52:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:52:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 14:22:51 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:22:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:23:02 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:23:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:23:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:23:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:23:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:23:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:23:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 08:53:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:53:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:53:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:53:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:24:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:24:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 08:57:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:57:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:58:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:58:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 08:59:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 08:59:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:00:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:00:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:02:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:02:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:02:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:02:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:02:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:02:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 14:32:59 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:32:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:33:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:33:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:33:11 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:33:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:33:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:33:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:33:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:33:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:33:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 09:03:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:03:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:03:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:03:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:33:22 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:33:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:33:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:33:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:33:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:33:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:33:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 09:03:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:03:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:04:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:04:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:34:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:34:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:37:01 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:37:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:37:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:37:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:37:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:37:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:37:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 09:07:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:07:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 14:37:07 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:37:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:37:14 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 14:37:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 14:37:24 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 14:37:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 14:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 323
ERROR - 2018-01-13 14:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 325
ERROR - 2018-01-13 14:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 14:37:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 327
ERROR - 2018-01-13 09:07:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:07:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:17:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:17:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:19:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:19:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:19:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:19:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:45:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 09:45:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:46:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 09:46:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:17:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:17:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:18:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:18:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 15:51:58 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 15:51:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 15:52:05 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 15:52:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 15:52:07 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 15:52:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 15:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 15:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 15:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 341
ERROR - 2018-01-13 15:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 15:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 15:52:50 --> Severity: Notice --> Undefined variable: tax_type E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 169
ERROR - 2018-01-13 10:22:50 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-13 10:22:50 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-13 15:56:11 --> Severity: Notice --> Undefined variable: tax_type E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 169
ERROR - 2018-01-13 10:28:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:28:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 15:59:16 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 15:59:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 15:59:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 15:59:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 15:59:26 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 15:59:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 15:59:31 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 15:59:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 15:59:32 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 15:59:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 15:59:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 15:59:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 15:59:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 341
ERROR - 2018-01-13 15:59:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 15:59:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:00:53 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:00:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:00:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:00:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:01:00 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:01:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:01:02 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 16:01:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 16:01:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:01:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:01:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 341
ERROR - 2018-01-13 16:01:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:01:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:01:27 --> Severity: Notice --> Undefined variable: tax_type E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 133
ERROR - 2018-01-13 10:34:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:34:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:35:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:35:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:37:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:37:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:37:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:37:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:38:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:38:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:38:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:38:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:38:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:38:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:41:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:41:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 16:11:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:11:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:12:01 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:12:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:12:08 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:12:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:12:09 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 16:12:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 16:12:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:12:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:12:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 341
ERROR - 2018-01-13 16:12:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:12:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 10:45:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 10:45:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-13 16:15:34 --> Query error: Unknown column 'sales_id' in 'field list' - Invalid query: SELECT max(sales_id)
FROM `tbl_whole_sales`
ERROR - 2018-01-13 10:45:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 10:45:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:52:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:52:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 16:23:03 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:23:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:23:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:23:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:23:12 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:23:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:23:14 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 16:23:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 16:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 341
ERROR - 2018-01-13 16:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:23:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 10:53:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 10:53:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 16:24:17 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:24:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:24:22 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-13 16:24:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-13 16:24:24 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-13 16:24:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-13 16:24:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:24:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 339
ERROR - 2018-01-13 16:24:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 341
ERROR - 2018-01-13 16:24:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:24:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 343
ERROR - 2018-01-13 16:24:53 --> Query error: Unknown column 'invoice' in 'field list' - Invalid query: SELECT DISTINCT `sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `invoice`, `sales_ref_id`
FROM `tbl_whole_sales`
LEFT JOIN `tbl_wholes_sales_item` ON `tbl_wholes_sales_item`.`who_sales_ref_id`=`tbl_whole_sales`.`whole_sales_id`
WHERE `whole_sales_id` = 2
ERROR - 2018-01-13 16:24:53 --> Query error: Unknown column 'whole_sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515840893
WHERE `whole_sales_id` = 2
AND `id` = 'b48e7e2e677aec80e3d49e224647e402bfb5b549'
ERROR - 2018-01-13 16:29:36 --> Query error: Unknown column 'invoice' in 'field list' - Invalid query: SELECT DISTINCT `sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `invoice`, `sales_ref_id`
FROM `tbl_whole_sales`
LEFT JOIN `tbl_wholes_sales_item` ON `tbl_wholes_sales_item`.`who_sales_ref_id`=`tbl_whole_sales`.`whole_sales_id`
WHERE `whole_sales_id` = 3
ERROR - 2018-01-13 16:29:36 --> Query error: Unknown column 'whole_sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515841176
WHERE `whole_sales_id` = 3
AND `id` = 'b48e7e2e677aec80e3d49e224647e402bfb5b549'
ERROR - 2018-01-13 16:32:17 --> Query error: Unknown column 'invoice' in 'field list' - Invalid query: SELECT DISTINCT `sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `cgst`, `cgst_amt`, `igst`, `igst_amt`, `invoice`, `sales_ref_id`
FROM `tbl_whole_sales`
LEFT JOIN `tbl_wholes_sales_item` ON `tbl_wholes_sales_item`.`who_sales_ref_id`=`tbl_whole_sales`.`whole_sales_id`
WHERE `whole_sales_id` = 4
ERROR - 2018-01-13 16:32:17 --> Query error: Unknown column 'whole_sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515841337
WHERE `whole_sales_id` = 4
AND `id` = 'b48e7e2e677aec80e3d49e224647e402bfb5b549'
ERROR - 2018-01-13 11:02:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-13 11:02:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-13 16:32:43 --> Query error: Unknown column 'invoice' in 'field list' - Invalid query: SELECT DISTINCT `sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `cgst`, `cgst_amt`, `igst`, `igst_amt`, `invoice`, `sales_ref_id`
FROM `tbl_whole_sales`
LEFT JOIN `tbl_wholes_sales_item` ON `tbl_wholes_sales_item`.`who_sales_ref_id`=`tbl_whole_sales`.`whole_sales_id`
WHERE `whole_sales_id` = '4'
ERROR - 2018-01-13 16:32:43 --> Query error: Unknown column 'whole_sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515841363
WHERE `whole_sales_id` = '4'
AND `id` = 'b48e7e2e677aec80e3d49e224647e402bfb5b549'
ERROR - 2018-01-13 16:33:21 --> Query error: Unknown column 'sales_ref_id' in 'field list' - Invalid query: SELECT DISTINCT `sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `cgst`, `cgst_amt`, `igst`, `igst_amt`, `who_invoice`, `sales_ref_id`
FROM `tbl_whole_sales`
LEFT JOIN `tbl_wholes_sales_item` ON `tbl_wholes_sales_item`.`who_sales_ref_id`=`tbl_whole_sales`.`whole_sales_id`
WHERE `whole_sales_id` = '4'
ERROR - 2018-01-13 16:33:21 --> Query error: Unknown column 'whole_sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515841401
WHERE `whole_sales_id` = '4'
AND `id` = 'b48e7e2e677aec80e3d49e224647e402bfb5b549'
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: cus_name E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: invoice E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: pdate E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: sales_ref_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 87
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:33:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:49 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:46:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:54 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:47:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:58 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:48:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:49:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: stotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: gtotal E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: comm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:50:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined index: who_iomm_sgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined index: comm_gst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:29 --> Severity: Notice --> Undefined index: comm_gst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:29 --> Severity: Notice --> Undefined index: comm_cgst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:29 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:55:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:56:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:58:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 11:28:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:28:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:29:10 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-13 11:29:10 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 16:59:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-13 11:29:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:29:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:29:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:29:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:30:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:30:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:31:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:31:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:32:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:32:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:32:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:32:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 17:07:03 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-13 17:07:03 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-13 17:07:03 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-13 17:07:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-13 17:07:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-13 11:37:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-13 11:37:04 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-13 11:37:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:37:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:37:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:37:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:37:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:37:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:38:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-13 11:38:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:41:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-13 11:41:04 --> 404 Page Not Found: Audio/alert.mp3
