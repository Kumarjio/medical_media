<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-08 06:46:00 --> 404 Page Not Found: Audio/fail.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-08 06:46:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-08 11:16:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-08 06:46:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-08 06:46:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-08 11:16:19 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-08 06:46:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-08 06:46:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-08 11:16:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.php 114
