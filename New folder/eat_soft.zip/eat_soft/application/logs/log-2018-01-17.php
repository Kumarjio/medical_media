<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-17 04:05:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 04:05:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 09:36:38 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-17 09:36:38 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 09:36:38 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 09:36:38 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 04:06:39 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-17 04:06:39 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-17 09:43:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-17 09:43:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 09:43:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 09:43:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 04:13:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-17 04:13:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-17 09:44:20 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-17 09:44:20 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 09:44:20 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 09:44:20 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-17 04:14:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-17 04:14:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-17 12:54:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 12:54:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 12:54:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 12:54:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:01:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:01:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 18:32:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 13:02:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:02:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:02:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-17 13:02:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-17 13:02:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:02:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 18:32:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-17 18:32:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-17 18:32:53 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-17 18:32:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-17 18:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-17 18:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-17 18:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-17 18:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-17 18:32:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-17 13:03:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:03:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:03:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:03:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:04:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:04:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:04:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:04:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:05:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:05:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:06:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:06:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:06:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:06:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:07:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:07:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:07:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:07:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:09:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:09:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:09:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:09:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:31:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:31:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:32:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:32:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-17 13:32:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-17 13:32:44 --> 404 Page Not Found: Audio/fail.mp3
