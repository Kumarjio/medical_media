<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-18 04:12:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 04:12:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 04:12:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 04:12:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 04:12:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:12:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:18:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:18:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:18:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:18:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:18:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:18:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:19:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:19:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:36:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:36:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:37:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:37:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:37:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:37:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:38:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:38:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:38:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:38:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:39:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:39:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:39:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:39:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:40:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:40:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:40:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:40:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:40:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:40:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:41:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:41:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:42:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:43:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:43:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:43:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:43:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:44:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:44:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:45:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:45:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:50:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:50:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:50:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:50:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:53:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:53:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:54:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:54:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:26:56 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-18 10:26:56 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-18 10:26:56 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-18 10:26:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 10:26:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-18 04:56:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 04:56:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 04:57:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 04:57:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 04:57:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 04:57:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 04:57:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:57:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:57:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 04:57:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 04:57:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 04:57:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 04:58:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:58:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:58:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 04:58:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:01:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:01:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:01:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:01:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:02:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:02:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:03:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:03:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:03:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:03:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:04:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:04:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:07:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:07:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:07:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:07:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:07:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:07:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:12:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:12:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:13:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:13:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:15:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:15:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:21:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:21:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:22:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:22:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:52:24 --> Severity: Notice --> Undefined index: add E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 53
ERROR - 2018-01-18 10:52:24 --> Query error: Table 'db_methew_gar.tbl_po_inv_hold' doesn't exist - Invalid query: INSERT INTO `tbl_po_inv_hold` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `lot`, `remarks`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `comm_igst`, `lot_placed`, `purchase_mode`, `grn_date`) VALUES ('1', '11', '11', '2018-01-18', '1', '11', '11', '121', '147.62', '6.66', '6.66', '13.31', '11', 'cash', '2018-01-18')
ERROR - 2018-01-18 10:58:26 --> Severity: Notice --> Undefined index: add E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 53
ERROR - 2018-01-18 05:28:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:28:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:28:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:28:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:58:55 --> Severity: Notice --> Undefined index: add E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 53
ERROR - 2018-01-18 05:28:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:28:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:29:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:29:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:29:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:29:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:00:26 --> Severity: Notice --> Undefined index: add E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 53
ERROR - 2018-01-18 05:30:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:00:52 --> Severity: Notice --> Undefined index: hold E:\wamp\www\duty\mathewgarments\application\controllers\Goodsreceived.php 56
ERROR - 2018-01-18 05:30:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:30:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:31:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:31:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:01:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:01:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:01:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:01:40 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 05:31:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 05:31:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 05:31:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:31:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:32:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:32:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:34:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:34:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:34:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:34:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:34:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:34:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:37:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:37:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:37:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:37:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:37:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:37:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:38:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:38:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 11:08:24 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-18 11:08:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-18 11:08:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-18 11:08:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-18 11:08:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 11:08:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-18 11:08:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-18 05:38:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:38:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:42:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:42:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:42:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 05:42:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 05:43:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 05:43:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 05:44:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:44:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:44:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:44:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:45:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:45:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:45:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:45:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:46:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:46:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:56:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 05:56:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:33:56 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 06:04:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 06:04:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 11:34:03 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-18 06:04:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 06:04:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 06:05:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 06:05:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 11:35:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' `tbl_product`
WHERE  = '8'' at line 2 - Invalid query: SELECT *, `tbl_product`.*
FROM , `tbl_product`
WHERE  = '8'
ERROR - 2018-01-18 11:35:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'' at line 2 - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516255530
WHERE  = '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'
ERROR - 2018-01-18 11:36:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'' at line 2 - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516255561
WHERE  = '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'
ERROR - 2018-01-18 11:36:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'' at line 2 - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516255593
WHERE  = '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'
ERROR - 2018-01-18 11:36:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'' at line 2 - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516255598
WHERE  = '8'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:47:35 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:48:35 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:49:06 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 102
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 210
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: unit E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-18 11:49:07 --> Severity: Notice --> Undefined variable: item E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: supplier E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 37
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 37
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 76
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 76
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 193
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 193
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 202
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 202
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 370
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 370
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 373
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 373
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: supplier E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 37
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 37
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 76
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 76
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 193
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 193
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 202
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 202
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 370
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 370
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 373
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 373
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: supplier E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 37
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 37
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 76
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 76
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 193
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 193
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 202
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 202
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 370
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 370
ERROR - 2018-01-18 11:49:50 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 373
ERROR - 2018-01-18 11:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 373
ERROR - 2018-01-18 11:50:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:50:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:50:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:51:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:51:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:51:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:55:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:55:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:55:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:55:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:55:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:56:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 11:57:19 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:00:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:00:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:01:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:01:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:02:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 259
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 264
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 269
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 274
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 279
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 259
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 264
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 269
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 274
ERROR - 2018-01-18 12:08:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 279
ERROR - 2018-01-18 12:10:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 259
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 264
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 269
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 274
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 279
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 259
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 264
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 269
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 274
ERROR - 2018-01-18 12:10:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 279
ERROR - 2018-01-18 12:13:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 259
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 264
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 269
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 274
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 279
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 259
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 264
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 269
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 274
ERROR - 2018-01-18 12:13:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 279
ERROR - 2018-01-18 12:17:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:17:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:19:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:19:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:20:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:20:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:21:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:21:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:23:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:23:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:24:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:24:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:24:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:25:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:25:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:25:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:32:20 --> Query error: Not unique table/alias: 'tbl_po_inv' - Invalid query: SELECT *
FROM `tbl_po_inv`
JOIN `tbl_grn` ON `tbl_grn`.`po_ref_id`=`tbl_po_inv`.`po_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_grn`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
WHERE `po_id` = '1'
ERROR - 2018-01-18 12:32:20 --> Query error: Unknown column 'po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516258940
WHERE `po_id` = '1'
AND `id` = 'e137ffe205d93a16ccb0ecf1a41e2791f406920f'
ERROR - 2018-01-18 12:50:31 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 251
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 197
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 201
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 201
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 201
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 203
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 203
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 203
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 211
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 211
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 213
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 213
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 214
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 214
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 223
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 223
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 232
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 232
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 233
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 233
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 236
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 237
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 239
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 241
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 248
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 248
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 262
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 267
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 272
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 277
ERROR - 2018-01-18 12:51:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 282
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 201
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 201
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 201
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 203
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 203
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 203
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 211
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 211
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 213
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 213
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 214
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 214
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 223
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 223
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 232
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 232
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 233
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: value E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 233
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 236
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 237
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 239
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 241
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 248
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined variable: data_count E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 248
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 262
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 267
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 272
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 277
ERROR - 2018-01-18 12:51:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 282
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:06 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:52:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:52:19 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 249
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:22 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:52:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:54 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:55 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:54:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:56:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:56:44 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:56:44 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:56:44 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:56:44 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 206
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:56:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:58:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 12:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:01:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:01:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:09:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:09:31 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:09:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:09:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:09:44 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:09:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:10:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:02 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:10:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:10:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:10:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:10:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:11:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:11:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:11:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:11:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:12:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:16:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:19:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:20:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:20:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:20:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:20:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:22:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:22:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 13:22:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:29:15 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 328
ERROR - 2018-01-18 14:29:26 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 328
ERROR - 2018-01-18 14:29:54 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 328
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:30:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:39:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 406
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined variable: po_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 409
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined variable: po_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 412
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 415
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 429
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined variable: po_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 453
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 09:10:03 --> 404 Page Not Found: Stock/index
ERROR - 2018-01-18 09:11:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 09:11:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 09:11:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 09:11:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 406
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined variable: po_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 409
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined variable: po_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 412
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 415
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 429
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined variable: po_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 453
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:41:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 09:12:02 --> 404 Page Not Found: Stock/index
ERROR - 2018-01-18 09:12:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 09:12:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 09:13:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 09:13:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 09:13:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 09:13:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:43:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:43:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:44:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 09:14:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 09:14:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:44:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:44:47 --> Severity: Notice --> Undefined variable: sname E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 313
ERROR - 2018-01-18 14:44:47 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 317
ERROR - 2018-01-18 14:44:47 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 326
ERROR - 2018-01-18 14:44:47 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 09:14:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:14:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:15:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:15:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:15:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 09:15:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:45:30 --> Severity: Notice --> Undefined variable: sname E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 313
ERROR - 2018-01-18 14:45:30 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 317
ERROR - 2018-01-18 14:45:30 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 326
ERROR - 2018-01-18 14:45:30 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:46:52 --> Severity: Notice --> Undefined variable: sname E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 313
ERROR - 2018-01-18 14:46:52 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 317
ERROR - 2018-01-18 14:46:52 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 326
ERROR - 2018-01-18 14:46:52 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:47:06 --> Severity: Notice --> Undefined variable: sname E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 313
ERROR - 2018-01-18 14:47:06 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 317
ERROR - 2018-01-18 14:47:06 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 326
ERROR - 2018-01-18 14:47:06 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:47:27 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:47:40 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:48:04 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:51:08 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 332
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:51:16 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 341
ERROR - 2018-01-18 14:51:16 --> Query error: Unknown column 'qty' in 'field list' - Invalid query: SELECT `qty`
FROM `tbl_stock`
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` IS NULL
ERROR - 2018-01-18 14:51:16 --> Query error: Unknown column 'pro_imag_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516267276
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` IS NULL
AND `id` = '4ed49342b2eab8bd32ec974cecfa6acef3ae2460'
ERROR - 2018-01-18 14:51:57 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 341
ERROR - 2018-01-18 14:51:57 --> Query error: Unknown column 'qty' in 'field list' - Invalid query: SELECT `qty`
FROM `tbl_stock`
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` IS NULL
ERROR - 2018-01-18 14:51:57 --> Query error: Unknown column 'pro_imag_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516267317
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` IS NULL
AND `id` = '4ed49342b2eab8bd32ec974cecfa6acef3ae2460'
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:52:01 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 341
ERROR - 2018-01-18 14:52:01 --> Query error: Unknown column 'qty' in 'field list' - Invalid query: SELECT `qty`
FROM `tbl_stock`
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` IS NULL
ERROR - 2018-01-18 14:52:01 --> Query error: Unknown column 'pro_imag_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516267321
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` IS NULL
AND `id` = '4ed49342b2eab8bd32ec974cecfa6acef3ae2460'
ERROR - 2018-01-18 14:52:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:52:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:52:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:52:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:52:41 --> Query error: Unknown column 'qty' in 'field list' - Invalid query: SELECT `qty`
FROM `tbl_stock`
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` = '2'
ERROR - 2018-01-18 14:52:41 --> Query error: Unknown column 'pro_imag_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516267361
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` = '2'
AND `id` = '4ed49342b2eab8bd32ec974cecfa6acef3ae2460'
ERROR - 2018-01-18 14:53:01 --> Query error: Unknown column 'qty' in 'field list' - Invalid query: SELECT `qty`
FROM `tbl_stock`
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` = '2'
ERROR - 2018-01-18 14:53:01 --> Query error: Unknown column 'pro_imag_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516267381
WHERE `pro_imag_ref_id` = '4'
AND `size_reff_id` = '2'
AND `id` = '4ed49342b2eab8bd32ec974cecfa6acef3ae2460'
ERROR - 2018-01-18 14:53:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `po_ref_id` = '8'' at line 3 - Invalid query: SELECT *
FROM 
WHERE `po_ref_id` = '8'
ERROR - 2018-01-18 14:53:08 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516267388
WHERE `po_ref_id` = '8'
AND `id` = '4ed49342b2eab8bd32ec974cecfa6acef3ae2460'
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:54:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 09:24:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 09:24:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 14:54:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:02:02 --> Severity: Error --> Unsupported operand types E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 335
ERROR - 2018-01-18 15:02:46 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 335
ERROR - 2018-01-18 15:02:46 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 335
ERROR - 2018-01-18 15:02:46 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 335
ERROR - 2018-01-18 15:02:46 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 335
ERROR - 2018-01-18 15:05:02 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 336
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:25:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:25:45 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_driver.php 1440
ERROR - 2018-01-18 15:25:45 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `tbl_po_inv_item` SET `po_ref_id` = Array, `style_ref_id` = '1', `color_ref_id` = '1', `size_ref_id` = '1', `hsncode` = '9005', `product_img_ref_id` = '1', `wholesale_tax` = '5', `wholesale_amt` = '180', `r_rate` = '200', `r_percent` = '5', `qty` = '10', `p_rate` = '150', `p_rate_key` = 'OFTY', `total` = '1575', `sgst` = 0, `cgst` = 0, `igst` = '5', `sgst_amt` = 0, `cgst_amt` = 0, `igst_amt` = '75', `barcode_status` = 1
WHERE `po_inv_id` = '1'
ERROR - 2018-01-18 15:26:35 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_driver.php 1440
ERROR - 2018-01-18 15:26:35 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `tbl_po_inv_item` SET `po_ref_id` = Array, `style_ref_id` = '1', `color_ref_id` = '1', `size_ref_id` = '1', `hsncode` = '9005', `product_img_ref_id` = '1', `wholesale_tax` = '5', `wholesale_amt` = '180', `r_rate` = '200', `r_percent` = '5', `qty` = '10', `p_rate` = '150', `p_rate_key` = 'OFTY', `total` = '1575', `sgst` = 0, `cgst` = 0, `igst` = '5', `sgst_amt` = 0, `cgst_amt` = 0, `igst_amt` = '75', `barcode_status` = 1
WHERE `po_inv_id` = '1'
ERROR - 2018-01-18 15:27:45 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_driver.php 1440
ERROR - 2018-01-18 15:27:45 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `tbl_po_inv_item` SET `po_ref_id` = Array, `style_ref_id` = '1', `color_ref_id` = '1', `size_ref_id` = '1', `hsncode` = '9005', `product_img_ref_id` = '1', `wholesale_tax` = '5', `wholesale_amt` = '180', `r_rate` = '200', `r_percent` = '5', `qty` = '10', `p_rate` = '150', `p_rate_key` = 'OFTY', `total` = '1575', `sgst` = 0, `cgst` = 0, `igst` = '5', `sgst_amt` = 0, `cgst_amt` = 0, `igst_amt` = '75', `barcode_status` = 1
WHERE `po_inv_id` = '1'
ERROR - 2018-01-18 09:59:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:59:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:29:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 09:59:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 09:59:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:00:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:00:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:30:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:30:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:00:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:00:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:30:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:00:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:00:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:31:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:31:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:01:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:01:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:31:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:01:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:01:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:31:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:01:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:01:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:32:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:02:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:02:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:32:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:33:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:03:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:03:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:33:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:33:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:34:09 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_driver.php 1440
ERROR - 2018-01-18 15:34:09 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `tbl_po_inv_item` SET `po_ref_id` = Array, `style_ref_id` = '2', `color_ref_id` = '3', `size_ref_id` = '2', `hsncode` = '9003', `product_img_ref_id` = '4', `wholesale_tax` = '124414', `wholesale_amt` = '12414', `r_rate` = '441', `r_percent` = '44414', `qty` = '141414', `p_rate` = '12412', `p_rate_key` = '124141', `total` = '2000962847.52', `sgst` = 0, `cgst` = 0, `igst` = '14', `sgst_amt` = 0, `cgst_amt` = 0, `igst_amt` = '245732279.52', `barcode_status` = 1
WHERE `po_inv_id` = '11'
ERROR - 2018-01-18 10:06:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:06:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:36:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:06:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:06:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:37:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:12:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:12:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:13:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:13:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:14:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:14:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:14:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:14:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 15:44:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:16:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:16:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:16:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:16:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:16:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:16:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:20:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:21:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:21:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:24:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:24:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 17
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 48
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 55
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 63
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 104
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 112
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 134
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 261
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 266
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 17
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 48
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 55
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 63
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 104
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 112
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 134
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 261
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 266
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-18 15:54:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 48
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 55
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 63
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 104
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 112
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 134
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 261
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 266
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 36
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 48
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 55
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 63
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 75
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 104
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 112
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 134
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 261
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 266
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-18 15:56:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-18 16:01:35 --> Query error: Unknown column 'po_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_hold`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
WHERE `po_id` = '6'
ERROR - 2018-01-18 16:01:35 --> Query error: Unknown column 'po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516271495
WHERE `po_id` = '6'
AND `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ERROR - 2018-01-18 16:02:10 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_hold`
JOIN `tbl_grn_hold` ON `tbl_grn_hold`.`po_ref_id`=`tbl_po_inv_hold`.`po_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_grn_hold`.`color_ref_id`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_grn_hold`.`product_img_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_grn_hold`.`size_ref_id`
WHERE `po_hold_id` = '6'
ERROR - 2018-01-18 16:02:10 --> Query error: Unknown column 'po_hold_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516271530
WHERE `po_hold_id` = '6'
AND `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ERROR - 2018-01-18 16:02:32 --> Query error: Unknown column 'tbl_po_inv_hold.po_hold-id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_hold`
JOIN `tbl_grn_hold` ON `tbl_grn_hold`.`po_ref_id`=`tbl_po_inv_hold`.`po_hold-id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_grn_hold`.`color_ref_id`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_grn_hold`.`product_img_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_grn_hold`.`size_ref_id`
WHERE `po_hold_id` = '6'
ERROR - 2018-01-18 16:02:32 --> Query error: Unknown column 'po_hold_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516271552
WHERE `po_hold_id` = '6'
AND `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ERROR - 2018-01-18 16:03:21 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 212
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:03:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:03:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:10:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:10:45 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT `tbl_grn_hold`.*, `tbl_po_inv_hold`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn_hold`
LEFT JOIN `tbl_po_inv_hold` ON `tbl_po_inv_hold`.`po_id`=`tbl_grn_hold`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ORDER BY `tbl_po_inv_hold`.`po_id` DESC
ERROR - 2018-01-18 16:10:45 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516272045
WHERE `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ORDER BY `tbl_po_inv_hold`.`po_id` DESC
ERROR - 2018-01-18 16:11:53 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT `tbl_grn_hold`.*, `tbl_po_inv_hold`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn_hold`
LEFT JOIN `tbl_po_inv_hold` ON `tbl_po_inv_hold`.`po_id`=`tbl_grn_hold`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ORDER BY `tbl_po_inv_hold`.`po_hold_id` DESC
ERROR - 2018-01-18 16:11:53 --> Query error: Unknown column 'tbl_po_inv_hold.po_hold_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516272113
WHERE `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ORDER BY `tbl_po_inv_hold`.`po_hold_id` DESC
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:12:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:12:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:12:14 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT `tbl_grn_hold`.*, `tbl_po_inv_hold`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn_hold`
LEFT JOIN `tbl_po_inv_hold` ON `tbl_po_inv_hold`.`po_id`=`tbl_grn_hold`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ORDER BY `tbl_po_inv_hold`.`po_hold_id` DESC
ERROR - 2018-01-18 16:12:14 --> Query error: Unknown column 'tbl_po_inv_hold.po_hold_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516272134
WHERE `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ORDER BY `tbl_po_inv_hold`.`po_hold_id` DESC
ERROR - 2018-01-18 16:13:29 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT `tbl_grn_hold`.*, `tbl_po_inv_hold`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn_hold`
LEFT JOIN `tbl_po_inv_hold` ON `tbl_po_inv_hold`.`po_id`=`tbl_grn_hold`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ORDER BY `tbl_po_inv_hold`.`po_id` DESC
ERROR - 2018-01-18 16:13:29 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516272209
WHERE `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ORDER BY `tbl_po_inv_hold`.`po_id` DESC
ERROR - 2018-01-18 16:13:34 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT `tbl_grn_hold`.*, `tbl_po_inv_hold`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn_hold`
LEFT JOIN `tbl_po_inv_hold` ON `tbl_po_inv_hold`.`po_id`=`tbl_grn_hold`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ORDER BY `tbl_po_inv_hold`.`po_id` DESC
ERROR - 2018-01-18 16:13:34 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516272214
WHERE `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ORDER BY `tbl_po_inv_hold`.`po_id` DESC
ERROR - 2018-01-18 16:14:12 --> Query error: Unknown column 'tbl_po_inv_hold.po_id' in 'on clause' - Invalid query: SELECT `tbl_grn_hold`.*, `tbl_po_inv_hold`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn_hold`
LEFT JOIN `tbl_po_inv_hold` ON `tbl_po_inv_hold`.`po_id`=`tbl_grn_hold`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn_hold`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv_hold`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv_hold`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ORDER BY `tbl_po_inv_hold`.`po_hold_id` DESC
ERROR - 2018-01-18 16:14:12 --> Query error: Unknown column 'tbl_po_inv_hold.po_hold_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516272252
WHERE `id` = 'c7abbfffe7c9261b0a77ded3cade1a75b6f76a10'
ORDER BY `tbl_po_inv_hold`.`po_hold_id` DESC
ERROR - 2018-01-18 10:46:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 10:46:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:16:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:16:55 --> Query error: Unknown column 'po_inv_id' in 'where clause' - Invalid query: DELETE FROM `tbl_po_inv_hold`
WHERE `po_inv_id` = '5'
ERROR - 2018-01-18 10:47:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:47:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:17:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 10:47:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:47:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:17:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 10:47:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:47:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:17:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 10:47:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:47:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:18:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 10:48:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:48:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:18:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:18:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:18:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:18:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:18:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:18:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:18:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:49:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:49:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:49:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:49:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:50:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:50:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:20:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 10:50:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:50:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:50:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:50:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:51:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:51:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:52:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:52:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:23:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 10:53:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:53:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:54:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 10:54:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:30:37 --> Query error: Unknown table 'tbl_po_inv' - Invalid query: SELECT `tbl_grn`.*, `tbl_po_inv`.*
FROM `tbl_grn`
ERROR - 2018-01-18 16:33:27 --> Query error: Unknown table 'tbl_po_inv' - Invalid query: SELECT `tbl_po_inv`.*
FROM `tbl_grn`
ERROR - 2018-01-18 16:36:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM (`tbl_po_inv`, `tbl_grn`)
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=' at line 1 - Invalid query: SELECT `tbl_grn`.*, `tbl_po_inv`.*, *
FROM (`tbl_po_inv`, `tbl_grn`)
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_grn`.`po_ref_id`
LEFT JOIN `tbl_grn` ON `tbl_grn`.`po_ref_id`=`tbl_po_inv`.`po_id`
ERROR - 2018-01-18 11:12:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:12:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:13:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:13:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:13:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:13:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:13:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:13:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:14:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:14:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:44:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:14:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:14:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:44:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:44:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:15:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:15:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:15:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:15:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:16:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:16:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:46:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:16:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 11:16:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 11:16:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 11:16:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 16:46:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 16:48:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:18:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:18:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:37:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:37:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:07:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:37:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:37:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:38:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:38:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:08:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:38:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:38:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:40:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:40:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:10:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:43:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:43:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:44:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:44:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:44:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:44:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:44:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:44:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:45:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:45:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:15:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:45:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:45:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:16:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:46:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:46:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:46:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:46:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:47:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:47:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:18:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:48:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:48:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:48:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:48:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:49:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:49:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:49:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:49:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:54:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:55:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:26:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 11:56:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 11:56:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:32:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 17:32:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 12:02:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:02:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:34:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:05:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:05:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 17:35:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 12:05:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:05:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:06:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 12:06:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 17:36:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-18 12:12:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:12:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:12:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:12:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:13:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:13:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 56
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 76
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 105
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 123
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 135
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 262
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 267
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 272
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 277
ERROR - 2018-01-18 17:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 282
ERROR - 2018-01-18 12:13:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:13:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:14:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:14:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 12:17:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:17:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:27:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:27:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:28:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:28:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:29:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:29:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:31:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:31:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:31:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:31:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:33:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:33:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:33:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:33:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:33:42 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 12:33:42 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 12:33:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:33:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:33:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:33:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:33:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:33:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:40:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:40:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:44:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:44:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:48:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:48:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:48:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:48:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:48:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:48:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 18:18:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:18:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:18:50 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:18:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 12:48:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:48:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 18:24:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:24:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:24:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:24:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 12:54:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:54:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 18:24:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:24:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:24:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:24:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:24:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:24:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 12:54:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:54:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 12:57:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 12:57:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:11:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-18 13:11:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-18 13:12:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:12:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:13:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:13:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:21:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:21:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 18:51:53 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:51:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:51:54 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:51:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:51:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:51:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:51:58 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-18 18:51:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-18 18:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 18:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 18:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-18 18:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-18 18:51:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-18 18:52:30 --> Severity: Error --> Call to undefined method Retail_model::where() E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-18 13:22:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:22:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:23:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:23:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:23:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:23:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:23:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:23:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 18:53:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:53:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:53:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:53:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:53:50 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-18 18:53:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-18 18:53:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 18:53:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 18:53:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-18 18:53:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-18 18:53:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-18 13:24:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:24:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:25:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:25:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:25:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:25:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:25:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:25:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 18:55:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:55:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:55:30 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-18 18:55:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-18 18:55:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-18 18:55:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-18 18:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 18:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-18 18:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-18 18:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-18 18:55:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-18 13:26:02 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:26:02 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-18 13:28:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:28:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:28:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:28:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:34:26 --> Severity: Parsing Error --> syntax error, unexpected '$con' (T_VARIABLE), expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 84
ERROR - 2018-01-18 19:05:19 --> Severity: Notice --> Undefined variable: stock_hold E:\wamp\www\duty\mathewgarments\application\views\goods_return.php 82
ERROR - 2018-01-18 13:35:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:35:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:35:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:35:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:37:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:37:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:37:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:37:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:40:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:40:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:41:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:41:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:41:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:41:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:41:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:41:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:42:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:42:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-18 19:14:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-18 13:45:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:45:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:46:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:46:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:46:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:46:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:46:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:46:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:47:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:47:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:47:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:47:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:48:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:48:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:48:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:48:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:48:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:48:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:48:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:48:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:48:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:48:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:49:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:49:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:49:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:49:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:49:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:49:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:49:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:49:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:49:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:49:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:54:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:54:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:54:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:54:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:55:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:55:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:55:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:55:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:55:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 13:55:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:55:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 13:55:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:03:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:03:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:05:36 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 30
ERROR - 2018-01-18 14:05:51 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 28
ERROR - 2018-01-18 14:05:59 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 27
ERROR - 2018-01-18 14:11:41 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 28
ERROR - 2018-01-18 14:12:05 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 29
ERROR - 2018-01-18 14:12:21 --> 404 Page Not Found: Returndet/get_grn_details
ERROR - 2018-01-18 19:42:41 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-18 19:42:41 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv`
JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_ref_id` = `tbl_po_inv`.`po_id`
WHERE `po_id` = `Array`
ERROR - 2018-01-18 19:42:41 --> Query error: Unknown column 'po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516284761
WHERE `po_id` = `Array`
AND `id` = '0c8666e857b5f70e3fdbf1a76e71b0e8ada00f21'
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 17
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: supplier E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-18 19:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 48
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 55
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 63
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 75
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 75
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 76
ERROR - 2018-01-18 19:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 76
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 104
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 112
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 134
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: all_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 186
ERROR - 2018-01-18 19:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 186
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 261
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 266
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 271
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 276
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: com_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 281
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: all_data E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 290
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 348
ERROR - 2018-01-18 19:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 348
ERROR - 2018-01-18 19:49:29 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 351
ERROR - 2018-01-18 19:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 351
ERROR - 2018-01-18 14:19:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:19:29 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 19:52:48 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 211
ERROR - 2018-01-18 14:22:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:22:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:24:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:24:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:31:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:31:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:31:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:31:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:31:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:31:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:31:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:31:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:32:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:32:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:32:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:32:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 14:50:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:50:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:50:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:50:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:53:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:53:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:55:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:55:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:55:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:55:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:55:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 14:55:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 14:55:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:55:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:57:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 14:57:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:05:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:05:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:05:18 --> 404 Page Not Found: Goodsreceived/index.php
ERROR - 2018-01-18 15:05:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:05:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:05:29 --> 404 Page Not Found: Goodsreceived/index.php
ERROR - 2018-01-18 15:05:43 --> 404 Page Not Found: Goodsreceived/index.php
ERROR - 2018-01-18 15:06:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:06:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:06:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:06:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:09:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 15:09:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 15:09:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:09:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:10:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:10:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:10:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:10:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:11:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:11:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:12:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:13:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:13:12 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:13:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:13:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:15:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:15:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:16:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:16:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:17:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:17:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:18:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:18:37 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:20:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:20:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:20:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:20:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:24:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:24:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:25:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:25:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:26:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:26:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:26:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:26:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:26:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:26:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:27:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:27:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:28:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:28:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:29:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:29:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:30:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:30:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:32:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:32:19 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:32:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:32:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:33:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:33:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:37:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 15:37:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 15:37:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:37:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 21:08:57 --> Severity: Notice --> Undefined variable: storage E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 177
ERROR - 2018-01-18 15:38:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:38:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:39:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:39:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:39:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:39:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-18 15:39:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-18 15:39:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-18 15:39:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:39:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:40:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-18 15:40:48 --> 404 Page Not Found: Returndet/audio
