<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-11 05:15:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 05:15:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 05:22:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 05:22:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-11 09:52:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 05:22:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 05:22:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 09:52:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 05:22:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 05:22:42 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 05:22:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 05:22:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 05:23:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 05:23:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 05:23:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 05:23:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 05:25:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 05:25:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-11 09:55:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 05:25:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 05:25:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined index: customer D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined index: lot_id D:\xampp\htdocs\duty\mathewgarments\application\controllers\Returndet.php 93
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-11 09:55:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2017-12-11 05:25:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 05:25:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2017-12-11 10:23:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 10:23:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 10:25:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 10:25:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 10:26:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 10:26:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 10:39:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 10:39:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:10:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:10:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:10:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:10:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:10:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:10:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:13:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:13:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:16:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:16:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:17:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:17:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:17:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:17:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:18:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:18:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:21:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:21:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:21:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:21:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:21:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:21:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:21:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:21:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:21:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:21:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:27:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:27:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:29:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:29:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:30:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 14:30:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 19:01:46 --> The filetype you are attempting to upload is not allowed.
ERROR - 2017-12-11 14:31:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:31:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:31:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:31:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:32:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 14:32:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 14:34:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:34:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:34:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:34:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:34:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:34:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-11 14:35:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:35:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:54:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:54:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:54:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 14:54:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 14:56:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 14:56:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 14:56:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 14:56:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 15:20:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:20:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:20:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:20:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:20:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 15:20:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 15:22:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:22:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:23:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:23:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:23:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:23:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:24:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:24:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:30:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:30:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:30:33 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 15:30:33 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 20:01:06 --> You did not select a file to upload.
ERROR - 2017-12-11 15:31:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:31:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-11 15:31:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 15:31:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-11 15:34:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-11 15:34:27 --> 404 Page Not Found: Audio/fail.mp3
