<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-07 10:01:47 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor`
WHERE `is_deleted` =0
ERROR - 2018-04-07 10:01:47 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523075507
WHERE `is_deleted` =0
AND `id` = '996b833099e55135a501f98d8081d8b5bd6ab842'
ERROR - 2018-04-07 10:21:05 --> Severity: Notice --> Undefined variable: suply D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 81
ERROR - 2018-04-07 10:21:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 81
ERROR - 2018-04-07 10:22:19 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 83
ERROR - 2018-04-07 10:22:19 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 83
ERROR - 2018-04-07 10:22:19 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 83
ERROR - 2018-04-07 10:22:19 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 83
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:16 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:25:17 --> Severity: Notice --> Undefined index: table_name D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 96
ERROR - 2018-04-07 10:27:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 05:02:42 --> 404 Page Not Found: Purchase/purchase_list
ERROR - 2018-04-07 10:32:56 --> Query error: Table 'db_hotel.tbl_item' doesn't exist - Invalid query: SELECT *
FROM `tbl_item`
WHERE `is_delete` =0
ERROR - 2018-04-07 10:32:56 --> Query error: Unknown column 'is_delete' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523077376
WHERE `is_delete` =0
AND `id` = '162a11bf249620bf5a19ad7a75eaa08048440deb'
ERROR - 2018-04-07 10:44:09 --> Query error: Unknown column 'is_delete' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor`
WHERE `is_delete` =0
ERROR - 2018-04-07 10:44:09 --> Query error: Unknown column 'is_delete' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523078049
WHERE `is_delete` =0
AND `id` = '162a11bf249620bf5a19ad7a75eaa08048440deb'
ERROR - 2018-04-07 10:45:13 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: INSERT INTO `tbl_vendor` (`vendor_name`, `vendor_mobile`, `vendor_email`, `vendor_gst`, `vendor_area`, `vendor_city`, `vendor_state`, `vendor_pincode`, `create_date`, `is_delete`) VALUES ('2313421', '3412424', '2424234', '342342342', '423423', '423424', '2342342', '4234234', '2018-04-07', 0)
ERROR - 2018-04-07 10:45:20 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: INSERT INTO `tbl_vendor` (`vendor_name`, `vendor_mobile`, `vendor_email`, `vendor_gst`, `vendor_area`, `vendor_city`, `vendor_state`, `vendor_pincode`, `create_date`, `is_delete`) VALUES ('2313421', '3412424', '2424234', '342342342', '423423', '423424', '2342342', '4234234', '2018-04-07', 0)
ERROR - 2018-04-07 10:54:19 --> Severity: Notice --> Undefined index: stocks E:\wamp\www\duty\hotel\application\controllers\Purchase.php 76
ERROR - 2018-04-07 10:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\hotel\application\controllers\Purchase.php 76
ERROR - 2018-04-07 10:56:19 --> Severity: Parsing Error --> syntax error, unexpected '?>' E:\wamp\www\duty\hotel\application\views\purchase\purchase_list.php 120
ERROR - 2018-04-07 11:18:33 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\wamp\www\duty\hotel\application\models\Purchase_model.php 70
ERROR - 2018-04-07 11:18:47 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\wamp\www\duty\hotel\application\models\Purchase_model.php 70
ERROR - 2018-04-07 11:19:25 --> Severity: Notice --> Undefined property: Stock::$Purchase_model E:\wamp\www\duty\hotel\application\controllers\Stock.php 26
ERROR - 2018-04-07 11:19:25 --> Severity: Error --> Call to a member function get_all_stock() on null E:\wamp\www\duty\hotel\application\controllers\Stock.php 26
ERROR - 2018-04-07 11:23:45 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\stock_list.php 115
ERROR - 2018-04-07 11:26:45 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\stock_list.php 90
ERROR - 2018-04-07 06:03:35 --> 404 Page Not Found: Stock/add_consumed_stock
ERROR - 2018-04-07 11:34:47 --> Severity: Notice --> Undefined property: Stock::$Purchase_model E:\wamp\www\duty\hotel\application\controllers\Stock.php 78
ERROR - 2018-04-07 11:34:47 --> Severity: Error --> Call to a member function get_all_vendor() on null E:\wamp\www\duty\hotel\application\controllers\Stock.php 78
ERROR - 2018-04-07 11:50:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\wamp\www\duty\hotel\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2018-04-07 11:50:05 --> Unable to connect to the database
ERROR - 2018-04-07 13:14:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\wamp\www\duty\hotel\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2018-04-07 13:14:28 --> Unable to connect to the database
ERROR - 2018-04-07 13:47:24 --> Severity: Notice --> Undefined property: Stock::$Purchase_model E:\wamp\www\duty\hotel\application\controllers\Stock.php 88
ERROR - 2018-04-07 13:47:24 --> Severity: Error --> Call to a member function add_stock() on null E:\wamp\www\duty\hotel\application\controllers\Stock.php 88
ERROR - 2018-04-07 13:47:55 --> Severity: Notice --> Undefined property: Stock::$Purchase_model E:\wamp\www\duty\hotel\application\controllers\Stock.php 88
ERROR - 2018-04-07 13:47:55 --> Severity: Error --> Call to a member function add_stock() on null E:\wamp\www\duty\hotel\application\controllers\Stock.php 88
ERROR - 2018-04-07 13:48:19 --> Query error: Table 'db_hotel.tbl_consumed_product' doesn't exist - Invalid query: INSERT INTO `tbl_consumed_product` (`consumed_pro_ref_id`, `consumed_unit`, `previous_qty`, `consumed_qty`, `consumed_date`, `consumed_time`, `is_deleted`) VALUES ('1', 'ml', '1232', '10', '2018-04-07', '01:48:19 pm', 0)
ERROR - 2018-04-07 13:54:15 --> Query error: Table 'db_hotel.tbl_consumed_product' doesn't exist - Invalid query: INSERT INTO `tbl_consumed_product` (`consumed_pro_ref_id`, `consumed_unit`, `previous_qty`, `consumed_qty`, `consumed_date`, `consumed_time`, `is_deleted`) VALUES ('1', 'ml', '1232', '10', '2018-04-07', '01:54:15 pm', 0)
ERROR - 2018-04-07 08:26:08 --> 404 Page Not Found: Stock/consumed_list
ERROR - 2018-04-07 08:26:50 --> Severity: Compile Error --> Cannot redeclare Stock::index() E:\wamp\www\duty\hotel\application\controllers\Stock.php 91
ERROR - 2018-04-07 14:00:51 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\hotel\application\views\stock\stock_list.php 95
ERROR - 2018-04-07 14:00:51 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\hotel\application\views\stock\stock_list.php 95
ERROR - 2018-04-07 14:00:51 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\hotel\application\views\stock\stock_list.php 95
ERROR - 2018-04-07 14:01:27 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 115
ERROR - 2018-04-07 14:03:25 --> Severity: Notice --> Undefined variable: product_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 59
ERROR - 2018-04-07 14:03:25 --> Severity: Notice --> Undefined variable: product_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 61
ERROR - 2018-04-07 14:03:25 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 115
ERROR - 2018-04-07 14:04:14 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 115
ERROR - 2018-04-07 14:04:22 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 115
ERROR - 2018-04-07 14:04:26 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 115
ERROR - 2018-04-07 14:04:28 --> Severity: Notice --> Undefined variable: purchase E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 115
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_invoice_no E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 119
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_invoice_date E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 120
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 121
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_gtotal E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 122
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 123
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 124
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_invoice_no E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 119
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_invoice_date E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 120
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 121
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_gtotal E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 122
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 123
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 124
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_invoice_no E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 119
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_invoice_date E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 120
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 121
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_gtotal E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 122
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 123
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 124
ERROR - 2018-04-07 14:05:04 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 123
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 124
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 123
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 124
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 123
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 124
ERROR - 2018-04-07 14:06:57 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 126
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 127
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 126
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 127
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 125
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 126
ERROR - 2018-04-07 14:08:03 --> Severity: Notice --> Undefined index: purchase_inv_id E:\wamp\www\duty\hotel\application\views\stock\consumed_stock_list.php 127
ERROR - 2018-04-07 14:47:23 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_item`
WHERE `is_deleted` =0
ERROR - 2018-04-07 14:47:23 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523092643
WHERE `is_deleted` =0
AND `id` = '8db00d13f7e69d652657da70677624a62c6bf506'
ERROR - 2018-04-07 14:48:31 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `cp_admin_login`
WHERE `is_deleted` =0
AND `user_type` = 2
ERROR - 2018-04-07 14:48:31 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523092711
WHERE `is_deleted` =0
AND `user_type` = 2
AND `id` = '8db00d13f7e69d652657da70677624a62c6bf506'
ERROR - 2018-04-07 14:49:24 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `cp_admin_login`
WHERE `is_deleted` =0
AND `user_type` = 2
ERROR - 2018-04-07 14:49:24 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523092764
WHERE `is_deleted` =0
AND `user_type` = 2
AND `id` = '8db00d13f7e69d652657da70677624a62c6bf506'
ERROR - 2018-04-07 14:49:54 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `cp_admin_login`
WHERE `is_deleted` =0
AND `user_type` = 2
ERROR - 2018-04-07 14:49:54 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523092794
WHERE `is_deleted` =0
AND `user_type` = 2
AND `id` = '8db00d13f7e69d652657da70677624a62c6bf506'
ERROR - 2018-04-07 14:50:06 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `cp_admin_login`
WHERE `is_deleted` =0
AND `user_type` = 2
ERROR - 2018-04-07 14:50:06 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523092806
WHERE `is_deleted` =0
AND `user_type` = 2
AND `id` = '8db00d13f7e69d652657da70677624a62c6bf506'
ERROR - 2018-04-07 14:50:43 --> Severity: Notice --> Undefined variable: emp E:\wamp\www\duty\hotel\application\views\sales\add_sales.php 75
ERROR - 2018-04-07 14:50:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\hotel\application\views\sales\add_sales.php 75
ERROR - 2018-04-07 14:51:04 --> Severity: Notice --> Undefined variable: emp E:\wamp\www\duty\hotel\application\views\sales\add_sales.php 75
ERROR - 2018-04-07 14:51:04 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\hotel\application\views\sales\add_sales.php 75
ERROR - 2018-04-07 14:51:07 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `cp_admin_login`
WHERE `is_deleted` =0
AND `user_type` = 2
ERROR - 2018-04-07 14:51:07 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523092867
WHERE `is_deleted` =0
AND `user_type` = 2
AND `id` = '8db00d13f7e69d652657da70677624a62c6bf506'
ERROR - 2018-04-07 14:52:07 --> Query error: Unknown column 'server_name' in 'field list' - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `server_name`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_deleted`, `sales_date`) VALUES ('SB2', '2018-04-07', '8', '14:52:07', '1', '1', '0', '0.00', '0.00', '100', '100.00', 0, 0, '2018-04-07')
ERROR - 2018-04-07 14:52:12 --> Query error: Unknown column 'server_name' in 'field list' - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `server_name`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_deleted`, `sales_date`) VALUES ('SB2', '2018-04-07', '8', '14:52:12', '1', '1', '0', '0.00', '0.00', '100', '100.00', 0, 0, '2018-04-07')
ERROR - 2018-04-07 14:53:23 --> Query error: Unknown column 'is_deleted' in 'field list' - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `server_name`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_deleted`, `sales_date`) VALUES ('SB2', '2018-04-07', '8', '14:53:23', '2', '1', '0', '0.00', '0.00', '100', '100.00', 0, 0, '2018-04-07')
ERROR - 2018-04-07 14:53:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 14:54:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 14:55:53 --> Severity: Notice --> Undefined variable: created_date E:\wamp\www\duty\hotel\application\models\Sales_model.php 58
ERROR - 2018-04-07 14:55:53 --> Severity: Notice --> Undefined variable: created_date E:\wamp\www\duty\hotel\application\models\Sales_model.php 60
ERROR - 2018-04-07 14:55:53 --> Query error: Column 'value_date' cannot be null - Invalid query: INSERT INTO `tbl_value` (`purchase_value`, `sales_value`, `value_date`) VALUES (0, '80.00', NULL)
ERROR - 2018-04-07 14:56:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 14:56:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\hotel\application\models\Purchase_model.php 59
ERROR - 2018-04-07 14:57:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\hotel\application\models\Sales_model.php 64
ERROR - 2018-04-07 14:58:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:00:22 --> Query error: Unknown column 'is_delete' in 'where clause' - Invalid query: SELECT *
FROM `tbl_item`
WHERE `is_delete` =0
ERROR - 2018-04-07 15:00:22 --> Query error: Unknown column 'is_delete' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523093422
WHERE `is_delete` =0
AND `id` = '53ad047b210c11fb15d99e25baf2c3fac1935787'
ERROR - 2018-04-07 11:44:14 --> 404 Page Not Found: Sales/edit_sales
ERROR - 2018-04-07 15:15:02 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: UPDATE `tbl_item` SET `is_delete` = 1
WHERE `item_id` = '1'
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:15:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:16:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:16:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 85
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 11:47:54 --> 404 Page Not Found: Sales/edit_sales
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:17:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 11:48:25 --> 404 Page Not Found: Sales/edit_sales
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:20:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:21:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:21:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:21:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:21:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:21:58 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:21:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:03 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:22:25 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:22:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:22:59 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 155
ERROR - 2018-04-07 15:22:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 155
ERROR - 2018-04-07 15:22:59 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 345
ERROR - 2018-04-07 15:22:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 345
ERROR - 2018-04-07 15:24:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:24:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:24:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:24:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:24:51 --> Severity: Notice --> Undefined variable: bill D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 52
ERROR - 2018-04-07 15:24:51 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:24:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:24:51 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:24:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:25:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:25:05 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:25:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:25:05 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:25:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:25:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:25:17 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:25:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:25:17 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:25:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:25:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:25:44 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:25:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:25:44 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:25:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:26:48 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 73
ERROR - 2018-04-07 15:27:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:27:13 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:27:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:27:13 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:27:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:27:27 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:27:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:27:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:27:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:27:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:27:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 339
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:30:11 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:13 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 52
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 59
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 73
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:23 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:30:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:30:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:30:26 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:30:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 52
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 59
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 73
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:30:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:30:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:14 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:15 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:31:17 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:31:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:31:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:31:25 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:31:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:15 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: row_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined index: table_id D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:32:56 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:32:56 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:33:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:33:33 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:33:33 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:33:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:33:54 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:33:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:33:54 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:33:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:33:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:33:56 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 149
ERROR - 2018-04-07 15:33:56 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 340
ERROR - 2018-04-07 15:34:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:35:58 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 15:36:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 15:36:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:38:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:39:10 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:40:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:40:25 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 12:44:50 --> Severity: Compile Error --> Cannot redeclare Sales::add_sales() D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 59
ERROR - 2018-04-07 12:45:42 --> Severity: Compile Error --> Cannot redeclare Sales::add_sales() D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 59
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:16:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:16:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:18:31 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:19:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:19:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:20:45 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:23:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:27:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:11 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:28:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:29:00 --> Severity: Warning --> Missing argument 1 for Sales::edit_sales() D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 52
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 55
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 46
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 52
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 59
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 73
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 172
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 189
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 204
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 216
ERROR - 2018-04-07 16:29:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 227
ERROR - 2018-04-07 16:30:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:30:19 --> Severity: Warning --> Missing argument 1 for Sales::edit_sales() D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 52
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 55
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 46
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 52
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 59
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 73
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 93
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 107
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 172
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 189
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 204
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 216
ERROR - 2018-04-07 16:30:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\duty\hotel\application\views\sales\sales_edit.php 227
ERROR - 2018-04-07 16:31:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:31:35 --> Severity: Error --> Call to undefined method Sales_model::edit_sales() D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 61
ERROR - 2018-04-07 16:32:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:37 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:32:47 --> Severity: Error --> Call to undefined method Sales_model::where() D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 128
ERROR - 2018-04-07 16:38:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:41:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:41:03 --> Severity: Notice --> Undefined index: sales_grand_total D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 126
ERROR - 2018-04-07 16:41:43 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 13:11:47 --> 404 Page Not Found: Sales/sales_list
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:41:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:42:33 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:42:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:42:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:01 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:43:16 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:43:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:44:06 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:44:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:45:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:45:18 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:45:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:37 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 16:47:51 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 16:47:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:48:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:48:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:49:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:49:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:49:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:49:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:49:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:50:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:50:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:50:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:50:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:50:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:50:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:51:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:51:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:05 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:52:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:53:11 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:54:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:54:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:54:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:54:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:54:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:55:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:55:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:56:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 16:58:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:04:10 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:04:43 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:05:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:06:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:07:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:08:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:09:51 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:10:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:10:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:10:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:10:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:10:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:12:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:12:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:14:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:15:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:15:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:15:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:15:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:15:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:16:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:16:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:16:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:16:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:17:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:17:43 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:19:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:20:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:21:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:26:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:27:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:27:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:27:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:27:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:27:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:28:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:29:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:30:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:30:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:30:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:30:53 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:31:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:31:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:31:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:31:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:32:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:33:02 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:33:57 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:34:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:34:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:37:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:37:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:39:03 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:40:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:40:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:43:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:43:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:44:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:47:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:48:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:48:20 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:48:29 --> Severity: Notice --> Undefined variable: sgst_per D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 146
ERROR - 2018-04-07 17:50:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:50:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:50:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:50:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:50:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 17:51:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 17:51:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:01:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:01:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:01:35 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:01:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:17 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:02:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:02:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:04:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:05:24 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:05:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:06:07 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:19 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:28 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:29 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:42 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:52 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:07:56 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:37 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:08:47 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:10 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:11 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:09:20 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:09:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:10:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:10:53 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:10:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_price D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-07 18:11:00 --> Severity: Notice --> Undefined index: sale_qty D:\xampp\htdocs\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-07 18:11:02 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:12:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:13:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 14:46:04 --> 404 Page Not Found: Purchase/edit_purchase
ERROR - 2018-04-07 18:35:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:35:50 --> Severity: Notice --> Undefined variable: vendor D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 47
ERROR - 2018-04-07 18:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 47
ERROR - 2018-04-07 18:35:50 --> Severity: Notice --> Undefined variable: sno D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 106
ERROR - 2018-04-07 18:35:50 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:35:50 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:35:50 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 262
ERROR - 2018-04-07 18:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 262
ERROR - 2018-04-07 18:36:18 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:36:18 --> Severity: Notice --> Undefined variable: vendor D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 47
ERROR - 2018-04-07 18:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 47
ERROR - 2018-04-07 18:36:18 --> Severity: Notice --> Undefined variable: sno D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 106
ERROR - 2018-04-07 18:36:18 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:36:18 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 110
ERROR - 2018-04-07 18:36:18 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 262
ERROR - 2018-04-07 18:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 262
ERROR - 2018-04-07 18:37:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:37:15 --> Severity: Notice --> Undefined variable: vendor D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 47
ERROR - 2018-04-07 18:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 47
ERROR - 2018-04-07 18:37:15 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:15 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:15 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:37:45 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:37:45 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:45 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:37:45 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:39:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:39:38 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:39:38 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:39:38 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:42:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:42:55 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:42:55 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:42:55 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:43:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:43:40 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:43:40 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:43:40 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 152
ERROR - 2018-04-07 18:43:40 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 155
ERROR - 2018-04-07 18:43:40 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:45:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:45:01 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:45:01 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 111
ERROR - 2018-04-07 18:45:01 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\purchase\purchase_edit.php 263
ERROR - 2018-04-07 18:45:22 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:48:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:48:35 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:49:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 15:19:28 --> 404 Page Not Found: Purchase/editPurchaseEntry
ERROR - 2018-04-07 18:55:20 --> Severity: Notice --> Uninitialized string offset: 1 D:\xampp\htdocs\duty\hotel\application\models\Purchase_model.php 174
ERROR - 2018-04-07 18:55:25 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:55:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:56:03 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:56:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:58:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 18:58:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 19:00:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 19:00:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 19:00:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 19:02:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-07 19:04:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
