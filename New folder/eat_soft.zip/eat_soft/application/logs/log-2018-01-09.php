<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-09 07:57:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 07:57:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 07:57:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 07:57:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 08:00:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 08:00:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 08:02:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 08:02:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 13:32:31 --> Severity: Notice --> Undefined property: Retail::$Goodsreceived_model E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 33
ERROR - 2018-01-09 13:32:31 --> Severity: Error --> Call to a member function get_all_stocks() on null E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 33
ERROR - 2018-01-09 13:32:47 --> Severity: Notice --> Undefined variable: supplier E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 37
ERROR - 2018-01-09 13:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 37
ERROR - 2018-01-09 13:32:47 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 79
ERROR - 2018-01-09 13:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 79
ERROR - 2018-01-09 13:32:47 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 196
ERROR - 2018-01-09 13:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 196
ERROR - 2018-01-09 13:32:47 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 205
ERROR - 2018-01-09 13:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 205
ERROR - 2018-01-09 13:32:47 --> Severity: Notice --> Undefined variable: product E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 347
ERROR - 2018-01-09 13:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 347
ERROR - 2018-01-09 13:32:47 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 350
ERROR - 2018-01-09 13:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 350
ERROR - 2018-01-09 08:02:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 08:02:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 08:03:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 08:03:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:06:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 09:06:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 14:50:43 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 103
ERROR - 2018-01-09 14:50:43 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 239
ERROR - 2018-01-09 09:20:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:20:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 14:51:22 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 235
ERROR - 2018-01-09 09:21:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:21:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 14:52:21 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 236
ERROR - 2018-01-09 09:22:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:22:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 14:52:37 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 09:22:37 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:22:37 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 14:54:51 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 09:24:52 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:24:52 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 14:57:08 --> Severity: Parsing Error --> syntax error, unexpected '<' E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 102
ERROR - 2018-01-09 14:57:31 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 09:27:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:27:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 14:58:25 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 09:28:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:28:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:28:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 09:28:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 14:58:33 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 14:58:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 14:58:37 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 14:58:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 14:58:39 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 14:58:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 14:58:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-09 14:58:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-09 14:58:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-09 14:58:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-09 14:58:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-09 14:58:51 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 14:58:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 14:59:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 14:59:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 14:59:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-09 14:59:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-09 14:59:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-09 14:59:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-09 14:59:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-09 09:29:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 09:29:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 14:59:11 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 14:59:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 14:59:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-09 14:59:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-09 14:59:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-09 14:59:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-09 14:59:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-09 09:29:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 09:29:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 09:31:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 09:31:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 09:36:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 09:36:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 15:08:57 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 09:38:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 09:38:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 15:09:10 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 54
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 60
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 61
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 62
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 66
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 54
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 60
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 61
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 62
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 66
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: vendor_id E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 54
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 60
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 61
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 62
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 66
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:11:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:12:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:12:36 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:12:36 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:14:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:14:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:14:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:27:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:27:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:27:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:28:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:28:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:28:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:28:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:28:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:28:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:29:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:30:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:31:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:31:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:31:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:32:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:32:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:32:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:34:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:34:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:34:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:35:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:35:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:35:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:35:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:35:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:35:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:36:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:38:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:38:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:38:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:38:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:38:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:38:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:39:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:51 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:51 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:40:51 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:41:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:41:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:41:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:41:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:41:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:41:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:42:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:42:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:42:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:43:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:43:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:43:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:43:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:43:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:43:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:44:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:45:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:45:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:45:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:45:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:45:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:51:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:51:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 15:51:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 16:48:01 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 16:48:13 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 11:22:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:22:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:22:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:22:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:22:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:22:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:22:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:22:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:22:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:22:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:22:34 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:22:34 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 16:52:55 --> Query error: Field 'opening_qty' doesn't have a default value - Invalid query: INSERT INTO `tbl_product` (`pro_name`, `brd_name`, `mat_name`, `style`, `hsn`) VALUES ('2', '3', '1', 'TS001', '6002')
ERROR - 2018-01-09 11:23:27 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:23:27 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:23:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:23:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:23:49 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:23:49 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:23:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:23:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:24:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:02 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:02 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:22 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:24 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:24:24 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:03 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:03 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:12 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:12 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:14 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:14 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:31 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:31 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:33 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:33 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:51 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:25:51 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:26:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:26:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:26:49 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-09 11:26:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:26:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:26:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 11:26:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 11:31:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 11:31:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 11:31:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:31:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:31:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:31:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:32:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:32:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 17:02:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 17:02:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 17:02:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-09 17:02:22 --> Query error: Unknown column 'sales_out_ref_id' in 'field list' - Invalid query: INSERT INTO `tbl_single_po_entry` (`po_inv_ref_id`, `trans_out_status`, `sale_out_status`, `mrp_rate`, `mrp_gst`, `wh_rate`, `wh_gst`, `transfer_out_ref_id`, `transfer_in_ref_id`, `sales_out_ref_id`, `gen_date`) VALUES ('3', 1, 1, '250', '5', '220', '5', 0, 0, 0, '09-01-2018')
ERROR - 2018-01-09 17:03:15 --> Query error: Unknown column 'sales_out_ref_id' in 'field list' - Invalid query: INSERT INTO `tbl_single_po_entry` (`po_inv_ref_id`, `trans_out_status`, `sale_out_status`, `mrp_rate`, `mrp_gst`, `wh_rate`, `wh_gst`, `transfer_out_ref_id`, `transfer_in_ref_id`, `sales_out_ref_id`, `gen_date`) VALUES ('3', 1, 1, '250', '5', '220', '5', 0, 0, 0, '09-01-2018')
ERROR - 2018-01-09 11:34:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:34:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:34:41 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-09 11:34:41 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-09 11:35:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-09 11:35:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-09 11:35:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:35:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:35:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:35:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:35:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:35:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:35:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:35:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:35:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 11:35:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:35:51 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-09 11:35:51 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-09 11:36:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 11:36:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 17:06:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:06:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:06:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:06:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:06:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:06:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:06:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:06:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:06:37 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:06:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:06:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:06:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:06:43 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 17:06:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 17:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 17:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 17:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 11:37:09 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 11:37:09 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 17:07:16 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 11:37:16 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 11:37:16 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 17:09:44 --> Severity: Notice --> A non well formed numeric value encountered E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 72
ERROR - 2018-01-09 17:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 72
ERROR - 2018-01-09 17:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 72
ERROR - 2018-01-09 17:10:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:10:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 72
ERROR - 2018-01-09 17:10:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:10:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 72
ERROR - 2018-01-09 17:10:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:10:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:12:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:12:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:12:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:12:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:12:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:12:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:13:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:13:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 17:13:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:13:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 133
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 133
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 138
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 152
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 162
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 167
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 133
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 133
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 138
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 152
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 162
ERROR - 2018-01-09 17:28:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 167
ERROR - 2018-01-09 17:32:20 --> Query error: Unknown column 'style_name' in 'field list' - Invalid query: SELECT DISTINCT `style_name`
FROM `tbl_sales`
LEFT JOIN `tbl_sales_item` ON `tbl_sales_item`.`sales_ref_id`=`tbl_sales`.`sales_id`
WHERE `sales_id` = '1'
ERROR - 2018-01-09 17:32:20 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515499340
WHERE `sales_id` = '1'
AND `id` = '27a571c1c7d95802cc9054dda57f7489e3f3808d'
ERROR - 2018-01-09 17:33:36 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 12:03:37 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:03:37 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:03:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:03:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:03:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:03:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:03:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 12:03:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 12:05:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 12:05:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-09 12:05:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:05:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:05:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:05:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:05:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:05:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:05:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:05:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:05:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:05:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 17:36:05 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:14 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:30 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:36:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:36:40 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 17:36:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 17:36:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:36:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:36:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 17:36:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 17:36:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 17:37:00 --> Severity: Notice --> Undefined variable: invoice E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 122
ERROR - 2018-01-09 17:37:00 --> Query error: Column 'invoice' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`invoice`, `cus_name`, `purchase_mode`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `emp_id`, `sale_type`, `get_pay`, `bal_pay`, `pdate`) VALUES (NULL, 'musthak', 'cash', '2100', '2205.00', '52.50', '52.50', 'EMP001', 'RP', '2300', '95.00', '2018-01-09')
ERROR - 2018-01-09 12:10:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:10:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 17:40:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:40:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:40:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:40:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:40:51 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:40:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:40:54 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:40:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:40:56 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 17:40:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 17:40:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:40:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:40:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 17:40:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 17:40:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 12:11:42 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:11:42 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:12:21 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:12:21 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 17:42:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:37 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:39 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:42 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-09 17:42:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 17:42:51 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-09 17:42:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 17:42:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:42:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 17:42:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 17:42:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 17:42:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 12:13:29 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:13:29 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 17:43:34 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 12:13:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:13:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 17:44:25 --> Query error: Unknown column 'hsn' in 'field list' - Invalid query: SELECT DISTINCT `style`, `hsn`
FROM `tbl_sales`
LEFT JOIN `tbl_sales_item` ON `tbl_sales_item`.`sales_ref_id`=`tbl_sales`.`sales_id`
WHERE `sales_id` = '2'
ERROR - 2018-01-09 17:44:25 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515500065
WHERE `sales_id` = '2'
AND `id` = 'f4e61e98fe9f1dce1050a5b97c5a554bbf911481'
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 17:56:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:02:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:05:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:06:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:07:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:08:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:09:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-09 18:13:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-09 18:15:56 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 18:17:17 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\retail_list.php 237
ERROR - 2018-01-09 12:47:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:47:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:48:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:48:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:51:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:51:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 18:22:05 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 18:22:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 18:22:38 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 18:22:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-09 18:22:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 18:22:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 18:22:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 18:22:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 18:22:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 12:53:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:53:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:53:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:53:18 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-09 12:54:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:54:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:57:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:57:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:57:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 12:57:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 18:27:39 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 18:27:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-09 18:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 18:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 18:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 18:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 18:27:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 12:57:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 12:57:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 14:21:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 14:21:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 19:51:54 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 19:51:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 19:51:59 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-09 19:51:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-09 19:52:02 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 19:52:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-09 19:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 19:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 19:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 19:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 19:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 14:22:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 14:22:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 19:52:14 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 19:52:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-09 19:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 19:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 19:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 19:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 19:52:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 14:22:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-09 14:22:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 19:52:15 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-09 19:52:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-09 19:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 19:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-09 19:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-09 19:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 19:52:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-09 14:22:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-09 14:22:15 --> 404 Page Not Found: Audio/alert.mp3
