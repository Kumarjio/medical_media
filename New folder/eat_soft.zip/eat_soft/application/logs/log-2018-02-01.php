<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-01 04:21:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:21:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:22:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:22:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:43:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:43:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:43:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-01 04:43:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-01 10:21:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-02-01 10:21:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-02-01 04:51:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:51:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:52:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:52:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:52:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:52:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:52:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:52:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:52:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 04:52:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:53:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 04:53:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 05:04:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 05:04:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 05:04:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 05:04:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 05:04:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 05:04:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 05:15:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 05:15:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 10:46:33 --> Severity: Notice --> Undefined variable: purchase_mode E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 132
ERROR - 2018-02-01 10:46:33 --> Query error: Column 'who_purchase_mode' cannot be null - Invalid query: INSERT INTO `tbl_whole_sales` (`who_invoice`, `who_cus_name`, `who_cus_no`, `who_purchase_mode`, `who_stotal`, `who_gtotal`, `who_comm_cgst`, `who_comm_sgst`, `who_comm_igst`, `who_sale_type`, `who_sale_tax_type`, `who_emp_id`, `who_pdate`, `who_cancel_status`) VALUES ('WB01', 'MUSTHAK', '81244998572', NULL, '6600', '7392.00', '396.00', '396.00', '0.00', 'WB', 'gst', 'EMP001', '2018-02-01', 0)
ERROR - 2018-02-01 10:47:18 --> Query error: Field 'who_purchase_mode' doesn't have a default value - Invalid query: INSERT INTO `tbl_whole_sales` (`who_invoice`, `who_cus_name`, `who_cus_no`, `who_stotal`, `who_gtotal`, `who_comm_cgst`, `who_comm_sgst`, `who_comm_igst`, `who_sale_type`, `who_sale_tax_type`, `who_emp_id`, `who_pdate`, `who_cancel_status`) VALUES ('WB01', 'MUSTHAK', '81244998572', '6600', '7392.00', '396.00', '396.00', '0.00', 'WB', 'gst', 'EMP001', '2018-02-01', 0)
ERROR - 2018-02-01 05:23:07 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:23:07 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:27:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:27:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 10:57:39 --> Severity: Notice --> Undefined index: who_purchase_mode E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 96
ERROR - 2018-02-01 10:57:39 --> Severity: Notice --> Undefined index: who_trans_amt E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 103
ERROR - 2018-02-01 10:57:39 --> Severity: Notice --> Undefined index: who_trans_no E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 104
ERROR - 2018-02-01 10:57:39 --> Severity: Notice --> Undefined index: who_purchase_mode E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 96
ERROR - 2018-02-01 10:57:39 --> Severity: Notice --> Undefined index: who_trans_amt E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 103
ERROR - 2018-02-01 10:57:39 --> Severity: Notice --> Undefined index: who_trans_no E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 104
ERROR - 2018-02-01 05:27:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:27:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:28:57 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:28:57 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 11:02:36 --> Severity: Notice --> Undefined variable: statusofcancel E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 103
ERROR - 2018-02-01 11:02:36 --> Severity: Notice --> Undefined index: who_bal_pay E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 103
ERROR - 2018-02-01 05:32:36 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:32:36 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 11:02:48 --> Severity: Notice --> Undefined index: who_bal_pay E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 103
ERROR - 2018-02-01 11:02:48 --> Severity: Notice --> Undefined index: who_bal_pay E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 103
ERROR - 2018-02-01 05:32:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:32:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:33:14 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:33:14 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 11:04:46 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-02-01 11:04:46 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-02-01 05:34:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-01 05:34:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-01 05:34:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-02-01 05:34:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-02-01 05:35:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:35:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:36:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:36:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:50:33 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:50:33 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:56:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 05:56:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:00:24 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:00:24 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:00:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:00:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:04:37 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:04:37 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:05:09 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:05:09 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:06:14 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:06:14 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:07:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:07:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:07:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:07:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:08:30 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:08:30 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:08:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:08:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:10:34 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:10:34 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:10:49 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:10:49 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:11:15 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:11:15 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:11:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:11:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:12:21 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:12:21 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:12:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:12:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:12:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:12:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:13:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:13:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:17:24 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:17:24 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:19:26 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:19:26 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:20:08 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:20:08 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:24:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:24:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:24:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:24:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:26:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:26:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:29:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:29:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:29:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:29:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:30:00 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:30:00 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:31:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:31:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:32:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:32:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:33:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:33:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:39:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:39:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:41:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:41:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:42:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:42:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:12:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 06:42:20 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:42:20 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 12:13:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-02-01 06:43:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:43:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:43:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:43:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:44:10 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:44:10 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:44:34 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:44:34 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:45:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:45:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:45:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:45:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:46:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:46:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:47:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:47:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:47:25 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:47:25 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:47:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:47:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:48:02 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:48:02 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:48:37 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:48:37 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:49:07 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:49:07 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:49:28 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:49:28 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:50:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:50:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:51:53 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:51:53 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:52:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:52:46 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:53:20 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:53:20 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:54:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:54:44 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:55:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:55:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:56:13 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:56:13 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:57:33 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:57:33 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:58:20 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:58:20 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:59:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 06:59:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:00:56 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:00:56 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:01:18 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:01:18 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:02:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:02:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:02:35 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-01 07:02:35 --> 404 Page Not Found: Wholesale/audio
