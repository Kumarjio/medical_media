<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: username D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 40
ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: password D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 41
ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 42
ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: ecode D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 43
ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: mobile D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 44
ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 45
ERROR - 2018-04-06 10:29:24 --> Severity: Notice --> Undefined variable: area_name D:\xampp\htdocs\duty\hotel\application\models\Vendor_model.php 46
ERROR - 2018-04-06 10:29:24 --> Query error: Unknown column 'username' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `username` = NULL, `password` = NULL, `name` = NULL, `emp_code` = NULL, `phone` = NULL, `user_type` = NULL, `area_name` = NULL, `email_id` = 'cssaigowtham@gmail.com'
WHERE `vendor_id` = '1'
ERROR - 2018-04-06 10:29:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->emp_code D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->area_name D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:46:48 --> Severity: Notice --> Undefined index: $loop->phone D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 74
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 75
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 76
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 77
ERROR - 2018-04-06 10:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 78
ERROR - 2018-04-06 10:53:02 --> Severity: Parsing Error --> syntax error, unexpected '$loop' (T_VARIABLE), expecting ',' or ';' D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 79
ERROR - 2018-04-06 07:34:43 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:55 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:34:56 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 07:35:03 --> 404 Page Not Found: Brand/index
ERROR - 2018-04-06 11:05:22 --> Severity: Notice --> Undefined property: Inventory_master::$Vendor_model D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:05:22 --> Severity: Error --> Call to a member function get_all_vendor() on null D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:06:28 --> Severity: Notice --> Undefined variable: emp D:\xampp\htdocs\duty\hotel\application\views\inventory\add_item.php 69
ERROR - 2018-04-06 11:15:17 --> Severity: Notice --> Undefined property: Inventory_master::$Vendor_model D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:15:17 --> Severity: Error --> Call to a member function get_all_item() on null D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:15:36 --> Severity: Notice --> Undefined property: Inventory_master::$inventory_model D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:15:36 --> Severity: Error --> Call to a member function get_all_item() on null D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:15:37 --> Severity: Notice --> Undefined property: Inventory_master::$inventory_model D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:15:37 --> Severity: Error --> Call to a member function get_all_item() on null D:\xampp\htdocs\duty\hotel\application\controllers\Inventory_master.php 15
ERROR - 2018-04-06 11:29:20 --> Severity: Notice --> Undefined variable: phone_no D:\xampp\htdocs\duty\hotel\application\models\Inventory_model.php 26
ERROR - 2018-04-06 11:29:20 --> Query error: Column 'item_qty' cannot be null - Invalid query: INSERT INTO `tbl_item` (`item_name`, `item_qty`, `item_price`, `item_parcel`, `item_date`, `is_delete`) VALUES ('idly', NULL, '5', '0', '2018-04-06', 0)
ERROR - 2018-04-06 11:32:03 --> Severity: Notice --> Undefined index: item_qty D:\xampp\htdocs\duty\hotel\application\views\inventory\add_item.php 76
ERROR - 2018-04-06 11:32:03 --> Severity: Notice --> Undefined index: item_parcel D:\xampp\htdocs\duty\hotel\application\views\inventory\add_item.php 78
ERROR - 2018-04-06 11:33:01 --> Severity: Notice --> Undefined index: item_qty D:\xampp\htdocs\duty\hotel\application\views\inventory\add_item.php 76
ERROR - 2018-04-06 11:33:01 --> Severity: Notice --> Undefined index: item_parcel D:\xampp\htdocs\duty\hotel\application\views\inventory\add_item.php 78
ERROR - 2018-04-06 08:25:33 --> 404 Page Not Found: Sales/index
ERROR - 2018-04-06 08:26:02 --> 404 Page Not Found: Sales/index
ERROR - 2018-04-06 11:58:54 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 66
ERROR - 2018-04-06 11:59:24 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 66
ERROR - 2018-04-06 11:59:56 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 66
ERROR - 2018-04-06 12:00:40 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 66
ERROR - 2018-04-06 12:02:34 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 66
ERROR - 2018-04-06 12:33:07 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:08 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:08 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:08 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:08 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:08 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:47 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:48 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:33:48 --> Severity: Error --> Call to undefined method CI_Loader::select_max() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:34:17 --> Severity: Error --> Call to undefined method CI_Loader::select() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 51
ERROR - 2018-04-06 12:35:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:37 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:38 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:38 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:38 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:38 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:38 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:38 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:55 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:57 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:57 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:35:57 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:05 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:05 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:05 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:05 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:06 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:17 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:18 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:18 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:18 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:18 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:18 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:18 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:19 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:36:53 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:47 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:48 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:48 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:48 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:48 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:48 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:48 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:49 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:49 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:37:59 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:00 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:38:01 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:23 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:24 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:40 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:40 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:40 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:41 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:46 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:47 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:39:53 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 52
ERROR - 2018-04-06 12:51:07 --> Severity: Notice --> Undefined variable: bill_no D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 53
ERROR - 2018-04-06 12:52:32 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 58
ERROR - 2018-04-06 12:52:32 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 58
ERROR - 2018-04-06 12:52:32 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 58
ERROR - 2018-04-06 12:52:32 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 58
ERROR - 2018-04-06 12:52:32 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 58
ERROR - 2018-04-06 12:52:32 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 58
ERROR - 2018-04-06 12:56:00 --> Severity: Warning --> date() expects at least 1 parameter, 0 given D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 65
ERROR - 2018-04-06 13:03:56 --> Severity: Warning --> Missing argument 1 for CI_DB_query_builder::from(), called in D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php on line 74 and defined D:\xampp\htdocs\duty\hotel\system\database\DB_query_builder.php 458
ERROR - 2018-04-06 13:03:56 --> Severity: Notice --> Undefined variable: from D:\xampp\htdocs\duty\hotel\system\database\DB_query_builder.php 460
ERROR - 2018-04-06 13:03:56 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2018-04-06 13:52:28 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 275
ERROR - 2018-04-06 13:52:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 275
ERROR - 2018-04-06 14:05:17 --> Severity: Notice --> Undefined index: emp D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 16
ERROR - 2018-04-06 14:07:41 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 380
ERROR - 2018-04-06 14:21:42 --> Severity: Error --> Call to undefined method Sales_model::get_all_item() D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 15
ERROR - 2018-04-06 14:22:55 --> Severity: Notice --> Undefined variable: item_price D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 23
ERROR - 2018-04-06 14:23:04 --> Severity: Notice --> Undefined variable: item_price D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 23
ERROR - 2018-04-06 15:03:16 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 15:03:16 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_item` (`item_name`, `item_price`, `item_date`, `is_delete`) VALUES (Array, '8', '2018-04-06', 0)
ERROR - 2018-04-06 15:56:38 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 15:56:38 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 15:56:38 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_item` (`item_name`, `item_price`, `item_date`, `is_delete`) VALUES (Array, Array, '2018-04-06', 0)
ERROR - 2018-04-06 17:12:00 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 17:12:00 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_item` (`item_name`, `item_price`, `item_date`, `is_delete`) VALUES (Array, '10', '2018-04-06', 0)
ERROR - 2018-04-06 17:13:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 17:13:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 17:13:17 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_item` (`item_name`, `item_price`, `item_date`, `is_delete`) VALUES (Array, Array, '2018-04-06', 0)
ERROR - 2018-04-06 17:31:40 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 28
ERROR - 2018-04-06 14:02:57 --> 404 Page Not Found: Sales_master/add_sales
ERROR - 2018-04-06 14:06:48 --> 404 Page Not Found: Sales_master/add_sales
ERROR - 2018-04-06 17:37:19 --> Severity: Warning --> extract() expects parameter 1 to be array, null given D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 26
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 28
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: sale_bill_date D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 29
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 30
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: sale_table_row D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 31
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: sale_table_name D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 32
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: parcel_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 33
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: sgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 34
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: cgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 35
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: stotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 36
ERROR - 2018-04-06 17:37:19 --> Severity: Notice --> Undefined variable: gtotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 37
ERROR - 2018-04-06 17:37:19 --> Query error: Column 'sale_bill_no' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_delete`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0)
ERROR - 2018-04-06 17:37:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 28
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: sale_bill_date D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 29
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 30
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: sale_table_row D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 31
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: sale_table_name D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 32
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: parcel_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 33
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: sgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 34
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: cgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 35
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: stotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 36
ERROR - 2018-04-06 17:38:06 --> Severity: Notice --> Undefined variable: gtotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 37
ERROR - 2018-04-06 17:38:06 --> Query error: Column 'sale_bill_no' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_delete`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0)
ERROR - 2018-04-06 17:38:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-06 17:38:55 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\hotel\system\database\DB_driver.php 1392
ERROR - 2018-04-06 17:38:55 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_delete`) VALUES ('SB2', '2018-04-06', 'SB2', '', Array, '0', '0.00', '0.00', '80', '80.00', 0, 0)
ERROR - 2018-04-06 18:00:47 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 62
ERROR - 2018-04-06 18:00:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 62
ERROR - 2018-04-06 18:01:02 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 62
ERROR - 2018-04-06 18:01:06 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 62
ERROR - 2018-04-06 18:01:08 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 62
ERROR - 2018-04-06 18:01:35 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 62
ERROR - 2018-04-06 18:04:34 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:04:34 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:04:34 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:11:43 --> Severity: Parsing Error --> syntax error, unexpected '?' D:\xampp\htdocs\duty\hotel\application\views\sales\add_sales.php 464
ERROR - 2018-04-06 18:12:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:12:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:12:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:12:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:12:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:12:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:12:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:12:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 14:42:57 --> 404 Page Not Found: Undefined/index
ERROR - 2018-04-06 14:44:07 --> 404 Page Not Found: Undefined/index
ERROR - 2018-04-06 14:44:26 --> 404 Page Not Found: Undefined/index
ERROR - 2018-04-06 14:44:46 --> 404 Page Not Found: Undefined/index
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 29
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: sale_bill_date D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 30
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 31
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: sale_table_row D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 32
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: sale_table_name D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 33
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: parcel_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 34
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: sgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 35
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: cgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 36
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: stotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 37
ERROR - 2018-04-06 18:17:32 --> Severity: Notice --> Undefined variable: gtotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 38
ERROR - 2018-04-06 18:17:32 --> Query error: Column 'sale_bill_no' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_delete`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0)
ERROR - 2018-04-06 18:17:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 29
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: sale_bill_date D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 30
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 31
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: sale_table_row D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 32
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: sale_table_name D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 33
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: parcel_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 34
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: sgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 35
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: cgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 36
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: stotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 37
ERROR - 2018-04-06 18:17:44 --> Severity: Notice --> Undefined variable: gtotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 38
ERROR - 2018-04-06 18:17:44 --> Query error: Column 'sale_bill_no' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_delete`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0)
ERROR - 2018-04-06 18:17:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 29
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: sale_bill_date D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 30
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: sales_bill_no D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 31
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: sale_table_row D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 32
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: sale_table_name D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 33
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: parcel_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 34
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: sgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 35
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: cgst_amt D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 36
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: stotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 37
ERROR - 2018-04-06 18:17:46 --> Severity: Notice --> Undefined variable: gtotal D:\xampp\htdocs\duty\hotel\application\models\Sales_model.php 38
ERROR - 2018-04-06 18:17:46 --> Query error: Column 'sale_bill_no' cannot be null - Invalid query: INSERT INTO `tbl_sales` (`sale_bill_no`, `bill_date`, `bill_time`, `sale_table_row`, `sale_table_name`, `parcel_amt`, `sgst_amt`, `cgst_amt`, `sales_total`, `sales_grand_total`, `status`, `is_delete`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0)
ERROR - 2018-04-06 18:17:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-06 18:18:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:18:33 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:18:33 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:18:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:18:41 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:18:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 136
ERROR - 2018-04-06 18:18:41 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 18:18:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 326
ERROR - 2018-04-06 14:52:49 --> 404 Page Not Found: Sales/getInvoice
ERROR - 2018-04-06 18:33:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 166
ERROR - 2018-04-06 18:33:25 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:36:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:36:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:36:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:38:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:38:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:39:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:39:12 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:39:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:39:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:41:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:41:48 --> Severity: Notice --> Undefined variable: invoice D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 95
ERROR - 2018-04-06 18:41:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 95
ERROR - 2018-04-06 18:41:48 --> Severity: Notice --> Undefined variable: sale D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 98
ERROR - 2018-04-06 18:41:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 98
ERROR - 2018-04-06 18:42:09 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:42:09 --> Severity: Notice --> Undefined index: item_name D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 98
ERROR - 2018-04-06 18:42:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 98
ERROR - 2018-04-06 18:44:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:44:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 98
ERROR - 2018-04-06 18:44:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:45:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:45:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:46:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:47:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:47:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:47:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:47:40 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:48:13 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:48:14 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:48:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:48:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:49:38 --> Query error: Table 'db_hotel.tbl_sale' doesn't exist - Invalid query: SELECT *
FROM `tbl_sale_items`
LEFT JOIN `tbl_sale` ON `tbl_sales`.`sal_id`=`tbl_sale_items`.`sale_item_id`
LEFT JOIN `tbl_item` ON `tbl_item`.`item_id`=`tbl_sale_items`.`sale_item_name`
WHERE `tbl_sales`.`sal_id` = '14'
ERROR - 2018-04-06 18:49:38 --> Query error: Unknown column 'tbl_sales.sal_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523020778
WHERE `tbl_sales`.`sal_id` = '14'
AND `id` = '92b7a74dab87955ca1853970564f6bcfb0a3809c'
ERROR - 2018-04-06 18:50:04 --> Query error: Table 'db_hotel.tbl_sale' doesn't exist - Invalid query: SELECT *
FROM `tbl_sale_items`
LEFT JOIN `tbl_sale` ON `tbl_sales`.`sal_id`=`tbl_sale_items`.`sale_item_id`
LEFT JOIN `tbl_item` ON `tbl_item`.`item_id`=`tbl_sale_items`.`sale_item_name`
WHERE `tbl_sale_items`.`sale_item_id` = '14'
ERROR - 2018-04-06 18:50:04 --> Query error: Unknown column 'tbl_sale_items.sale_item_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523020804
WHERE `tbl_sale_items`.`sale_item_id` = '14'
AND `id` = '92b7a74dab87955ca1853970564f6bcfb0a3809c'
ERROR - 2018-04-06 18:50:28 --> Query error: Table 'db_hotel.tbl_sale' doesn't exist - Invalid query: SELECT *
FROM `tbl_sale_items`
LEFT JOIN `tbl_sale` ON `tbl_sales`.`sal_id`=`tbl_sale_items`.`sale_ref_id`
LEFT JOIN `tbl_item` ON `tbl_item`.`item_id`=`tbl_sale_items`.`sale_item_name`
WHERE `tbl_sale_items`.`sale_ref_id` = '14'
ERROR - 2018-04-06 18:50:28 --> Query error: Unknown column 'tbl_sale_items.sale_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1523020828
WHERE `tbl_sale_items`.`sale_ref_id` = '14'
AND `id` = '92b7a74dab87955ca1853970564f6bcfb0a3809c'
ERROR - 2018-04-06 18:50:45 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:51:08 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:51:46 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:53:30 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:54:00 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:54:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:55:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:56:11 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:57:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:57:42 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:58:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:58:48 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:59:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:59:16 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:59:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:59:43 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 18:59:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:00:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:00:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:01:10 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:01:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:01:31 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:01:50 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:02:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:03:04 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:03:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\hotel\application\views\sales\sales_invoice.php 139
ERROR - 2018-04-06 19:03:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:04:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:05:11 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:05:49 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:06:36 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:06:55 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:07:15 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:08:07 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:08:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 15:54:09 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:57:03 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:57:11 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:57:45 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:57:46 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:57:46 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:57:46 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 15:58:11 --> Severity: Compile Error --> Non-abstract method Sales::sale_list() must contain body D:\xampp\htdocs\duty\hotel\application\controllers\Sales.php 20
ERROR - 2018-04-06 19:28:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:29:01 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-06 19:29:06 --> Query error: Unknown column 'tbl_sale_items.sales_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_sales`
JOIN `tbl_sale_items` ON `tbl_sale_items`.`sales_ref_id`=`tbl_sales`.`sal_id`
ERROR - 2018-04-06 19:31:58 --> Query error: Table 'db_hotel.tbl_items' doesn't exist - Invalid query: SELECT *
FROM `tbl_sales`
LEFT JOIN `tbl_sale_items` ON `tbl_sale_items`.`sale_ref_id`=`tbl_sales`.`sal_id`
JOIN `tbl_items` ON `tbl_items`.`item_id`=`tbl_sale_items`.`sale_item_name`
ERROR - 2018-04-06 19:32:24 --> Query error: Unknown column 'tbl_items.item_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_sales`
LEFT JOIN `tbl_sale_items` ON `tbl_sale_items`.`sale_ref_id`=`tbl_sales`.`sal_id`
LEFT JOIN `tbl_item` ON `tbl_items`.`item_id`=`tbl_sale_items`.`sale_item_name`
ERROR - 2018-04-06 19:43:19 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
