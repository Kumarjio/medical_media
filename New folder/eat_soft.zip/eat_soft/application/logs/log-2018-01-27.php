<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-27 04:08:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:08:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 09:38:27 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-27 04:08:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:08:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 09:38:32 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-27 04:08:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 04:08:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 09:38:37 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-27 04:21:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 04:21:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 09:51:44 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-27 04:21:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:21:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 09:51:50 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-27 04:23:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:23:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:24:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:24:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:26:42 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:26:42 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:26:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:26:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:27:43 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 04:27:43 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 09:58:42 --> Severity: Error --> Maximum execution time of 120 seconds exceeded E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2018-01-27 09:58:42 --> Severity: Error --> Maximum execution time of 120 seconds exceeded E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2018-01-27 09:58:42 --> Query error: Unknown column 'transfer_out_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1517027322
WHERE `transfer_out_ref_id` =0
AND `transfer_in_ref_id` =0
AND `sale_out_ref_id` =0
AND `id` = '59ba71a9d3b4f2e285a52f110fb32759183a2f70'
ERROR - 2018-01-27 09:58:42 --> Severity: Warning --> Cannot modify header information - headers already sent E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-27 04:29:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:29:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:29:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:29:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:29:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:29:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:29:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:29:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:29:40 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:29:40 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 09:59:44 --> Severity: Error --> Maximum execution time of 120 seconds exceeded E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2018-01-27 04:29:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:29:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:30:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:30:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:31:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:31:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:31:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:31:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:31:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:31:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:31:32 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:31:32 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:31:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:31:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:34:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:34:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:40:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:40:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 10:10:00 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 70
ERROR - 2018-01-27 04:40:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:40:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:40:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:40:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:41:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 04:41:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 04:44:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 04:44:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 04:44:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:44:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:44:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:44:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:45:36 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:45:36 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 04:46:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:46:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:50:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:50:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:51:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 04:51:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 04:51:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 04:51:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:51:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 04:51:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:10:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:10:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:10:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:10:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:11:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:11:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:13:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:13:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:14:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:14:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:17:23 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 05:17:23 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 05:18:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 05:18:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-27 05:18:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:18:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:18:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:18:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:21:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:21:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:23:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:23:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:24:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:24:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:25:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:25:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:25:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:25:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:26:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:26:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:27:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:27:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:27:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:27:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:27:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:27:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:28:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 05:28:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 05:59:00 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 48
ERROR - 2018-01-27 05:59:34 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 05:59:34 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:07:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:07:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:16:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:16:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:16:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:16:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:17:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:17:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:17:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:17:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:17:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:17:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:17:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:17:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:18:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:18:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:18:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:18:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:18:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:18:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:21:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:21:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:21:26 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:21:26 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:24:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:24:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:25:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:25:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:46:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:46:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:48:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:48:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:49:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:49:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:49:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:49:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:49:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:49:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:50:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:50:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:51:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:51:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 06:52:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 06:52:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 12:25:45 --> Severity: Compile Error --> Cannot redeclare Wholesale_model::addsalesEntry() E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 233
ERROR - 2018-01-27 06:59:29 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 06:59:29 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:07:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:07:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:07:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 07:07:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 07:07:30 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:07:30 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:07:33 --> 404 Page Not Found: Wholesale/wholesale_list_hold
ERROR - 2018-01-27 07:11:15 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:11:15 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:11:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:11:19 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:11:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 07:11:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 07:20:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 07:20:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 07:20:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 07:20:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 07:20:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 07:20:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-27 12:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-27 12:52:42 --> Severity: Notice --> Undefined index: whole_sales_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 107
ERROR - 2018-01-27 12:52:42 --> Severity: Notice --> Undefined index: whole_sales_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 108
ERROR - 2018-01-27 12:52:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 108
ERROR - 2018-01-27 12:52:42 --> Severity: Notice --> Undefined index: whole_sales_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 109
ERROR - 2018-01-27 07:22:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:22:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 12:53:48 --> Severity: Notice --> Undefined index: whole_sales_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 107
ERROR - 2018-01-27 12:53:48 --> Severity: Notice --> Undefined index: whole_sales_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 109
ERROR - 2018-01-27 07:23:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:23:48 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 12:54:07 --> Severity: Notice --> Undefined index: whole_sales_id E:\wamp\www\duty\mathewgarments\application\views\wholesale_list_hold.php 107
ERROR - 2018-01-27 07:24:08 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:24:08 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:24:34 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:24:34 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:25:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:25:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:27:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:27:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:28:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:28:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:30:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:30:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:31:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:31:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:32:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:32:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:32:35 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:32:35 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-27 07:36:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:36:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:44:43 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:44:43 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:45:49 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:45:49 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:46:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:46:01 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:53:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 07:53:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-27 13:23:40 --> Severity: Error --> Call to undefined method Retail_model::get_hold_item() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 130
ERROR - 2018-01-27 13:25:34 --> Severity: Notice --> Undefined variable: session_data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 131
ERROR - 2018-01-27 13:26:11 --> Severity: Notice --> Undefined variable: session_data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 131
ERROR - 2018-01-27 13:26:32 --> Severity: Notice --> Undefined variable: session_data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 131
ERROR - 2018-01-27 08:04:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:04:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:04:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:04:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:05:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:05:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:06:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:06:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:06:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:06:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 13:36:59 --> Severity: Notice --> Undefined variable: s_no E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 84
ERROR - 2018-01-27 13:36:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 84
ERROR - 2018-01-27 08:07:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:07:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:07:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:07:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:08:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:08:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 13:43:23 --> Severity: Parsing Error --> syntax error, unexpected end of file E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 312
ERROR - 2018-01-27 08:13:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:13:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:14:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:14:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:16:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:16:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:16:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 08:16:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:17:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-27 08:17:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-27 13:47:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-27 13:50:16 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 422
ERROR - 2018-01-27 08:20:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 08:20:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-27 13:50:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-27 08:21:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 08:21:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 37
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 49
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 57
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 64
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 72
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 84
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 113
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 121
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 131
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 143
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 270
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 275
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 280
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 285
ERROR - 2018-01-27 13:53:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 290
