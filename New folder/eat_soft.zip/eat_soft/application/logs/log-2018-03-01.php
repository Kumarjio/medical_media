<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-01 05:45:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 05:45:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 11:15:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:15:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:15:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 05:46:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 05:46:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 11:16:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:16:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:16:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 05:46:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 05:46:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 11:16:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:16:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:16:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 05:46:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 05:46:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 11:16:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:16:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:16:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:09:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 06:09:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 11:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:39:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:10:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 06:10:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 11:40:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:40:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:40:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:15:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 06:15:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 11:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:17:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 06:17:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 11:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 11:47:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:30:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 06:30:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 12:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:30:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-01 06:30:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-03-01 12:00:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:00:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:00:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:36:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 06:36:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 12:06:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:06:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:06:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:38:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 06:38:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 12:08:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:08:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:08:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: purchase_mode E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 219
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:08:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:43:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 06:43:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 12:13:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:13:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:13:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:43:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-01 06:43:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-01 12:13:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:13:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:13:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:44:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-01 06:44:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-03-01 12:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:14:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 06:45:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-03-01 06:45:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-03-01 12:15:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:15:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-03-01 12:15:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
