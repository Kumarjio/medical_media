<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-05 11:28:21 --> 404 Page Not Found: Audio/fail.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-05 11:28:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-04-05 11:28:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-04-05 11:28:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-04-05 11:28:25 --> 404 Page Not Found: Customer/audio
ERROR - 2018-04-05 11:28:25 --> 404 Page Not Found: Customer/audio
ERROR - 2018-04-05 11:28:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-04-05 11:28:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-04-05 11:28:38 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-04-05 11:28:38 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-04-05 11:49:06 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-04-05 11:49:06 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-04-05 11:49:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-04-05 11:49:20 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-04-05 11:49:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-04-05 11:49:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-04-05 11:49:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-04-05 11:49:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-04-05 12:01:25 --> 404 Page Not Found: Employee/index
ERROR - 2018-04-05 12:01:25 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:01:25 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:32:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 71
ERROR - 2018-04-05 15:32:58 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:32:58 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 71
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 71
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 71
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 71
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:33:20 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:34:17 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 71
ERROR - 2018-04-05 15:34:17 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:34:17 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 15:34:43 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:44 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:34:45 --> Severity: Notice --> Undefined variable: overall D:\xampp\htdocs\duty\hotel\application\views\dashboard.php 65
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 17
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 17
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 17
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 23
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 28
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 28
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 33
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 33
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 38
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 38
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 44
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 44
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 62
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 62
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 70
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 70
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 85
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 85
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 91
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 91
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 103
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 103
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 103
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 119
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 119
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 131
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 131
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 141
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 141
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 226
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:39:21 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 227
ERROR - 2018-04-05 15:46:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''admin\'  and is_delete = 0' at line 1 - Invalid query: select * from cp_admin_login where username = 'admin' and password = 'admin\'  and is_delete = 0
ERROR - 2018-04-05 15:46:30 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:46:30 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:16:42 --> 404 Page Not Found: Employee/index
ERROR - 2018-04-05 12:16:42 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:16:42 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:46:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''admin\'  and is_delete = 0' at line 1 - Invalid query: select * from cp_admin_login where username = 'admin' and password = 'admin\'  and is_delete = 0
ERROR - 2018-04-05 15:46:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:46:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:46:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''admin\'  and is_delete = 0' at line 1 - Invalid query: select * from cp_admin_login where username = 'admin' and password = 'admin\'  and is_delete = 0
ERROR - 2018-04-05 15:46:55 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:46:55 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:47:16 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_general.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 15:47:16 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_general.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:19:39 --> 404 Page Not Found: Goodsreceived/index
ERROR - 2018-04-05 12:19:39 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:19:39 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:26:42 --> 404 Page Not Found: Employee/index
ERROR - 2018-04-05 12:26:42 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:26:42 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:26:45 --> 404 Page Not Found: Employee/index
ERROR - 2018-04-05 12:26:45 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:26:45 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:32:39 --> 404 Page Not Found: Employee/index
ERROR - 2018-04-05 12:32:39 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:32:39 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:06:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-05 16:06:44 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 53
ERROR - 2018-04-05 12:37:00 --> 404 Page Not Found: Employee/addCustomer1
ERROR - 2018-04-05 12:37:00 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:37:00 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:07:06 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-05 16:07:06 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 53
ERROR - 2018-04-05 12:37:15 --> 404 Page Not Found: Employee/addCustomer1
ERROR - 2018-04-05 12:37:15 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:37:15 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:07:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-05 16:07:17 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 53
ERROR - 2018-04-05 16:10:15 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:15 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:15 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:15 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:25 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:25 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:25 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:25 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:50 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:50 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:50 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:50 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:51 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:51 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:51 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:51 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:52 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:53 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:54 --> Severity: Notice --> Undefined property: Employee_master::$Employee_model D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:54 --> Severity: Error --> Call to a member function get_all_employee() on null D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 15
ERROR - 2018-04-05 16:10:54 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:10:54 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_php.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 269
ERROR - 2018-04-05 16:11:26 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\hotel\application\views\employee\employee_list.php 53
ERROR - 2018-04-05 12:42:05 --> 404 Page Not Found: Employee/editCustomer1
ERROR - 2018-04-05 12:42:05 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:42:05 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:49:37 --> 404 Page Not Found: Employee/editCustomer1
ERROR - 2018-04-05 12:49:37 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:49:37 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:55:24 --> 404 Page Not Found: Employee/editCustomer1
ERROR - 2018-04-05 12:55:24 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 12:55:24 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:30:43 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:30:43 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:30:43 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:30:52 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:30:52 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:30:52 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:31:01 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:31:01 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:31:01 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:32:04 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:32:04 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:32:04 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:33:56 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:33:56 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:33:56 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:34:40 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:34:40 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:34:40 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:05 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:05 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:05 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:06 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:07 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:07 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:07 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:07 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:07 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:07 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:07 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:07 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:07 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:30 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:35:30 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:35:30 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:36:58 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:36:58 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:36:58 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:37:04 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:37:04 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:37:04 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 13:15:54 --> 404 Page Not Found: Employee/editCustomer1
ERROR - 2018-04-05 13:15:54 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 13:15:54 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 13:16:01 --> 404 Page Not Found: Customer/index
ERROR - 2018-04-05 13:16:01 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 13:16:01 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_404.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:32 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:32 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:32 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:50 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:50 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:50 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:50 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:50 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:50 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:50 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:50 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:50 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:46:51 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:48:18 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:48:18 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:48:18 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:48:22 --> Query error: Table 'db_hotel.tbl_branch' doesn't exist - Invalid query: SELECT *
FROM `tbl_branch`
ERROR - 2018-04-05 16:48:22 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 16:48:22 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:37 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:45 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:46 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:47 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:22:53 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:13 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:15 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\duty\hotel\application\views\include_css.php 4
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:23:33 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:24:51 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:25:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:19 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:20 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:21 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:26:24 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:00 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:01 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:02 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:27:23 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:08 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:11 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:12 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:29:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''admin\'  and is_delete = 0' at line 1 - Invalid query: select * from cp_admin_login where username = 'admin' and password = 'admin\'  and is_delete = 0
ERROR - 2018-04-05 17:29:37 --> Severity: Warning --> include(D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php): failed to open stream: No such file or directory D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 17:29:37 --> Severity: Warning --> include(): Failed opening 'D:\xampp\htdocs\duty\hotel\application\views\errors\html\error_db.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php 182
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:32:41 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:16 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:18 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:28 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:29 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:38 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:39 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:52 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:54 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:33:55 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:29 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:30 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:30 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:30 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:30 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:33 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:36:43 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:37:48 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:39:35 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 156
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:40:30 --> Severity: Notice --> Undefined index: user_type D:\xampp\htdocs\duty\hotel\application\views\menu_navigation.php 157
ERROR - 2018-04-05 17:41:59 --> Severity: Notice --> Undefined index: user_id D:\xampp\htdocs\duty\hotel\application\controllers\Dashboard.php 26
ERROR - 2018-04-05 14:12:08 --> 404 Page Not Found: Employee/editCustomer1
ERROR - 2018-04-05 14:18:42 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 28
ERROR - 2018-04-05 14:18:42 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 28
ERROR - 2018-04-05 14:18:43 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 28
ERROR - 2018-04-05 14:18:43 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 28
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: password D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 23
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 24
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: ecode D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 25
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: mobile D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 26
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 27
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: area_name D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 28
ERROR - 2018-04-05 18:17:39 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 30
ERROR - 2018-04-05 18:17:39 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('sdfsda', NULL, NULL, NULL, NULL, NULL, NULL, '2018-04-05', NULL, 0)
ERROR - 2018-04-05 18:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\duty\hotel\system\core\Exceptions.php:272) D:\xampp\htdocs\duty\hotel\system\core\Common.php 569
ERROR - 2018-04-05 18:17:56 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 25
ERROR - 2018-04-05 18:18:10 --> Severity: Notice --> Undefined variable: inps D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 25
ERROR - 2018-04-05 14:54:48 --> 404 Page Not Found: Employee/editCustomer1
ERROR - 2018-04-05 15:07:18 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 25
ERROR - 2018-04-05 15:07:18 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 25
ERROR - 2018-04-05 15:07:18 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 25
ERROR - 2018-04-05 15:07:18 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\duty\hotel\application\controllers\Employee_master.php 25
ERROR - 2018-04-05 15:21:03 --> 404 Page Not Found: Employee_master/edit_employee1
ERROR - 2018-04-05 19:29:57 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 21
ERROR - 2018-04-05 19:29:57 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 21
ERROR - 2018-04-05 19:29:57 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 21
ERROR - 2018-04-05 19:29:57 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 21
ERROR - 2018-04-05 19:30:55 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 38
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: username D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 39
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: password D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 40
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 41
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: ecode D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 42
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: mobile D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 43
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 44
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: area_name D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 45
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 47
ERROR - 2018-04-05 19:31:34 --> Severity: Notice --> Undefined variable: hidden_id D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 48
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: username D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 39
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: password D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 40
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: name D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 41
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: ecode D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 42
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: mobile D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 43
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 44
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: area_name D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 45
ERROR - 2018-04-05 19:32:58 --> Severity: Notice --> Undefined variable: email D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 47
ERROR - 2018-04-05 19:50:56 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 29
ERROR - 2018-04-05 19:50:56 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('sdfasd', 'asdfasd', 'asdfdsfasd', 'dfasdf', '22444', NULL, 'fsdfasd', '2018-04-05', 'sdfdas', 0)
ERROR - 2018-04-05 19:50:58 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 29
ERROR - 2018-04-05 19:50:58 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('sdfasd', 'asdfasd', 'asdfdsfasd', 'dfasdf', '22444', NULL, 'fsdfasd', '2018-04-05', 'sdfdas', 0)
ERROR - 2018-04-05 19:50:59 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 29
ERROR - 2018-04-05 19:50:59 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('sdfasd', 'asdfasd', 'asdfdsfasd', 'dfasdf', '22444', NULL, 'fsdfasd', '2018-04-05', 'sdfdas', 0)
ERROR - 2018-04-05 19:50:59 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 29
ERROR - 2018-04-05 19:50:59 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('sdfasd', 'asdfasd', 'asdfdsfasd', 'dfasdf', '22444', NULL, 'fsdfasd', '2018-04-05', 'sdfdas', 0)
ERROR - 2018-04-05 19:50:59 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 29
ERROR - 2018-04-05 19:50:59 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('sdfasd', 'asdfasd', 'asdfdsfasd', 'dfasdf', '22444', NULL, 'fsdfasd', '2018-04-05', 'sdfdas', 0)
ERROR - 2018-04-05 19:53:32 --> Severity: Notice --> Undefined variable: emp_type D:\xampp\htdocs\duty\hotel\application\models\Employee_model.php 29
ERROR - 2018-04-05 19:53:32 --> Query error: Column 'user_type' cannot be null - Invalid query: INSERT INTO `cp_admin_login` (`username`, `password`, `name`, `emp_code`, `phone`, `user_type`, `area_name`, `created_date`, `email_id`, `is_delete`) VALUES ('fgfd', 'gsdfgsd', 'sdfgsdf', 'sgsdf', '424524', NULL, 'sdfgsdf', '2018-04-05', 'sdfgsf', 0)
