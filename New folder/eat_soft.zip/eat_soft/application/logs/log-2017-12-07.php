<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-07 05:05:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:05:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:05:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:05:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:05:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:05:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:06:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:06:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:14:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:14:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:14:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:14:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:14:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:14:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:17:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:17:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 05:17:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 05:18:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:18:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:18:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:18:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:18:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:18:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:21:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:21:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:24:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:24:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:28:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:28:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:29:01 --> 404 Page Not Found: Goodsreceived/get_image
ERROR - 2017-12-07 05:33:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:33:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:36:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:36:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:36:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:36:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:37:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:37:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:07:16 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 37
ERROR - 2017-12-07 05:37:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:37:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:38:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:38:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:38:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:38:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:42:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:42:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:43:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:43:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:44:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:44:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:45:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:45:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:45:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:45:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:46:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:46:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:47:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:47:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:47:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:47:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:49:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 05:49:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 05:49:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:49:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:20:28 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 51
ERROR - 2017-12-07 10:20:28 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 116
ERROR - 2017-12-07 10:20:28 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 05:50:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:50:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:50:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:50:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:21:20 --> Severity: Notice --> Undefined variable: muinput D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 51
ERROR - 2017-12-07 10:21:20 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 116
ERROR - 2017-12-07 10:21:20 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 05:51:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:51:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:53:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:53:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:53:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:53:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:23:50 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 116
ERROR - 2017-12-07 10:23:50 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 05:53:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:53:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:54:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:54:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:24:47 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 116
ERROR - 2017-12-07 10:24:47 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 10:24:47 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 05:54:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:54:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:56:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:56:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:27:26 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 116
ERROR - 2017-12-07 10:27:26 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 10:27:26 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 10:27:26 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 05:57:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:57:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:57:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:57:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:59:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:59:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:29:50 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 10:29:50 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 131
ERROR - 2017-12-07 05:59:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 05:59:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:01:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:01:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:01:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:01:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:02:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:02:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:10:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:10:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:11:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:11:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:12:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:12:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 06:13:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:13:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:14:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:14:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:17:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:17:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:21:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:21:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:21:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:21:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:22:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:22:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:22:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:22:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:23:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:23:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:24:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:24:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:24:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:24:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:34:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:34:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:36:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:36:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:38:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:38:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:38:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:38:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:40:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:40:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:41:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:41:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:56:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:56:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:56:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:56:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:56:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 06:56:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:56:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 06:56:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:05:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:05:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:05:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:05:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:05:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:05:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:06:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 07:06:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 07:08:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:08:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:08:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:08:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:08:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:08:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:08:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:08:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:10:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:10:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:10:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:10:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:10:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:10:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:11:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:11:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:11:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:11:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:11:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:11:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:11:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:11:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:13:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:13:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:15:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:15:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:15:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:15:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:15:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:15:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:17:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:17:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:18:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:18:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:19:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:19:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:19:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:19:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:26:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:26:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:26:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:26:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:26:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:26:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:27:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:27:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:27:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:27:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:27:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:27:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:27:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:27:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:28:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:28:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:28:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:28:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:28:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:28:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:29:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:29:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:29:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:29:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:29:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:29:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:30:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:30:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:30:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:30:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:30:26 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-07 07:30:26 --> 404 Page Not Found: Size/audio
ERROR - 2017-12-07 07:30:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 07:30:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 07:31:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:31:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:31:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:31:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:31:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:31:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:36:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:36:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:37:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 07:37:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 07:37:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:37:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:37:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:37:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:46:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:46:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:46:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:46:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:46:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:46:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:47:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 07:47:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 07:47:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 07:47:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:05:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:05:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:05:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 08:05:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 08:05:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 08:05:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 08:05:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 08:05:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 08:05:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:05:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:06:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:06:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:06:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:06:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:06:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:06:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:06:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:06:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:06:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:09:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:09:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:09:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:09:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:09:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:09:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:10:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:10:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:10:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:10:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:11:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:11:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:11:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:11:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:11:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:11:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:11:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:11:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:12:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:12:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:13:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:13:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:18:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:18:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:19:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 08:19:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:19:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:19:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 08:45:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 08:45:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:33:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:33:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:33:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:33:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:35:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:35:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:35:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:35:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:35:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:35:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:36:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:36:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:37:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:37:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:37:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:37:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:37:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:37:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:37:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:37:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:38:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:38:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:38:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:38:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:43:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:43:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:43:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:43:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:47:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:47:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:47:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:47:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:48:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:48:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:48:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:48:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:48:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:48:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:50:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:50:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:50:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:50:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:53:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:53:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:59:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:59:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:59:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:59:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 09:59:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 09:59:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:04:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:04:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:04:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:04:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:04:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:04:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:05:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:05:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:05:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:05:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:07:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:07:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:07:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:07:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:08:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:08:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:11:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:11:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:12:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:12:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:14:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:14:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:16:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:16:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:16:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:16:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:22:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:22:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:23:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:23:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:23:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:23:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:27:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:27:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:27:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:27:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:28:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:28:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:31:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:31:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:32:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 10:32:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:32:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:32:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 10:33:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 10:33:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:20:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:20:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:20:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:20:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:22:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:22:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:22:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:22:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:22:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:22:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:23:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:23:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:23:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:23:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:23:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:23:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:24:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:24:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:26:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:26:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:31:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:31:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:34:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:34:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:34:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:34:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:36:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:36:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:36:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:36:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:08:04 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 20
ERROR - 2017-12-07 11:38:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:38:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:38:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:38:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:39:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:39:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:45:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 11:45:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:45:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:45:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 11:50:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 11:50:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:05:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:05:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:14:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:14:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 16:44:18 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2017-12-07 16:44:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` = `Array`' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` = `Array`
ERROR - 2017-12-07 12:15:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:15:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:45:16 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2017-12-07 16:45:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` = `Array`' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` = `Array`
ERROR - 2017-12-07 16:45:16 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512645316
WHERE `branch_id` = `Array`
AND `id` = '5d251c2058bab5974f786ddad3a9b18470f51d7c'
ERROR - 2017-12-07 12:15:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:15:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:17:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:17:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:47:58 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 30
ERROR - 2017-12-07 16:47:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` IS NULL' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` IS NULL
ERROR - 2017-12-07 16:47:58 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512645478
WHERE `branch_id` IS NULL
AND `id` = '5d251c2058bab5974f786ddad3a9b18470f51d7c'
ERROR - 2017-12-07 12:18:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:18:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 16:48:27 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 30
ERROR - 2017-12-07 12:18:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:18:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:49:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 30
ERROR - 2017-12-07 16:49:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` IS NULL' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` IS NULL
ERROR - 2017-12-07 16:49:02 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512645542
WHERE `branch_id` IS NULL
AND `id` = '5d251c2058bab5974f786ddad3a9b18470f51d7c'
ERROR - 2017-12-07 12:19:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:19:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:49:22 --> Severity: Notice --> Undefined variable: storage_name D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 30
ERROR - 2017-12-07 16:49:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 30
ERROR - 2017-12-07 16:49:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` = 'Array'' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` = 'Array'
ERROR - 2017-12-07 12:19:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:19:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 16:50:01 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\controllers\Dashboard.php 56
ERROR - 2017-12-07 12:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:50:41 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2017-12-07 16:50:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` = `Array`' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` = `Array`
ERROR - 2017-12-07 16:50:41 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512645641
WHERE `branch_id` = `Array`
AND `id` = 'e37bd7698ecc681fc5e16f1b0f78760856281c77'
ERROR - 2017-12-07 12:22:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:22:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:52:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `branch_id` = '1'' at line 2 - Invalid query: SELECT `branch_id`, `branch_name`
WHERE `branch_id` = '1'
ERROR - 2017-12-07 16:52:43 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512645763
WHERE `branch_id` = '1'
AND `id` = 'e37bd7698ecc681fc5e16f1b0f78760856281c77'
ERROR - 2017-12-07 12:23:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:23:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 16:53:47 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\application\controllers\Dashboard.php 56
ERROR - 2017-12-07 12:24:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:24:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:25:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:25:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:25:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:25:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:26:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:26:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:26:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:26:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:26:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:26:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:27:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:27:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 12:27:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 12:27:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:35:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 12:35:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:05:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:05:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:06:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:06:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 17:36:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2017-12-07 17:36:05 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2017-12-07 17:36:05 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `branch_id`, `branch_name`
FROM `tbl_branch`
WHERE `branch_id` = `Array`
AND `branch_id` = `Array`
ERROR - 2017-12-07 17:36:05 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512648365
WHERE `branch_id` = `Array`
AND `branch_id` = `Array`
AND `id` = '938d250d1e27426e127ddbd12e4777998183f6b8'
ERROR - 2017-12-07 13:06:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:06:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:07:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:07:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 17:37:33 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 35
ERROR - 2017-12-07 17:38:06 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 35
ERROR - 2017-12-07 13:08:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:08:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 17:38:21 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: SELECT `branch_id`, `branch_name`
FROM `tbl_branch`
WHERE `lot` = '1'
AND `lot` = '2'
ERROR - 2017-12-07 17:38:21 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512648501
WHERE `lot` = '1'
AND `lot` = '2'
AND `id` = '938d250d1e27426e127ddbd12e4777998183f6b8'
ERROR - 2017-12-07 13:08:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:08:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 17:38:39 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: SELECT `branch_id`, `branch_name`
FROM `tbl_branch`
WHERE `lot` IN('1')
AND `lot` IN('2')
ERROR - 2017-12-07 17:38:39 --> Query error: Unknown column 'lot' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512648519
WHERE `lot` IN('1')
AND `lot` IN('2')
AND `id` = '938d250d1e27426e127ddbd12e4777998183f6b8'
ERROR - 2017-12-07 13:08:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:08:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:09:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:09:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:10:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:10:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:10:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:10:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:11:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:11:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:12:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:12:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 17:42:43 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512648763
WHERE `branch_id` IN('1')
AND `branch_id` IN('2')
AND `id` = '1ba3fce27d6deaf1f96df9a16a5548b2d0608f75'
ERROR - 2017-12-07 13:13:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 13:13:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-07 13:13:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:13:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:14:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:14:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:14:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:14:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:16:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:16:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:16:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:16:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 17:46:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 32
ERROR - 2017-12-07 17:46:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 17:46:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 32
ERROR - 2017-12-07 17:46:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 13:17:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:17:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:17:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:17:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:19:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:19:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:20:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:20:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:20:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:20:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:22:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:22:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 17:52:04 --> Severity: Warning --> array_push() expects at least 2 parameters, 1 given D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 17:52:04 --> Severity: Warning --> array_push() expects at least 2 parameters, 1 given D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 13:22:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:22:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 17:52:22 --> Severity: Error --> Call to undefined function push() D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 13:25:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:25:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:26:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:26:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 17:56:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 13:26:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:26:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:26:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:26:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:27:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:27:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:32:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:32:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:33:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:33:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:35:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:35:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 18:06:32 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 40
ERROR - 2017-12-07 13:36:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:36:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:37:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:37:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:38:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:38:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:38:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:38:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:40:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:40:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 18:10:57 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, object given D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 33
ERROR - 2017-12-07 13:44:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:44:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:44:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:44:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:45:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:45:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:46:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:46:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:46:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:46:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:47:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:47:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:49:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:49:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:49:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:49:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:52:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:52:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:52:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:52:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:55:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:55:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:56:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:56:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:56:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-07 13:56:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-07 13:56:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-07 13:56:46 --> 404 Page Not Found: Product/audio
