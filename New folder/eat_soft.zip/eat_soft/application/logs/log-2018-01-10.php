<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-10 05:02:33 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-10 05:02:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 05:02:43 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 05:02:43 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 10:32:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-10 10:46:10 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sales_item`
WHERE `sales_id` = '3'
AND `sales_rate` = '250'
ERROR - 2018-01-10 10:46:10 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515561370
WHERE `sales_id` = '3'
AND `sales_rate` = '250'
AND `id` = '14cb812c5a3120023354c4eb7a1fec2235f6610d'
ERROR - 2018-01-10 10:47:30 --> Query error: Unknown column 'invoice' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sales_item`
WHERE `invoice` = 'RB003'
AND `sales_rate` = '250'
ERROR - 2018-01-10 10:47:30 --> Query error: Unknown column 'invoice' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515561450
WHERE `invoice` = 'RB003'
AND `sales_rate` = '250'
AND `id` = '14cb812c5a3120023354c4eb7a1fec2235f6610d'
ERROR - 2018-01-10 10:47:53 --> Query error: Unknown column 'invoice' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sales_item`
WHERE `invoice` = 'RB003'
ERROR - 2018-01-10 10:47:53 --> Query error: Unknown column 'invoice' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515561473
WHERE `invoice` = 'RB003'
AND `id` = '14cb812c5a3120023354c4eb7a1fec2235f6610d'
ERROR - 2018-01-10 10:49:02 --> Query error: Unknown column 'invoice' in 'where clause' - Invalid query: SELECT *
FROM `tbl_sales_item`
WHERE `invoice` = 'RB003'
ERROR - 2018-01-10 10:49:02 --> Query error: Unknown column 'invoice' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515561542
WHERE `invoice` = 'RB003'
AND `id` = '14cb812c5a3120023354c4eb7a1fec2235f6610d'
ERROR - 2018-01-10 10:51:39 --> Severity: Parsing Error --> syntax error, unexpected 'get' (T_STRING) E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 319
ERROR - 2018-01-10 10:51:46 --> Severity: Notice --> Undefined index: sales_ref_id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 319
ERROR - 2018-01-10 10:52:43 --> Query error: Table 'db_methew_gar.sales_rate' doesn't exist - Invalid query: SELECT DISTINCT *
FROM (`sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `invoice`, `sales_ref_id`)
LEFT JOIN `tbl_sales_item` ON `tbl_sales_item`.`sales_ref_id`=`tbl_sales`.`sales_id`
WHERE `sales_id` = '3'
ERROR - 2018-01-10 10:52:43 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515561763
WHERE `sales_id` = '3'
AND `id` = '14cb812c5a3120023354c4eb7a1fec2235f6610d'
ERROR - 2018-01-10 10:53:07 --> Query error: Table 'db_methew_gar.sales_rate' doesn't exist - Invalid query: SELECT DISTINCT *
FROM (`sales_rate`, `style`, `pro_name`, `pro_hsn`, `sgst`, `sgst_amt`, `invoice`, `sales_ref_id`)
LEFT JOIN `tbl_sales_item` ON `tbl_sales_item`.`sales_ref_id`=`tbl_sales`.`sales_id`
WHERE `sales_id` = '3'
ERROR - 2018-01-10 10:53:07 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515561787
WHERE `sales_id` = '3'
AND `id` = '14cb812c5a3120023354c4eb7a1fec2235f6610d'
ERROR - 2018-01-10 10:58:34 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting variable (T_VARIABLE) or '$' E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 319
ERROR - 2018-01-10 10:58:50 --> Severity: Parsing Error --> syntax error, unexpected ''style'' (T_CONSTANT_ENCAPSED_STRING) E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 319
ERROR - 2018-01-10 11:11:30 --> Severity: Parsing Error --> syntax error, unexpected ',' E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-10 11:12:18 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-10 11:12:18 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-10 11:12:18 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-10 11:12:18 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-10 11:12:18 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:24:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 121
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 135
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:27:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 150
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 123
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 137
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 152
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 123
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 137
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:28:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 152
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 112
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 117
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 117
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 122
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 131
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 136
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 146
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 151
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 112
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 117
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 117
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 122
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 131
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 136
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 146
ERROR - 2018-01-10 11:34:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 151
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 119
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 133
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 143
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 148
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 119
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 133
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 143
ERROR - 2018-01-10 11:35:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 148
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 105
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 124
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 139
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 105
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 124
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 139
ERROR - 2018-01-10 11:35:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 104
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 123
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 138
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 143
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 104
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 123
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 138
ERROR - 2018-01-10 11:36:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 143
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:37:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:37:56 --> Severity: Parsing Error --> syntax error, unexpected end of file E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 202
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:38:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 104
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 123
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 138
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 143
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 104
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 109
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 114
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 123
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 128
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 138
ERROR - 2018-01-10 11:39:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 143
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 105
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 124
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 139
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 105
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 124
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 139
ERROR - 2018-01-10 11:41:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:41:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:41:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:42:49 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:42:49 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:42:49 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:42:49 --> Severity: Notice --> Undefined variable: count_data E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 97
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:42:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 106
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 111
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 116
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 125
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 130
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 140
ERROR - 2018-01-10 11:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 145
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:46:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:47:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:48:58 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 99
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:49:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:50:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:50:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:51:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:52:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:52:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:53:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:54:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:54:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:55:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:55:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:55:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 11:56:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 06:27:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 06:27:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 06:27:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:27:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:28:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:28:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:32:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:32:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:32:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:32:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:32:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 06:32:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:23:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:23:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:23:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 07:23:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 07:23:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 07:23:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 12:53:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 12:56:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 07:33:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 07:33:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 07:34:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:34:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:35:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:35:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:38:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:38:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:39:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:39:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:42:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:42:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 07:42:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 07:42:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 07:42:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 07:42:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:12:53 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-10 13:12:53 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-10 13:12:53 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-10 13:12:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 13:12:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-10 13:12:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 07:42:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:42:54 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 13:16:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 07:46:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:46:09 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 13:16:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 07:46:30 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:46:30 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 13:16:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 07:46:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:46:51 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 13:16:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 07:46:55 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:46:55 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 13:18:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 07:48:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:48:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 07:48:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 07:48:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 07:49:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 07:49:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 07:49:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 07:49:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 07:52:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 07:52:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 13:33:24 --> Severity: Warning --> require(fpdf.php): failed to open stream: No such file or directory E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:33:24 --> Severity: Compile Error --> require(): Failed opening required 'fpdf.php' (include_path='.;C:\php\pear') E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:34:03 --> Severity: Warning --> require(fpdf.php): failed to open stream: No such file or directory E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:34:03 --> Severity: Compile Error --> require(): Failed opening required 'fpdf.php' (include_path='.;C:\php\pear') E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:46:45 --> Severity: Warning --> require(fpdf.php): failed to open stream: No such file or directory E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:46:45 --> Severity: Compile Error --> require(): Failed opening required 'fpdf.php' (include_path='.;C:\php\pear') E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:48:28 --> Severity: Parsing Error --> syntax error, unexpected '?>' E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 63
ERROR - 2018-01-10 13:49:29 --> Severity: Warning --> require(fpdf.php): failed to open stream: No such file or directory E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:49:29 --> Severity: Compile Error --> require(): Failed opening required 'fpdf.php' (include_path='.;C:\php\pear') E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:50:17 --> Severity: Warning --> require(fpdf.php): failed to open stream: No such file or directory E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:50:17 --> Severity: Compile Error --> require(): Failed opening required 'fpdf.php' (include_path='.;C:\php\pear') E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:50:39 --> Severity: Warning --> require(fpdf.php): failed to open stream: No such file or directory E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:50:39 --> Severity: Compile Error --> require(): Failed opening required 'fpdf.php' (include_path='.;C:\php\pear') E:\wamp\www\duty\mathewgarments\application\views\code128.php 42
ERROR - 2018-01-10 13:51:19 --> Severity: Error --> Class 'emberlabs\Barcode\BarcodeBase' not found E:\wamp\www\duty\mathewgarments\application\views\code128.php 14
ERROR - 2018-01-10 13:51:37 --> Severity: Error --> Class 'BarcodeBase' not found E:\wamp\www\duty\mathewgarments\application\views\code128.php 14
ERROR - 2018-01-10 13:52:25 --> Severity: Error --> Call to undefined function getBar() E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 63
ERROR - 2018-01-10 08:22:35 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 08:22:35 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 08:40:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 08:40:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 08:40:26 --> 404 Page Not Found: Barcode/single_pro_barcode30
ERROR - 2018-01-10 08:40:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 08:40:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 09:25:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 09:25:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 14:55:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:55:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:55:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:55:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:55:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:55:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:58:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:58:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:58:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:59:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:59:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 14:59:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:00:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:00:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:00:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:00:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:00:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:00:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:01:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:01:29 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:01:29 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:01:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:01:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:01:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:02:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:03:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:04:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:05:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:05:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:05:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:06:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:07:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:07:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:07:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:07:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:07:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:07:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:08:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:08:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:08:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:08:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:08:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:08:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:09:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:09:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:09:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:09:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:09:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:09:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:10:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:10:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:10:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:11:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:12:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:12:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:12:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:13:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:13:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:13:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:13:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:13:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:13:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:31 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:14:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:51 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:15:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:16:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:16:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:16:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:22:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:22:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:22:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:22:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:22:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:22:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:24:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:24:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:24:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:25:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:25:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:25:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:25:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:25:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:25:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:26:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:27:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:27:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:27:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:27:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:27:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:27:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:28:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:28:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:28:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:28:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:28:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:28:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:29 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:29:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:30:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:31:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:32:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:35 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:33:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:39:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:39:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 10:11:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:11:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:11:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 10:11:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 15:46:36 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-10 15:46:36 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-10 10:16:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 10:16:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 10:16:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 10:16:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 10:19:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:19:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 15:49:41 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-10 15:49:41 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-10 15:49:41 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-10 15:49:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:49:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-10 15:49:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 10:19:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 10:19:41 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 15:49:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 10:19:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 10:19:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 15:50:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 10:20:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 10:20:06 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-10 10:20:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:20:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:23:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:23:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:23:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:23:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 15:53:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:53:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:53:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:36 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:36 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 15:55:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 10:26:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:26:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:26:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:26:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 15:56:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 15:56:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 15:56:29 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 15:56:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 15:56:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 15:56:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 15:56:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 15:56:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 15:56:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 10:26:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:26:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:26:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:26:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:26:37 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 10:26:37 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 10:26:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:26:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 15:56:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 15:56:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 15:57:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 15:57:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 15:57:58 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 15:57:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 15:57:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 15:57:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 15:57:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 15:57:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 15:57:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 10:28:26 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 10:28:26 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 16:00:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 16:00:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 16:01:16 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 16:01:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 16:01:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 16:01:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 16:01:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 16:01:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 16:01:35 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 16:01:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 16:01:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 16:01:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 16:01:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 16:01:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 16:01:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 10:32:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 10:32:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 10:38:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:38:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:38:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:38:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 16:09:18 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-10 16:09:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-10 16:09:33 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-10 16:09:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-10 16:09:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-10 16:09:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-10 16:09:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-10 16:09:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-10 16:09:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-10 16:09:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-10 16:09:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-10 16:09:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-10 16:09:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-10 16:09:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-10 16:09:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-10 10:40:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:40:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:42:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:42:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:43:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:43:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:43:14 --> 404 Page Not Found: Branch/audio
ERROR - 2018-01-10 10:43:14 --> 404 Page Not Found: Branch/audio
ERROR - 2018-01-10 10:43:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:43:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:43:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:43:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:43:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:43:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-10 10:45:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:45:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:47:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:47:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:50:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:50:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 16:20:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 16:20:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 16:21:03 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 16:21:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 16:21:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 16:21:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 16:21:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 16:21:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 16:21:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 10:51:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:51:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:52:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 10:52:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 10:52:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 10:52:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 11:09:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:09:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 16:39:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:39:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:39:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:39:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:39:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:39:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:39:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:40:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:40:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:42:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:42:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:42:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:43:50 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:44:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:44:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:44:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:44:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:44:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:45:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:45:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:45:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:45:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:46:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:46:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:47:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:47:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:49:36 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:49:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 16:49:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-10 11:22:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:22:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:22:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:22:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:25:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:25:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:25:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 11:25:57 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 16:56:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 16:57:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 11:27:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:27:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:27:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:27:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:28:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:28:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 16:58:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 16:58:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 16:58:46 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 16:58:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 16:58:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 16:58:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 16:58:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 16:58:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 16:58:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 11:29:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:29:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:33:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:33:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 17:10:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:10:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:10:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:10:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:11:56 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 17:11:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 17:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 17:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 17:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 17:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 17:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 11:42:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:42:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:51:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:51:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:51:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:51:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:52:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:52:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:52:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:52:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:54:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:54:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:54:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:54:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:56:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:56:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-10 11:57:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 11:57:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:57:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 11:57:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 17:27:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:42 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:52 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:27:59 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:27:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:15 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:20 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:35 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:39 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:42 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:45 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:52 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:55 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:28:59 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:28:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:29:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:29:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:29:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:29:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:29:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 17:29:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 17:29:11 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 17:29:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 17:29:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 17:29:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 303
ERROR - 2018-01-10 17:29:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 17:29:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 17:29:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 11:59:53 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 11:59:53 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 12:00:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 12:00:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 12:00:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 12:00:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 12:00:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 12:00:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 12:16:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 12:16:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 12:16:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 12:16:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 17:48:31 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:36 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:40 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:42 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:52 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:54 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:56 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:48:57 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 17:48:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 17:49:06 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-10 17:49:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-10 17:49:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-10 17:49:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-10 17:49:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 307
ERROR - 2018-01-10 17:49:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-10 17:49:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-10 17:49:30 --> Query error: Unknown column 'cus_no' in 'field list' - Invalid query: INSERT INTO `tbl_sales` (`invoice`, `cus_name`, `cus_no`, `purchase_mode`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `emp_id`, `sale_type`, `get_pay`, `bal_pay`, `pdate`) VALUES ('WB007', 'MUASTHAK', '8124498572', 'cash', '400', '420.00', '10.00', '10.00', 'emp001', 'RP', '500', '80.00', '2018-01-10')
ERROR - 2018-01-10 12:20:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 12:20:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 12:59:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 12:59:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:14:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:14:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:14:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:14:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 18:45:09 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 18:45:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 18:45:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 18:45:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 18:45:20 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 18:45:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 18:45:23 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 18:45:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 18:45:28 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-10 18:45:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-10 18:47:52 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-10 18:47:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-10 18:47:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-10 18:47:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 305
ERROR - 2018-01-10 18:47:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 307
ERROR - 2018-01-10 18:47:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-10 18:47:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 309
ERROR - 2018-01-10 13:18:11 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-10 13:18:11 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-10 13:19:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:19:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:19:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:19:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:19:30 --> 404 Page Not Found: Retail/wholes_bill
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 71
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 76
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 108
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 113
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 118
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 127
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 132
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 142
ERROR - 2018-01-10 18:49:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 147
ERROR - 2018-01-10 13:19:58 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:19:58 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:26:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 13:26:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-10 13:29:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:29:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:30:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:30:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:30:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:30:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:31:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:31:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:32:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 13:32:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 13:32:56 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:32:56 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:34:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:34:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:34:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:34:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:36:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 13:36:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-10 14:31:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 14:31:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 14:31:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 14:31:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 20:01:39 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-10 20:01:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-10 20:01:42 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 20:01:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 20:01:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 20:01:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 20:01:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 20:01:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-10 20:01:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-10 14:32:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 14:32:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 20:02:04 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-10 20:02:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-10 20:02:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 20:02:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-10 20:02:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-10 20:02:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-10 20:02:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-10 14:32:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 14:32:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 14:49:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-10 14:49:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 14:49:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-10 14:49:40 --> 404 Page Not Found: Audio/alert.mp3
