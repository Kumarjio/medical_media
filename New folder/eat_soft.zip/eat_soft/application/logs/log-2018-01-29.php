<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-29 10:51:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\wamp\www\duty\math\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2018-01-29 10:51:00 --> Unable to connect to the database
ERROR - 2018-01-29 05:21:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 05:21:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 05:21:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 05:21:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 05:48:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 05:48:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 05:54:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 05:54:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 06:39:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 06:39:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 06:39:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 06:39:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 06:39:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 06:39:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 30
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 50
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 58
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 65
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 73
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 114
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 122
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 144
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 271
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 276
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 281
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 286
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 291
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 30
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 50
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 58
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 65
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 73
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 114
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 122
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 144
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 271
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 276
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 281
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 286
ERROR - 2018-01-29 12:09:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 291
ERROR - 2018-01-29 12:10:16 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\math\application\models\Goodsreceived_model.php 422
ERROR - 2018-01-29 06:40:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 06:40:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 06:40:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 06:40:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 06:41:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 06:41:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 06:52:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 06:52:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 08:11:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 08:11:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 08:14:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 08:14:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 08:14:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 08:14:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 09:28:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 09:28:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 10:15:58 --> Severity: Parsing Error --> syntax error, unexpected '$newrow' (T_VARIABLE) E:\wamp\www\duty\math\application\controllers\Barcode.php 96
ERROR - 2018-01-29 10:36:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 10:36:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 10:36:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 10:36:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 10:46:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 10:46:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 10:51:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 10:51:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 10:54:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 10:54:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 11:23:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 11:23:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 12:51:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 12:51:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:03:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:03:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:03:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:03:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:08:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:08:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:08:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:08:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:10:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:10:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 30
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 50
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 58
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 65
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 73
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 114
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 122
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 144
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 271
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 276
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 281
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 286
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 291
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 30
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 50
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 58
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 65
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 73
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 114
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 122
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 144
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 271
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 276
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 281
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 286
ERROR - 2018-01-29 18:40:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 291
ERROR - 2018-01-29 18:42:11 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\math\application\models\Goodsreceived_model.php 422
ERROR - 2018-01-29 13:12:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:12:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:13:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:13:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:13:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:13:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:22:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:22:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:22:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:22:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:22:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:22:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:22:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-29 13:22:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-29 13:23:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:23:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:24:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:24:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 18:54:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\branch_edit.php 14
ERROR - 2018-01-29 18:54:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\math\application\views\branch_edit.php 24
ERROR - 2018-01-29 18:54:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\math\application\views\branch_edit.php 38
ERROR - 2018-01-29 18:54:05 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\branch_edit.php 14
ERROR - 2018-01-29 18:54:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\math\application\views\branch_edit.php 24
ERROR - 2018-01-29 18:54:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\math\application\views\branch_edit.php 38
ERROR - 2018-01-29 13:24:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:24:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:24:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:24:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:24:33 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:24:33 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:24:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:24:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:24:40 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:24:40 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:29:42 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:29:42 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:30:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:30:19 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:19 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:30:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:30:27 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:27 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:30:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:30:38 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:38 --> 404 Page Not Found: Productcreation/audio
ERROR - 2018-01-29 13:30:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:30:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:32:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:32:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:32:58 --> 404 Page Not Found: Brand/audio
ERROR - 2018-01-29 13:32:58 --> 404 Page Not Found: Brand/audio
ERROR - 2018-01-29 13:33:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:33:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:33:23 --> 404 Page Not Found: Brand/audio
ERROR - 2018-01-29 13:33:23 --> 404 Page Not Found: Brand/audio
ERROR - 2018-01-29 13:33:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:33:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:34:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:34:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:34:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:34:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 19:04:55 --> Query error: Table 'db_methew_gar.tbl_unit' doesn't exist - Invalid query: SELECT *
FROM `tbl_unit`
ORDER BY `unit_id` DESC
ERROR - 2018-01-29 19:04:55 --> Query error: Unknown column 'unit_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1517232895
WHERE `id` = 'b2444e47d263743c7e58f96f18e076e8a8cf4d5a'
ORDER BY `unit_id` DESC
ERROR - 2018-01-29 13:35:11 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:35:11 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:35:21 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:35:21 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:35:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:35:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:02 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:02 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:06 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:06 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:11 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:11 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:17 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:17 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:24 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:24 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:30 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:30 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:41 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:41 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:47 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:47 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:36:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:36:59 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:36:59 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:03 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:03 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:10 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:10 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:17 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:17 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:23 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:23 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:28 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:28 --> 404 Page Not Found: Size/audio
ERROR - 2018-01-29 13:37:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:49 --> 404 Page Not Found: Material/audio
ERROR - 2018-01-29 13:37:49 --> 404 Page Not Found: Material/audio
ERROR - 2018-01-29 13:37:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:37:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:37:58 --> 404 Page Not Found: Material/audio
ERROR - 2018-01-29 13:37:58 --> 404 Page Not Found: Material/audio
ERROR - 2018-01-29 13:38:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:28 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:28 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:35 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:35 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:40 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:40 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:45 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:45 --> 404 Page Not Found: Color/audio
ERROR - 2018-01-29 13:38:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:38:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:38:59 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:38:59 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:39:37 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:39:37 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:39:41 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:39:41 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:06 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:06 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:10 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:10 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:31 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:31 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:33 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:33 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:51 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:51 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:58 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:40:58 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:32 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:32 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:54 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:41:54 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:42:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:42:00 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:42:21 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:42:21 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 14
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 24
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 57
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 14
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 24
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 57
ERROR - 2018-01-29 13:42:44 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 13:42:44 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 14
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 24
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 57
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 14
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 24
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:12:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 57
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 14
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 24
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 57
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 14
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 24
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 33
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 42
ERROR - 2018-01-29 19:13:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\product_image_edit.php 57
ERROR - 2018-01-29 13:43:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:43:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 19:13:17 --> Query error: Table 'db_methew_gar.tbl_unit' doesn't exist - Invalid query: SELECT `tbl_unit`.*
FROM `tbl_unit`
ERROR - 2018-01-29 19:14:00 --> Severity: Error --> Call to undefined method Goodsreceived_model::get_unit() E:\wamp\www\duty\math\application\controllers\Goodsreceived.php 28
ERROR - 2018-01-29 13:44:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:44:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:45:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:45:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 19:15:52 --> Severity: Error --> Call to undefined method Goodsreceived_model::get_unit() E:\wamp\www\duty\math\application\controllers\Goodsreceived.php 116
ERROR - 2018-01-29 19:16:10 --> Severity: Error --> Call to undefined method Goodsreceived_model::get_unit() E:\wamp\www\duty\math\application\controllers\Goodsreceived.php 116
ERROR - 2018-01-29 19:16:33 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 30
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 50
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 58
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 65
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 73
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 114
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 122
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 144
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 271
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 276
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 281
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 286
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 291
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 30
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\math\application\views\goods_edit_hold.php 33
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 38
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 50
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 58
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 65
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 73
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 85
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 114
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 122
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 132
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 144
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 271
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 276
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 281
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 286
ERROR - 2018-01-29 19:16:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\goods_edit_hold.php 291
ERROR - 2018-01-29 19:17:09 --> Severity: Notice --> Undefined offset: 2 E:\wamp\www\duty\math\application\models\Goodsreceived_model.php 422
ERROR - 2018-01-29 13:47:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:47:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:47:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:47:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 19:17:19 --> Severity: Error --> Call to undefined method Goodsreceived_model::get_unit() E:\wamp\www\duty\math\application\controllers\Returndet.php 33
ERROR - 2018-01-29 13:47:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-29 13:47:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-29 13:49:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:49:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:49:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:49:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:49:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:49:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:50:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:50:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:50:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:50:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:50:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:50:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:50:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:50:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:50:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:50:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:51:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:51:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:51:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:51:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:52:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:52:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:52:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:52:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:52:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:52:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 13:52:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:52:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:52:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:52:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:52:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:52:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:53:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:53:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:53:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-29 13:53:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-29 13:54:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:54:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 19:24:17 --> Severity: Error --> Call to undefined method Goodsreceived_model::get_unit() E:\wamp\www\duty\math\application\controllers\Stock_transfer.php 61
ERROR - 2018-01-29 13:56:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-29 13:56:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-29 13:57:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-29 13:57:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-29 13:57:14 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-29 13:57:14 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-29 13:57:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:57:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:57:46 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-29 13:57:46 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-29 13:57:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-29 13:57:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 73
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 78
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 79
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 110
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 115
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 115
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 120
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 129
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 134
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 144
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 149
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 73
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 78
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 79
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 110
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 115
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 115
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 120
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 129
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 134
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 144
ERROR - 2018-01-29 19:27:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\math\application\views\retail_print.php 149
ERROR - 2018-01-29 13:58:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 13:58:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 13:58:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-29 13:58:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-29 13:59:08 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-29 13:59:08 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-29 19:29:35 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\math\application\views\product_report.php 73
ERROR - 2018-01-29 19:29:35 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\math\application\views\product_report.php 82
ERROR - 2018-01-29 14:08:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:08:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:08:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:08:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:08:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:08:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:08:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:08:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:08:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:08:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:09:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:09:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined variable: row /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 33
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 30
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined variable: row /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 33
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 50
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 58
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 65
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 73
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 114
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 122
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 144
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 271
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 276
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 281
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 286
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 291
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 30
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined variable: row /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 33
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 50
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 58
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 65
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 73
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 114
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 122
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 144
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 271
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 276
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 281
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 286
ERROR - 2018-01-29 19:39:51 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 291
ERROR - 2018-01-29 14:09:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:09:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:09:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:09:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:10:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:10:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 19:40:36 --> Severity: Notice --> Undefined variable: row /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 33
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 30
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined variable: row /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 33
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 50
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 58
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 65
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 73
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 114
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 122
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 144
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 271
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 276
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 281
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 286
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 291
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 30
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined variable: row /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 33
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 38
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 50
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 58
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 65
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 73
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 85
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 114
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 122
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 132
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 144
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 271
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 276
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 281
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 286
ERROR - 2018-01-29 19:40:37 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit_hold.php 291
ERROR - 2018-01-29 19:41:07 --> Severity: Notice --> Undefined offset: 1 /home/sureshshivsai/public_html/mathewgarments/application/models/Goodsreceived_model.php 422
ERROR - 2018-01-29 19:41:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/helpers/url_helper.php 561
ERROR - 2018-01-29 14:39:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:39:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:39:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:39:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:39:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:39:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:39:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:39:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-29 14:42:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:42:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:57:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:57:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-29 14:57:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-29 14:57:20 --> 404 Page Not Found: Audio/fail.mp3
