<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-30 09:54:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 09:54:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 09:54:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 09:54:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 09:54:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 09:54:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 14:25:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-30 14:25:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 168
ERROR - 2017-12-30 14:25:40 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (9, '7', '3', '7', '578578', NULL, '1', NULL, '1', '1', '21', '21.42', '1', '1', '0.21', '0.21')
ERROR - 2017-12-30 14:29:02 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 168
ERROR - 2017-12-30 14:29:02 --> Query error: Column 'retail_amt' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (10, '7', '3', '7', '578578', '1', NULL, '1', '1', '21', '21.42', '1', '1', '0.21', '0.21')
ERROR - 2017-12-30 09:59:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 09:59:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 09:59:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 09:59:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 09:59:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 09:59:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:00:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:00:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:01:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:01:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:01:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:01:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:04:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:04:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:05:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:05:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 14:36:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-30 14:36:38 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (13, '7', '3', '1', '578578', NULL, '1', '1', '1', '2', '2', '4.08', '1', '1', '0.04', '0.04')
ERROR - 2017-12-30 14:38:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-30 14:38:24 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (14, '7', '3', '1', '578578', NULL, '1', '1', '1', '2', '2', '4.08', '1', '1', '0.04', '0.04')
ERROR - 2017-12-30 14:39:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-30 14:39:43 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (15, '7', '3', '1', '578578', NULL, '1', '1', '1', '2', '2', '4.08', '1', '1', '0.04', '0.04')
ERROR - 2017-12-30 14:43:53 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-30 14:43:53 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (16, '7', '3', '1', '578578', NULL, '1', '1', '1', '2', '2', '4.08', '1', '1', '0.04', '0.04')
ERROR - 2017-12-30 14:44:12 --> Severity: Notice --> Undefined variable: percent D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-30 14:44:12 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (17, '2', '4', '1', '5678', NULL, '2', '4', '3', '1', '4', '4.04', '1', '0', '0.04', '0')
ERROR - 2017-12-30 14:46:41 --> Severity: Notice --> Undefined variable: percent D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 171
ERROR - 2017-12-30 14:46:41 --> Query error: Column 'r_percent' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (18, '2', '4', '1', '5678', '2', '3', '4', NULL, '1', '4', '4.04', '1', '0', '0.04', '0')
ERROR - 2017-12-30 14:46:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 170
ERROR - 2017-12-30 10:17:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:17:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:17:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:17:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:17:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:17:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:18:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:18:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:18:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:18:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:20:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:20:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:21:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:21:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:22:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:22:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:27:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:27:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:28:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:28:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:29:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:29:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:30:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:30:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:30:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:30:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:31:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:31:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:32:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:32:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:32:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:32:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:38:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:38:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:38:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:38:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:39:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:39:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:40:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:41:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:41:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:41:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:41:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:41:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:41:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:42:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:42:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:43:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:43:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:43:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:43:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:44:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:44:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:45:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:45:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:46:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:46:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:47:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:47:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:50:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:50:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:51:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:51:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:52:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:52:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:52:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:52:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:53:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:53:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:54:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:54:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:54:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:54:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:55:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:55:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:56:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:56:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:56:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:56:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:04:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:04:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:06:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:06:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:07:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:07:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:12:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 10:12:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 10:12:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 10:12:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 10:12:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:12:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 15:43:55 --> Query error: Unknown column 'r_rate' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (15, '8', '4', '2', '4567467', '1', '2', '2', '1', '2', '2', '4', '0', '0', '0', '0')
ERROR - 2017-12-30 15:45:20 --> Query error: Field 'unit_ref_id' doesn't have a default value - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (23, '2', '4', '2', '5678', '1', '2', '2', '1', '2', '2', '4', '0', '0', '0', '0')
ERROR - 2017-12-30 15:45:41 --> Severity: Notice --> Undefined index: name /home/sureshshivsai/public_html/mathewgarments/application/views/menu_navigation.php 157
ERROR - 2017-12-30 15:45:41 --> Severity: Notice --> Undefined index: user_type /home/sureshshivsai/public_html/mathewgarments/application/views/menu_navigation.php 158
ERROR - 2017-12-30 10:15:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:15:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 15:45:58 --> Severity: Notice --> Undefined index: name /home/sureshshivsai/public_html/mathewgarments/application/views/menu_navigation.php 157
ERROR - 2017-12-30 15:45:58 --> Severity: Notice --> Undefined index: user_type /home/sureshshivsai/public_html/mathewgarments/application/views/menu_navigation.php 158
ERROR - 2017-12-30 10:15:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:15:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 15:46:49 --> Severity: Notice --> Undefined index: name /home/sureshshivsai/public_html/mathewgarments/application/views/menu_navigation.php 157
ERROR - 2017-12-30 15:46:49 --> Severity: Notice --> Undefined index: user_type /home/sureshshivsai/public_html/mathewgarments/application/views/menu_navigation.php 158
ERROR - 2017-12-30 10:19:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 10:19:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 10:19:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 10:19:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 10:19:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:19:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 15:49:45 --> Query error: Unknown column 'r_rate' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (7, '2', '4', '2', '5678', '1', '1', '2', '1', '1', '3', '3', '0', '0', '0', '0')
ERROR - 2017-12-30 10:22:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 10:22:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 10:22:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 10:22:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 10:22:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:22:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 15:53:03 --> Query error: Field 'unit_ref_id' doesn't have a default value - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (23, '2', '4', '1', '5678', '3', '3', '4', '3', '3', '5', '15', '0', '0', '0', '0')
ERROR - 2017-12-30 10:23:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:23:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:23:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:23:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:23:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 10:23:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 11:43:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 11:43:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 11:43:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 11:43:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 11:46:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 11:46:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 11:50:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 11:50:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 11:50:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 11:50:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 11:50:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 11:50:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 16:22:01 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
ERROR - 2017-12-30 12:02:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 12:02:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 12:02:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:02:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:02:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 12:02:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 12:03:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 12:03:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-30 16:35:35 --> Query error: Unknown column 'tbl_product_img.product_img_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`product_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
ERROR - 2017-12-30 16:40:01 --> Query error: Unknown column 'tbl_product_img.product_img_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`product_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
ERROR - 2017-12-30 16:40:56 --> Query error: Unknown column 'tbl_product_img.product_img_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`product_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
ERROR - 2017-12-30 16:41:59 --> Query error: Unknown column 'tbl_product_img.product_img_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`product_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
ERROR - 2017-12-30 12:14:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:14:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:17:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:17:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:18:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:18:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:21:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:21:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:21:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:21:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:21:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:21:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:32:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:32:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:41:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:41:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:43:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:43:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:44:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:44:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:44:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:44:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 12:46:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 12:46:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:01:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:01:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:03:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:03:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:04:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:04:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:04:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:04:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:06:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:06:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:06:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-30 13:06:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:06:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-30 13:06:31 --> 404 Page Not Found: Audio/fail.mp3
