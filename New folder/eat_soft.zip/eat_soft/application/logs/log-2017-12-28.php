<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-28 07:06:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:06:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:06:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:06:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:06:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:06:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:07:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:07:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:39:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:39:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:39:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:39:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:39:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:39:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:40:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:40:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:44:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:44:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:45:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:45:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:45:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:45:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:45:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:45:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:45:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:45:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:46:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:46:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:47:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 07:47:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:17:12 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:47:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:47:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:48:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:48:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:48:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:48:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:39 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:48:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:48:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:48:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:48:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:48:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:48:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:18:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:49:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:49:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:19:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 07:49:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:49:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:49:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:49:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:49:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:49:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:53:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:53:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:55:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:55:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:55:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 07:55:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 07:56:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:56:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:56:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:56:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:58:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:58:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:58:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:58:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 07:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:00:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:00:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:02:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:02:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:02:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:02:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:02:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 08:02:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 12:33:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-28 08:03:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 08:03:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 08:03:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:03:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:03:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:03:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:03:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:03:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:07:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:07:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:08:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:08:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:08:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:08:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:10:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:10:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:11:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:11:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:14:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:14:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:16:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:16:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:16:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:16:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:19:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:19:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:30:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:30:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:31:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:31:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:32:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:32:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:32:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:32:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:33:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:33:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:33:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:33:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:34:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:34:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:34:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:34:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:39:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:39:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:39:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:39:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:40:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:40:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:42:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:42:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:43:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:43:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:44:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:44:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:44:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:44:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:44:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 08:44:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: taxamount D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-28 13:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: vinvno D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_unit_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: pi_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined index: tbl_pro_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-28 13:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-28 13:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 13:14:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-28 08:44:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:44:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:45:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:45:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:45:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:45:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:47:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:47:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:48:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:48:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:49:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:49:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:49:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:49:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:56:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:56:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:56:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:56:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:58:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:58:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:59:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 08:59:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:01:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:01:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:01:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:01:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:02:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:02:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:02:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:02:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:03:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:03:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:03:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:03:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:04:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:04:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:04:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:04:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:04:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:04:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:08:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:08:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:08:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:08:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:09:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:09:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:11:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:11:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:11:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:11:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:11:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:11:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:12:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:12:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:12:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:12:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:13:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:13:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:16:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:16:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:18:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:18:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:19:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:19:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:20:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 09:20:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 09:20:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 09:20:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 09:20:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 09:20:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 09:21:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:21:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:21:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:21:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:21:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:21:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:22:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:22:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:23:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:23:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:24:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 09:24:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 09:27:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:27:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:28:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 09:28:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 10:18:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 10:18:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 10:18:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 10:18:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 10:18:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 10:18:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 10:18:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 10:18:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 10:18:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 10:18:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 10:19:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 10:19:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 10:19:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 10:19:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 10:40:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 10:40:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 10:43:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 10:43:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 10:43:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 10:43:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:01:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:01:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:06:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:06:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:08:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:08:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:11:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:11:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:12:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:12:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:13:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:13:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:13:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:13:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:14:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:14:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:16:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:16:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:17:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:17:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:17:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:17:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:21:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:21:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 11:26:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:26:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:26:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:26:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:27:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:27:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:27:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:27:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:27:42 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:27:42 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:29:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:29:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:29:45 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:29:45 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:30:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:30:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:30:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:30:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-28 11:31:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:31:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 14
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 24
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 36
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 43
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 50
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 59
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 66
ERROR - 2017-12-28 16:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\vendor_edit.php 73
ERROR - 2017-12-28 11:32:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:32:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:32:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:32:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:32:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:32:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:32:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:32:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:32:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:32:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:32:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:32:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:33:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:33:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:33:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:33:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:33:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:33:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:33:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:33:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:34:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:34:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:34:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:25 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:35:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:38 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:36:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:37:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:37:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:37:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:37:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:37:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:37:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:38:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:38:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:39:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:40:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:40:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-28 16:10:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-28 11:40:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:40:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:46:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:46:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:46:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:46:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 11:46:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:46:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:46:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:46:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:46:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:46:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:46:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:46:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:47:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:47:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:47:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:47:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:47:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:47:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 11:52:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 11:52:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:00:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:00:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:00:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:00:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:01:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:01:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:01:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:01:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:01:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:01:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:02:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:02:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:02:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:02:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:03:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:03:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-28 12:04:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:04:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:04:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:04:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:10:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:10:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:13:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:13:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:13:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:13:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:17:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:17:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:21:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:21:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:22:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:22:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 16:52:16 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-28 12:45:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:45:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:56:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-28 12:56:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-28 12:56:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 12:56:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:03:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:03:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:04:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:04:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:05:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:05:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:06:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:06:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:06:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:06:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:07:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:07:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:09:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:09:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:10:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:10:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:23:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:23:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 17:55:44 --> Query error: Unknown column 'wholesale_tax' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (2, '7', '3', '1', '578578', '23', '23', '2000', '2000', '3', '200', '618', '3', '0', '18', '0')
ERROR - 2017-12-28 17:56:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 167
ERROR - 2017-12-28 17:56:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 169
ERROR - 2017-12-28 17:56:38 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (3, '7', '3', '7', '578578', NULL, '23', NULL, '3000', '3', '300', '936', '0', '4', '0', '36')
ERROR - 2017-12-28 17:57:03 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 166
ERROR - 2017-12-28 17:57:03 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 168
ERROR - 2017-12-28 17:57:03 --> Query error: Column 'retail_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `retail_tax`, `wholesale_tax`, `retail_amt`, `wholesale_amt`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (4, '7', '3', '7', '578578', NULL, '23', NULL, '3000', '3', '300', '936', '0', '4', '0', '36')
ERROR - 2017-12-28 13:30:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:30:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:30:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:30:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:34:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:34:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:34:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:34:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:35:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:44:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:44:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:44:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:44:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:53:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 13:53:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:01:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:01:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:02:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:02:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:02:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:02:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:03:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:03:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:04:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:04:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:06:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-28 14:06:41 --> 404 Page Not Found: Goodsreceived/audio
