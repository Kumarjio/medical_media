<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-28 04:06:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:06:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 09:36:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:36:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:36:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:37:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE  IS NULL
AND  IS NULL' at line 3 - Invalid query: SELECT *
FROM 
WHERE  IS NULL
AND  IS NULL
ERROR - 2018-02-28 09:37:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND  IS NULL
AND `id` = '607c5e24486dfff3eafa7286d1c1a48b634a1bdf'' at line 2 - Invalid query: UPDATE `ci_session` SET `timestamp` = 1519790824
WHERE  IS NULL
AND  IS NULL
AND `id` = '607c5e24486dfff3eafa7286d1c1a48b634a1bdf'
ERROR - 2018-02-28 04:22:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:22:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 09:52:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:52:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:52:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:56:12 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC), expecting ')' E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 93
ERROR - 2018-02-28 09:56:19 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC), expecting ')' E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 93
ERROR - 2018-02-28 04:26:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:26:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 09:56:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:56:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:56:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:56:33 --> Severity: Notice --> Undefined variable: grn E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 97
ERROR - 2018-02-28 04:26:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:26:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 09:56:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:56:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:56:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 04:27:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:27:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 09:57:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:57:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:57:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 04:28:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 04:28:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 09:58:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:58:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:58:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 04:29:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:29:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 09:59:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:59:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 09:59:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 04:31:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 04:31:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 10:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:01:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:01:36 --> Severity: Notice --> Undefined variable: i E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 95
ERROR - 2018-02-28 10:01:36 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 95
ERROR - 2018-02-28 04:32:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 04:32:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 10:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:02:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 04:33:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 04:33:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 10:03:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:03:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:03:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:04:56 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN), expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\models\Dashboard_model.php 97
ERROR - 2018-02-28 04:35:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 04:35:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 10:05:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:05:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 10:05:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 13:07:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 13:07:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 18:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 18:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 18:37:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 13:07:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-28 13:07:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-28 18:37:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 18:37:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-28 18:37:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
