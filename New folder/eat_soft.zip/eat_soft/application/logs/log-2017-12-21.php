<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-21 11:06:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-21 11:06:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-21 11:06:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-21 11:06:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-21 11:07:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-21 11:07:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-21 11:07:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-21 11:07:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-21 16:38:05 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 140
ERROR - 2017-12-21 16:38:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 169
ERROR - 2017-12-21 16:38:05 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-21 16:38:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-21 16:38:11 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 140
ERROR - 2017-12-21 16:38:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/libraries/Session/Session.php 169
ERROR - 2017-12-21 16:38:11 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2017-12-21 16:38:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/application/controllers/Returndet.php:1) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-21 11:08:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-21 11:08:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-21 11:09:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-21 11:09:18 --> 404 Page Not Found: Audio/fail.mp3
