<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-25 04:06:06 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-25 04:06:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:06:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:06:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:07:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:07:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:08:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:08:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:08:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:08:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:09:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:09:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:10:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:10:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:12:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:12:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:21:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:21:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:22:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:22:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:23:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:23:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:23:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:23:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:24:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:24:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:24:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:24:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:26:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:26:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:27:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:27:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:27:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:27:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:27:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:27:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:28:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:28:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:29:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:29:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:29:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:29:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:29:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:29:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:31:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:31:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:33:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:33:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:35:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:35:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:36:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:36:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:37:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:37:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:37:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:37:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:39:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:39:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:40:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:40:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:41:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:41:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:43:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:43:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:44:53 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 04:44:53 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 04:45:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:45:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:46:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:46:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:46:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:46:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:46:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 04:46:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 10:16:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 04:47:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 04:47:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 04:48:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 04:48:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 10:18:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 04:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:48:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:48:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:49:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:49:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:49:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:49:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:53:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:53:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 04:53:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 04:53:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:24:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:24:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 10:56:04 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 195
ERROR - 2018-01-25 05:31:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:31:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:36:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:36:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:36:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:36:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:38:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:38:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 11:08:31 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:38:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 05:38:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 11:08:33 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:41:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 05:41:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 11:11:30 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:41:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:41:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:11:43 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:41:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:41:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:41:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:41:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:41:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:41:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:43:40 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:43:40 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:47:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:47:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:47:34 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:47:34 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:49:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:49:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:49:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:49:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:50:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:50:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 11:20:25 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:51:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:51:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:21:01 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:54:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:54:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:24:47 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:54:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 05:54:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 11:24:49 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:56:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 05:56:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 11:26:11 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:56:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:56:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:26:17 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 05:56:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:56:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:56:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:56:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:56:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:56:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:56:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:57:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:57:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:57:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:57:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:57:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 05:57:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:57:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:58:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:58:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:58:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 05:58:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:59:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 05:59:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:00:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:00:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:05:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:05:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:06:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:06:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:11:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:11:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:12:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 06:12:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 06:13:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:13:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 11:45:13 --> Severity: Notice --> Undefined variable: comm_igst E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 168
ERROR - 2018-01-25 11:45:13 --> Severity: Notice --> Undefined variable: tax_type E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 170
ERROR - 2018-01-25 11:45:13 --> Query error: Column 'who_comm_igst' cannot be null - Invalid query: INSERT INTO `tbl_whole_sales` (`who_invoice`, `who_cus_name`, `who_cus_no`, `who_purchase_mode`, `who_stotal`, `who_gtotal`, `who_comm_cgst`, `who_comm_sgst`, `who_comm_igst`, `who_sale_type`, `who_sale_tax_type`, `who_get_pay`, `who_bal_pay`, `who_emp_id`, `who_trans_no`, `who_trans_amt`, `who_pdate`) VALUES ('RBHF04', 'GERGER', '352', 'cash_card', '4300', '4816.00', '258.00', '258.00', NULL, 'WB', NULL, '3000', '-1816.00', 'EMP001', 'SDCVEVWEVWEV', '1816.00', '2018-01-25')
ERROR - 2018-01-25 06:17:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:17:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:47:33 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-25 11:47:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-25 11:47:37 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-25 11:47:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-25 11:47:40 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-25 11:47:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-25 06:17:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:17:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:20:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:20:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:20:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:20:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:21:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:21:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:21:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:21:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:22:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:22:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:29:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:29:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:31:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:31:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:51:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:51:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:52:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:52:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:22:46 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-25 12:22:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-25 12:22:53 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-25 12:22:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-25 06:53:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 06:53:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:23:15 --> Severity: Warning --> Missing argument 1 for Wholesale::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 82
ERROR - 2018-01-25 12:23:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 83
ERROR - 2018-01-25 12:23:22 --> Severity: Warning --> Missing argument 1 for Wholesale::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 86
ERROR - 2018-01-25 12:23:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Wholesale.php 87
ERROR - 2018-01-25 06:53:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 06:53:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:17:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:17:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:17:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:17:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:17:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:17:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:18:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:18:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:18:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:18:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:18:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:18:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:18:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:18:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:21:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:21:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:21:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:21:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:22:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:22:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:22:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:22:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:23:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:23:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:23:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:23:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:23:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:23:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:23:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:23:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:23:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:23:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:24:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:24:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:25:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:25:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:25:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:25:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:27:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:27:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:27:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:27:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:27:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:27:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:28:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:28:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:28:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:28:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:28:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:28:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:28:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 07:28:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 07:28:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:28:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:28:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:28:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:28:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-25 07:28:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-25 07:57:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 07:57:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 07:57:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:57:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:57:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:57:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 07:59:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 07:59:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 08:00:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 08:00:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 08:00:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 08:00:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 08:01:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 08:01:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 08:20:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 08:20:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 08:20:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 08:20:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 08:27:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 08:27:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 11:54:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 11:54:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:54:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 11:54:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 17:28:40 --> Query error: Unknown column 'invoice' in 'field list' - Invalid query: UPDATE `tbl_whole_sales` SET `invoice` = 'WB0001'
WHERE `whole_sales_id` = 1
ERROR - 2018-01-25 11:59:31 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 11:59:31 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:03:00 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:03:00 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:04:15 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:04:15 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 17:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 17:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-25 17:37:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-25 12:09:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:09:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:11:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:11:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 17:41:40 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 12:11:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 12:11:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 17:41:42 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 12:12:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 12:12:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-25 17:42:51 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 12:12:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:12:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 17:42:58 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-25 12:13:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:13:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:13:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:13:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:13:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:13:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:14:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:14:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:16:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:16:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:16:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:16:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:17:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:17:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:18:24 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:18:24 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:21:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:21:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:21:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:21:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:23:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:23:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:23:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:23:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:23:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:23:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:25:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:25:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:25:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:25:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:25:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:25:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:26:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:26:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:26:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:26:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:28:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:28:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:28:11 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-25 12:28:11 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-25 17:58:42 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-25 17:58:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-25 17:58:44 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-25 17:58:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-25 17:58:47 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-25 17:58:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-25 12:28:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:28:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:28:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:28:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:29:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:29:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:29:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:29:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:30:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:30:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:31:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:31:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:33:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:33:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:35:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:35:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:36:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:36:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:36:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:36:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:36:40 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:36:40 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:36:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:36:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:38:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:38:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:38:39 --> 404 Page Not Found: Wholesale/wholesale_list
ERROR - 2018-01-25 12:38:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:38:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:38:55 --> 404 Page Not Found: Wholesale/wholesale_list
ERROR - 2018-01-25 12:40:11 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:40:11 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:45:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:45:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 18:15:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 133
ERROR - 2018-01-25 12:45:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:45:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:46:31 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:46:31 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:46:59 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:46:59 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:47:27 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:47:27 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:47:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:47:42 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:47:50 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:47:50 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:48:01 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:48:01 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:49:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:49:32 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:49:37 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:49:37 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:50:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:50:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 12:50:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:50:16 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 12:51:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:51:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 18:22:19 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-25 18:22:19 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-25 12:52:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:52:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 18:22:37 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-25 18:22:37 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-25 12:52:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:52:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 18:22:42 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-25 18:22:42 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-25 12:52:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:52:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 18:22:45 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-25 18:22:45 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-25 12:52:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:52:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:53:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-25 12:53:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-25 12:53:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:53:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:53:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 12:53:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 18:25:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-25 18:25:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-25 18:25:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-25 18:25:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-25 12:56:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:56:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:57:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 12:57:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:57:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 12:57:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:00:10 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:00:10 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:00:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:00:51 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:01:02 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:01:02 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:01:05 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:01:05 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:01:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:01:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 13:03:33 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:03:33 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:03:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:03:38 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:10:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 13:10:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:10:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 13:10:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 13:11:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 13:11:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:11:50 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:11:50 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:11:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:11:54 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:12:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:12:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 13:12:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 13:12:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-25 18:42:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-25 18:42:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-25 18:42:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-25 18:42:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-25 13:15:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:15:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 13:15:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 13:15:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 13:15:29 --> 404 Page Not Found: Branch/audio
ERROR - 2018-01-25 13:15:29 --> 404 Page Not Found: Branch/audio
ERROR - 2018-01-25 13:21:30 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:21:30 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 13:21:33 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:21:33 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:25:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:25:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:25:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:25:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:28:26 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:28:26 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 19:23:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM (`tbl_stock`, `tbl_single_po_entry`)
JOIN `tbl_po_inv_item` ON `tbl_po_in' at line 1 - Invalid query: SELECT *, *
FROM (`tbl_stock`, `tbl_single_po_entry`)
JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
WHERE `tbl_stock`.`pro_imag_ref_id` = '1'
AND `tbl_stock`.`size_reff_id` = '2'
AND `tbl_single_po_entry`.`single_po_entry_id` = '11'
ERROR - 2018-01-25 19:23:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php:388) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-25 19:23:18 --> Query error: Unknown column 'tbl_stock.pro_imag_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516888398
WHERE `tbl_stock`.`pro_imag_ref_id` = '1'
AND `tbl_stock`.`size_reff_id` = '2'
AND `tbl_single_po_entry`.`single_po_entry_id` = '11'
AND `id` = '62c2b13708e3af520ebedc3a53d86cfafb076f65'
ERROR - 2018-01-25 19:23:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php:388) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-25 13:58:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 13:58:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 19:30:28 --> Severity: Notice --> Undefined variable: status E:\wamp\www\duty\mathewgarments\application\models\Wholesale_model.php 384
ERROR - 2018-01-25 19:30:28 --> Query error: Unknown column 'tbl_whole_sales.whole_sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516888828
WHERE `tbl_whole_sales`.`whole_sales_id` = '2'
AND `id` = '597a9897f8e182eb02571896478e7127309124b7'
ERROR - 2018-01-25 14:00:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:00:41 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:01:01 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:01:01 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:01:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 14:01:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 14:01:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 14:01:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 14:01:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 14:01:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 14:02:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-25 14:02:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-25 14:02:31 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:02:31 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 19:36:56 --> Severity: Parsing Error --> syntax error, unexpected '?' E:\wamp\www\duty\mathewgarments\application\views\wholesale_list.php 112
ERROR - 2018-01-25 14:07:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:07:04 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:07:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:07:17 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:07:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:07:55 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:08:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:08:40 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:10:13 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:10:13 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:11:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:11:06 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-01-25 14:11:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-25 14:11:39 --> 404 Page Not Found: Retail/audio
