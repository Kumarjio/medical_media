<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-23 04:45:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-23 04:45:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-23 04:46:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-23 04:46:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-23 04:46:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-23 04:46:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-23 08:32:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-23 08:32:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-23 08:34:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-23 08:34:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-23 08:34:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-23 08:34:18 --> 404 Page Not Found: Goodsreceived/audio
