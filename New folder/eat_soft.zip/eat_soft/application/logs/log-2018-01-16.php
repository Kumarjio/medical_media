<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-16 04:16:10 --> 404 Page Not Found: Audio/fail.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-16 04:16:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 04:16:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 04:16:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 04:16:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 04:16:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 04:28:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 04:28:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 04:42:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 04:42:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_code E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_name E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_code E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined index: i_name E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:13:32 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 126
ERROR - 2018-01-16 04:43:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 04:43:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 10:16:34 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:34 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined index: i_code E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined index: i_name E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined index: i_code E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined index: i_name E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:16:35 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 126
ERROR - 2018-01-16 04:46:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 04:46:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 10:17:35 --> Severity: Error --> Call to undefined method Reports_model::get_omv_det() E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 35
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_code E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_name E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_code E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined index: i_name E:\wamp\www\duty\mathewgarments\application\views\product_report.php 60
ERROR - 2018-01-16 10:17:49 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 126
ERROR - 2018-01-16 04:47:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 04:47:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 10:33:05 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 125
ERROR - 2018-01-16 05:03:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:03:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 10:34:10 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 124
ERROR - 2018-01-16 05:04:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:04:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 10:34:57 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 124
ERROR - 2018-01-16 05:04:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 05:04:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 10:35:22 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 125
ERROR - 2018-01-16 05:05:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:05:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 10:59:37 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 125
ERROR - 2018-01-16 05:29:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:29:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:16:53 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 125
ERROR - 2018-01-16 05:46:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:46:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 05:46:59 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-16 05:46:59 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-16 05:47:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 05:47:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 05:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:48:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-16 05:48:31 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-16 05:48:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:48:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 05:54:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 05:54:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:24:35 --> Severity: Notice --> Undefined variable: stock E:\wamp\www\duty\mathewgarments\application\views\product_report.php 125
ERROR - 2018-01-16 05:54:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 05:54:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 11:26:16 --> Query error: Unknown column 'tbl_po_inv.supplier_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_stock`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_stock`.`pro_imag_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`style`=`tbl_product_img`.`style_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
ERROR - 2018-01-16 06:10:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:10:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:40:16 --> Severity: Notice --> Undefined index: from_dt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 15
ERROR - 2018-01-16 11:40:16 --> Severity: Notice --> Undefined index: to_dt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 16
ERROR - 2018-01-16 06:10:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:10:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:10:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:10:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:10:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:10:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:12:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:12:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:12:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:12:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:21:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:21:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 11:51:10 --> Severity: Notice --> Undefined index: stock E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 69
ERROR - 2018-01-16 11:51:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 69
ERROR - 2018-01-16 06:21:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:21:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:21:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:21:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:22:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:22:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:22:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:22:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:22:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:22:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:23:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:23:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:23:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:23:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:54:06 --> Severity: Notice --> Undefined index: from_dt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 15
ERROR - 2018-01-16 11:54:06 --> Severity: Notice --> Undefined index: to_dt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 16
ERROR - 2018-01-16 06:24:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:24:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 11:54:29 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 71
ERROR - 2018-01-16 11:54:29 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 80
ERROR - 2018-01-16 06:24:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:24:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:54:54 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 11:54:54 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 06:24:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:24:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:56:51 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 11:56:51 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 06:26:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:26:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 11:56:58 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 73
ERROR - 2018-01-16 11:56:58 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 82
ERROR - 2018-01-16 06:26:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:26:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:27:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:27:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:28:05 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:28:05 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:28:10 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:28:10 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:03:54 --> Query error: Unknown column 'tbl_po_inv_item.item_code' in 'where clause' - Invalid query: SELECT `tbl_grn`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_grn`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_grn`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
WHERE `tbl_po_inv_item`.`item_code` = '1'
ERROR - 2018-01-16 12:03:54 --> Query error: Unknown column 'tbl_po_inv_item.item_code' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516084434
WHERE `tbl_po_inv_item`.`item_code` = '1'
AND `id` = '9416c115385dac090263123ad86f084f7d9e56f6'
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 12:09:36 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 06:39:37 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 06:39:37 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:41 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 12:09:41 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 06:39:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:39:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:43:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:43:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:13:28 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 12:13:28 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 06:43:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:43:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:14:46 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 12:14:46 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 06:44:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:44:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:54:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:54:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:57:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 06:57:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:27:45 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 12:27:45 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 06:57:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 06:57:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 13:01:10 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 13:01:10 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 07:31:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 07:31:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 13:03:20 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 38
ERROR - 2018-01-16 13:06:27 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 13:06:27 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 07:36:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 07:36:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 13:09:30 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 40
ERROR - 2018-01-16 13:09:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 41
ERROR - 2018-01-16 13:51:26 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:51:26 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:51:26 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:51:26 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:51:26 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:51:26 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:51:26 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
WHERE 0 = `Array`
AND 1 = `Array`
AND 2 = `Array`
AND 3 = `Array`
AND 4 = `Array`
AND 5 = `Array`
ERROR - 2018-01-16 13:51:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-16 13:51:26 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516090886
WHERE 0 = `Array`
AND 1 = `Array`
AND 2 = `Array`
AND 3 = `Array`
AND 4 = `Array`
AND 5 = `Array`
AND `id` = '9416c115385dac090263123ad86f084f7d9e56f6'
ERROR - 2018-01-16 13:51:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-16 13:52:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-16 13:52:18 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
WHERE 0 = `Array`
ERROR - 2018-01-16 13:52:18 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516090938
WHERE 0 = `Array`
AND `id` = '9416c115385dac090263123ad86f084f7d9e56f6'
ERROR - 2018-01-16 13:56:37 --> Query error: Unknown column 'tbl_po_inv_item.style_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516091197
WHERE `tbl_po_inv_item`.`style_ref_id` IS NULL
AND `tbl_po_inv_item`.`product_img_ref_id` IS NULL
AND `tbl_po_inv_item`.`size_ref_id` IS NULL
AND `tbl_po_inv_item`.`style_ref_id` IS NULL
AND `tbl_po_inv_item`.`product_img_ref_id` IS NULL
AND `tbl_po_inv_item`.`size_ref_id` IS NULL
AND `tbl_po_inv_item`.`style_ref_id` IS NULL
AND `tbl_po_inv_item`.`product_img_ref_id` IS NULL
AND `tbl_po_inv_item`.`size_ref_id` IS NULL
AND `tbl_po_inv_item`.`style_ref_id` IS NULL
AND `tbl_po_inv_item`.`product_img_ref_id` IS NULL
AND `tbl_po_inv_item`.`size_ref_id` IS NULL
AND `tbl_po_inv_item`.`style_ref_id` IS NULL
AND `tbl_po_inv_item`.`product_img_ref_id` IS NULL
AND `tbl_po_inv_item`.`size_ref_id` IS NULL
AND `tbl_po_inv_item`.`style_ref_id` IS NULL
AND `tbl_po_inv_item`.`product_img_ref_id` IS NULL
AND `tbl_po_inv_item`.`size_ref_id` IS NULL
AND `id` = '9416c115385dac090263123ad86f084f7d9e56f6'
ERROR - 2018-01-16 13:56:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php:43) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-16 13:57:58 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 39
ERROR - 2018-01-16 13:57:58 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 39
ERROR - 2018-01-16 13:57:58 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 39
ERROR - 2018-01-16 13:57:58 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 39
ERROR - 2018-01-16 13:57:58 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 39
ERROR - 2018-01-16 13:57:58 --> Severity: Notice --> Undefined index:  E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 39
ERROR - 2018-01-16 14:03:20 --> Severity: Notice --> Undefined variable: query E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 38
ERROR - 2018-01-16 14:03:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM (`tbl_stock`, `tbl_product`)
LEFT JOIN `tbl_product_img` ON `tbl_product_' at line 1 - Invalid query: SELECT *, *
FROM (`tbl_stock`, `tbl_product`)
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_stock`.`pro_imag_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`style`=`tbl_product_img`.`style_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_stock`.`size_reff_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
ERROR - 2018-01-16 14:03:38 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:03:38 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:33:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:33:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:04:37 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:04:37 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:34:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:34:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:18 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 08:37:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:37:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 14:07:25 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\product_report.php 121
ERROR - 2018-01-16 08:37:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:37:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:08:01 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:08:01 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:38:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:38:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:13:09 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:13:09 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:43:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:43:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined index: product_img_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined index: product_img_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined index: product_img_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined index: product_img_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined index: product_img_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 14:14:03 --> Severity: Notice --> Undefined index: product_img_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 08:44:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:44:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:14:42 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:14:42 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:44:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:44:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:17:04 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:17:04 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:47:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:47:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:18:18 --> Severity: Parsing Error --> syntax error, unexpected 'get' (T_STRING) E:\wamp\www\duty\mathewgarments\application\views\product_report.php 120
ERROR - 2018-01-16 14:18:27 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:18:27 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:20:07 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:20:07 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:50:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:50:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:20:57 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:20:57 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:50:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:50:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:21:19 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:21:19 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:51:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:51:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:21:30 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:21:30 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 08:51:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:51:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:06 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:54:06 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:54:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:54:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:54:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:54:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:54:50 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:54:50 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:20 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:20 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:41 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:41 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:44 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:55:44 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-01-16 14:25:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-01-16 08:55:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:55:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:56:06 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:06 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:08 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:08 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:32 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:32 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:48 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:56:48 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 14:27:03 --> The filetype you are attempting to upload is not allowed.
ERROR - 2018-01-16 08:57:04 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:04 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:05 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:05 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2018-01-16 14:27:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2018-01-16 08:57:32 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:32 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:36 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:57:47 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-16 08:58:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 08:58:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 08:58:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 08:58:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 09:01:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 09:01:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 09:01:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:01:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:31:47 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:31:47 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:01:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:01:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:31:57 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:31:57 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:01:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:01:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:32:07 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:32:07 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:02:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:02:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:02:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:02:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:02:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:02:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:02:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:02:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:02:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:02:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:02:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:02:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:33:20 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:33:20 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:03:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:03:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:33:45 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:33:45 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:03:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:03:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:33:52 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:33:52 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:03:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:03:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:34:39 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:34:39 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:04:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:04:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:34:46 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:34:46 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:04:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:04:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:34:56 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:34:56 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:04:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:04:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:35:26 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:35:26 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:05:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:05:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:35:54 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:35:54 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:05:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:05:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:42:18 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:42:18 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:12:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:12:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:44:37 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:44:37 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:44:37 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\views\product_report.php 123
ERROR - 2018-01-16 09:14:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:14:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:45:21 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:45:21 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:15:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:15:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:45:35 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:45:35 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:15:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:15:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:45:46 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:45:46 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:15:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:15:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:46:26 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:46:26 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:46:26 --> Severity: Notice --> Undefined variable: data2 E:\wamp\www\duty\mathewgarments\application\views\product_report.php 124
ERROR - 2018-01-16 09:16:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:16:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:46:38 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:46:38 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:16:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:16:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:47:28 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:47:28 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:17:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:17:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:48:01 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:48:01 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:18:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:18:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:50:39 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:50:39 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:20:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:20:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:50:59 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:50:59 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:20:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:20:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 14:53:20 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 138
ERROR - 2018-01-16 09:23:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:23:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 14:53:45 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:53:45 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 14:53:45 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:45 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:45 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 14:53:45 --> Severity: Notice --> Undefined index: pro_imag_ref_id E:\wamp\www\duty\mathewgarments\application\views\product_report.php 137
ERROR - 2018-01-16 09:23:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:23:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:54:07 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:54:07 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:24:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:24:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:54:54 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:54:54 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:24:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:24:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:25:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:25:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:25:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 09:25:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 14:55:15 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:55:15 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:25:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:25:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:26:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 09:26:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 14:56:43 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:56:43 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:26:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:26:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:56:49 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:56:49 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:26:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:26:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 14:56:50 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 14:56:50 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:26:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:26:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:00:10 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:00:10 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:30:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:30:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:00:33 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:00:33 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:30:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:30:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:00:55 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:00:55 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:30:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:30:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:01:02 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:01:02 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:31:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:31:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:31:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-16 09:31:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-16 09:31:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:31:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:31:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:31:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 15:01:35 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:01:35 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:31:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:31:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:01:46 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:01:46 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:31:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:31:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:03:24 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 09:33:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 09:33:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 15:04:05 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:04:05 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:34:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:34:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:04:08 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:04:08 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:34:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:34:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:04:13 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:04:13 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:34:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:34:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 15:04:18 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:04:18 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:34:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:34:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 15:05:17 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:05:17 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:35:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:35:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: style_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:05:27 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 09:35:27 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 09:35:27 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:07:20 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 09:37:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 09:37:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 09:43:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:43:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:17:54 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:17:54 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:47:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 09:47:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 15:17:58 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 15:17:58 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 09:47:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 09:47:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 126
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 127
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: material_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 128
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 129
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 126
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 127
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: material_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 128
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 129
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 126
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 127
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: material_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 128
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 129
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 126
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 127
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: material_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 128
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 129
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 125
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 126
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 127
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: material_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 128
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 129
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 130
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 131
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: image_url E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 132
ERROR - 2018-01-16 15:19:43 --> Severity: Notice --> Undefined index: curr_qty E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 133
ERROR - 2018-01-16 09:49:44 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 09:49:44 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 15:32:57 --> Query error: Unknown column 'tbl_product_img.color_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_grn`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_grn`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_stock`.`size_reff_id`
ERROR - 2018-01-16 15:35:13 --> Query error: Unknown column 'tbl_grn.size_reff_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_grn`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_grn`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_grn`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_grn`.`color_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_grn`.`size_reff_id`
ERROR - 2018-01-16 10:17:28 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:17:28 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:18:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:18:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:19:32 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:19:32 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:20:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:20:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:23:42 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:23:42 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:26:38 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:26:38 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:29:47 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:29:47 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:29:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:29:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:30:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:30:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:30:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:30:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:30:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:30:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:40:44 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:40:44 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:45:48 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:45:48 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:46:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:46:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:47:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 10:47:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 10:47:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 10:47:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 10:48:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 10:48:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 16:19:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::distint() E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 57
ERROR - 2018-01-16 16:20:29 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 61
ERROR - 2018-01-16 16:20:29 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 61
ERROR - 2018-01-16 16:20:29 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 61
ERROR - 2018-01-16 16:20:29 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 61
ERROR - 2018-01-16 16:20:29 --> Severity: Notice --> Undefined index: product_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 61
ERROR - 2018-01-16 16:20:29 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 61
ERROR - 2018-01-16 10:50:30 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:50:30 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:51:02 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:51:02 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:51:10 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:51:10 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:52:33 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:52:33 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:52:37 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:52:37 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:02 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:02 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:31 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:54:31 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:02 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:02 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:15 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:15 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:37 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:37 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:43 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:43 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:49 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:56:49 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 16:27:02 --> Severity: Notice --> Undefined variable: lot_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 62
ERROR - 2018-01-16 16:27:02 --> Severity: Notice --> Undefined variable: lot_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 62
ERROR - 2018-01-16 10:57:03 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:57:03 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 16:27:04 --> Severity: Notice --> Undefined variable: lot_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 62
ERROR - 2018-01-16 16:27:04 --> Severity: Notice --> Undefined variable: lot_id E:\wamp\www\duty\mathewgarments\application\views\grn_report.php 62
ERROR - 2018-01-16 10:57:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:57:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:57:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:57:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:57:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:57:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:59:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:59:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:59:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 10:59:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:00:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:00:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:01:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:01:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:01:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:01:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:02:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:02:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:02:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:02:06 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 16:40:47 --> Severity: Compile Error --> Cannot redeclare Reports_model::get_grn_det() E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 74
ERROR - 2018-01-16 16:41:47 --> Severity: Compile Error --> Cannot redeclare Reports_model::get_grn_det() E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 74
ERROR - 2018-01-16 16:41:57 --> Severity: Compile Error --> Cannot redeclare Reports_model::get_grn_det() E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 74
ERROR - 2018-01-16 16:42:01 --> Severity: Compile Error --> Cannot redeclare Reports_model::get_grn_det() E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 74
ERROR - 2018-01-16 11:12:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 11:12:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 16:42:10 --> Severity: Compile Error --> Cannot redeclare Reports_model::get_grn_det() E:\wamp\www\duty\mathewgarments\application\models\Reports_model.php 74
ERROR - 2018-01-16 16:42:29 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 16:42:29 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 11:12:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 11:12:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 11:12:36 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:12:36 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:13:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:13:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:30:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:30:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:31:10 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:31:10 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:38:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:38:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 179
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 180
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 181
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 182
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: material_name E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 183
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 184
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 185
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: p_rate E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 187
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: sgst E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 188
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: cgst E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 189
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: igst E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 190
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 191
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 192
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 193
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 194
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 195
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 196
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 197
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 198
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 199
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 200
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 179
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 180
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 181
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 182
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: material_name E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 183
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 184
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 185
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: p_rate E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 187
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: sgst E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 188
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: cgst E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 189
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: igst E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 190
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 191
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 192
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 193
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 194
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 195
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 196
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 197
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 198
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 199
ERROR - 2018-01-16 17:16:12 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 200
ERROR - 2018-01-16 11:46:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:46:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 167
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 168
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 169
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 170
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 171
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 172
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 173
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 174
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 175
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 176
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 167
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 168
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 169
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 170
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 171
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 172
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 173
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 174
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 175
ERROR - 2018-01-16 17:17:54 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 176
ERROR - 2018-01-16 11:47:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 11:47:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:30:00 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 60
ERROR - 2018-01-16 17:30:00 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 62
ERROR - 2018-01-16 17:30:00 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 62
ERROR - 2018-01-16 12:00:00 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:00:00 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:30:37 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 60
ERROR - 2018-01-16 17:30:37 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 62
ERROR - 2018-01-16 17:30:37 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 62
ERROR - 2018-01-16 12:00:38 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:00:38 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:33:25 --> Severity: Notice --> Undefined index: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 18
ERROR - 2018-01-16 12:03:25 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:03:25 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:34:01 --> Severity: Notice --> Undefined index: cus_id E:\wamp\www\duty\mathewgarments\application\views\grn_ovearall_report.php 18
ERROR - 2018-01-16 12:04:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:04:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:05:05 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:05:05 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:05:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:05:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:06:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:06:24 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:06:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 12:06:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 12:07:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 12:07:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-16 12:07:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:07:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:07:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:07:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:07:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:07:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:07:41 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:07:41 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:07 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:07 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:16 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:16 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:19 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:19 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:08:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:51 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:51 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:57 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:09:57 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:10:00 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:10:00 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 222
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 223
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 224
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 225
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: material_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 226
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 227
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 228
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 230
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 231
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 232
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 233
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 234
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 235
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 236
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 237
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 238
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 239
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 240
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 241
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 242
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 243
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 222
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 223
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 224
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 225
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: material_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 226
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 227
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 228
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 230
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 231
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 232
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 233
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 234
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 235
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 236
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 237
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 238
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 239
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 240
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 241
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 242
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 243
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 222
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 223
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 224
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 225
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: material_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 226
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 227
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 228
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 230
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 231
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 232
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 233
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 234
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 235
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 236
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 237
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 238
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 239
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 240
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 241
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 242
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 243
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: style E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 222
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: hsn E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 223
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_create E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 224
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: brand_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 225
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: material_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 226
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: color_name E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 227
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: size_fixing E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 228
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 230
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 231
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 232
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 233
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: sgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 234
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: cgst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 235
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: igst_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 236
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_rate E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 237
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: r_percent E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 238
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_amt E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 239
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: wholesale_tax E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 240
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: p_rate_key E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 241
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 242
ERROR - 2018-01-16 17:40:28 --> Severity: Notice --> Undefined index: total E:\wamp\www\duty\mathewgarments\application\controllers\Reports.php 243
ERROR - 2018-01-16 12:11:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:11:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:11:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:11:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:12:28 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:12:28 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:13:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:13:58 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:14:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:14:04 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:14:09 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:14:09 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:15:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:15:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 17:46:30 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 17:46:30 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 12:16:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:16:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:25:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:25:22 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:25:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:25:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:13 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:47 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:47 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:53 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:53 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:57 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:57 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:26:59 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:30:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:30:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:31:50 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:31:50 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:31:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:31:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:31:57 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:31:57 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:32:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:32:12 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:38:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:38:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:39:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:39:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:39:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:39:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 18:11:05 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:11:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:11:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:11:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:11:18 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:11:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:11:20 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:11:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:11:27 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-16 18:11:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-16 18:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-16 18:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-16 18:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-16 18:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-16 18:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-16 12:42:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-16 12:42:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-16 12:47:18 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:47:18 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:47:25 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:47:25 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:50:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:50:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 18:21:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:21:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:21:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:21:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:21:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:21:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:21:16 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:21:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:21:22 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-16 18:21:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-16 18:21:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-16 18:21:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-16 18:21:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-16 18:21:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-16 18:21:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-16 12:51:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-16 12:51:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-16 12:51:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:51:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 18:22:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:18 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:20 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-16 18:22:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-16 18:22:49 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-16 18:22:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-16 18:22:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-16 18:22:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-16 18:22:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-16 18:22:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-16 18:22:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-16 12:53:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-16 12:53:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 160
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 161
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 162
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: branch_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 163
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: remarks E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 164
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 167
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 169
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 160
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 161
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 162
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: branch_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 163
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: remarks E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 164
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 167
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 169
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 160
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 161
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 162
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: branch_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 163
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: remarks E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 164
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 167
ERROR - 2018-01-16 18:24:28 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 169
ERROR - 2018-01-16 12:54:28 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:54:28 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:55:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:55:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 12:57:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 12:57:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 155
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 156
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 157
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: branch_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 158
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: remarks E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 159
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 162
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 164
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 155
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 156
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 157
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: branch_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 158
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: remarks E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 159
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 162
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 164
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 155
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: vendor_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 156
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: lot E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 157
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: branch_name E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 158
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: remarks E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 159
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: comm_igst E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 162
ERROR - 2018-01-16 18:28:11 --> Severity: Notice --> Undefined index: lot_placed E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 164
ERROR - 2018-01-16 12:58:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 12:58:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 18:32:24 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 159
ERROR - 2018-01-16 18:32:24 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 159
ERROR - 2018-01-16 18:32:24 --> Severity: Notice --> Undefined index: dcno E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 159
ERROR - 2018-01-16 13:02:25 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:02:25 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:02:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:02:55 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:03:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:03:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:04:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:04:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:08:17 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:08:17 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 18:44:53 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 18:44:53 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 13:14:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 13:14:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 18:47:22 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 18:47:22 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 13:17:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 13:17:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 13:24:39 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:24:39 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:27:38 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:27:38 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:27:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:27:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:28:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:28:20 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:28:34 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:28:34 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:33:05 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:33:05 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:05:33 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::distinct() E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 88
ERROR - 2018-01-16 13:35:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:35:54 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:08:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:08:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:22 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:38:23 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:38:23 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:08:31 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:08:31 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:31 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:31 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:38:31 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:38:31 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:08:39 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:08:39 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:39 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:39 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:38:39 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:38:39 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:08:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:08:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:38:42 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:38:42 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:08:49 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:08:49 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:49 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:08:49 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:38:49 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:38:49 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:13:01 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:13:01 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:13:01 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:13:01 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:43:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:43:01 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:14:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:14:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:14:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:14:42 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:44:42 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:44:42 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:14:45 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:14:45 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:14:45 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:14:45 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:44:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:44:45 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:15:03 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:15:03 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:15:03 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:15:03 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:45:03 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:45:03 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:15:07 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 62
ERROR - 2018-01-16 19:15:07 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:15:07 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 19:15:07 --> Severity: Notice --> Undefined variable: cus_id E:\wamp\www\duty\mathewgarments\application\views\retail_overall_report.php 64
ERROR - 2018-01-16 13:45:07 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:45:07 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 19:22:49 --> Severity: Notice --> Undefined variable: frmdt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 73
ERROR - 2018-01-16 19:22:49 --> Severity: Notice --> Undefined variable: todt E:\wamp\www\duty\mathewgarments\application\views\product_report.php 82
ERROR - 2018-01-16 13:52:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-16 13:52:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-16 13:58:30 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 13:58:30 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 14:02:11 --> 404 Page Not Found: Reports/audio
ERROR - 2018-01-16 14:02:11 --> 404 Page Not Found: Reports/audio
