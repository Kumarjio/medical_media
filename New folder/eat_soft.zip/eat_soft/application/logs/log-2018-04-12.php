<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-12 10:48:29 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: UPDATE `tbl_item` SET `is_delete` = 1
WHERE `item_id` = '6'
ERROR - 2018-04-12 10:48:33 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: UPDATE `tbl_item` SET `is_delete` = 1
WHERE `item_id` = '6'
ERROR - 2018-04-12 11:20:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 5
ERROR - 2018-04-12 11:20:39 --> Severity: Notice --> Undefined index: item_name E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-12 11:20:39 --> Severity: Notice --> Undefined index: sale_price E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-12 11:20:39 --> Severity: Notice --> Undefined index: sale_qty E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-12 11:20:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 5
ERROR - 2018-04-12 11:20:51 --> Severity: Notice --> Undefined index: item_name E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-12 11:20:51 --> Severity: Notice --> Undefined index: sale_price E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-12 11:20:51 --> Severity: Notice --> Undefined index: sale_qty E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-12 11:26:08 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: UPDATE `tbl_item` SET `is_delete` = 1
WHERE `item_id` = '1'
ERROR - 2018-04-12 11:27:30 --> Query error: Unknown column 'is_delete' in 'field list' - Invalid query: UPDATE `tbl_item` SET `is_delete` = 1
WHERE `item_id` = '2'
ERROR - 2018-04-12 11:38:15 --> Severity: Notice --> Undefined index: item_name E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-12 11:38:15 --> Severity: Notice --> Undefined index: sale_price E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-12 11:38:15 --> Severity: Notice --> Undefined index: sale_qty E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-12 11:38:43 --> Severity: Notice --> Undefined index: item_name E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-12 11:38:43 --> Severity: Notice --> Undefined index: sale_price E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-12 11:38:43 --> Severity: Notice --> Undefined index: sale_qty E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-12 11:38:46 --> Severity: Notice --> Undefined index: item_name E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-12 11:38:46 --> Severity: Notice --> Undefined index: sale_price E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-12 11:38:46 --> Severity: Notice --> Undefined index: sale_qty E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-12 11:41:40 --> Severity: Notice --> Undefined index: item_name E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 88
ERROR - 2018-04-12 11:41:40 --> Severity: Notice --> Undefined index: sale_price E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 89
ERROR - 2018-04-12 11:41:40 --> Severity: Notice --> Undefined index: sale_qty E:\wamp\www\duty\hotel\application\views\sales\sales_list.php 90
ERROR - 2018-04-12 11:51:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\hotel\application\views\include_css.php 5
