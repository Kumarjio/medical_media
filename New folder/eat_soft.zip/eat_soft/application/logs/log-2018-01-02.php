<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-02 05:34:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 05:34:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 05:34:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 05:34:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 05:35:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 05:35:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 05:36:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 05:36:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 05:37:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 05:37:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 05:59:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 05:59:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:04:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:04:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:04:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:04:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:05:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:05:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:05:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:05:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:07:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:07:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:07:35 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 06:07:35 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 06:18:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:18:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:20:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:20:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:21:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:21:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:22:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:22:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:23:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:23:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:56:06 --> Severity: Notice --> Use of undefined constant DESC - assumed 'DESC' C:\xampp\htdocs\duty\mathewgarments\application\models\Barcode_model.php 12
ERROR - 2018-01-02 06:26:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:26:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:27:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:27:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:31:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:31:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:49:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:49:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:20:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\duty\mathewgarments\application\controllers\Barcode.PHP 51
ERROR - 2018-01-02 06:50:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:50:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:52:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:52:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:52:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:52:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:53:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:53:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:53:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:53:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 06:54:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 06:54:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 07:13:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 07:13:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 07:33:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 07:33:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 07:38:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:38:14 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:41:06 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:41:06 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:42:27 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:42:27 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:43:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:43:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:44:25 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:44:25 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:44:46 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:44:46 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:06 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:06 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:45:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:46:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:46:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:46:45 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:46:45 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:47:20 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:47:20 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:47:53 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:47:54 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:48:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:48:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:48:23 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:48:23 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:48:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:48:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:49:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:49:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:50:53 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:50:53 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:52:20 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:52:20 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:53:10 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:53:10 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:55:15 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:55:15 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:55:38 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:55:38 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:27:12 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id=tbl_single_po_entry.po_inv_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.	`po_inv_id=tbl_single_po_entry`. `po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
ERROR - 2018-01-02 12:27:55 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id=tbl_single_po_entry.po_inv_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.	`po_inv_id=tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
ERROR - 2018-01-02 07:58:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 07:58:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:00:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:00:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:00:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:00:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:14 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:14 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:30 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:30 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:36 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:36 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:01:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:01:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:01:57 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:04:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:04:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:04:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:04:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:06:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:06:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:08:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:08:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:09:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:09:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:10:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:10:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:10:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:10:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:11:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:11:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:11:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 08:11:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 08:14:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 08:14:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:01:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:01:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:01:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:01:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:05:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:05:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:06:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:06:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:13:29 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:13:29 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:16:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:16:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:16:49 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:16:49 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:17:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:17:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:17:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:17:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:18:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:18:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:19:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:19:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:19:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:19:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:19:37 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:19:37 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:21:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:21:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:30:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:30:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:30:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:30:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:30:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-02 10:30:39 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-02 10:34:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:34:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:37:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:37:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:42:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:42:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:12:30 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:12:30 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:12:30 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:12:30 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:12:30 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:12:30 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:42:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:42:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:42:46 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 10:42:46 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 15:12:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:12:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:12:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:12:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:12:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:12:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:42:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:42:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 15:13:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:13:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:13:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:13:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:13:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:13:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:43:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:43:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:15:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:15:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:45:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:45:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 15:15:10 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:10 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:10 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:15:10 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:10 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:10 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:45:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:45:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:15:22 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:22 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:22 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:15:22 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:22 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:22 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:45:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:45:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:15:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:15:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:45:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:45:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:45:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:45:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:15:57 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:57 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:57 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:15:57 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:15:57 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:15:57 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:45:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:45:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:16:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:16:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:16:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:16:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:16:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:16:06 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:46:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:46:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:16:32 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:16:32 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:16:32 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:16:32 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:16:32 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:16:32 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:46:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:46:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:52:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:52:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:22:06 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2018-01-02 10:53:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:53:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:53:59 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\duty\mathewgarments\application\controllers\Stock_transfer.php 55
ERROR - 2018-01-02 15:24:18 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:24:18 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:24:18 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:24:18 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:24:18 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:24:18 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:54:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:54:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:54:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:54:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:54:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 10:54:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:55:02 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-02 10:55:02 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-02 10:55:04 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-02 10:55:04 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-02 10:55:26 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-02 10:55:26 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-02 10:56:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:56:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:26:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:26:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:26:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:26:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:26:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:26:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 10:56:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 10:56:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:26:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:26:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:26:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:26:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:26:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:26:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:26:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:26:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:26:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:26:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:26:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:26:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:26:57 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:26:57 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:26:57 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 10:56:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 10:56:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:30:15 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:30:15 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:30:15 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:00:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:00:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:30:29 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:30:29 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:30:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:30:29 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:30:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:00:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:00:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:30:38 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:30:38 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:30:38 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:00:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:00:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:31:00 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:31:00 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:00 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:01:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:01:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:31:12 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:31:12 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:12 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:31:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:01:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:01:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:31:18 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:31:18 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:18 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:31:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:01:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:01:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:31:26 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:31:26 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:26 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:31:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:01:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:01:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:31:29 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:31:29 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:29 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:01:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:01:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:31:56 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:31:56 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:31:56 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 11:01:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:01:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:32:22 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:32:22 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:32:22 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:32:22 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:32:22 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 15:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 11:02:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:02:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:33:20 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:33:20 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:33:20 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:33:20 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:33:20 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 15:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 11:03:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:03:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:33:41 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:33:41 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:33:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:33:41 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:33:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:33:41 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:33:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:33:41 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 15:33:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 11:03:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:03:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:34:00 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:34:00 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 25
ERROR - 2018-01-02 15:34:00 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 34
ERROR - 2018-01-02 15:34:00 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 47
ERROR - 2018-01-02 15:34:00 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 15:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 56
ERROR - 2018-01-02 11:04:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:04:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:34:55 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:34:55 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 31
ERROR - 2018-01-02 15:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 31
ERROR - 2018-01-02 15:34:55 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 44
ERROR - 2018-01-02 15:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 44
ERROR - 2018-01-02 15:34:55 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 53
ERROR - 2018-01-02 15:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 53
ERROR - 2018-01-02 11:04:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:04:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:35:28 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:35:28 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:28 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 15:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 11:05:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:05:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:35:29 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:35:29 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:29 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 15:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 11:05:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:05:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:35:39 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:35:39 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:39 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 15:35:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 11:05:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:05:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:35:52 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:35:52 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:35:52 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 15:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 11:05:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:05:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:06:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:06:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:36:37 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:36:37 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:36:37 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:36:37 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:36:37 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:36:37 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 11:06:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:06:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 15:36:39 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:36:39 --> Severity: Notice --> Undefined variable: style_name C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:36:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 41
ERROR - 2018-01-02 15:36:39 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 15:36:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 50
ERROR - 2018-01-02 11:06:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:06:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:43:28 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 36
ERROR - 2018-01-02 15:43:43 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:43:43 --> Severity: Notice --> Undefined index: style C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 42
ERROR - 2018-01-02 15:43:43 --> Severity: Notice --> Undefined index: style C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 42
ERROR - 2018-01-02 15:43:43 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 51
ERROR - 2018-01-02 15:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 51
ERROR - 2018-01-02 11:13:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:13:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:44:28 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 15:44:28 --> Severity: Notice --> Undefined variable: color C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 51
ERROR - 2018-01-02 15:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 51
ERROR - 2018-01-02 11:14:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:14:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:44:50 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:14:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:14:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:44:54 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:14:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:14:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:45:17 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:15:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:15:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:45:25 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:15:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:15:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:45:29 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:15:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:15:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:15:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:15:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:16:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:16:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:17:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:17:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:17:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:17:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 15:47:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:47:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:47:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 15:47:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 15:47:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 15:47:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 11:17:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:17:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 15:47:36 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:17:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:17:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:49:00 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:19:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:19:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:49:21 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:19:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:19:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:49:33 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:19:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:19:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:49:58 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:19:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:19:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:51:13 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:21:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:21:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:51:20 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:21:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:21:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:51:25 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:21:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:21:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:52:04 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:22:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:22:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:52:24 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:22:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:22:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:52:35 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:22:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:22:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:52:44 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:22:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:22:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:52:51 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:22:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:22:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:53:12 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:23:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:23:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:53:21 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:23:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:23:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:53:44 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:23:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:23:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:53:59 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:23:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:23:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:55:26 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:25:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:25:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:57:23 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:27:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:27:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:57:40 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:27:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:27:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:58:31 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:28:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:28:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:58:48 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:28:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:28:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:58:53 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:28:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:28:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 15:58:57 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:28:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:28:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:07:30 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:37:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:37:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:07:47 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:37:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:37:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:08:25 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:38:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:38:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:08:53 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:38:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:38:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:39:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:39:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 16:20:54 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:20:54 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:20:54 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:20:54 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:20:54 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:20:54 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 11:50:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:50:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 16:20:57 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 11:50:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:50:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:21:31 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 11:51:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:51:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:21:45 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 16:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 11:51:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:51:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:22:27 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 16:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 11:52:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:52:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:24:39 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 11:54:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:54:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:54:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:54:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:54:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:54:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:55:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:55:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 16:26:00 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:26:00 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:26:00 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:26:00 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:26:00 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:26:00 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:26:03 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 16:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 11:56:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:56:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:57:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 11:57:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:57:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 11:57:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 16:27:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:27:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:27:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:27:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:27:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:27:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 11:57:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 11:57:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 37
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 79
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 177
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 186
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 314
ERROR - 2018-01-02 16:27:09 --> Severity: Notice --> Undefined variable: size C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 16:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\duty\mathewgarments\application\views\addstock_transfer.php 317
ERROR - 2018-01-02 11:57:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:57:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:28:10 --> Severity: Notice --> Undefined property: Stock_transfer::$Goodsreceived_model C:\xampp\htdocs\duty\mathewgarments\application\controllers\Stock_transfer.php 55
ERROR - 2018-01-02 16:28:10 --> Severity: Error --> Call to a member function get_all_pro() on null C:\xampp\htdocs\duty\mathewgarments\application\controllers\Stock_transfer.php 55
ERROR - 2018-01-02 11:58:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:58:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 16:28:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:28:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:28:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:28:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:28:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:28:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 11:58:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 11:58:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:01:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:01:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:01:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:01:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:04:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:04:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:07:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:07:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:07:56 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:07:56 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:08:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:08:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:08:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:08:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:08:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:08:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:08:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:08:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:09:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:09:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:09:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:09:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:10:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:10:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:10:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:10:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:11:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:11:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:12:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:12:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:12:52 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:12:52 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:15:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:15:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:15:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:15:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:18:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:18:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:19:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:19:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:50:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 12:20:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:20:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:20:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:20:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:23:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:23:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:23:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:23:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:23:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:23:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 16:56:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 12:26:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:26:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:30:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:30:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-02 12:30:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:30:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:30:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 12:30:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-02 17:10:12 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id C:\xampp\htdocs\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-02 12:40:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-02 12:40:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-02 12:40:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:40:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:42:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:43:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:43:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:43:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:43:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:44:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:44:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:44:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:44:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:45:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:46:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:46:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:46:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:46:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:47:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:47:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:47:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:47:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:47:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 12:47:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 13:04:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 13:04:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 13:04:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 13:04:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 13:08:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-02 13:08:34 --> 404 Page Not Found: Stock_transfer/audio
