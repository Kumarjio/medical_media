<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-19 03:05:56 --> 404 Page Not Found: Returndet/get_stock_details
ERROR - 2018-01-19 03:06:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:06:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:06:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:06:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:06:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:06:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:06:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:06:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:13:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:13:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:14:03 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:14:03 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:14:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:14:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:15:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:15:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:16:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:16:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:17:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:17:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:18:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:18:36 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:19:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:19:01 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:20:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:20:11 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:20:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:20:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:20:52 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:20:52 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 08:51:00 --> Severity: Error --> Call to undefined method Returndet::input() E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 42
ERROR - 2018-01-19 08:51:15 --> Severity: Notice --> Undefined variable: wholesale_percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 717
ERROR - 2018-01-19 08:51:15 --> Severity: Notice --> Undefined variable: wholesale_rate E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 718
ERROR - 2018-01-19 08:51:15 --> Severity: Notice --> Undefined variable: rate E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 719
ERROR - 2018-01-19 08:51:15 --> Severity: Notice --> Undefined variable: percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 720
ERROR - 2018-01-19 08:51:15 --> Query error: Column 'wholesale_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (6, '1', '1', '2', '9005', '1', NULL, NULL, NULL, NULL, '10', '1500', 'kjikji', '16800', 0, 0, '12', 0, 0, '1800', 1)
ERROR - 2018-01-19 08:51:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 654
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 669
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 48
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 57
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 64
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 72
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 113
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 121
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 08:51:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 143
ERROR - 2018-01-19 03:22:00 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:22:00 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 654
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 669
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 48
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 57
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 64
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 72
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 113
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 121
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 08:52:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 143
ERROR - 2018-01-19 03:22:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:22:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:22:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:22:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:22:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:22:13 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 654
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined index: grn_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 669
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 48
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 57
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 64
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 72
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 113
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 121
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 09:12:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 143
ERROR - 2018-01-19 03:42:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:50 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:42:53 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:43:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:43:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:43:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:43:48 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:44:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:44:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 48
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 57
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 64
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 72
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 113
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 121
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 09:14:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 143
ERROR - 2018-01-19 03:44:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:44:27 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:44:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:44:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 36
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 48
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 57
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 64
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 72
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 84
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 113
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 121
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 131
ERROR - 2018-01-19 09:14:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 143
ERROR - 2018-01-19 03:44:40 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:44:40 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:44:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:44:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:45:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 03:45:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 03:45:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:45:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:46:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 03:46:16 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:27:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:27:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 10:05:36 --> Severity: Notice --> Undefined variable: wholesale_percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 719
ERROR - 2018-01-19 10:05:36 --> Severity: Notice --> Undefined variable: wholesale_rate E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 720
ERROR - 2018-01-19 10:05:36 --> Severity: Notice --> Undefined variable: rate E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 721
ERROR - 2018-01-19 10:05:36 --> Severity: Notice --> Undefined variable: percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 722
ERROR - 2018-01-19 10:05:36 --> Query error: Column 'wholesale_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_return_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '1', '1', '2', '9005', '1', NULL, NULL, NULL, NULL, '0', '1500', 'kjikji', '0', 0, 0, '12', 0, 0, '1800', 1)
ERROR - 2018-01-19 04:35:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:35:46 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 10:05:59 --> Severity: Notice --> Undefined variable: wholesale_percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 719
ERROR - 2018-01-19 10:05:59 --> Severity: Notice --> Undefined variable: wholesale_rate E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 720
ERROR - 2018-01-19 10:05:59 --> Severity: Notice --> Undefined variable: rate E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 721
ERROR - 2018-01-19 10:05:59 --> Severity: Notice --> Undefined variable: percent E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 722
ERROR - 2018-01-19 10:05:59 --> Query error: Column 'wholesale_tax' cannot be null - Invalid query: INSERT INTO `tbl_po_return_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `p_rate_key`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (2, '1', '1', '2', '9005', '1', NULL, NULL, NULL, NULL, '10', '1500', 'kjikji', '16800', 0, 0, '12', 0, 0, '1800', 1)
ERROR - 2018-01-19 04:37:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 04:37:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 04:41:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 04:41:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 10:11:38 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:41:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 04:41:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:11:52 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:41:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 04:41:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 10:11:54 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:44:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 04:44:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 10:14:05 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:44:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 04:44:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:14:14 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:44:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:44:18 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 10:14:18 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:44:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 04:44:45 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 10:14:45 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:44:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 04:44:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:14:55 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:44:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 04:44:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:14:59 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:49:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 04:49:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:19:35 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:49:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:49:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 10:19:45 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:50:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:50:45 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 10:20:46 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:53:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 04:53:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:23:04 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 17
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 36
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 48
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 55
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 63
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 75
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 104
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 112
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 122
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 134
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 261
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 266
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 271
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 281
ERROR - 2018-01-19 10:23:07 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:53:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 04:53:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:23:26 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:53:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 04:53:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:23:41 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:53:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 04:53:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 10:23:42 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:55:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 04:55:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-19 10:25:35 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:55:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 04:55:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:25:46 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:55:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 04:55:49 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 10:25:50 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 04:56:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 04:56:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:26:44 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 05:01:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:01:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:31:03 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 65
ERROR - 2018-01-19 05:01:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:01:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 05:11:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:11:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 05:35:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:35:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 05:35:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 05:35:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 05:36:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 05:36:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:38:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:38:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 05:38:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 05:38:33 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 11:08:35 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 792
ERROR - 2018-01-19 05:38:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 05:38:57 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 37
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 49
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 58
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 65
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 73
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 85
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 85
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 114
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 122
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 132
ERROR - 2018-01-19 11:10:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\return_datas.php 144
ERROR - 2018-01-19 05:40:17 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 05:40:17 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 05:42:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 05:42:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 05:42:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 05:42:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:13:13 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 11:13:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 11:13:17 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 11:13:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 11:13:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-19 11:13:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-19 11:13:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-19 11:13:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-19 11:13:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-19 11:13:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-19 11:13:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-19 05:43:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 05:43:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:03:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 06:03:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 06:04:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:04:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:04:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 06:04:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 06:17:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 06:17:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 06:24:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 06:24:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 06:24:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:24:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:25:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:25:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:25:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:25:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:25:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:25:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:38:15 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 06:38:15 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 06:38:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 06:38:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 06:38:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:38:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:39:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:39:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:39:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:39:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:39:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:39:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:46:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:46:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:59:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 06:59:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:12:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 07:12:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 07:12:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:12:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:19:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 07:19:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 07:20:00 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-19 07:20:00 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-19 07:21:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:21:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:22:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:22:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:22:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 07:22:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 12:52:09 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer.php 51
ERROR - 2018-01-19 07:22:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:22:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:25:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:25:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 12:56:43 --> Severity: Error --> Call to undefined function random_string() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer.php 60
ERROR - 2018-01-19 07:27:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:27:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:27:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 07:27:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 08:54:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 08:54:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 08:57:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 08:57:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 14:27:16 --> Severity: Warning --> Missing argument 1 for CI_DB_query_builder::from(), called in E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php on line 94 and defined E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 458
ERROR - 2018-01-19 14:27:16 --> Severity: Notice --> Undefined variable: from E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 460
ERROR - 2018-01-19 14:27:16 --> Severity: Warning --> Missing argument 1 for CI_DB_query_builder::where(), called in E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php on line 94 and defined E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 600
ERROR - 2018-01-19 14:27:16 --> Severity: Notice --> Undefined variable: key E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 602
ERROR - 2018-01-19 14:27:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE  IS NULL' at line 2 - Invalid query: SELECT *
WHERE  IS NULL
ERROR - 2018-01-19 14:27:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `id` = '79fbc69d5d12788965506223a8290690929ca6bd'' at line 2 - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516352236
WHERE  IS NULL
AND `id` = '79fbc69d5d12788965506223a8290690929ca6bd'
ERROR - 2018-01-19 14:27:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\database\DB_driver.php:1697) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-19 08:58:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 08:58:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 14:28:47 --> Severity: Notice --> Array to string conversion E:\wamp\www\duty\mathewgarments\system\database\DB_query_builder.php 662
ERROR - 2018-01-19 14:28:47 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_transfer_out`
WHERE `dcno` = `Array`
ERROR - 2018-01-19 14:28:47 --> Query error: Unknown column 'dcno' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516352327
WHERE `dcno` = `Array`
AND `id` = '79fbc69d5d12788965506223a8290690929ca6bd'
ERROR - 2018-01-19 14:41:20 --> Query error: Column 'dcno' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_transfer_out`
LEFT JOIN `tbl_transfer_out_item` ON `tbl_transfer_out_item`.`transfer_out_ref_id`=`tbl_transfer_out`.`transfer_out_id`
LEFT JOIN `tbl_single_po_entry` ON `tbl_single_po_entry`.`single_po_entry_id`=`tbl_transfer_out_item`.`pro_bar_code`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
WHERE `dcno` = '12'
ERROR - 2018-01-19 14:41:20 --> Query error: Unknown column 'dcno' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516353080
WHERE `dcno` = '12'
AND `id` = '79fbc69d5d12788965506223a8290690929ca6bd'
ERROR - 2018-01-19 14:42:31 --> Query error: Column 'dcno' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_transfer_out`
LEFT JOIN `tbl_transfer_out_item` ON `tbl_transfer_out_item`.`transfer_out_ref_id`=`tbl_transfer_out`.`transfer_out_id`
LEFT JOIN `tbl_single_po_entry` ON `tbl_single_po_entry`.`single_po_entry_id`=`tbl_transfer_out_item`.`pro_bar_code`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
WHERE `dcno` = '12'
ERROR - 2018-01-19 14:42:31 --> Query error: Unknown column 'dcno' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1516353151
WHERE `dcno` = '12'
AND `id` = '79fbc69d5d12788965506223a8290690929ca6bd'
ERROR - 2018-01-19 09:20:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:20:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:20:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 09:20:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 09:20:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:20:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:27:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:27:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:27:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:27:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:40:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 09:40:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-19 09:40:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 09:40:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 09:40:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 09:40:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 09:40:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:40:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:10:46 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 15:10:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 15:10:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 15:10:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 09:43:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:43:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:43:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:43:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:44:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:44:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:15:33 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 37
ERROR - 2018-01-19 15:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 37
ERROR - 2018-01-19 15:15:33 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 15:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 09:45:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:45:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:15:46 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 15:15:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 15:15:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-19 15:15:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-19 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-19 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-19 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-19 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-19 15:15:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-19 15:15:54 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 37
ERROR - 2018-01-19 15:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 37
ERROR - 2018-01-19 15:15:54 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 15:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 09:45:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:45:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:17:03 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 82
ERROR - 2018-01-19 15:17:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 82
ERROR - 2018-01-19 09:47:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:47:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:17:12 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 15:17:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 09:47:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:47:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:17:56 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 15:17:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 84
ERROR - 2018-01-19 09:47:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:47:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:18:30 --> Severity: Notice --> Undefined variable: branch E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 81
ERROR - 2018-01-19 15:18:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\addstock_transfer_in.php 81
ERROR - 2018-01-19 09:48:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:48:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:50:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:50:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:50:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:50:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:51:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:51:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:51:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 09:51:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 09:51:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:51:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:52:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:52:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:53:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 09:53:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:12:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:12:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:26:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:26:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:27:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:27:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 15:57:42 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 15:57:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 10:58:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:58:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 16:28:41 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:28:41 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:28:44 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:28:44 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:28:46 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-19 16:28:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-19 10:58:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:58:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:59:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 10:59:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 10:59:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 10:59:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 16:29:51 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 16:29:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 16:29:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-19 16:29:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-19 16:29:54 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-19 16:29:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-19 11:00:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:00:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:00:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:00:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:00:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:00:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 16:30:30 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:30:30 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 11:00:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:00:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:14:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 11:14:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 11:14:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 11:14:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-19 11:14:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-19 11:14:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-19 11:14:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:14:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:14:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:14:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:14:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:14:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 16:44:59 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:44:59 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:45:04 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:45:04 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:45:07 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:45:07 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:45:09 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:45:09 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 11:15:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:15:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:15:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:15:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 16:45:23 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:45:23 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:45:25 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:45:25 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:45:27 --> Severity: Warning --> Missing argument 2 for Stock_transfer::get_single_po_details_stock_in() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 112
ERROR - 2018-01-19 16:45:27 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 113
ERROR - 2018-01-19 16:45:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-19 16:45:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-19 11:15:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-19 11:15:40 --> 404 Page Not Found: Stock_transfer/audio
