<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-20 05:31:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:31:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:31:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:31:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:37:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:37:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:37:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:37:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:52:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:52:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:53:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:53:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:53:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:53:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:53:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:53:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:55:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:55:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:55:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 05:55:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 05:55:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:55:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:55:09 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 05:55:09 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 05:56:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:56:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:56:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:56:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:56:20 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-20 05:56:20 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-20 05:56:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:56:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:56:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:56:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:56:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:56:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:57:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:57:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:57:14 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-20 05:57:14 --> 404 Page Not Found: Branch/audio
ERROR - 2017-12-20 05:57:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:57:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:28:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-20 10:28:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-20 10:28:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-20 10:28:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 14
ERROR - 2017-12-20 10:28:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 24
ERROR - 2017-12-20 10:28:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\branch_edit.php 38
ERROR - 2017-12-20 05:58:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:58:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:58:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:58:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:58:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:58:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:58:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:58:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:59:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 06:00:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 06:00:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 06:01:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 06:01:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:08:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:08:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:08:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:08:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:09:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:09:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:09:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:09:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:40:14 --> Query error: Field 'unit_ref_id' doesn't have a default value - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`) VALUES (1, '1', '1', '1', '1', '7000', '7280', '0', '4', '0', '0', '280', '0')
ERROR - 2017-12-20 05:12:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:12:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:12:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:12:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:13:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:13:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:13:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:13:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:15:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:15:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:16:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:16:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:17:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:17:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:17:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:17:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:17:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:17:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:19:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:19:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:19:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:19:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:21:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:21:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 05:22:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:22:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:22:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:22:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:22:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 05:22:12 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 05:22:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:22:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:22:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:22:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:22:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:22:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:22:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:22:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:22:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:22:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 10:53:23 --> Query error: Field 'opening_qty' doesn't have a default value - Invalid query: INSERT INTO `tbl_product` (`pro_name`, `brd_name`, `mat_name`, `style`) VALUES ('5', '1', '5', 'SA009')
ERROR - 2017-12-20 05:26:04 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:26:04 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:26:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:26:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:26:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:26:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:26:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:26:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:28:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:28:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 10:58:17 --> Query error: Unknown column 'tbl_product_img.color_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_product_img`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_img`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_id`
WHERE `produt_img_id` = '3'
ERROR - 2017-12-20 10:58:17 --> Query error: Unknown column 'produt_img_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513747697
WHERE `produt_img_id` = '3'
AND `id` = '040d73255731c72010eebc8765b90a71ff37111a'
ERROR - 2017-12-20 10:58:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 05:30:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:30:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:30:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:30:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:30:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:30:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:30:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:30:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:31:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:31:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:31:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:31:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:32:04 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:32:04 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:32:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:32:17 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:02:26 --> Query error: Unknown column 'tbl_product_img.color_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_product_img`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_img`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id` = `tbl_product_img`.`color_id`
WHERE `produt_img_id` = '1'
ERROR - 2017-12-20 11:02:26 --> Query error: Unknown column 'produt_img_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513747946
WHERE `produt_img_id` = '1'
AND `id` = '040d73255731c72010eebc8765b90a71ff37111a'
ERROR - 2017-12-20 11:02:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 05:48:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:48:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:18:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 05:49:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:49:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:14 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 05:49:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:49:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:36 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 05:49:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:49:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 05:49:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:49:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 11:19:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 05:50:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:50:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 05:50:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:50:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:50:21 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-20 05:50:21 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-20 05:50:26 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-20 05:50:26 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-20 05:51:15 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-20 05:51:15 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-20 05:51:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:51:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:51:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:51:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:51:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:51:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:51:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:51:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:51:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:51:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 05:51:46 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 05:51:46 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 05:51:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 05:51:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:14:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:14:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:15:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:15:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:16:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:16:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:16:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:16:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:17:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:17:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:17:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:17:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:17:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:17:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:17:32 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-20 08:17:32 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-20 08:17:56 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-20 08:17:56 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-20 08:18:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:18:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:18:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:18:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:18:59 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-20 08:18:59 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-20 08:19:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:19:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:19:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:19:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:19:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:19:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:50:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:01 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:01 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:50:01 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:01 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:01 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 08:20:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:20:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:50:26 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:26 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:26 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:50:26 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:26 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:26 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:50:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:45 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:45 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:50:45 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:45 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:45 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:50:56 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:56 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:56 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:50:56 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:50:56 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:50:56 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 08:21:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:21:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:51:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:51:20 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:51:20 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 13:51:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 14
ERROR - 2017-12-20 13:51:20 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 24
ERROR - 2017-12-20 13:51:20 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/size_edit.php 38
ERROR - 2017-12-20 08:21:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:21:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:22:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:22:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:24:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:24:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:24:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:24:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:25:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:26:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:26:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:26:27 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:26:27 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:26:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:26:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:26:49 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:26:49 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:34:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:34:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:35:02 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:35:02 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:35:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:35:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:35:46 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:35:46 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 08:36:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:36:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:37:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:37:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:37:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:37:47 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:38:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:38:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:08:49 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 08:39:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:39:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:09:13 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 08:39:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:39:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:25 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 08:40:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:40:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:10:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 08:41:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:41:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 14:17:09 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 08:52:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:52:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 08:52:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 08:52:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 08:52:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 08:52:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 14:25:47 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 14:25:47 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 14:25:47 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 14:25:47 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 10:00:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:00:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:00:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:00:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 10:00:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:00:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 15:31:13 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:31:13 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:31:13 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:31:13 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:32:05 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:32:05 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:32:05 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:32:05 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:32:44 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:32:44 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:32:45 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:32:45 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:34:08 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:34:08 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:34:08 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:34:08 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:35:08 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:35:08 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:35:08 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:35:08 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:39:08 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:39:08 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 15:39:08 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 15:39:08 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 10:12:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:12:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 15:48:23 --> Severity: Notice --> Undefined offset: 7 /home/sureshshivsai/public_html/mathewgarments/application/models/Goodsreceived_model.php 144
ERROR - 2017-12-20 15:48:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/helpers/url_helper.php 561
ERROR - 2017-12-20 10:23:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:23:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 15:53:26 --> Severity: Notice --> Undefined variable: arr /home/sureshshivsai/public_html/mathewgarments/application/models/Dashboard_model.php 99
ERROR - 2017-12-20 15:53:26 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `pro_ref_id` = '1'
ERROR - 2017-12-20 15:53:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 10:23:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:23:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 10:24:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:24:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 15:54:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/branch_edit.php 14
ERROR - 2017-12-20 15:54:52 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/branch_edit.php 24
ERROR - 2017-12-20 15:54:52 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/branch_edit.php 38
ERROR - 2017-12-20 15:54:52 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/branch_edit.php 14
ERROR - 2017-12-20 15:54:52 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/branch_edit.php 24
ERROR - 2017-12-20 15:54:52 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/branch_edit.php 38
ERROR - 2017-12-20 10:25:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:25:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 10:25:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:25:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 10:25:43 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-20 10:25:43 --> 404 Page Not Found: Rate/audio
ERROR - 2017-12-20 10:25:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 10:25:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 10:27:15 --> 404 Page Not Found: Stocksummary/index
ERROR - 2017-12-20 15:57:20 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-20 15:57:20 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513765640
WHERE `id` = 'b9b790867daad2a5953600d08b389292bc476596'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-12-20 15:57:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 10:27:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:27:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 15:59:50 --> Query error: Incorrect integer value: 'adafaf' for column 'invoice' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('2', 'adafaf', '223', '2017-12-20', '1', '3', '8', 'qwrwerf', '104407936743884', '104407936743884.00')
ERROR - 2017-12-20 10:32:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:32:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:32:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 10:32:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 16:04:03 --> Query error: Incorrect integer value: 'rqwerer' for column 'dcno' at row 1 - Invalid query: INSERT INTO `tbl_po_inv` (`supplier_ref_id`, `invoice`, `dcno`, `pdate`, `storage_name`, `rate_ref_id`, `lot`, `remarks`, `stotal`, `gtotal`) VALUES ('2', '4234', 'rqwerer', '2017-12-20', '1', '3', '6', 'sfsfsd', '3305911529839', '4066271104136.64')
ERROR - 2017-12-20 16:05:18 --> Severity: Notice --> Undefined variable: color /home/sureshshivsai/public_html/mathewgarments/application/models/Goodsreceived_model.php 143
ERROR - 2017-12-20 16:05:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/helpers/url_helper.php 561
ERROR - 2017-12-20 11:36:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:36:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:36:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:36:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:37:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:37:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:37:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:37:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:37:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:37:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:37:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 11:37:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 17:07:58 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:07:58 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:07:59 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:07:59 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:08:43 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:08:43 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:08:43 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:08:43 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:09:17 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:09:17 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:09:17 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:09:17 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:09:46 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:09:46 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:09:46 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:09:46 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:10:17 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:10:17 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:10:17 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:10:17 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:10:49 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:10:49 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:10:50 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:10:50 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:11:27 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:11:27 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:11:27 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:11:27 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:11:59 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:11:59 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:11:59 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:11:59 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 11:42:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 11:42:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 11:44:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:44:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 17:14:42 --> Severity: Notice --> Undefined variable: arr /home/sureshshivsai/public_html/mathewgarments/application/models/Dashboard_model.php 99
ERROR - 2017-12-20 17:14:42 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `pro_ref_id` = '11'
ERROR - 2017-12-20 17:14:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/core/Exceptions.php:272) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 17:14:47 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
ERROR - 2017-12-20 17:14:47 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513770287
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
AND `id` = 'e770e554e5d0df30e7fe7f693b636eebe86e38d8'
ERROR - 2017-12-20 17:14:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 17:14:49 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
ERROR - 2017-12-20 17:14:49 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513770289
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
AND `id` = 'e770e554e5d0df30e7fe7f693b636eebe86e38d8'
ERROR - 2017-12-20 17:14:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 17:14:50 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
ERROR - 2017-12-20 17:14:50 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513770290
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
AND `id` = 'e770e554e5d0df30e7fe7f693b636eebe86e38d8'
ERROR - 2017-12-20 17:14:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 17:14:50 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
ERROR - 2017-12-20 17:14:50 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513770290
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
AND `id` = 'e770e554e5d0df30e7fe7f693b636eebe86e38d8'
ERROR - 2017-12-20 17:14:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 17:14:51 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
ERROR - 2017-12-20 17:14:51 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513770291
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '11'
AND `id` = 'e770e554e5d0df30e7fe7f693b636eebe86e38d8'
ERROR - 2017-12-20 17:14:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/sureshshivsai/public_html/mathewgarments/system/database/DB_driver.php:1697) /home/sureshshivsai/public_html/mathewgarments/system/core/Common.php 564
ERROR - 2017-12-20 11:45:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:45:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:45:57 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 11:45:57 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 11:48:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:48:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:49:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:49:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:49:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:49:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:49:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:49:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:50:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:50:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:50:14 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-20 11:50:14 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-20 11:50:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:50:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:53:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:53:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:54:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:54:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:55:00 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 11:55:00 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-20 11:55:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:55:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:58:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:58:40 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:58:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:58:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:58:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 11:58:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 11:58:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:58:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:59:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:59:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:59:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:59:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:59:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 11:59:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 12:02:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 12:02:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 12:03:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 12:03:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 12:03:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 12:03:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 17:34:40 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:34:40 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 17:34:41 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 17:34:41 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 12:58:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 12:58:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 12:58:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 12:58:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:00:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 13:00:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:00:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 13:00:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:00:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 13:00:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:02:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 13:02:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:02:11 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 13:02:11 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-20 13:21:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 13:21:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 13:22:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 13:22:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 18:53:20 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:01:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:01:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:41:54 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:41:55 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 14:13:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 14:13:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 14
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 24
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 33
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 42
ERROR - 2017-12-20 19:43:31 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/product_image_edit.php 57
ERROR - 2017-12-20 15:42:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 15:42:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 15:43:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 15:43:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined variable: seller /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 114
ERROR - 2017-12-20 21:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 114
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 126
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 138
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 152
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 162
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 276
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined variable: seller /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 114
ERROR - 2017-12-20 21:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 114
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 126
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 138
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 152
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 162
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 276
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined variable: seller /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 114
ERROR - 2017-12-20 21:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 114
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 126
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 138
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 152
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 162
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Undefined offset: 0 /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 276
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 351
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 21:13:33 --> Severity: Notice --> Trying to get property of non-object /home/sureshshivsai/public_html/mathewgarments/application/views/goods_edit.php 352
ERROR - 2017-12-20 15:43:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-20 15:43:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-20 15:43:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 15:43:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-20 21:15:27 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:27 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:15:40 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:40 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:15:41 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:41 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:15:48 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:48 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:15:48 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:48 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:15:58 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:58 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:15:58 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:15:58 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:16:14 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:16:14 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:16:15 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:16:15 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:17:02 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:17:02 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:17:02 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:17:02 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:17:16 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:17:16 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:17:16 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:17:16 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
ERROR - 2017-12-20 21:17:19 --> Severity: Warning --> Missing argument 1 for Goodsreceived::get_correspond_col() /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 74
ERROR - 2017-12-20 21:17:19 --> Severity: Notice --> Undefined variable: style /home/sureshshivsai/public_html/mathewgarments/application/controllers/Goodsreceived.php 75
