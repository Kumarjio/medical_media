<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-06 12:39:56 --> 404 Page Not Found: Audio/alert.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-06 12:39:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-06 12:49:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-06 12:49:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-06 12:49:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-06 12:49:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-06 13:05:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-06 13:05:53 --> 404 Page Not Found: Goodsreceived/audio
