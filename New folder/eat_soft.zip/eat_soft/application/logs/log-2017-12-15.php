<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 09:51:47 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 05:21:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 05:21:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 05:21:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 05:21:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 05:21:54 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 05:21:54 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 05:21:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 05:21:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 05:21:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:21:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:22:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:22:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:23:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:23:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:30:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:30:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:31:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 05:31:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 05:31:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 05:31:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 05:31:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:31:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:32:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:32:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 05:32:40 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 05:32:40 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 05:33:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 05:33:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 06:25:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 06:25:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 06:25:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 06:25:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 06:25:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:25:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:26:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:26:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:37:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:37:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:37:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:37:59 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:42:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:42:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:43:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:43:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:43:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:43:55 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:43:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:43:58 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:44:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:44:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:46:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:46:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:46:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 06:46:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 06:46:12 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 06:46:12 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 06:46:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 06:46:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 06:46:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 06:46:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 06:46:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:46:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:47:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:47:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:47:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:47:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:47:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:47:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 06:48:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 06:48:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:04:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:04:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 07:05:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:05:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 07:05:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:05:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:05:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:05:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:05:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 07:05:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:06:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:06:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 07:06:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:06:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:07:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:07:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:07:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:07:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 07:13:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 07:13:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:43:29 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT `tbl_product_image`.*, `tbl_product`.*, `tbl_productcreation`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_product`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_image`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
ERROR - 2017-12-15 11:45:04 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT `tbl_product_image`.*, `tbl_product`.*, `tbl_productcreation`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_product`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_image`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
ERROR - 2017-12-15 11:46:18 --> Query error: Table 'db_methew_gar.tbl_product_image' doesn't exist - Invalid query: SELECT *
FROM `tbl_product_image`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_image`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
ERROR - 2017-12-15 11:46:55 --> Query error: Unknown column 'tbl_product_image.style_name' in 'on clause' - Invalid query: SELECT *
FROM `tbl_product_img`
LEFT JOIN `tbl_product` ON `tbl_product`.`style` = `tbl_product_image`.`style_name`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id` = `tbl_product`.`pro_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id` = `tbl_product`.`mat_name`
LEFT JOIN `tbl_brand` ON `tbl_brand`.`brand_id` = `tbl_product`.`brd_name`
ERROR - 2017-12-15 07:17:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:17:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:20:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:20:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:20:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:20:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:47 --> Severity: Notice --> Undefined variable: pcreate D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:09:47 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:09:47 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 12:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 07:39:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:39:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:59 --> Severity: Compile Error --> Cannot redeclare Product_model::get_color() D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 287
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:12:47 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 12:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 07:42:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:42:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined index: p_create_id D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 25
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:13:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:13:45 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 12:13:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 07:43:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:43:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:14:13 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 35
ERROR - 2017-12-15 12:14:13 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 12:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 45
ERROR - 2017-12-15 07:44:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:44:13 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:15:37 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 44
ERROR - 2017-12-15 12:15:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 44
ERROR - 2017-12-15 07:45:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:45:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:18:10 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 44
ERROR - 2017-12-15 12:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_add.php 44
ERROR - 2017-12-15 07:48:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:48:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:49:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:49:48 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:27 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:50:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:51:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:51:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:57:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:57:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:57:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:57:43 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:58:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 07:58:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:00:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:00:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:00:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:00:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:00:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:00:41 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:01:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:01:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:02:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 08:02:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 08:02:06 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 08:02:06 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 08:02:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 08:02:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 08:02:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:02:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:02:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:02:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:02:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:02:44 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:03:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:03:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:03:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:03:29 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:22:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:22:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:24:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 08:24:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 09:57:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 09:57:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 09:58:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 09:58:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:02:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:02:49 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 14:33:00 --> Severity: Notice --> Undefined property: stdClass::$color_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 67
ERROR - 2017-12-15 14:33:00 --> Severity: Notice --> Undefined property: stdClass::$color_name D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 67
ERROR - 2017-12-15 10:03:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:03:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 63
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 64
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 65
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 66
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 67
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 68
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 71
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 73
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 63
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 64
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 65
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 66
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 67
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 68
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 71
ERROR - 2017-12-15 14:38:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 73
ERROR - 2017-12-15 10:08:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:08:22 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:08:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:08:39 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:11:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:11:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:11:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:11:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:11:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:11:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:12:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:12:02 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:16:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:16:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 14:52:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 14:52:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 14:52:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 14:52:37 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 14:55:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 14:56:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 14:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 14:56:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 14:56:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 10:26:59 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 141
ERROR - 2017-12-15 10:30:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:30:16 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 15:00:20 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 63
ERROR - 2017-12-15 15:01:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 68
ERROR - 2017-12-15 15:01:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_list.php 68
ERROR - 2017-12-15 10:31:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:31:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:31:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:31:52 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 15:02:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:02:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:02:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:02:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:02:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:02:53 --> Severity: Notice --> Undefined index: image_url D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:02:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:02:55 --> Severity: Notice --> Undefined index: image_url D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:02:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:02:55 --> Severity: Notice --> Undefined index: image_url D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:03:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:03:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:03:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:03:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:04:38 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:22 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:05:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:22:29 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:11 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 147
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:28 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 147
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:48 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:25:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 10:59:25 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 158
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:33 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:29:35 --> Severity: Notice --> Undefined variable: pname D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 50
ERROR - 2017-12-15 15:29:35 --> Severity: Notice --> Undefined variable: material D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 51
ERROR - 2017-12-15 15:29:35 --> Severity: Notice --> Undefined variable: brand D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 52
ERROR - 2017-12-15 15:29:35 --> Severity: Notice --> Undefined variable: style D:\xampp\htdocs\duty\mathewgarments\application\models\Product_model.php 53
ERROR - 2017-12-15 10:59:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 10:59:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-15 15:29:45 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2017-12-15 10:59:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 10:59:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:29:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:00:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:00:03 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:30:11 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:26:28 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 157
ERROR - 2017-12-15 11:26:29 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 157
ERROR - 2017-12-15 11:26:35 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 157
ERROR - 2017-12-15 11:27:14 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 156
ERROR - 2017-12-15 11:27:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:27:54 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:28:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:28:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:29:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:29:01 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:29:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:29:07 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:44 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:29:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:29:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 15:59:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:00:01 --> Severity: Notice --> Undefined index: images D:\xampp\htdocs\duty\mathewgarments\application\controllers\Product.php 151
ERROR - 2017-12-15 16:00:01 --> You did not select a file to upload.
ERROR - 2017-12-15 11:30:04 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:30:04 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:30:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:30:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:00:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:00:30 --> The filetype you are attempting to upload is not allowed.
ERROR - 2017-12-15 11:30:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:30:32 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:02:04 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:02:09 --> The filetype you are attempting to upload is not allowed.
ERROR - 2017-12-15 11:32:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:32:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:34:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:34:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:04:49 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:34:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:34:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:01 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:35:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:35:08 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:05:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:35:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:35:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:37:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:37:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:37:41 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:37:41 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:38:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:38:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:38:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:38:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:38:17 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 11:38:17 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 11:38:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:38:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:38:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:38:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:38:41 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 11:38:41 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 11:38:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:38:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:39:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:39:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:39:11 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 11:39:11 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 11:39:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:39:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:39:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:39:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:39:33 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:39:33 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:05 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:19 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:40:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:41:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:41:00 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:41:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:41:10 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 14
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 24
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 33
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 42
ERROR - 2017-12-15 16:11:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\product_image_edit.php 57
ERROR - 2017-12-15 11:41:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:41:37 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:01 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 11:42:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:42:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:12:11 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 11:42:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:42:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:42:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:42:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 16:12:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-15 11:42:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:42:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:42:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:42:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:45:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:45:20 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:45:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:45:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:45:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:45:50 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:45:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 11:45:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-15 16:20:42 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-15 11:50:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:50:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:50:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:50:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:50:51 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:50:51 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:50:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:50:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:51:01 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:01 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:51:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:51:15 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:15 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:51:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:51:25 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:25 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 11:51:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:51:34 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:51:34 --> 404 Page Not Found: Productcreation/audio
ERROR - 2017-12-15 11:52:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 11:52:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:04:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:04:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:04:22 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 12:04:22 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 12:04:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:04:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:04:36 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 12:04:36 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 12:04:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:04:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:04:58 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 12:04:58 --> 404 Page Not Found: Brand/audio
ERROR - 2017-12-15 12:05:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:05:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:05:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:05:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:05:27 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:05:27 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:05:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:05:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:05:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:05:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:05:41 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:05:41 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:05:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:05:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:05:52 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:05:52 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:06:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:06:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:06:13 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:06:13 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:06:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:06:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:06:24 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:06:24 --> 404 Page Not Found: Material/audio
ERROR - 2017-12-15 12:06:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:06:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:06:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:06:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:06:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:06:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:02 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:02 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:07:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:17 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:17 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:07:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:26 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:26 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:07:35 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:35 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:07:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:44 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:44 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:07:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:52 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:52 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:07:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:07:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:08:03 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:08:03 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:08:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:08:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:08:17 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:08:17 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-15 12:08:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:08:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:08:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-15 12:08:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-15 12:08:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:08:34 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:09:57 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:09 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:11 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:28 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:31 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:42 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:10:45 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:15 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:30 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:35 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:53 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:11:56 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:12:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:12:23 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:12:26 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-15 12:12:26 --> 404 Page Not Found: Product/audio
