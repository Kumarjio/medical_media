<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 09:34:20 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 05:04:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 05:04:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 05:04:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 05:04:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 05:04:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:04:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:05:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:05:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:14:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:14:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:14:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:14:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:16:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:16:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 09:47:14 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 134
ERROR - 2017-12-19 09:47:16 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:47:16 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:47:16 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:47:16 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:47:16 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:47:16 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 05:17:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:17:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:17:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:17:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:48:45 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 05:18:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:18:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 100
ERROR - 2017-12-19 09:59:32 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 05:29:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 05:29:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 10:06:44 --> Query error: Not unique table/alias: 'tbl_po_inv_item' - Invalid query: SELECT *
FROM (`tbl_po_inv_item`, `tbl_po_inv_item`)
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
ERROR - 2017-12-19 10:12:52 --> Severity: Warning --> join() expects at most 2 parameters, 3 given D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 108
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:47:14 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 06:17:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:17:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 10:47:17 --> Severity: Warning --> join() expects at most 2 parameters, 3 given D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 108
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:01 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 10:52:03 --> Severity: Warning --> join() expects at most 2 parameters, 3 given D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 108
ERROR - 2017-12-19 06:22:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:22:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:22:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:22:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:23:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:23:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 10:53:56 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 10:53:56 --> Severity: Notice --> Undefined index: vendor_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 111
ERROR - 2017-12-19 10:53:56 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 115
ERROR - 2017-12-19 06:23:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:23:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 10:56:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEF' at line 2 - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 10:56:30 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513661190
WHERE `id` = '58bd8db82ae91dbc072d9840d3601316aecd9725'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 10:58:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEF' at line 2 - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 10:58:57 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513661337
WHERE `id` = '58bd8db82ae91dbc072d9840d3601316aecd9725'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 10:59:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEF' at line 2 - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 10:59:56 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513661396
WHERE `id` = '58bd8db82ae91dbc072d9840d3601316aecd9725'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 11:00:28 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 11:00:28 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 06:30:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:30:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:30:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:30:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 11:01:08 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 11:01:08 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 06:31:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:31:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 11:02:02 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 11:02:02 --> Severity: Notice --> Undefined index: material_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 101
ERROR - 2017-12-19 11:03:26 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-12-19 06:33:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:33:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:33:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:33:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:34:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:34:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:36:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:36:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 11:06:47 --> Severity: Notice --> Undefined variable: sname D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 123
ERROR - 2017-12-19 06:36:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:36:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:36:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:36:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:37:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:37:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:37:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:37:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:38:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:38:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-19 11:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-19 11:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-19 11:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 11:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2017-12-19 06:39:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:39:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 11:09:47 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:01 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:02 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:03 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:03 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:03 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:04 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:04 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:04 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*, `tbl_sizefix`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 70
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 70
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 70
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 70
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 70
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 70
ERROR - 2017-12-19 11:13:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 06:43:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:43:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:44:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:44:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:44:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 06:44:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 11:17:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:17:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:17:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:17:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:17:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:17:35 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 06:47:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 06:47:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 11:22:19 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:22:19 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:22:19 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:22:19 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:22:19 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:22:19 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 06:52:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:52:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 11:25:40 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:25:40 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:25:40 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:25:40 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:25:40 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:25:40 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 06:55:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:55:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 11:26:38 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:26:38 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:26:38 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:26:38 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:26:38 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:26:38 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 06:56:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 06:56:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 11:28:43 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_product` ON `tbl_product`.`style`=`tbl_po_inv_item`.`style_ref_id`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 11:28:43 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513663123
WHERE `id` = '30b6d3565ccf9319f6b584e885d099a37247071e'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-12-19 11:29:18 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_product` ON `tbl_product`.`style`=`tbl_po_inv_item`.`style_ref_id`
ERROR - 2017-12-19 11:30:06 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_vendor`.*, `tbl_productcreation`.*, `tbl_branch`.*, `tbl_brand`.*, `tbl_material`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:02 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 07:01:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:01:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:03 --> Severity: Notice --> Undefined index: style_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 93
ERROR - 2017-12-19 07:01:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:01:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 11:31:23 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:23 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:23 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:23 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:23 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 11:31:23 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 73
ERROR - 2017-12-19 07:01:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:01:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:02:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:02:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:33:30 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 07:03:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:03:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$product_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$material_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:44:02 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 07:14:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:14:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 11:45:24 --> Severity: Notice --> Undefined property: stdClass::$brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 74
ERROR - 2017-12-19 07:15:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:15:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:18:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:18:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:18:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:18:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:18:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:18:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 11:49:28 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1')
AND `pro_ref_id` = '1'
ERROR - 2017-12-19 07:19:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:19:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:20:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:20:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:20:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:20:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:21:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:21:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:21:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:21:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 11:51:36 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('5')
AND `pro_ref_id` = '1'
ERROR - 2017-12-19 11:51:36 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513664496
WHERE `po_ref_id` IN('5')
AND `pro_ref_id` = '1'
AND `id` = '5c3ea06c84c22aa9330cb7f17bc681f51789480f'
ERROR - 2017-12-19 07:34:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:34:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:53:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:53:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:53:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:53:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:54:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:54:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:54:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 07:54:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 07:54:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:54:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:59:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 07:59:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 08:00:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 08:00:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 08:00:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 08:00:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 08:00:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 08:00:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 12:31:00 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-19 12:31:00 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `pro_ref_id` = '1'
ERROR - 2017-12-19 12:32:41 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-19 12:32:41 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
WHERE `pro_ref_id` = '1'
ERROR - 2017-12-19 12:32:41 --> Query error: Unknown column 'pro_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1513666961
WHERE `pro_ref_id` = '1'
AND `id` = 'fb3c6d44c319871d428c7124836250dda6d552c9'
ERROR - 2017-12-19 08:14:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 08:14:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 08:31:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 08:31:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 08:31:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 08:31:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 09:39:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 09:39:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 09:39:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 09:39:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 09:39:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 09:39:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 09:41:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 09:41:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 09:42:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 09:42:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-19 10:02:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 10:02:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 12:02:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 12:02:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 12:03:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 12:03:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 12:08:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 12:08:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 12:19:10 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-19 12:19:10 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-19 18:22:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''admin\'  and is_delete = 0' at line 1 - Invalid query: select * from cp_admin_login where username = 'admin' and password = 'admin\'  and is_delete = 0
ERROR - 2017-12-19 13:52:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 13:52:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 13:52:20 --> 404 Page Not Found: Vendor/index
ERROR - 2017-12-19 13:52:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 13:52:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 13:52:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-19 13:52:43 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-19 13:53:08 --> 404 Page Not Found: Supplier/index
ERROR - 2017-12-19 13:54:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 13:54:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 13:54:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 13:54:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 13:54:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-19 13:54:03 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-19 13:54:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 13:54:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 14:08:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 14:08:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-19 14:08:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-19 14:08:52 --> 404 Page Not Found: Audio/fail.mp3
