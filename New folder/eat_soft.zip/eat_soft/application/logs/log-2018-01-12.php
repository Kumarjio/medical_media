<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-12 04:22:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 04:22:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 04:22:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 04:22:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 04:28:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 04:28:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 09:58:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:13 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:09:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:10:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:11:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:12:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:13:36 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:13:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:14:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:14:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:18:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:18:33 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 04:48:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 04:48:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 04:48:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 04:48:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 04:48:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 04:48:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 04:48:47 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 04:48:47 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:18:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:19:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:21:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:25:25 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:25:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:26:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:26:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:26:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:32:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:32:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:33:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:33:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:34:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:35:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:35:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:35:50 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:36:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:36:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:37:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:37:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:37:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:37:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:37:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:37:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:38:16 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:38:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:38:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:40:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:40:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:40:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:41:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:42:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:42:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:42:42 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:43:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:43:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 10:43:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:44:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:45:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 05:15:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:15:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:16:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:16:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:18:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:18:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 51
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 52
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 53
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 55
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 56
ERROR - 2018-01-12 11:12:41 --> Severity: Notice --> Undefined variable: loop E:\wamp\www\duty\mathewgarments\application\views\stocksummary_list.php 57
ERROR - 2018-01-12 05:42:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:42:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:43:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:43:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:46:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:46:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:46:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:46:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:48:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:48:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:49:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:49:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:49:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:49:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:50:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:50:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:50:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:50:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:50:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:50:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:50:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:50:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:50:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:50:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:51:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:51:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:51:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:51:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:51:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:51:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:52:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:52:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:52:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 05:52:32 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 05:52:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:52:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:52:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 05:52:38 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:22:41 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:22:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 05:53:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 05:53:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 05:54:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 05:54:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 06:01:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 06:01:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 06:02:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:02:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:02:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:02:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:03:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:03:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:05:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:05:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:06:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:06:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:06:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:06:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:07:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:07:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:07:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:07:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:08:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:08:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:08:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:08:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:08:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:08:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:08:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:08:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:08:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:08:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:08:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:08:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:09:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:09:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:09:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:09:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:09:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:09:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:10:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:10:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:10:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:10:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:10:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:10:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:10:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:10:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:11:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:11:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:12:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:12:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:12:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:12:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:13:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:13:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:17:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:17:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:18:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:18:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:18:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 06:18:25 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:48:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 11:49:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 06:22:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:22:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:29:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 06:29:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 06:29:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:29:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:35:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 06:35:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:38:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 06:38:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 09:51:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 09:51:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 09:55:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 09:55:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 15:25:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 73
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 78
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 79
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 110
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 115
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 120
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 129
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 134
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 144
ERROR - 2018-01-12 15:25:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\retail_print.php 149
ERROR - 2018-01-12 10:02:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:02:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:02:38 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-12 10:02:38 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-12 10:03:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:03:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:09:24 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:09:24 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:39:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 59
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 64
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 65
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 15:44:11 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\wholesale_print.php 132
ERROR - 2018-01-12 10:14:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:14:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:14:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:14:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:16:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:16:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:16:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:16:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:16:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-12 10:16:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-12 10:17:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:17:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 15:47:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:47:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:47:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:47:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:47:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:47:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:47:35 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:47:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:47:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:47:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:48:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:48:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:48:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:48:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:48:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:48:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:48:24 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:48:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:26 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:28 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:49:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:49:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:01 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:15 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 15:50:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 15:50:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-12 15:50:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-12 15:50:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-12 15:50:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-12 15:50:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-12 15:50:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-12 15:50:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-12 10:21:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:21:00 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:27:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:27:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:27:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:27:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:27:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 10:27:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 16:01:41 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-12 16:01:41 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-12 16:01:42 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-12 16:01:42 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-12 10:31:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 10:31:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 10:32:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:32:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:32:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:32:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:32:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:32:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:32:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:32:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:32:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:32:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 16:02:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:52 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:54 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:55 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:02:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:02:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:02 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:05 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:13 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:15 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:16 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:16 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:21 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:24 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:26 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:28 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:30 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 16:03:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 16:03:44 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-12 16:03:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-12 16:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-12 16:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-12 16:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-12 16:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-12 16:03:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-12 10:34:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:34:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:42:20 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:42:20 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-12 10:42:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:42:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:42:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:42:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:49:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:49:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:54:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 10:54:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 10:54:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 10:54:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 10:54:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 10:54:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-12 11:01:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 11:01:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:11:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:11:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 11:23:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 11:23:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:28:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:28:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 11:28:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 11:28:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 17:11:23 --> Severity: Warning --> Division by zero E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 163
ERROR - 2018-01-12 11:41:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 11:41:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 11:41:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 11:41:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:41:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 11:41:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:00:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:00:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:23:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:23:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 18:54:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 18:54:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 18:54:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 18:54:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 18:54:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 18:54:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 18:54:18 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 18:54:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 13:24:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:24:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:24:49 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-12 13:24:49 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-12 13:24:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:24:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 18:55:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 82
ERROR - 2018-01-12 18:55:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 83
ERROR - 2018-01-12 19:20:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 86
ERROR - 2018-01-12 19:20:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 87
ERROR - 2018-01-12 19:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-12 19:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 305
ERROR - 2018-01-12 19:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 307
ERROR - 2018-01-12 19:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-12 19:20:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 309
ERROR - 2018-01-12 13:50:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:50:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:50:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:50:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:50:38 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-12 13:50:38 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-12 13:50:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:50:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:50:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 13:50:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 13:52:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:52:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:52:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-12 13:52:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-12 13:52:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 13:52:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 13:53:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-12 13:53:06 --> 404 Page Not Found: Goodsreceived/audio
