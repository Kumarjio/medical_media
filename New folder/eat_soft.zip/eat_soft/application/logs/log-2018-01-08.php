<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-08 04:36:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 04:36:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 04:39:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 04:39:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 04:59:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 04:59:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:31:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 10:31:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 10:31:09 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 10:31:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 10:31:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 10:31:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 05:19:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:19:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:20:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:20:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:20:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:20:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:20:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:20:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:21:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:21:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:22:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:22:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:22:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:22:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:24:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:24:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:30:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:30:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:30:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:30:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:31:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:31:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 05:44:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 05:44:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:15:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 11:15:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 11:15:45 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 11:15:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 11:15:47 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 11:15:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 11:15:49 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 11:15:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 11:15:53 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 11:15:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 11:16:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 90
ERROR - 2018-01-08 11:16:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 91
ERROR - 2018-01-08 06:10:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 06:10:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:55:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 11:55:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 11:56:12 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 11:56:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 06:38:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 06:38:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:08:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:08:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:08:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:08:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 06:40:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 06:40:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:10:46 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:10:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:10:57 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:10:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:12:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:12:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 06:42:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 06:42:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 06:42:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-08 06:42:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-08 06:42:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 06:42:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 06:42:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 06:42:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 12:12:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 12:12:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 12:12:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-08 12:12:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-08 06:42:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 06:42:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 06:42:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-08 06:42:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-08 06:43:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 06:43:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:13:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:13:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:14:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:14:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:35:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:35:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:35:42 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:35:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 07:08:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 07:08:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 07:25:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 07:25:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:55:18 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:55:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:55:22 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:55:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:55:26 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:55:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:55:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:55:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: sgst_ E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 169
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: sgst_ E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 169
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: sgst_ E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 169
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: sgst_ E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 169
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:55:59 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 197
ERROR - 2018-01-08 12:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\helpers\url_helper.php 561
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: size E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 177
ERROR - 2018-01-08 12:56:38 --> Severity: Notice --> Undefined variable: insert_id E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 197
ERROR - 2018-01-08 12:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\helpers\url_helper.php 561
ERROR - 2018-01-08 07:27:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:27:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:57:32 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:57:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:57:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:57:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:57:35 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:57:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:57:36 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:57:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:57:39 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 12:57:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 13:00:01 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 13:00:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 07:33:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:33:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:34:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:34:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:43:05 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:43:05 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:47:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:47:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:47:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:47:39 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:54:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 07:54:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:06:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:06:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:07:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:07:22 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:07:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:07:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:07:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:07:48 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:08:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:08:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:08:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:08:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:23:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:23:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:24:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:24:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 13:54:54 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 13:54:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 08:25:26 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:25:26 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:25:29 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:25:29 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 13:57:10 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 13:57:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 08:27:27 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 08:27:27 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 14:36:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 14:36:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 15:08:08 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 192
ERROR - 2018-01-08 09:39:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:39:07 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:39:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:39:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:39:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:39:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:47:50 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:47:50 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:48:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:48:31 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:54:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:54:04 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:54:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:54:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:55:14 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:55:14 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:55:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 09:55:36 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:03:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:03:28 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:03:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:03:35 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:04:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:04:41 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:05:05 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:05:05 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 10:06:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:06:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:07:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:07:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:07:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 10:07:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 15:37:18 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-08 15:37:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-08 10:07:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 10:07:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 10:07:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 10:07:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 10:07:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:07:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:19:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:19:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:19:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:19:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:19:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:19:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 15:49:58 --> Severity: Warning --> mt_rand() expects exactly 2 parameters, 1 given E:\wamp\www\duty\mathewgarments\application\views\retail_add.php 48
ERROR - 2018-01-08 10:19:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:19:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:20:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:20:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:21:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:21:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:22:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:22:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:23:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:23:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:23:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:23:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:23:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:23:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:30:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 10:30:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 16:00:33 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:00:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:00:39 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:00:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 10:36:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 10:36:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:06:26 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:06:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:29:59 --> Severity: Parsing Error --> syntax error, unexpected 'get' (T_STRING) E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 318
ERROR - 2018-01-08 11:00:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:00:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:30:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:30:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 11:00:30 --> 404 Page Not Found: Retail/change_delete_status
ERROR - 2018-01-08 11:00:41 --> 404 Page Not Found: Retail/change_delete_status
ERROR - 2018-01-08 11:01:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:01:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:31:47 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:31:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 11:01:50 --> 404 Page Not Found: Retail/change_delete_status
ERROR - 2018-01-08 11:01:52 --> 404 Page Not Found: Retail/change_delete_status
ERROR - 2018-01-08 11:03:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:03:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:33:42 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:33:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:33:44 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:33:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = 1' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = 1
ERROR - 2018-01-08 16:33:44 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409424
WHERE `single_po_entry_id` = 1
AND `id` = '32b684bae2846d7a502cf927db400000680e74b1'
ERROR - 2018-01-08 16:33:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = 1' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = 1
ERROR - 2018-01-08 16:33:48 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409428
WHERE `single_po_entry_id` = 1
AND `id` = '32b684bae2846d7a502cf927db400000680e74b1'
ERROR - 2018-01-08 11:05:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:05:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:35:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:35:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:35:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:35:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` IS NULL' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` IS NULL
ERROR - 2018-01-08 16:35:32 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409532
WHERE `single_po_entry_id` IS NULL
AND `id` = 'badd2758e05c8c2701c9a4b4072059795c912786'
ERROR - 2018-01-08 16:35:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = '5'' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = '5'
ERROR - 2018-01-08 16:35:34 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409534
WHERE `single_po_entry_id` = '5'
AND `id` = 'badd2758e05c8c2701c9a4b4072059795c912786'
ERROR - 2018-01-08 11:09:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:09:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 16:39:51 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:39:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:39:52 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:39:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:39:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` IS NULL' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` IS NULL
ERROR - 2018-01-08 16:39:52 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409792
WHERE `single_po_entry_id` IS NULL
AND `id` = 'badd2758e05c8c2701c9a4b4072059795c912786'
ERROR - 2018-01-08 16:39:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = '6'' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = '6'
ERROR - 2018-01-08 16:39:56 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409796
WHERE `single_po_entry_id` = '6'
AND `id` = 'badd2758e05c8c2701c9a4b4072059795c912786'
ERROR - 2018-01-08 11:11:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:11:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:41:40 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:41:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:41:41 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:41:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:41:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` IS NULL' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` IS NULL
ERROR - 2018-01-08 16:41:41 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409901
WHERE `single_po_entry_id` IS NULL
AND `id` = '84db456be081642e710e3e8c9e0949fbed3157cc'
ERROR - 2018-01-08 16:41:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '== `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = '6'' at line 3 - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id` == `tbl_single_po_entry`.`po_inv_ref_id`
WHERE `single_po_entry_id` = '6'
ERROR - 2018-01-08 16:41:45 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515409905
WHERE `single_po_entry_id` = '6'
AND `id` = '84db456be081642e710e3e8c9e0949fbed3157cc'
ERROR - 2018-01-08 11:12:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:12:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 16:42:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:42:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:42:27 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:42:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 11:13:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:13:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:43:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:43:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:43:21 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:43:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:43:21 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:43:21 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 322
ERROR - 2018-01-08 16:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 16:43:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 16:43:28 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:43:28 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:43:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 322
ERROR - 2018-01-08 11:14:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:14:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:44:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:44:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:44:27 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:44:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:44:27 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:44:27 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:44:29 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:44:29 --> Severity: Notice --> Undefined variable: res E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 11:15:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:15:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:45:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:45:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:45:28 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:45:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:45:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 11:15:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:15:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:45:48 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:45:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:45:53 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:45:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-08 16:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 16:45:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 11:17:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:17:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 16:47:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:47:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:47:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:47:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:47:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:47:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:47:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-08 16:47:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 16:47:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 11:18:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:18:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 16:48:28 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 16:48:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 16:48:29 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 16:48:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 16:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 321
ERROR - 2018-01-08 16:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 323
ERROR - 2018-01-08 16:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 16:48:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 11:18:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:18:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:38:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:38:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:08:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:08:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:08:43 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:08:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:08:47 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:08:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:08:48 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:08:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:08:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:39:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:39:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:10:01 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:10:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:10:02 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:10:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:10:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:10:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:10:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:10:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:10:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:41:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:41:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:41:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:41:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 17:11:25 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:11:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:11:27 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-08 17:11:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-08 17:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 17:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 17:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-08 17:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 17:11:27 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 11:41:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:41:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:41:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:41:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 17:11:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:11:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:11:44 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:11:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:11:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:11:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:11:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:11:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:11:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:42:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:42:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:12:44 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:12:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:12:45 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:12:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:12:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:12:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:12:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:12:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:12:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:12:55 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:12:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:12:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:12:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:13:02 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:13:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:13:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:13:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:13:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:13:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:13:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:43:09 --> 404 Page Not Found: Index/index
ERROR - 2018-01-08 17:13:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:13:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:13:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:13:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:13:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:13:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:13:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:43:33 --> 404 Page Not Found: Index/index
ERROR - 2018-01-08 11:43:48 --> 404 Page Not Found: Index/index
ERROR - 2018-01-08 17:13:53 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:13:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:13:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:13:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:13:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:13:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:13:53 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:14:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:14:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:14:03 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:14:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:14:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:14:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:14:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:14:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:14:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:14:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:14:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:14:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:14:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:44:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:44:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:45:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:45:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:15:04 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:15:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:15:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:15:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:15:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:15:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:15:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 11:45:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:45:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:45:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:45:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 17:15:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:15:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:15:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:15:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:16:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:16:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:16:05 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:16:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:16:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:16:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:16:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:16:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:16:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:16:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:16:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:16:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:16:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:16:12 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:16:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 324
ERROR - 2018-01-08 17:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 326
ERROR - 2018-01-08 17:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:16:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 328
ERROR - 2018-01-08 17:17:34 --> Query error: Field 'sale_type' doesn't have a default value - Invalid query: INSERT INTO `tbl_sales` (`invoice`, `cus_name`, `purchase_mode`, `stotal`, `gtotal`, `comm_cgst`, `comm_sgst`, `emp_id`, `get_pay`, `bal_pay`, `pdate`) VALUES ('RB001', 'mustahk', 'cash', '600', '630.00', '15.00', '15.00', 'emp001', '630', '0', '2018-01-08')
ERROR - 2018-01-08 17:18:47 --> Query error: Unknown column 'sales_out_ref_id' in 'field list' - Invalid query: UPDATE `tbl_single_po_entry` SET `sales_out_ref_id` = 1
WHERE `single_po_entry_id` = '1'
ERROR - 2018-01-08 11:49:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 11:49:19 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 11:51:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 11:51:06 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 11:52:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:52:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 11:53:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:53:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 17:23:17 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:23:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:23:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:23:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:23:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:23:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:23:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:23:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:23:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-08 17:23:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-08 17:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 17:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 17:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-08 17:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 17:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 11:53:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:53:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:57:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:57:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:57:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:57:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 17:27:54 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:27:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:27:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:27:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:27:58 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 17:27:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 17:28:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-08 17:28:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-08 17:28:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 17:28:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 17:28:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-08 17:28:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 17:28:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 11:58:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:58:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 11:58:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 11:58:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:00:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:00:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:30:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:30:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:31:02 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:31:02 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:31:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:31:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:31:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:31:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:31:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:01:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:01:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 17:31:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:31:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:03:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:03:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:33:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:33:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:04:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:04:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:34:22 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:34:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:05:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:05:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 17:35:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:35:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:05:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:05:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:07:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:07:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:37:20 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:37:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:37:29 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:37:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:08:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:08:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 17:38:53 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:38:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:39:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:39:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:39:04 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:39:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:39:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:39:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:39:08 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:39:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:39:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:39:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:39:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:39:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:39:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:10:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:10:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 17:40:20 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:40:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:40:25 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:40:25 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:40:28 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:40:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:40:30 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:40:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:40:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:40:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:40:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:40:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:40:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:40:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:40:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:11:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:11:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:16:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:16:11 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 17:46:14 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:46:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:46:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:46:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:46:20 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:46:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:46:23 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:46:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:46:32 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:46:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:46:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:46:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:46:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:46:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:46:32 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:17:12 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:17:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 17:47:15 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:47:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:47:17 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:47:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:47:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:47:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:47:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:47:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:47:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:17:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:17:55 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 17:48:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:48:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 12:20:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:20:03 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 17:50:06 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:50:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:50:11 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:50:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:50:14 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:50:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:50:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:50:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:50:21 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:50:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:50:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:50:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:50:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:50:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:50:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:50:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:50:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:50:49 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:50:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:50:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:20:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:20:54 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 17:50:56 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:50:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:51:00 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:51:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:51:03 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:51:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:51:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:51:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:51:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:51:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:51:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:51:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:51:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:52:52 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:52:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:52:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:22:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:22:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 17:53:07 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:53:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:53:08 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:53:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:53:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:53:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:53:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:53:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:53:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:53:17 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 17:53:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 17:53:20 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 17:53:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 17:53:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:53:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 17:53:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 17:53:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 17:53:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 12:25:24 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:25:24 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-08 12:27:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:27:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:43:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:43:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:44:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:44:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:44:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:44:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:45:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:45:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:45:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:45:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:45:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:45:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:46:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:46:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:46:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:46:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:46:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:46:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:46:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:46:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:47:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:47:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:47:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 12:47:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:47:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 12:47:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:01:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:01:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 13:03:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 13:03:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:03:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 13:03:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:03:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:03:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 13:04:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 13:04:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:12:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 13:12:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 18:54:04 --> Query error: Unknown column 'tbl_single_po_entry.style_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_single_po_entry`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
WHERE `po_inv_ref_id` = '1'
ERROR - 2018-01-08 18:54:04 --> Query error: Unknown column 'po_inv_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515417844
WHERE `po_inv_ref_id` = '1'
AND `id` = '69ac3101991d8c08fdd796db4e0dddb8d9ce2ffc'
ERROR - 2018-01-08 18:54:18 --> Query error: Unknown column 'tbl_single_po_entry.style_ref_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_single_po_entry`.`style_ref_id`
WHERE `po_inv_ref_id` = '1'
ERROR - 2018-01-08 18:54:18 --> Query error: Unknown column 'po_inv_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515417858
WHERE `po_inv_ref_id` = '1'
AND `id` = '69ac3101991d8c08fdd796db4e0dddb8d9ce2ffc'
ERROR - 2018-01-08 18:55:03 --> Query error: Not unique table/alias: 'tbl_product' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
WHERE `po_inv_ref_id` = '1'
ERROR - 2018-01-08 18:55:03 --> Query error: Unknown column 'po_inv_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515417903
WHERE `po_inv_ref_id` = '1'
AND `id` = '69ac3101991d8c08fdd796db4e0dddb8d9ce2ffc'
ERROR - 2018-01-08 19:02:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:03:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:03:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:03:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:03:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:03:51 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:03:51 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:04:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:04:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:04:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:04:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:04:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:04:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:05:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:05:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:05:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:08:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:08:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:08:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:08:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:08:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:08:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:10:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:10:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:10:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:10:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:10:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:10:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:11:45 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:12:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:12:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:12:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:12:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:12:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:12:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:13:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:14:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:14:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:15:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:15:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:15:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:16:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:16:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:16:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:16:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:16:29 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:16:29 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:17:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:52 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:18:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:19:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:20:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:20:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:20:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:29 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:30 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:21:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:22:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:22:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:22:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:22:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:22:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:22:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:24:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:25:53 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:27:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:28:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:28:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:28:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:28:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:28:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:28:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:38:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:38:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:38:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:39:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:39:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:39:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:39:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:39:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:48:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:48:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:48:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:49:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:49:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:49:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:49:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:49:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:49:14 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:50:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:50:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:50:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:51:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:21 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:52:57 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:12 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:53:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:17 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:54:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:06 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:55:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:56:04 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:56:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:56:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:56:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:56:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:56:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:11 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:18 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:54 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:57:55 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:58:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:58:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:58:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:58:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:58:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 19:58:42 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:00 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:27 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:48 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:00:49 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:40 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:41 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:01:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:03 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:15 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:16 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:02:58 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 14:33:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:33:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 20:03:34 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:03:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:04:09 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:04:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:04:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:04:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:04:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:04:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:04:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:35:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:35:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:06:14 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:06:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 14:36:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:36:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:06:22 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:06:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:06:27 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:06:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:06:31 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:06:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:06:37 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:06:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 14:36:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:36:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:37:03 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-08 14:37:03 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-08 14:38:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:38:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 20:08:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:08:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:08:05 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:08:37 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:08:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:08:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:09:08 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:09:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:09:09 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:20:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:20:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:20:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 14:51:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:51:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:51:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:51:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:21:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:21:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 20:21:13 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-08 14:51:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:51:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:22:01 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:22:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:22:08 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:22:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:22:52 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:22:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:22:58 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:22:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:23:06 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:23:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:23:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:23:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:23:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:23:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:23:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:53:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:53:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:53:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 14:53:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 20:23:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 20:23:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 20:23:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 20:23:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 20:23:26 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-08 20:23:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-08 20:23:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-08 20:23:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 76
ERROR - 2018-01-08 20:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 20:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 46
ERROR - 2018-01-08 20:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 48
ERROR - 2018-01-08 20:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 20:23:35 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 50
ERROR - 2018-01-08 14:55:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 14:55:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-08 14:55:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:55:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:25:38 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:25:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:25:41 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:25:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:25:42 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:25:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:25:49 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:25:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:25:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:56:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:56:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:26:19 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:26:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:26:24 --> Severity: Warning --> Missing argument 1 for Retail::get_single_pro_data() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 80
ERROR - 2018-01-08 20:26:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 81
ERROR - 2018-01-08 20:26:26 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:26:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:26:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:26:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:26:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:26:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:26:26 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:56:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:56:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:57:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:57:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:27:38 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:27:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:27:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:27:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:27:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:27:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:27:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:59:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 14:59:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:29:07 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:29:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:29:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:59:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:59:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 20:29:34 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:29:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:29:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:29:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:29:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:29:45 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:29:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:29:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:29:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:29:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:59:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:59:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 20:29:56 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:29:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:29:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:29:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:29:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:29:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 14:59:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 14:59:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 20:30:01 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:30:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:30:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 15:00:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 15:00:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:30:08 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:30:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:30:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:30:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:30:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:30:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:30:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 15:00:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 15:00:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 20:30:15 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 84
ERROR - 2018-01-08 20:30:15 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 85
ERROR - 2018-01-08 20:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 325
ERROR - 2018-01-08 20:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 327
ERROR - 2018-01-08 20:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 20:30:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 329
ERROR - 2018-01-08 15:00:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 15:00:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 15:01:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-08 15:01:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-08 20:39:12 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::distint() E:\wamp\www\duty\mathewgarments\application\models\Retail_model.php 332
ERROR - 2018-01-08 20:39:12 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515424152
WHERE `sales_id` = '1'
AND `id` = '01ae4f77076d87419cdb76144aa1059c2392812d'
ERROR - 2018-01-08 20:39:12 --> Severity: Warning --> Cannot modify header information - headers already sent E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-08 20:40:47 --> Query error: Unknown column 'hsn' in 'field list' - Invalid query: SELECT DISTINCT `style`, `hsn`
FROM `tbl_sales`
LEFT JOIN `tbl_sales_item` ON `tbl_sales_item`.`sales_ref_id`=`tbl_sales`.`sales_id`
WHERE `sales_id` = '1'
ERROR - 2018-01-08 20:40:47 --> Query error: Unknown column 'sales_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1515424247
WHERE `sales_id` = '1'
AND `id` = '01ae4f77076d87419cdb76144aa1059c2392812d'
