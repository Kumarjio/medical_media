<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-04 04:05:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:05:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:36:19 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 04:06:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:06:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:37:56 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 04:07:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:07:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:07:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:07:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:08:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:08:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:08:08 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 04:08:08 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 04:08:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:08:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:08:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:08:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:39:58 --> Query error: Field 'barcode_status' doesn't have a default value - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `igst`, `sgst_amt`, `igst_amt`) VALUES (3, '7', '3', '1', '578578', '1', '5', '230', '250', '5', '50', '200', '10500', '5', '0', '500', '0')
ERROR - 2018-01-04 04:11:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 04:11:22 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 04:11:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:11:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:18:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:18:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:19:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:19:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:19:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:19:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:20:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:20:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:20:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:20:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:20:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:20:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:20:21 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 04:20:21 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 09:51:07 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 04:21:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:21:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:21:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:21:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:39:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:39:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:39:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:39:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 04:43:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:43:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:13:45 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 10:13:45 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 10:13:45 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 10:13:46 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 04:43:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 04:43:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 04:43:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:43:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:44:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:44:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:14:37 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:14:37 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:14:46 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 28
ERROR - 2018-01-04 10:14:46 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:14:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:44:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:44:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:14:56 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 28
ERROR - 2018-01-04 10:14:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:14:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:15:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:15:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:15:12 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:15:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:15:23 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 28
ERROR - 2018-01-04 10:15:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:15:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:15:29 --> Severity: Notice --> Undefined variable: data1 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 28
ERROR - 2018-01-04 10:15:29 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:15:29 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:46:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:46:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:16:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:16:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:17:40 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:17:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:18:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:18:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:49:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:49:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:51:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:51:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:21:53 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:21:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:54:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:54:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:24:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:24:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:24:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:24:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:25:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:25:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:56:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:56:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:26:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:26:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:26:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:26:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:57:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:57:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:28:47 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:28:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 04:59:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:59:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:59:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:59:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:59:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 04:59:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:30:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:30:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:46:26 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 33
ERROR - 2018-01-04 10:47:04 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 33
ERROR - 2018-01-04 05:17:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 05:17:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:47:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:47:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 10:47:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:47:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 05:17:31 --> 404 Page Not Found: Stock_transfer/change_delete_status2
ERROR - 2018-01-04 05:17:41 --> 404 Page Not Found: Stock_transfer/change_delete_status2
ERROR - 2018-01-04 05:17:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 05:17:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 10:47:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 10:47:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 05:45:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 05:45:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 06:02:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 06:02:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 11:32:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:32:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:32:46 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:32:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:32:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:32:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:33:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:33:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:33:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:33:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:33:09 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:33:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:33:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:33:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:33:27 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:33:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:33:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 11:33:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 11:39:01 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2018-01-04 06:16:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:16:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:46:59 --> Severity: Notice --> Undefined variable: search_details E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 114
ERROR - 2018-01-04 11:46:59 --> Severity: Notice --> Undefined variable: search_details E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 140
ERROR - 2018-01-04 06:16:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:16:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:18:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:18:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:49:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:49:24 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:49:24 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:49:24 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:49:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:49:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 06:19:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:19:25 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:19:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:19:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:49:44 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:49:44 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:49:44 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:49:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:49:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 11:49:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:19:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:19:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:19:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:19:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:20:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:20:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:51:22 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:51:22 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:51:22 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:51:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:51:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 11:51:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:21:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:21:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:51:33 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:21:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:21:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:57:22 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:27:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:27:22 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:57:26 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:27:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:27:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:57:47 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:27:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:27:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:58:07 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:28:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:28:07 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:28:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:28:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:58:20 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:58:20 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:58:20 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 11:58:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:58:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 11:58:20 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:28:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:28:21 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:00:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:30:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:30:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:00:28 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:30:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:30:28 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:00:34 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:30:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:30:34 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:00:39 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:30:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:30:39 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:02:23 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:32:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:32:23 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:02:32 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:32:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:32:32 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:33:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:33:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:34:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:34:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 12:04:19 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 12:04:19 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 12:04:19 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 12:04:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 12:04:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 12:04:19 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:34:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:34:20 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:40:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:40:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:40:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 06:40:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 06:44:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 06:44:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 12:14:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 12:14:43 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 12:14:43 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 12:14:43 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 12:14:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 12:14:43 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 06:44:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:44:43 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 12:21:43 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 06:51:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:51:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 06:51:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 06:51:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 07:04:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 07:04:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 13:44:41 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR), expecting ')' E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 178
ERROR - 2018-01-04 08:15:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:15:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:16:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:16:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 13:54:33 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 290
ERROR - 2018-01-04 08:24:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 08:24:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 13:55:13 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 290
ERROR - 2018-01-04 08:25:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 08:25:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 08:42:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 08:42:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 08:42:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:42:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 14:13:19 --> Query error: Unknown column 'curr_qty' in 'field list' - Invalid query: INSERT INTO `tbl_grn` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `curr_qty`, `p_rate`, `total`, `curr_total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '2', '4', '1', '5678', '3', '5', '130', '150', '5', '100', '100', '100', '10500', '10500', 2.5, 2.5, '0', 250, 250, '0', 1)
ERROR - 2018-01-04 14:14:22 --> Query error: Unknown column 'curr_qty' in 'field list' - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `curr_qty`, `p_rate`, `total`, `curr_total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '2', '4', '1', '5678', '3', '5', '130', '150', '5', '100', '100', '100', '10500', '10500', 2.5, 2.5, '0', 250, 250, '0', 1)
ERROR - 2018-01-04 14:14:38 --> Query error: Unknown column 'sgst_amt' in 'field list' - Invalid query: INSERT INTO `tbl_grn` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (2, '2', '4', '1', '5678', '3', '5', '130', '150', '5', '100', '100', '10500', 2.5, 2.5, '0', 250, 250, '0', 1)
ERROR - 2018-01-04 14:16:41 --> Query error: Field 'branch_ref_id' doesn't have a default value - Invalid query: INSERT INTO `tbl_grn` (`po_ref_id`, `style_ref_id`, `color_ref_id`, `size_ref_id`, `hsncode`, `product_img_ref_id`, `wholesale_tax`, `wholesale_amt`, `r_rate`, `r_percent`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`, `barcode_status`) VALUES (1, '2', '4', '1', '5678', '3', '5', '130', '150', '5', '100', '100', '10500', 2.5, 2.5, '0', 250, 250, '0', 1)
ERROR - 2018-01-04 08:47:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:47:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:48:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:48:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:49:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:49:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:50:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:50:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 14:20:38 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 08:50:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:50:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:52:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:52:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: vinvno E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 24
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: taxamount E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 39
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-04 14:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: vinvno E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_unit_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_unit_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_unit_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: pi_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_unit_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 217
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_unit_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_unit_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 221
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: pi_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 225
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 234
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Undefined index: tbl_pro_id E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 238
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:05 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-04 14:22:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined variable: seller E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-04 14:22:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 114
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 126
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 138
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 152
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 162
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 276
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 351
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 14:22:06 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\goods_edit.php 352
ERROR - 2018-01-04 08:52:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:52:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 08:59:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 08:59:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 08:59:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 08:59:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:00:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:00:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:01:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:01:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:01:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:01:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:03:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:03:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:03:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:03:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:03:58 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:03:58 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:05:57 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:05:57 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:05:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:05:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:06:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:06:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:07:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:07:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:07:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:07:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:08:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:08:39 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:08:55 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:08:55 --> 404 Page Not Found: Product/audio
ERROR - 2018-01-04 09:13:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:13:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:13:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:13:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:18:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:18:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:18:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:18:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:19:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:19:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 14:49:30 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 14:49:30 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 09:19:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:19:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:19:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:19:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 14:50:19 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 14:50:19 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 14:50:19 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 09:20:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:20:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:25:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:25:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 14:55:38 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 14:55:38 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 14:55:38 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 14:55:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 14:55:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 14:55:38 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 09:25:38 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 09:25:38 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 14:55:41 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 14:55:41 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 14:55:41 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 09:25:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:25:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:26:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:26:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:26:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:26:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 14:57:12 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 09:27:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:27:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 09:27:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:27:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:27:20 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 09:27:21 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 09:27:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:27:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 09:48:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:48:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 15:18:51 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 09:48:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 09:48:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 15:40:01 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 201
ERROR - 2018-01-04 15:40:48 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 201
ERROR - 2018-01-04 10:11:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:11:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:11:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:11:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:41:54 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 15:41:55 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:11:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:11:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:14:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:14:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:14:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:14:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:45:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 15:45:51 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 15:45:52 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:15:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:15:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:17:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:17:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:17:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:17:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:48:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 15:48:30 --> Severity: Notice --> Undefined index: qty E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 15:48:30 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:18:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:18:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:20:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:20:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:20:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:20:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:51:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 15:51:49 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:21:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:21:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:22:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:22:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:53:26 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 15:53:26 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:23:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:23:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:53:39 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 15:53:39 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:23:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:23:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 15:55:33 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 15:55:33 --> Severity: Notice --> Undefined index: po_inv_id E:\wamp\www\duty\mathewgarments\application\views\goods_list.php 123
ERROR - 2018-01-04 10:25:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:25:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:25:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:25:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:26:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:26:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:26:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:26:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 15:56:24 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 15:56:24 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 15:56:24 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 15:56:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 15:56:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 15:56:24 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 10:26:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:26:24 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 15:56:44 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 10:26:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:26:44 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 15:56:56 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 10:26:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:26:56 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 15:57:10 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 10:27:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:27:10 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:28:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:28:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:28:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:28:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:29:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:29:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:29:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:29:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:39:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:39:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:39:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:39:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 16:13:21 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 10:43:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:43:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:46:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:46:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:46:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:46:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 16:17:24 --> Severity: Error --> Call to undefined function isempty() E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 16:17:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 194
ERROR - 2018-01-04 10:47:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:47:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 10:47:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:47:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:47:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:47:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:47:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:47:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 16:17:59 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:17:59 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:17:59 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:17:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 16:17:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 16:17:59 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 10:47:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:47:59 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 10:48:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:48:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:49:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:49:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:49:59 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 10:49:59 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 10:50:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:50:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:58:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:58:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 10:58:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 10:58:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 10:58:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 10:58:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:02:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:02:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:02:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:02:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:03:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 11:03:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 11:03:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:03:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:03:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:03:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 16:34:01 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:34:01 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:34:01 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:34:01 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 16:34:01 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 16:34:02 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:04:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:04:02 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:04:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:04:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:04:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:04:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:04:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:04:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:04:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:04:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 16:34:46 --> Severity: Notice --> Undefined index: customer E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:34:46 --> Severity: Notice --> Undefined index: branch_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:34:46 --> Severity: Notice --> Undefined index: lot_id E:\wamp\www\duty\mathewgarments\application\controllers\Returndet.php 104
ERROR - 2018-01-04 16:34:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 16:34:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\returndetails.php 115
ERROR - 2018-01-04 16:34:46 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:04:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:04:47 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 16:35:25 --> Severity: Notice --> Undefined variable: title E:\wamp\www\duty\mathewgarments\application\views\include_css.php 4
ERROR - 2018-01-04 11:05:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:05:26 --> 404 Page Not Found: Returndet/audio
ERROR - 2018-01-04 11:06:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:06:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:11:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:11:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:21:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 11:21:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 11:28:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:28:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:28:41 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 11:28:41 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 11:40:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:40:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:40:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 11:40:55 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 11:41:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:41:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:41:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:41:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:41:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:41:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:11:27 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 11:41:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:41:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:41:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 11:41:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 17:12:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 17:12:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 17:12:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 17:12:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 17:12:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 17:12:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 17:12:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 17:12:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 17:12:51 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 17:12:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 17:12:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 17:12:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 17:12:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 17:12:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 17:12:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 17:12:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 17:13:13 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 17:13:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 17:13:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 17:13:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 17:13:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 17:13:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:52 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:13:53 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 11:43:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:43:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:54:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:54:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:54:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:54:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:24:50 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 11:54:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 11:54:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 11:54:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 11:54:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:14:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 12:14:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 12:14:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 12:14:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-04 12:16:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 12:16:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 17:46:13 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 12:16:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 12:16:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 12:16:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:16:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:55:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:55:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:55:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:55:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 18:26:41 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:26:41 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 12:56:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:56:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 18:26:59 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:26:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:01 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:01 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 12:57:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:57:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 18:27:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:27:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:27:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 12:57:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:57:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:58:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 12:58:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 18:28:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:28:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 13:01:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:01:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 18:31:45 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:31:45 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:31:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:31:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 13:02:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:02:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:02:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 13:02:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 13:02:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 13:02:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 13:03:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 13:03:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 13:03:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 13:03:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 13:03:14 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 13:03:14 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-04 18:33:41 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-04 13:03:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-04 13:03:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-04 13:03:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:03:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:04:00 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 13:04:00 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-04 18:34:09 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:11 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:11 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:12 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:26 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:48 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:48 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:51 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:51 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:34:53 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:34:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:35:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:35:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:35:54 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:35:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:33 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:33 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:36 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:39 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:39 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:36:59 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:36:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:37:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:37:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:37:10 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:37:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:37:13 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:37:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:37:17 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:37:17 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:37:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:37:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 18:38:49 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:38:49 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:38:52 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:38:52 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:38:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:38:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:39:18 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:39:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:39:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:39:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:39:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:39:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:39:21 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:39:21 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:39:23 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-04 18:39:23 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 18:39:47 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 74
ERROR - 2018-01-04 18:39:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 75
ERROR - 2018-01-04 13:23:47 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 90
ERROR - 2018-01-04 13:23:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:23:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:35:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 13:35:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-04 19:05:38 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 19:05:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-04 13:35:38 --> 404 Page Not Found: Stack_transfer/save_transfer_out
ERROR - 2018-01-04 19:06:32 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 19:06:32 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-04 19:06:36 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-04 19:06:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-04 13:40:08 --> Severity: Parsing Error --> syntax error, unexpected '=' E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 87
