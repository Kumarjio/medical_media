<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-30 05:50:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:50:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:50:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:50:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:51:26 --> 404 Page Not Found: Stockreturn/index
ERROR - 2017-11-30 05:53:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:53:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:53:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:53:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:53:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 05:53:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 05:56:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:56:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:56:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:56:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:57:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:57:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:57:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:57:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:57:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:57:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:58:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:58:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:58:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:58:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:58:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:58:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 05:58:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 05:58:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 05:59:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 05:59:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 10:29:09 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 05:59:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:59:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 10:29:48 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 05:59:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 05:59:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:01:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:01:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:01:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:01:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:02:07 --> 404 Page Not Found: Stockreturn/index
ERROR - 2017-11-30 10:32:18 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 06:02:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:02:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:03:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:03:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:03:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:03:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 10:39:25 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 06:09:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:09:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:09:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:09:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 10:39:44 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 06:09:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:09:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:09:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:09:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:09:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:09:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:10:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:10:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:10:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:10:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:10:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:10:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:26:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:26:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:26:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:26:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:30:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:30:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:31:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:31:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:02:18 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:18 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:18 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:18 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:18 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:18 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 06:32:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:32:18 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:02:19 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:19 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:19 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:19 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:19 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:02:19 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 06:32:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:32:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:05:03 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:03 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:03 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:03 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:03 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:03 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 06:35:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:35:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:05:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:20 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:20 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:20 --> Severity: Notice --> Undefined index: branch_id D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 11:05:20 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 88
ERROR - 2017-11-30 06:36:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:36:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:36:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:36:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:36:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:36:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:38:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:38:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:08:38 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:08:38 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 06:38:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:38:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:38:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:38:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:39:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:39:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:39:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:39:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:39:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:39:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:40:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:40:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:40:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:40:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:40:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:11:23 --> Severity: Notice --> Undefined variable: rate D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 116
ERROR - 2017-11-30 06:41:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:41:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:41:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:41:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:42:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:42:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:12:16 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:12:16 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:12:16 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 06:42:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:42:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:42:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:42:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 11:15:55 --> Query error: Not unique table/alias: 'tbl_branch' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:15:55 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512020755
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 55
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 56
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 57
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 58
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 55
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 56
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 57
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 58
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 55
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 56
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 57
ERROR - 2017-11-30 11:18:18 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 58
ERROR - 2017-11-30 06:48:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:48:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:48:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:48:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:50:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:50:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:50:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:50:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:21:21 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:21:21 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021081
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:23:42 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv_item' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:23:42 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021222
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:24:04 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:04 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021244
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:05 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:05 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021245
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:05 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:05 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021245
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:05 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:05 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021245
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:39 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:39 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021279
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:39 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv`.`storage_name`
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:39 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021279
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv`.`po_id` DESC
ERROR - 2017-11-30 11:24:49 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:24:49 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021289
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:24:51 --> Query error: Unknown table 'db_methew_gar.tbl_po_inv' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:24:51 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021291
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:07 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:07 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021307
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:30 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:30 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021330
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:31 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:31 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021331
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:31 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:31 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021331
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:32 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:32 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021332
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:45 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:45 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021345
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:46 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:46 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021346
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:46 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:46 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021346
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:46 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:46 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021346
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021347
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021347
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021347
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.branch_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id` = `tbl_po_inv_item`.`branch_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:47 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021347
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:58 --> Query error: Unknown table 'db_methew_gar.tbl_branch' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:58 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021358
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:59 --> Query error: Unknown table 'db_methew_gar.tbl_branch' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_product`.*, `tbl_sizefix`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id` = `tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` = `tbl_po_inv_item`.`size_ref_id`
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:25:59 --> Query error: Unknown column 'tbl_po_inv_item.po_inv_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512021359
WHERE `id` = '57e1b89b54ce125daa4aa453e795adbe5bc0586a'
ORDER BY `tbl_po_inv_item`.`po_inv_id` DESC
ERROR - 2017-11-30 11:26:05 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:26:05 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:26:05 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 06:56:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:56:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:56:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 06:56:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 06:56:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 06:56:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 59
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 60
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: size_fixing D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 61
ERROR - 2017-11-30 11:30:12 --> Severity: Notice --> Undefined index: qty D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 62
ERROR - 2017-11-30 07:00:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:00:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 11:31:01 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:23 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:24 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:24 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:25 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:25 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:25 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:25 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:26 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:31:26 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 117
ERROR - 2017-11-30 11:32:17 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 118
ERROR - 2017-11-30 11:32:17 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 118
ERROR - 2017-11-30 07:03:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:03:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:04:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:04:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:04:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:04:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 11:42:06 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:06 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:06 --> Severity: Notice --> Undefined index: storage_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 07:12:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 11:42:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:21 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 07:12:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 11:42:22 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:22 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:22 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 07:12:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 11:42:22 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:22 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 11:42:22 --> Severity: Notice --> Undefined index: branch_name D:\xampp\htdocs\duty\mathewgarments\application\views\stocksummary_list.php 54
ERROR - 2017-11-30 07:12:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:12:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:12:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:12:34 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:12:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:12:40 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-30 07:12:40 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-30 07:12:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:12:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:12:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:47 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-30 07:12:47 --> 404 Page Not Found: Branch/audio
ERROR - 2017-11-30 07:12:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:12:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:13:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:13:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:13:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-30 07:13:02 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-11-30 07:13:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:13:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:13:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:13:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:13:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-30 07:13:36 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-30 07:13:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:13:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:13:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-30 07:13:51 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-30 07:14:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:14:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:14:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-30 07:14:21 --> 404 Page Not Found: Product/audio
ERROR - 2017-11-30 07:14:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:14:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:14:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:14:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:14:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 07:14:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 07:14:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:14:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:14:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:14:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:35:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:35:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:36:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:36:22 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:36:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:36:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:37:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:37:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:38:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:38:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:38:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:38:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:39:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:39:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:39:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:39:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:39:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-11-30 12:10:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:10:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 253
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 253
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 253
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 253
ERROR - 2017-11-30 12:10:40 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:10:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 07:40:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:40:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-11-30 12:11:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:11:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 255
ERROR - 2017-11-30 12:11:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 255
ERROR - 2017-11-30 07:41:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:41:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Undefined variable: seller D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-11-30 12:11:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 49
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 140
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:11:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 254
ERROR - 2017-11-30 12:11:21 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 255
ERROR - 2017-11-30 12:11:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 255
ERROR - 2017-11-30 07:41:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:41:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:13:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:13:53 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 262
ERROR - 2017-11-30 12:13:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 262
ERROR - 2017-11-30 07:43:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:43:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 263
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 263
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 263
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 263
ERROR - 2017-11-30 12:15:21 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 264
ERROR - 2017-11-30 12:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 264
ERROR - 2017-11-30 07:45:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:45:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:36 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 258
ERROR - 2017-11-30 12:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 258
ERROR - 2017-11-30 07:45:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:45:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 144
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 257
ERROR - 2017-11-30 12:15:38 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 258
ERROR - 2017-11-30 12:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 258
ERROR - 2017-11-30 07:45:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:45:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:27 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 07:46:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:46:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:29 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:16:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 07:46:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:46:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:30 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 07:46:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:46:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 147
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 151
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 260
ERROR - 2017-11-30 12:16:31 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 07:46:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:46:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 148
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 152
ERROR - 2017-11-30 12:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 152
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 261
ERROR - 2017-11-30 12:17:00 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 262
ERROR - 2017-11-30 12:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 262
ERROR - 2017-11-30 07:47:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:47:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:17:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:45 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 285
ERROR - 2017-11-30 12:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 285
ERROR - 2017-11-30 07:47:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:47:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:17:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:47 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 285
ERROR - 2017-11-30 12:17:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 285
ERROR - 2017-11-30 07:47:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:47:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:17:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 284
ERROR - 2017-11-30 12:17:49 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 285
ERROR - 2017-11-30 12:17:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 285
ERROR - 2017-11-30 07:47:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:47:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:18:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:05 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:48:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:48:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:23 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:48:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:48:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:48:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:48:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:18:36 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:48:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:48:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:19:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:00 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:49:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:49:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:10 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:19:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:49:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:49:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:21 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:49:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:49:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:19:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:39 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:19:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:49:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:49:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:19:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:19:55 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:19:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:49:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:49:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:20:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:20:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:20:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:20:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:20:32 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:20:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:50:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:50:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:21:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:51:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:51:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:21:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:32 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:51:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:51:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:21:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:21:36 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:21:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:51:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:51:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:22:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:22:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:22:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:22:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:22:19 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:22:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:52:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:52:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:23:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:23:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:23:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:23:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:23:32 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:23:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:53:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:53:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:25:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:25:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:25:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:25:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 280
ERROR - 2017-11-30 12:25:57 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 12:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 281
ERROR - 2017-11-30 07:55:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:55:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 12:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 479
ERROR - 2017-11-30 12:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 479
ERROR - 2017-11-30 12:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 479
ERROR - 2017-11-30 12:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 479
ERROR - 2017-11-30 12:28:16 --> Severity: Notice --> Undefined variable: item D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 480
ERROR - 2017-11-30 12:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\goods_add.php 480
ERROR - 2017-11-30 07:58:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:58:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:58:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:58:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:59:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 07:59:48 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:00:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:00:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:04:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:04:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:04:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:04:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:04:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:04:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:06:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:06:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:06:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:06:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:07:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:07:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:08:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:08:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:08:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:08:29 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:08:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:08:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:09:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:09:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:10:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:10:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:11:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:12:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:12:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:12:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 08:12:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 08:13:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-11-30 08:13:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-11-30 08:13:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:13:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:14:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:14:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:14:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:14:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:15:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:15:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:15:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:15:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:15:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:16:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:16:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:16:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:16:50 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:17:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:17:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:17:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:17:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:17:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 08:17:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:11:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:11:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:16:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:16:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:17:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:17:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:17:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:17:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:21:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:21:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:21:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:21:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:21:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:21:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:22:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:22:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:22:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:22:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:24:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:24:06 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:25:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:25:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:26:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:26:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:28:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:28:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:29:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:29:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:30:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-30 09:30:30 --> 404 Page Not Found: Goodsreceived/audio
