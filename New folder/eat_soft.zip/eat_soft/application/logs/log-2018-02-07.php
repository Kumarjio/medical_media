<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-07 07:18:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-07 07:18:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-07 07:18:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-07 07:18:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-07 08:02:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-07 08:02:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-07 08:02:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-07 08:02:13 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-07 08:02:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-07 08:02:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-07 08:02:22 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-07 08:02:22 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-07 08:02:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-07 08:02:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-07 08:03:02 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-07 08:03:02 --> 404 Page Not Found: Wholesale/audio
ERROR - 2018-02-07 13:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-07 13:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-07 13:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-07 13:33:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
