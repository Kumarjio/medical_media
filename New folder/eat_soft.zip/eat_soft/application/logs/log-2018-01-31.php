<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-31 05:11:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:11:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:11:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:11:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:29:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:29:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:29:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 05:29:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 05:30:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:30:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:32:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 05:32:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 05:32:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:32:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:33:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:33:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:33:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:33:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:34:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:34:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 05:37:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 05:37:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 06:45:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:45:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:45:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 06:45:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 06:45:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 06:45:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 06:45:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:45:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:46:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:46:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:48:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:48:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:48:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:48:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:50:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:50:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:51:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:51:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:51:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:51:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:52:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:52:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:53:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:53:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:54:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:54:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:54:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:54:30 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:55:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:55:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:55:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:55:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:55:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:55:46 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:56:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:56:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:56:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:56:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:58:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:58:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:58:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:58:56 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:59:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:59:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 06:59:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:00:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:00:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:01:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:01:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:02:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:02:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:35:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 07:35:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 07:36:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 07:36:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 07:36:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:36:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:40:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:40:44 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:41:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:41:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:42:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:42:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:42:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:42:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:43:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:43:26 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:13:28 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:14:14 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:14:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:19:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 07:49:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:49:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:49:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:49:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:19:54 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:19:55 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:24:01 --> Severity: Parsing Error --> syntax error, unexpected ')' E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 365
ERROR - 2018-01-31 13:24:16 --> Query error: Unknown column 'po_hold_id' in 'where clause' - Invalid query: DELETE FROM `tbl_grn_hold`
WHERE `po_hold_id` = '2'
ERROR - 2018-01-31 13:24:48 --> Query error: Unknown column 'tbl_grn_hold.po_hold_id' in 'where clause' - Invalid query: DELETE FROM `tbl_grn_hold`
WHERE `tbl_grn_hold`.`po_hold_id` = '2'
ERROR - 2018-01-31 07:55:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:55:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:25:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 07:55:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:55:17 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:25:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 07:55:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:55:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:25:45 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 07:55:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:55:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:55:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:55:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:56:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:56:21 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:26:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:26:39 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 510
ERROR - 2018-01-31 07:56:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:56:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:59:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:59:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:59:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 07:59:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:29:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:31:21 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING) E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 513
ERROR - 2018-01-31 08:04:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:04:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:34:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 08:04:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:04:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:05:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:05:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:35:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 08:05:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:05:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:35:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:35:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 08:05:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 08:05:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 08:06:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 08:06:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 08:13:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 08:13:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 08:13:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 08:13:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 08:13:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 08:13:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 08:13:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 08:13:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 08:13:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:13:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:15:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:15:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:45:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 08:15:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:15:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:45:55 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:45:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 08:16:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:16:37 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:18:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:18:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:18:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:18:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:19:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:19:47 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:19:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:19:51 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:50:05 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:50:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 08:20:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:20:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:23:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:23:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:23:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:23:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:24:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:24:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:55:55 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:55:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:56:27 --> Severity: Notice --> Undefined offset: 1 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 511
ERROR - 2018-01-31 08:26:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:26:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:27:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:27:04 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:27:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:27:05 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:28:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 08:28:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 13:58:12 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 14:35:18 --> Severity: Notice --> Undefined offset: 2 E:\wamp\www\duty\mathewgarments\application\models\Goodsreceived_model.php 511
ERROR - 2018-01-31 09:05:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:05:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:05:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:05:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:06:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:06:42 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 14:36:43 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 30
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined variable: row E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 33
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 38
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 50
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 58
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 65
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 73
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 85
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 114
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 122
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 132
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 144
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 271
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 276
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 281
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 286
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 291
ERROR - 2018-01-31 14:36:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\goods_edit_hold.php 309
ERROR - 2018-01-31 09:07:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:07:14 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-31 09:10:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:10:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:10:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:10:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:11:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:11:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:11:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:11:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:52:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2018-01-31 14:52:21 --> Unable to connect to the database
ERROR - 2018-01-31 09:23:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:23:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:23:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:23:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:24:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:24:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:50:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:50:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:51:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:51:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:53:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:53:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:53:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:53:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:53:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:53:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:54:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:54:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:54:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:54:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:55:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:55:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:56:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 09:56:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 09:56:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 09:56:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 09:56:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:56:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:58:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 09:58:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 09:58:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 09:58:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:02:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:02:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:03:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:03:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:06:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:06:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:16:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:16:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:17:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:17:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:17:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:17:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:18:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:18:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:34:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 10:34:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 16:06:36 --> Severity: Error --> Maximum execution time of 120 seconds exceeded E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2018-01-31 10:36:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 10:36:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 16:08:37 --> Severity: Error --> Maximum execution time of 120 seconds exceeded E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2018-01-31 10:38:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 10:38:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 16:10:38 --> Severity: Error --> Maximum execution time of 120 seconds exceeded E:\wamp\www\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2018-01-31 11:18:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 11:18:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 11:18:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:18:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:18:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:18:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:19:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:19:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:19:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:19:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:20:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:20:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:21:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:21:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:21:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:21:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:21:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:21:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:24:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:24:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:26:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:26:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:27:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:27:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:29:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:29:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:29:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:29:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:31:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:31:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:34:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:34:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:37:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:37:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:37:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:37:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:38:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:38:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:41:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:41:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:43:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:43:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:48:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:48:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:50:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:50:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:50:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:50:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:52:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:52:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:52:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 11:52:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:03:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:03:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:04:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:04:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:04:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:04:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:05:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:05:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:06:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:06:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:06:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:06:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:07:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:07:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:07:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:07:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:08:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:08:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:08:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:08:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:10:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:10:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:11:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:11:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:11:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:11:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:12:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:12:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:12:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:12:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:16:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:16:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:16:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:16:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:17:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:17:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:17:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:17:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:19:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:19:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:19:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:19:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:19:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:19:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:20:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:20:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 17:51:46 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 105
ERROR - 2018-01-31 17:51:46 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 107
ERROR - 2018-01-31 12:21:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:21:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 17:52:20 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 105
ERROR - 2018-01-31 17:52:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 107
ERROR - 2018-01-31 12:22:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:22:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:22:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:22:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:23:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:23:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:24:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:24:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:24:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:24:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:25:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:25:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 17:55:54 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 105
ERROR - 2018-01-31 17:55:54 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 107
ERROR - 2018-01-31 12:25:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:25:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:28:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:28:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 17:58:47 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 105
ERROR - 2018-01-31 17:58:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 107
ERROR - 2018-01-31 12:29:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:29:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:29:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:29:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:29:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:29:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:30:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:30:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:30:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-31 12:30:44 --> 404 Page Not Found: Retail/audio
ERROR - 2018-01-31 12:30:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 12:30:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 12:30:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 12:30:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 12:30:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:30:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:41:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 12:41:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 12:41:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 12:41:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 12:41:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:41:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:42:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:42:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:46:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:46:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:47:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:47:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:47:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:47:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:47:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:47:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:48:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:48:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:48:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:48:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 18:18:59 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 105
ERROR - 2018-01-31 18:18:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 107
ERROR - 2018-01-31 12:49:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:49:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:49:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:49:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 18:20:06 --> Severity: Warning --> Missing argument 1 for Retail::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 105
ERROR - 2018-01-31 18:20:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Retail.php 107
ERROR - 2018-01-31 12:50:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:50:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:50:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:50:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:51:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:51:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:51:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:51:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:55:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:55:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:55:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:55:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:56:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 12:56:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:06:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:06:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:14:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:14:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:15:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:15:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:15:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:15:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:15:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:15:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:16:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:16:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:17:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:17:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:17:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:17:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:20:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:20:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:20:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 13:20:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 13:20:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 13:20:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 13:20:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:20:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:21:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 13:21:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 13:22:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 13:22:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 13:22:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 13:22:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 13:22:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:22:32 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:22:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:22:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:25:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:25:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:25:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:25:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:27:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:27:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:28:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:28:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:28:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:28:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:28:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:28:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:29:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:29:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:29:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:29:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:30:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:30:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:30:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:30:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:30:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:30:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:31:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:31:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:32:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:32:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:39:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:39:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:40:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:40:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:42:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:42:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:42:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:42:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:43:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:43:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:43:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:43:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:44:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:44:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:45:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:45:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:46:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:46:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:47:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:47:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:47:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:47:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:48:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:48:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:49:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:49:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:49:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:49:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:50:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:50:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:50:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:50:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:52:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:54:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:55:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:56:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:56:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:57:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:57:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:58:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:59:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:59:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:59:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:59:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:59:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 13:59:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:01:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:02:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:02:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:04:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:04:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:04:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:04:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:04:11 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-31 14:04:11 --> 404 Page Not Found: Vendor/audio
ERROR - 2018-01-31 14:04:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:04:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:04:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:04:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:05:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:05:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:05:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:05:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:07:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:10:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:10:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:23:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:23:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:24:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:24:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-31 14:25:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:25:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:26:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:26:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:26:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:26:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:26:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:26:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:26:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:26:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:26:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:26:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:27:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:27:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:27:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:27:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:27:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:27:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:27:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:27:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:27:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-31 14:27:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-31 14:30:24 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-31 14:30:24 --> 404 Page Not Found: Barcode/audio
