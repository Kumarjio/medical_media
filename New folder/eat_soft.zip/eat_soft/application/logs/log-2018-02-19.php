<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-19 12:17:58 --> 404 Page Not Found: Audio/fail.mp3
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-19 12:17:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 17:47:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 17:47:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 17:47:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 17:47:58 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:18:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 12:18:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-19 17:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 17:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 17:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 17:48:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:30:10 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-19 12:30:10 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-19 12:30:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-19 12:30:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 18:00:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:14 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:30:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 12:30:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-19 18:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:17 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:30:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 12:30:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-19 18:00:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:19 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:30:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-19 12:30:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-19 18:00:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:00:20 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:38:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 12:38:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-19 18:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:39:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-19 12:39:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-19 18:09:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:09:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:09:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:09:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 12:45:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-19 12:45:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-19 18:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-19 18:15:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
