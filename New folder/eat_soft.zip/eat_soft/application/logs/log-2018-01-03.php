<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-03 07:48:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 07:48:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 07:48:26 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 07:48:26 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:10:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 08:40:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 08:40:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 08:40:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:40:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:42:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 08:42:05 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:17:20 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 08:47:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 08:47:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 08:47:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:47:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:47:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 08:47:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 08:47:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-03 08:47:52 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:19:01 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 08:49:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 08:49:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 08:49:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:49:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 14:19:13 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2018-01-03 08:55:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:55:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:56:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 08:56:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:00:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:00:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:04:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:04:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:04:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:04:16 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:04:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:04:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:05:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:05:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:05:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:05:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:05:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:05:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:06:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:06:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:07:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:07:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:07:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:07:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:07:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:07:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:08:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:08:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:08:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:08:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:09:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:09:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:09:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:09:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:10:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:10:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:10:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:10:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:10:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:10:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:12:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:12:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:16:07 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:16:07 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 14:46:35 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 09:16:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:16:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:16:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:16:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:17:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:17:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:22:50 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:22:50 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:23:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:23:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:23:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:23:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:23:43 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:23:43 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:26:10 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:26:10 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:26:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:26:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:26:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:26:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:26:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:26:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:27:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:27:04 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 15:00:59 --> Query error: Unknown column 'single_po_entry_id' in 'order clause' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
ORDER BY `single_po_entry_id` DESC
ERROR - 2018-01-03 15:00:59 --> Query error: Unknown column 'single_po_entry_id' in 'order clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1514971859
WHERE `id` = 'b3148a2f86e412d2108f404524cf3d492be93106'
ORDER BY `single_po_entry_id` DESC
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 60
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:28 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 09:31:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:31:28 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 61
ERROR - 2018-01-03 15:01:58 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\single_pro_barcode.php 62
ERROR - 2018-01-03 09:31:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:31:58 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:32:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:32:16 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:37:54 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:37:54 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:38:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:38:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 15:08:04 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 15:08:05 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 09:38:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:38:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:38:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:38:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:38:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:38:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:38:27 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 09:38:27 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 15:09:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 15:09:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 15:09:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 15:09:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 15:09:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 15:09:44 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 15:09:44 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 15:09:44 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 15:09:44 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 09:39:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 09:39:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 09:39:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:39:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:43:29 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 72
ERROR - 2018-01-03 09:43:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:43:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:50:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:50:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:54:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 09:54:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:12:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:12:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 15:43:12 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:13:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:13:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:13:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:13:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 15:43:38 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1514974418
WHERE `single_po_entry_id` = 'H'
AND `id` = '3cfc8639be19621e07cbb81fba96ee0778c7b1b1'
ERROR - 2018-01-03 15:43:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php:13) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-01-03 10:14:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:14:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:14:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:14:41 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:18:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:18:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:19:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:19:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 15:49:43 --> Query error: Not unique table/alias: 'tbl_po_inv_item' - Invalid query: SELECT *
FROM `tbl_single_po_entry`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_single_po_entry`.`po_inv_ref_id`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`style_ref_id`
LEFT JOIN `tbl_productcreation` ON `tbl_productcreation`.`p_create_id`=`tbl_product`.`pro_name`
LEFT JOIN `tbl_brand` ON `tbl_product`.`brd_name`=`tbl_brand`.`brand_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
LEFT JOIN `tbl_material` ON `tbl_material`.`material_id`=`tbl_product`.`mat_name`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id`=`tbl_po_inv_item`.`size_ref_id`
LEFT JOIN `tbl_product_img` ON `tbl_product_img`.`produt_img_id`=`tbl_po_inv_item`.`product_img_ref_id`
LEFT JOIN `tbl_color` ON `tbl_color`.`color_id`=`tbl_po_inv_item`.`color_ref_id`
WHERE `single_po_entry_id` = '150'
ERROR - 2018-01-03 15:49:43 --> Query error: Unknown column 'single_po_entry_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1514974783
WHERE `single_po_entry_id` = '150'
AND `id` = 'dcef81efc8189c13cd3650e87fe2ec48c1bd87e0'
ERROR - 2018-01-03 10:20:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:20:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:27:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:27:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:31:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:31:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:32:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:32:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:35:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:35:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:35:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:35:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:38:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:38:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:08:03 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:08:03 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:08:03 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:41:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:41:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:11:24 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:11:24 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:11:24 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:41:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:41:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:11:38 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:11:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:11:38 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:42:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:42:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:44:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:44:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:14:42 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:14:42 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:14:42 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:45:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:45:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:15:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:15:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:15:55 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:46:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:46:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:16:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:16:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:16:57 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:47:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:47:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:17:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:17:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:17:05 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:47:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:47:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:17:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:17:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:17:31 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:47:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:47:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:18:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:18:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:18:07 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:48:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:48:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:18:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:18:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:18:50 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:20:27 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:20:27 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:20:27 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:20:28 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:20:28 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:20:28 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:20:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:20:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:20:30 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:50:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:50:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:20:40 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:20:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:20:40 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:20:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:20:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:20:57 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 10:51:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 10:51:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:01:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:01:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:32:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:32:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:32:00 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:02:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:02:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:32:58 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:32:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:32:58 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:03:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:03:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:33:10 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:33:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:33:10 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:09:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:09:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:39:38 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:39:38 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:39:38 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:39:40 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:39:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:39:40 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:10:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:10:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:10:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:10:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:40:53 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:40:53 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:40:53 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:40:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:40:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:40:56 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:40:59 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:40:59 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:40:59 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:41:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:41:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:41:04 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:41:09 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:41:09 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:41:09 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:46:46 --> Query error: Unknown column 'tbl_po_inv_item.pro_ref_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv_item`.*, `tbl_po_inv`.*, `tbl_product`.*, `tbl_unit`.*, `tbl_vendor`.*, `tbl_branch`.*
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_po_inv` ON `tbl_po_inv`.`po_id`=`tbl_po_inv_item`.`po_ref_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`product_id`=`tbl_po_inv_item`.`pro_ref_id`
LEFT JOIN `tbl_unit` ON `tbl_unit`.`unit_id`=`tbl_po_inv_item`.`unit_ref_id`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`vendor_id`=`tbl_po_inv`.`supplier_ref_id`
LEFT JOIN `tbl_branch` ON `tbl_branch`.`branch_id`=`tbl_po_inv`.`storage_name`
ERROR - 2018-01-03 16:47:44 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:47:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:47:44 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:47:47 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:47:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:47:47 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:47:58 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:47:58 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:47:58 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:25:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:25:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:55:35 --> Severity: Error --> Call to undefined method Stock_transfer_model::where() E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 28
ERROR - 2018-01-03 16:55:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:55:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:55:35 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:25:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:25:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:55:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:55:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:55:50 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:55:50 --> Severity: Error --> Call to undefined method Stock_transfer_model::where() E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 28
ERROR - 2018-01-03 11:26:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:26:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:57:00 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:57:00 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:57:00 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:28:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:28:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 16:58:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:58:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:58:07 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:58:14 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:58:14 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:58:14 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 16:58:40 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 16:58:40 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 16:58:40 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:30:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:30:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 17:00:04 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:00:04 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:00:04 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:00:08 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:00:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:00:08 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:00:08 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:00:08 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:00:08 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:00:12 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:00:12 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:00:12 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:30:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:30:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 17:00:47 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:00:47 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:00:47 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:32:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:32:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 17:03:07 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:03:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:03:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:03:07 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:03:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:03:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:03:20 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:03:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:03:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:03:20 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:33:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:33:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 17:03:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:03:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:03:31 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:03:34 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:03:34 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:03:34 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:04:05 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:04:05 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:04:05 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:04:13 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:04:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:04:13 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:04:36 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:04:36 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:04:36 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:05:06 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:05:06 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:05:06 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:05:13 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:05:13 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:05:13 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 17:05:19 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 17:05:19 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 17:05:19 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 11:37:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:37:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:48:47 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 11:48:47 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 17:21:14 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 11:51:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 11:51:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 11:51:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 11:51:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:35:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:35:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 18:05:35 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:05:35 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:05:35 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 18:05:55 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:05:55 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:05:55 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 18:06:18 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:06:18 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:06:18 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 18:06:26 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:06:26 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:06:26 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 12:36:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:36:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:38:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:38:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:40:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:40:17 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:43:52 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:43:52 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:44:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:44:09 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:45:41 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:45:41 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:51:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 12:51:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 12:51:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 12:51:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 12:51:32 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:51:32 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 18:22:36 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 12:52:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 12:52:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 12:52:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 12:52:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 18:22:50 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:22:50 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:22:50 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 18:22:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:22:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:22:57 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 18:23:20 --> Severity: Warning --> Missing argument 1 for Stock_transfer::get_single_po_details() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 70
ERROR - 2018-01-03 18:23:20 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 71
ERROR - 2018-01-03 18:23:20 --> Severity: Notice --> Undefined offset: 6 E:\wamp\www\duty\mathewgarments\application\models\Stock_transfer_model.php 12
ERROR - 2018-01-03 12:53:45 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 12:53:45 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 13:16:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 13:16:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 60
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 61
ERROR - 2018-01-03 18:51:43 --> Severity: Notice --> Undefined index: tbl_single_po_entry_id E:\wamp\www\duty\mathewgarments\application\views\transfer_out.php 62
ERROR - 2018-01-03 13:21:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 13:21:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 13:21:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 13:21:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-01-03 13:29:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 13:29:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 13:29:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 13:29:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 13:29:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-01-03 13:29:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-01-03 13:29:29 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-01-03 13:29:29 --> 404 Page Not Found: Barcode/audio
