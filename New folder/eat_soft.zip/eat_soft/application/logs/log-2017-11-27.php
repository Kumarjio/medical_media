<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-27 12:44:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:44:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:15:19 --> Severity: Notice --> Undefined variable: item_name D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 76
ERROR - 2017-11-27 12:45:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:45:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:24 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:17:45 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 86
ERROR - 2017-11-27 17:17:45 --> Severity: Notice --> Undefined index: customer_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-11-27 17:17:45 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 17:17:45 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-27 12:47:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:47:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:20:08 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 86
ERROR - 2017-11-27 17:20:08 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-11-27 17:20:08 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 17:20:08 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-27 12:50:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:50:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:20:10 --> Severity: Notice --> Undefined index: i_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 86
ERROR - 2017-11-27 17:20:10 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 94
ERROR - 2017-11-27 17:20:10 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 17:20:10 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 98
ERROR - 2017-11-27 12:50:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:50:10 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:21:15 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 276
ERROR - 2017-11-27 17:22:02 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 276
ERROR - 2017-11-27 17:22:04 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 276
ERROR - 2017-11-27 17:22:04 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 276
ERROR - 2017-11-27 17:24:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 88
ERROR - 2017-11-27 17:24:28 --> Severity: Notice --> Undefined variable: customer D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 69
ERROR - 2017-11-27 12:54:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:54:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:24:59 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 69
ERROR - 2017-11-27 12:54:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:54:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:27:01 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 69
ERROR - 2017-11-27 12:57:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:57:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:27:02 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 69
ERROR - 2017-11-27 12:57:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 12:57:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:30:36 --> Severity: Notice --> Undefined variable: cnt D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 70
ERROR - 2017-11-27 17:30:36 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 71
ERROR - 2017-11-27 13:00:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:00:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:30:58 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 71
ERROR - 2017-11-27 13:00:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:00:58 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:35:39 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 293
ERROR - 2017-11-27 17:35:57 --> Severity: Notice --> Undefined variable: cnt D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 95
ERROR - 2017-11-27 17:35:57 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:35:57 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 102
ERROR - 2017-11-27 17:35:57 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 103
ERROR - 2017-11-27 13:05:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:05:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:36:20 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:36:20 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 102
ERROR - 2017-11-27 17:36:20 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 103
ERROR - 2017-11-27 13:06:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:06:20 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:43:08 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:43:08 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 102
ERROR - 2017-11-27 17:43:08 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 103
ERROR - 2017-11-27 13:13:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:13:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:43:38 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:43:38 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 17:43:38 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 103
ERROR - 2017-11-27 17:43:38 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 104
ERROR - 2017-11-27 13:13:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:13:38 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:44:19 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 17:44:19 --> Severity: Notice --> Undefined index: stotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 103
ERROR - 2017-11-27 17:44:19 --> Severity: Notice --> Undefined index: gtotal D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 104
ERROR - 2017-11-27 13:14:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:14:19 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:45:33 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:15:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:15:33 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:46:54 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:46:54 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:16:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:16:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:48:12 --> Severity: Notice --> Undefined variable: product D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 78
ERROR - 2017-11-27 13:18:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:18:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:48:23 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:48:23 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:18:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:18:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:48:59 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:48:59 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:49:00 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:49:00 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:19:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:19:00 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:49:01 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:49:01 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:19:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:19:01 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:49:31 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:49:31 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:19:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:19:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:49:31 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:49:31 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:19:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:19:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:49:32 --> Severity: Notice --> Undefined index: product_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 96
ERROR - 2017-11-27 17:49:32 --> Severity: Notice --> Undefined index: brand_name D:\xampp\htdocs\duty\mathewgarments\application\views\goods_list.php 97
ERROR - 2017-11-27 13:19:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:19:32 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:09 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:15 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:27 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:53 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:22:54 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:24:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:24:03 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:24:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:24:11 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:24:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:24:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:25:06 --> 404 Page Not Found: Stock/editstock
ERROR - 2017-11-27 13:29:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:29:12 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:29:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 13:29:13 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-11-27 17:59:18 --> Severity: Error --> Call to undefined method Goodsreceived_model::get_supplier() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Goodsreceived.php 52
ERROR - 2017-11-27 17:59:33 --> Query error: Table 'db_methew_gar.cb_customer' doesn't exist - Invalid query: SELECT `tbl_po_inv`.*, `tbl_po_inv_item`.*, `tbl_product`.*, `cb_customer`.*
FROM `tbl_po_inv`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_po_inv`.`po_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_po_inv_item`.`item_code`
LEFT JOIN `cb_customer` ON `cb_customer`.`cid`=`tbl_po_inv`.`seller_id`
WHERE `tbl_po_inv`.`po_id` = '3'
ERROR - 2017-11-27 17:59:33 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1511785773
WHERE `tbl_po_inv`.`po_id` = '3'
AND `id` = '4d4f6dbe0ee84276b743eeb2fde29e4d4eb99508'
ERROR - 2017-11-27 17:59:55 --> Query error: Unknown column 'tbl_product.i_id' in 'on clause' - Invalid query: SELECT `tbl_po_inv`.*, `tbl_po_inv_item`.*, `tbl_product`.*
FROM `tbl_po_inv`
LEFT JOIN `tbl_po_inv_item` ON `tbl_po_inv_item`.`po_inv_id`=`tbl_po_inv`.`po_id`
LEFT JOIN `tbl_product` ON `tbl_product`.`i_id`=`tbl_po_inv_item`.`item_code`
WHERE `tbl_po_inv`.`po_id` = '3'
ERROR - 2017-11-27 17:59:55 --> Query error: Unknown column 'tbl_po_inv.po_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1511785795
WHERE `tbl_po_inv`.`po_id` = '3'
AND `id` = '4d4f6dbe0ee84276b743eeb2fde29e4d4eb99508'
