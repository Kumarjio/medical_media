<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-03 04:32:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 04:32:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 04:33:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 04:33:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 04:33:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 04:33:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:27:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:27:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 10:57:56 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 10:57:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 10:57:57 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 10:57:57 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 05:27:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:27:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 11:03:30 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:03:30 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 11:03:31 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:03:31 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 05:33:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:33:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:33:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:33:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:33:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:33:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:34:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:34:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 11:05:07 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:05:07 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 05:35:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:35:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:35:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:35:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:35:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:35:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:36:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:36:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:42:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:43:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:43:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:47:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:47:44 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:48:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:48:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:48:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:48:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:50:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:50:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 11:20:43 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:20:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 11:20:43 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:20:43 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 11:20:44 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:20:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 11:20:44 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:20:44 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 05:50:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:50:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:50:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:50:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:52:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:52:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 11:22:10 --> Severity: Warning --> Missing argument 1 for Stock_transfer::change_delete_status() E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 78
ERROR - 2018-02-03 11:22:10 --> Severity: Notice --> Undefined variable: data E:\wamp\www\duty\mathewgarments\application\controllers\Stock_transfer.php 79
ERROR - 2018-02-03 05:52:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:52:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:52:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:52:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:53:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:53:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:54:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:54:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:54:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:54:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:54:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:54:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:55:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 05:55:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:02:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:02:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:03:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:03:29 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:06:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:06:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:07:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:07:21 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:07:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:07:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:07:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:07:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:08:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:08:57 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:09:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:09:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:10:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:10:10 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:12:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:12:45 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:13:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:13:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:13:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:13:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:13:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:13:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:14:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:15:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:15:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:15:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:15:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:15:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:15:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:16:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:16:08 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:16:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:16:39 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:16:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:16:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:17:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:17:14 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:19:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:19:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:19:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:19:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:13 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:30 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:20:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:21:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:21:58 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:22:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:22:17 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:27:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:27:27 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:27:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:27:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:26 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:28:56 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:20 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:29:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:30:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:30:04 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:30:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:30:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:31:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:31:43 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:31:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:31:50 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:32:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:32:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:32:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:32:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:35:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:35:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:35:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:35:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:35:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:35:37 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:36:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:36:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:36:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:36:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:38:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:38:22 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:39:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:39:35 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:39:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:39:54 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:43:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:43:12 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:43:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:43:34 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:44:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:44:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:44:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:44:55 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:45:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:45:05 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:45:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:45:42 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:46:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:46:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:46:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:46:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:46:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:46:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:51:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:51:46 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:58:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:58:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:59:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:59:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:59:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 06:59:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:00:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:00:03 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:00:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:00:53 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:01:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:01:25 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:01:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:01:28 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:08:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:08:15 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:10:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:10:31 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:10:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:10:33 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:10:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:10:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:12:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:12:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:13:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:13:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:13:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:13:02 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:13:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:13:18 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:14:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:14:48 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:15:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:15:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:45:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:15:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:15:09 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:45:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:45:10 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:17:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:17:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 12:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:47:37 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 07:17:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 07:17:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 12:47:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:47:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 12:47:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:47:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 07:17:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 07:17:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 12:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 12:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:47:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 07:18:00 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-03 07:18:00 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-03 12:48:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:48:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 12:48:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:48:00 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 07:18:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 07:18:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 12:48:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:48:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 12:48:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:48:04 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 119
ERROR - 2018-02-03 07:18:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:18:36 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:19:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:19:01 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:19:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:19:23 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:49:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:49:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:49:23 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:21:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:21:06 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:51:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:06 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:21:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:21:07 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:51:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:21:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:21:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:51:38 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:21:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:21:40 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:51:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:51:40 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:21:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:21:52 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:22:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:22:00 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:25:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 07:25:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 07:25:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 07:25:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 07:25:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-03 07:25:13 --> 404 Page Not Found: Barcode/audio
ERROR - 2018-02-03 07:25:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 07:25:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 07:25:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:25:19 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:25:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:25:47 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:55:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:55:48 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:25:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 07:25:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 12:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 12:55:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 07:43:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 07:43:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 13:13:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 13:13:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 08:30:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 08:30:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 14:00:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 14:00:56 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 08:32:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 08:32:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 14:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 14:02:57 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 08:32:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:32:59 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 14:02:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 14:02:59 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 08:33:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:33:24 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:33:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:33:49 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 14:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 14:03:49 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 08:33:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:33:51 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 14:03:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 14:03:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\controllers\Barcode.php 114
ERROR - 2018-02-03 08:34:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:34:11 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:34:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:34:38 --> 404 Page Not Found: Stock_transfer/audio
ERROR - 2018-02-03 08:35:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 08:35:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 08:35:23 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 08:35:23 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 08:37:48 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 08:37:48 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 08:44:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 08:44:30 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 14:14:32 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\hsn_list.php 48
ERROR - 2018-02-03 08:44:33 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-03 08:44:33 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-03 08:44:38 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:44:38 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:46:26 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:46:26 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:46:44 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:46:44 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:54:03 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:54:03 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:54:16 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:54:16 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:59:11 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:59:11 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:59:29 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:59:29 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:59:39 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 08:59:39 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:00:00 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:00:00 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:01:11 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:01:11 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:01:16 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:01:16 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:01:20 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:01:20 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:05 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:05 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:22 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:22 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:42 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:42 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:50 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:02:50 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:18 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:18 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:39 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:39 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:48 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:48 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:56 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:03:56 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:22 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:22 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:44 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:44 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:53 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:04:53 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:03 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:03 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:09 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:09 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:25 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:25 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:05:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:06:26 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:06:26 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:06:46 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:06:46 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:07:07 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:07:07 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:08:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:08:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:08:48 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:08:48 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:00 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:00 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:14 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:14 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:30 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:36 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:36 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:45 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:45 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:51 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:09:51 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:10:12 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:10:12 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:10:35 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:10:35 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:12:37 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:12:37 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 14:44:06 --> Severity: Notice --> Undefined variable: list E:\wamp\www\duty\mathewgarments\application\views\hsn_list.php 48
ERROR - 2018-02-03 09:14:07 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-03 09:14:07 --> 404 Page Not Found: Material/audio
ERROR - 2018-02-03 09:14:09 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:14:09 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:14:44 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:14:44 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:15:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:15:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:17:12 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:17:12 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:21:03 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:21:03 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:24:06 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:24:06 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 14:54:40 --> Severity: Notice --> Undefined index: hsn_pre_1 E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 32
ERROR - 2018-02-03 14:54:40 --> Severity: Notice --> Undefined index: hsn_pre_2 E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 35
ERROR - 2018-02-03 14:54:40 --> Severity: Notice --> Undefined index: hsn_pre_3 E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 38
ERROR - 2018-02-03 14:54:42 --> Severity: Notice --> Undefined index: percent E:\wamp\www\duty\mathewgarments\application\views\hsn_list.php 55
ERROR - 2018-02-03 09:24:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:24:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:26:25 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:26:25 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 14:58:11 --> Severity: Notice --> Undefined index: percent E:\wamp\www\duty\mathewgarments\application\views\hsn_list.php 55
ERROR - 2018-02-03 09:28:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:28:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:30:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:30:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 15:01:38 --> Severity: Notice --> Undefined property: stdClass::$percent E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 45
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 14
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 24
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 38
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 45
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 14
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 24
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 38
ERROR - 2018-02-03 15:01:39 --> Severity: Notice --> Trying to get property of non-object E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 45
ERROR - 2018-02-03 15:05:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:05:22 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:05:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:05:30 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:06:52 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:07:51 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:07:52 --> Severity: Warning --> Missing argument 1 for Hsn::update_hsn() E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 50
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 59
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 29
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 30
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 31
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 32
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 33
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 34
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 35
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 36
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 37
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 38
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 41
ERROR - 2018-02-03 15:07:52 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 43
ERROR - 2018-02-03 15:07:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= ''
WHERE `hsn_id` IS NULL' at line 1 - Invalid query: UPDATE `tbl_hsn` SET  = ''
WHERE `hsn_id` IS NULL
ERROR - 2018-02-03 15:07:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-02-03 15:08:00 --> Severity: Warning --> Missing argument 1 for Hsn::update_hsn() E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 50
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: id E:\wamp\www\duty\mathewgarments\application\controllers\Hsn.php 59
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 29
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 30
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 31
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 32
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 33
ERROR - 2018-02-03 15:08:00 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 34
ERROR - 2018-02-03 15:08:01 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 35
ERROR - 2018-02-03 15:08:01 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 36
ERROR - 2018-02-03 15:08:01 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 37
ERROR - 2018-02-03 15:08:01 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 38
ERROR - 2018-02-03 15:08:01 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 41
ERROR - 2018-02-03 15:08:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '', `hsn_code` = NULL, `hsn_per_1` = NULL, `hsn_min_1` = NULL, `hsn_max_1` = N' at line 1 - Invalid query: UPDATE `tbl_hsn` SET  = '', `hsn_code` = NULL, `hsn_per_1` = NULL, `hsn_min_1` = NULL, `hsn_max_1` = NULL, `hsn_per_2` = NULL, `hsn_min_2` = NULL, `hsn_max_2` = NULL, `hsn_per_3` = NULL, `hsn_min_3` = NULL, `hsn_max_3` = NULL
WHERE `hsn_id` IS NULL
ERROR - 2018-02-03 15:08:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:08:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:09:03 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 09:39:04 --> 404 Page Not Found: Hsn/update_hsn5
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:09:44 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:09:46 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 29
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 30
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 31
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 32
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 33
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 34
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 35
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 36
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 37
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: inps E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 38
ERROR - 2018-02-03 15:09:48 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 41
ERROR - 2018-02-03 15:09:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '', `hsn_code` = NULL, `hsn_per_1` = NULL, `hsn_min_1` = NULL, `hsn_max_1` = N' at line 1 - Invalid query: UPDATE `tbl_hsn` SET  = '', `hsn_code` = NULL, `hsn_per_1` = NULL, `hsn_min_1` = NULL, `hsn_max_1` = NULL, `hsn_per_2` = NULL, `hsn_min_2` = NULL, `hsn_max_2` = NULL, `hsn_per_3` = NULL, `hsn_min_3` = NULL, `hsn_max_3` = NULL
WHERE `hsn_id` = '1'
ERROR - 2018-02-03 15:09:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\wamp\www\duty\mathewgarments\system\core\Exceptions.php:272) E:\wamp\www\duty\mathewgarments\system\core\Common.php 569
ERROR - 2018-02-03 15:10:57 --> Severity: Notice --> Undefined variable: array E:\wamp\www\duty\mathewgarments\application\models\Hsn_model.php 41
ERROR - 2018-02-03 15:10:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '', `hsn_code` = '6001', `hsn_per_1` = '5', `hsn_min_1` = '1', `hsn_max_1` = '' at line 1 - Invalid query: UPDATE `tbl_hsn` SET  = '', `hsn_code` = '6001', `hsn_per_1` = '5', `hsn_min_1` = '1', `hsn_max_1` = '1000', `hsn_per_2` = '18', `hsn_min_2` = '1001', `hsn_max_2` = '20000', `hsn_per_3` = '18', `hsn_min_3` = '20001', `hsn_max_3` = '500000000'
WHERE `hsn_id` = '1'
ERROR - 2018-02-03 09:41:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:41:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:41:28 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:41:28 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:11:31 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 09:42:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:42:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:42:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:42:15 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 09:43:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:43:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:43:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:43:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:43:17 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 09:43:17 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 09:48:02 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 09:48:02 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 09:48:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 09:48:18 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:19:02 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:20:17 --> Severity: Notice --> Undefined variable: hsn E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 105
ERROR - 2018-02-03 15:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 105
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined variable: hsn E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 105
ERROR - 2018-02-03 15:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 105
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:20:18 --> Severity: Notice --> Undefined variable: hsn E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 105
ERROR - 2018-02-03 15:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 105
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:09 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 09:53:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:53:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:18 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 09:53:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:53:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:24 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 09:53:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:53:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:29 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 09:53:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 09:53:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:34 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 09:53:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:53:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:23:47 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:25:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 09:55:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 09:55:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:09:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:09:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:09:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:09:49 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:16:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:16:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:16:17 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 10:16:17 --> 404 Page Not Found: Hsn/audio
ERROR - 2018-02-03 10:17:35 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:17:35 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:17:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:17:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:17:41 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 10:17:41 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 10:17:56 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 10:17:56 --> 404 Page Not Found: Product/audio
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:48:07 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 14
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 24
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 40
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 58
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 77
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 15:48:08 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\product_edit.php 102
ERROR - 2018-02-03 10:18:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:18:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 25
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 35
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 43
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 51
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 59
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 67
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 75
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 83
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 91
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 99
ERROR - 2018-02-03 15:48:15 --> Severity: Notice --> Undefined offset: 0 E:\wamp\www\duty\mathewgarments\application\views\hsn_edit.php 107
ERROR - 2018-02-03 10:18:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:18:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:18:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:18:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:18:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:18:28 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:20:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:20:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:21:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:21:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:21:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:21:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:22:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:22:08 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:24:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:24:41 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:26:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:26:57 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:48:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-03 10:48:59 --> 404 Page Not Found: Retail/audio
ERROR - 2018-02-03 10:55:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2018-02-03 10:55:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2018-02-03 10:55:23 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2018-02-03 10:55:23 --> 404 Page Not Found: Goodsreceived/audio
