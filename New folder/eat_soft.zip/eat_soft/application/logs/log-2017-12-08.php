<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-08 09:52:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\duty\mathewgarments\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-12-08 09:52:21 --> Unable to connect to the database
ERROR - 2017-12-08 05:28:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:28:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:29:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:29:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:29:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 05:29:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 05:29:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:29:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:29:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:29:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:29:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 05:29:24 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 05:30:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:30:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:30:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:30:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:33:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:33:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:38:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:38:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:40:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:40:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:41:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:41:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:43:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:43:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:44:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:44:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:44:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:44:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:44:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:44:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:45:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:45:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:45:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:45:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:45:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:45:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:45:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:45:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:45:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:45:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:46:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:46:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:48:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:48:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:48:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:48:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:49:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:49:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:52:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:52:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:53:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:53:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:53:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:53:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:54:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:54:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:54:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:54:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:55:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:55:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:57:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:57:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:57:11 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:57:11 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:59:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:59:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 05:59:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 05:59:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:02:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:02:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:02:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:02:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:07:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:07:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:09:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:09:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:09:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:09:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:10:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:10:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:12:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:12:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:12:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:12:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:13:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:13:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:27:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:27:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:28:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:28:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:28:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:28:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:28:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:28:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:33:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:33:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:34:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:34:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:35:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:35:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:36:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:36:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:37:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:37:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:40:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:40:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:44:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:44:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:46:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:46:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:47:01 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:47:01 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:50:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:50:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:54:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:54:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:55:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:55:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:55:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:55:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 06:56:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 06:56:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:00:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:00:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:01:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:01:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:02:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:02:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:02:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:02:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:02:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:02:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:02:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:02:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:03:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:03:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:10:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:10:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:10:48 --> 404 Page Not Found: Dashboard/get_search_details1
ERROR - 2017-12-08 07:11:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:11:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:11:30 --> 404 Page Not Found: Dashboard/get_search_details1
ERROR - 2017-12-08 07:11:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:11:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:13:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:13:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:14:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:14:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:19:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:19:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:20:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:20:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:22:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:22:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:22:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:22:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:23:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:23:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:27:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:27:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:33:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:33:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:34:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:35:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:35:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:35:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:14:51 --> Severity: Parsing Error --> syntax error, unexpected '$data1' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 102
ERROR - 2017-12-08 07:45:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:45:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:15:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '== `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_i' at line 3 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` == `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
ERROR - 2017-12-08 07:45:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:45:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:16:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '== `tbl_sizefix`.`size_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'' at line 3 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_po_inv_item`.`size_ref_id` == `tbl_sizefix`.`size_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
ERROR - 2017-12-08 12:16:14 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512715574
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
AND `id` = 'cee9fa94fbc1118348e7ac50274ba63bf593cb65'
ERROR - 2017-12-08 07:47:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:47:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:17:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '== `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_i' at line 3 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` == `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
ERROR - 2017-12-08 12:17:20 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512715640
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
AND `id` = 'cee9fa94fbc1118348e7ac50274ba63bf593cb65'
ERROR - 2017-12-08 07:48:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:48:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:18:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '== `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_i' at line 3 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
RIGHT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` == `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
ERROR - 2017-12-08 12:18:52 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512715732
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
AND `id` = 'cee9fa94fbc1118348e7ac50274ba63bf593cb65'
ERROR - 2017-12-08 07:49:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 07:49:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:19:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '== `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_i' at line 3 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` == `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
ERROR - 2017-12-08 12:19:16 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512715756
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
AND `id` = 'cee9fa94fbc1118348e7ac50274ba63bf593cb65'
ERROR - 2017-12-08 07:49:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:49:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:20:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '== `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_i' at line 3 - Invalid query: SELECT *
FROM `tbl_po_inv_item`
LEFT JOIN `tbl_sizefix` ON `tbl_sizefix`.`size_id` == `tbl_po_inv_item`.`size_ref_id`
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
ERROR - 2017-12-08 12:20:05 --> Query error: Unknown column 'po_ref_id' in 'where clause' - Invalid query: UPDATE `ci_session` SET `timestamp` = 1512715805
WHERE `po_ref_id` IN('1', '2')
AND `pro_ref_id` = '5'
AND `id` = 'cee9fa94fbc1118348e7ac50274ba63bf593cb65'
ERROR - 2017-12-08 07:50:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:50:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:22:58 --> Severity: Parsing Error --> syntax error, unexpected '$data1' (T_VARIABLE) D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 102
ERROR - 2017-12-08 07:53:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 07:53:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:02:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:02:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:04:31 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:04:31 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:09:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:09:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:13:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:13:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:43:17 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 103
ERROR - 2017-12-08 08:15:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:15:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:17:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:17:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:47:07 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 08:18:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:18:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:22:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:22:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:23:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:23:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:23:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:23:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:24:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:24:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:26:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:26:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:27:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:27:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:27:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:27:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:29:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:29:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:29:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:29:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:30:40 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:30:40 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:31:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:31:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:31:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:31:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:32:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:32:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:35:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:35:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:35:27 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:35:27 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:35:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:35:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:35:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:35:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:38:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:38:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:39:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:39:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:39:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:39:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:39:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:39:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:40:22 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:40:22 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:41:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:41:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:42:41 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:42:41 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:47:26 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:47:26 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:52:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:52:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:55:05 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:55:05 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:57:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 08:57:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:59:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 08:59:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:10:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:10:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:11:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:11:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:13:13 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:13:13 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:13:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:13:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 14:46:26 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 14:47:09 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 14:47:52 --> Severity: Notice --> Undefined variable: product_details D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 14:47:52 --> Severity: Notice --> Undefined variable: response D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 14:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 10:17:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:17:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 14:48:23 --> Severity: Notice --> Undefined variable: product_details D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 14:48:23 --> Severity: Notice --> Undefined variable: response D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 14:48:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\duty\mathewgarments\application\views\dashboard.php 140
ERROR - 2017-12-08 10:18:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:18:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:32:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:32:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:32:58 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:32:58 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:33:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:33:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:34:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:34:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:35:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:35:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:36:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:36:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:38:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:38:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:45:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:45:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:46:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:46:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:46:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 10:46:07 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 10:46:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:46:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:51:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:51:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:52:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:52:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:53:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:53:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:54:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:54:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 10:54:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-08 10:54:26 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-08 10:55:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 10:55:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:04:20 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:04:20 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:08:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:08:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:09:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:09:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:09:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:09:36 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:11:06 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:11:06 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:11:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:11:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:11:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:11:25 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:12:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:12:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:12:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:12:18 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:12:29 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:12:29 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:12:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:12:31 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:14:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:14:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:14:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:14:12 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:14:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:14:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:19:37 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:19:37 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:19:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:19:40 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:19:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:19:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:19:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:19:46 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:20:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:20:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:22:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:22:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:24:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:24:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:24:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:24:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:25:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:25:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:26:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:26:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:32:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:32:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:32:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:32:06 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:32:49 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:32:49 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:32:53 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-08 11:32:53 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-08 11:37:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:37:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:37:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:37:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:37:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:37:14 --> 404 Page Not Found: Product/audio
ERROR - 2017-12-08 11:39:51 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:39:51 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:39:54 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-08 11:39:54 --> 404 Page Not Found: Vendor/audio
ERROR - 2017-12-08 11:42:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:42:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:42:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:42:55 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 11:44:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:44:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:48:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:48:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 16:19:00 --> Severity: Error --> Call to undefined method Product_model::get_color() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Color.php 17
ERROR - 2017-12-08 11:55:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:55:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 16:26:54 --> Severity: Error --> Call to undefined method Product_model::get_color() D:\xampp\htdocs\duty\mathewgarments\application\controllers\Color.php 17
ERROR - 2017-12-08 11:57:34 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:57:34 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:57:38 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:57:38 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:57:45 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:57:45 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:57:48 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:57:48 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:57:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:57:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:58:18 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:58:18 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:58:25 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:58:25 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:58:39 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:58:39 --> 404 Page Not Found: Color/audio
ERROR - 2017-12-08 11:58:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:58:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:58:52 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 11:58:52 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:59:14 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 11:59:14 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:00:57 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:00:57 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:01:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:01:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:01:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:01:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:01:20 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-08 12:01:20 --> 404 Page Not Found: Employee/audio
ERROR - 2017-12-08 12:01:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:01:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:04:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:04:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 16:34:46 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:52 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:53 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:54 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:34:56 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:35:00 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:35:04 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 16:35:58 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 12:07:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:07:03 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 16:37:12 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 12:08:55 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:08:55 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 16:39:10 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 12:10:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:10:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:10:32 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:10:32 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:12:00 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:12:00 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 16:42:05 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 12:12:17 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:12:17 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 16:42:28 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\duty\mathewgarments\application\models\Dashboard_model.php 99
ERROR - 2017-12-08 12:12:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:12:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:16:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:16:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:16:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:16:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:18:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:18:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:18:36 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:18:36 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:18:56 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:18:56 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:18:59 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:21:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:21:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:22:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:22:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:22:12 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:22:12 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:22:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:22:16 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:25:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:25:45 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 16:59:31 --> Severity: Notice --> Undefined variable: size D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 132
ERROR - 2017-12-08 16:59:31 --> Severity: Notice --> Undefined variable: unit D:\xampp\htdocs\duty\mathewgarments\application\models\Goodsreceived_model.php 133
ERROR - 2017-12-08 16:59:31 --> Query error: Column 'unit_ref_id' cannot be null - Invalid query: INSERT INTO `tbl_po_inv_item` (`po_ref_id`, `pro_ref_id`, `size_ref_id`, `unit_ref_id`, `qty`, `p_rate`, `total`, `sgst`, `cgst`, `igst`, `sgst_amt`, `cgst_amt`, `igst_amt`) VALUES (1, '8', NULL, NULL, '12', '100', '1200', '0', '0', '0', '0', '0', '0')
ERROR - 2017-12-08 12:30:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:30:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:32:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:32:43 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:34:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:34:02 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 12:34:08 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:34:08 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 12:37:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 12:37:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:00:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:00:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:03:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:03:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:05:04 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:05:04 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:06:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:06:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:08:46 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:08:46 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:09:10 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:09:10 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:09:19 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:09:19 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:15:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:15:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:17:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:17:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:17:15 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:17:15 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:17:24 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:17:24 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:17:30 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:17:30 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:17:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 13:17:35 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 13:18:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 13:18:39 --> 404 Page Not Found: Goodsreceived/audio
ERROR - 2017-12-08 13:18:44 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:18:44 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:18:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:18:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:19:18 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:19:18 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:19:28 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:19:28 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:19:38 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:19:38 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:19:53 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:19:53 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:20:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:20:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:20:23 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:20:23 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:22:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:22:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:23:16 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:23:16 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:26:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:26:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:29:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:29:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:29:48 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:29:48 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:29:59 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:29:59 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:30:39 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:30:39 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:34:02 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:34:02 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:34:50 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:34:50 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:35:33 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:35:33 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:35:42 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:35:42 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:36:09 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:36:09 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:40:21 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:40:21 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:40:43 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:40:43 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:40:52 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-08 13:40:54 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:40:54 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:41:07 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 13:41:07 --> 404 Page Not Found: Audio/fail.mp3
ERROR - 2017-12-08 13:41:12 --> 404 Page Not Found: Customer/cus_data
ERROR - 2017-12-08 14:01:03 --> 404 Page Not Found: Audio/alert.mp3
ERROR - 2017-12-08 14:01:03 --> 404 Page Not Found: Audio/fail.mp3
