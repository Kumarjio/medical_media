 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 public function  get_all_item(){
		$this->db->select('*');
		$this->db->from('tbl_item');
		$this->db->where('is_deleted',0);
		$query = $this->db->get();
		
		return $query->result_array();			
	 }
	 public function total_sales_list()
	 {
	 	$this->db->select('*')->from('tbl_sales');
	 	$this->db->join('cp_admin_login','cp_admin_login.admin_id=tbl_sales.server_name','left');
	 	$this->db->join('tbl_row','tbl_row.row_id=tbl_sales.sale_table_row','left');
	 	$this->db->join('tbl_table','tbl_table.table_id=tbl_sales.sale_table_name','left');
	 	$this->db->where('tbl_sales.is_deleted',0);
	 	$query=$this->db->get()->result_array();
	 	return $query;
	 }
	 public function get_item_price($item)
	 {
	 	$this->db->select('item_id,item_price')->from('tbl_item');
	 	$this->db->where('item_id',$item);
	 	$quer=$this->db->get();
	 	return $quer->result_array();
	 }
	 public function add_sales()
	 {
	 	extract($_REQUEST);
	 	$date=date('Y-m-d');
	 	$time=date('H:i:s');
	 	$array=array(
	 		        'sale_bill_no'=>$sales_bill_no,
	 		        'bill_date'=>$sale_bill_date,
	 		        'server_name'=>$server_name,
	 		        'bill_time'=>$time,
	 		        'sale_table_row'=>$sale_table_row,
	 		        'sale_table_name'=>$sale_table_name,

	 		        'sale_table_name'=>$sale_table_name,

	 		        'parcel_amt'=>$parcel_amt,
	 		         'sgst_per'=>$sgst_per,
	 		        'cgst_per'=>$cgst_per,
	 		        'sgst_amt'=>$sgst_amt,
	 		        'cgst_amt'=>$cgst_amt,
	 		        'sales_total'=>$stotal,
	 		        'sales_grand_total'=>$gtotal,
	 		        'status'=>0,
	 		        'is_deleted'=>0,
	 		         'sales_date'=>$date
	 	              );
	 	$this->db->insert('tbl_sales',$array);
       $insert_id=$this->db->insert_id();
        $value_det = $this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$date)->get()->result_array();
        if(empty($value_det)){
        	$valladd = array('purchase_value' => 0,'sales_value' => $gtotal,'value_date' => $date);
        	$this->db->insert('tbl_value',$valladd);
        }else{
        	$valladd = array('sales_value' => $gtotal+$value_det[0]['sales_value']);
        	$this->db->where('tbl_value.value_id',$value_det[0]['value_id'])->update('tbl_value',$valladd);
        }
	 	for($i=0; $i<count($item_name); $i++)
	 	{
	 		$array=array(
	 			        'sale_ref_id'=> $insert_id,
	 			        'sale_item_name'=> $item_name[$i],
	 			        'sale_price'=> $item_price[$i],
	 			        'sale_qty'=> $item_qty[$i],
	 			        'sale_item_total'=> $sale_total[$i],
	 		
	 			          );
	 		$this->db->insert('tbl_sale_items',$array);

	 	}
	 	return   $insert_id;
}
public function get_invoice($id)
{
$this->db->select('*')->from('tbl_sale_items');
$this->db->join('tbl_sales','tbl_sales.sal_id=tbl_sale_items.sale_ref_id','left');
$this->db->join('tbl_item','tbl_item.item_id=tbl_sale_items.sale_item_name','left');
$this->db->where('tbl_sales.sal_id',$id);
$query=$this->db->get()->result_array();
return $query;	
}
public function get_invoice_list($id)
{
$this->db->select('*')->from('tbl_sale_items');
$this->db->join('tbl_sales','tbl_sales.sal_id=tbl_sale_items.sale_ref_id','left');
$this->db->join('tbl_item','tbl_item.item_id=tbl_sale_items.sale_item_name','left');
$this->db->where('tbl_sales.sal_id',$id);
$query=$this->db->get()->result_array();
return $query;	
}
        public function sales_edit($id)
{
	$this->db->select('tbl_sales.*')->from('tbl_sales');
	$this->db->select('tbl_sale_items.*')->from('tbl_sale_items');
	$this->db->where('tbl_sales.sal_id',$id);
	$this->db->where('tbl_sale_items.sale_ref_id',$id);
	$query=$this->db->get()->result_array();
	return $query;


}
 public function edit_sales_update()
	 {
	 	extract($_REQUEST);

	 	$date=date('Y-m-d');
	 	$time=date('H:i:s');
	 	$previous_gtot = $this->db->select('*')->from('tbl_sales')->where('tbl_sales.sal_id',$hid_id)->get()->result_array();

	 	$value_det = $this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$previous_gtot[0]['bill_date'])->get()->result_array();
	
	 	

	 	
$cur_value=$value_det[0]['sales_value']-$previous_gtot[0]['sales_grand_total'];
$valladd = array('sales_value' => $cur_value);
        	//print_r($valladd);exit;
        	$this->db->where('tbl_value.value_id',$value_det[0]['value_id'])->update('tbl_value',$valladd);

	 	

       
	 	$array=array(
	 		        'sale_bill_no'=>$sales_bill_no,
	 		        'bill_date'=>$sale_bill_date,
	 		        'server_name'=>$server_name,
	 		        'bill_time'=>$time,
	 		        'sale_table_row'=>$sale_table_row,
	 		        'sale_table_name'=>$sale_table_name,
	 		         'sgst_per'=>$sgst_per,
	 		        'cgst_per'=>$cgst_per,
	 		        'parcel_amt'=>$parcel_amt,
	 		        'sgst_amt'=>$sgst_amt,
	 		        'cgst_amt'=>$cgst_amt,
	 		        'sales_total'=>$stotal,
	 		        'sales_grand_total'=>$gtotal,
	 		       
	 	              );
	 	
	 	$this->db->where('sal_id',$hid_id);
	 	$this->db->update('tbl_sales',$array);
      
$value_det1 = $this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$previous_gtot[0]['bill_date'])->get()->result_array();	 	
$cur_value1=$value_det1[0]['sales_value']+$gtotal;
$valladd1 = array('sales_value' => $cur_value1);
        	
        	$this->db->where('tbl_value.value_id',$value_det1[0]['value_id'])->update('tbl_value',$valladd1);

        
	 	for($i=0; $i<count($item_name); $i++)
	 	{
	 		$array=array(
	 			       
	 			        'sale_item_name'=> $item_name[$i],
	 			        'sale_price'=> $item_price[$i],
	 			        'sale_qty'=> $item_qty[$i],

	 			        'sale_item_total'=> $sale_total[$i],
	 		
	 			          );
	 		$this->db->where('tbl_sale_items.sale_item_id',$sal_ref_id[$i]);
	 		$this->db->update('tbl_sale_items',$array);

	 	}


	 	//return   $insert_id;
}
}