 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Vendor_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 function get_all_vendor(){
		$this->db->select('*');
		$this->db->from('tbl_vendor');
		$this->db->where('is_deleted',0);
		$query = $this->db->get();
		
		return $query->result_array();			
	 }
	  public function add_vendor()
	 {
	 	extract($_REQUEST);
	 	$inps=$this->input->post();
		$created_date=date('Y-m-d');
		if(empty($inps['hidden_id']))
		{
		$array=array(
		'vendor_name'=>$vendor_name,
		'vendor_mobile'=>$phone_no,
		'vendor_email'=>$email,
		'vendor_gst'=>$gst_no,
		'vendor_area'=>$location,
		'vendor_city'=>$city,
        'vendor_state'=>$state,
		'vendor_pincode'=>$pincode,
		'create_date'=>$created_date,
		'is_deleted'=>0);	
	   
	    $this->db->insert('tbl_vendor',$array);
	}
	else
	{
		$array=array(
		'vendor_name'=>$vendor_name,
		'vendor_mobile'=>$phone_no,
		'vendor_email'=>$email,
		'vendor_gst'=>$gst_no,
		'vendor_area'=>$location,
		'vendor_city'=>$city,
        'vendor_state'=>$state,
		'vendor_pincode'=>$pincode,
		);	
		//print_r($array);exit;
	   $this->db->where('vendor_id',$hidden_id);
	    $this->db->update('tbl_vendor',$array);
	}
	 }
	 public function vendor_edit($id)
	 {
	 	$this->db->select('*')->from('tbl_vendor');
	 	$this->db->where('vendor_id',$id);
	 	$query=$this->db->get();
	 	return $query->result_array();
	 }
	  public function vendor_delete($id){
	 	$array = array('is_deleted' => 1);
	 	$data = $this->db->where('tbl_vendor.vendor_id',$id)->update('tbl_vendor',$array);
	 	return $data;
	 }

}