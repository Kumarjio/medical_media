 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stock_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 function get_all_vendor(){
		$this->db->select('*');
		$this->db->from('tbl_vendor');
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();
		
		return $query;			
	 }
	 function get_all_product(){
		$this->db->select('*');
		$this->db->from('tbl_stock');
		$this->db->join('tbl_product','tbl_product.product_id=tbl_stock.pro_reff_id','left');
		$query = $this->db->get()->result_array();
		
		return $query;			
	 }
	 public function get_unitofproduct($id)
	 {
	 	$this->db->select('*');
		$this->db->from('tbl_stock');
		$this->db->where('pro_reff_id',$id);
		$this->db->join('tbl_product','tbl_product.product_id=tbl_stock.pro_reff_id','left');
		$query = $this->db->get()->result_array();
		
		return $query;			
	 }
	 public function add_stock(){
	 	extract($_REQUEST);
	 	$created_date = date('Y-m-d');
	 	$created_time = date('h:i:s a');
	 	for($i=0;$i<count($item_name1);$i++){
	 		$arrinv= array(
	 			'consumed_pro_ref_id'=>$item_name1[$i],
	 			'consumed_unit'=>$unit[$i],
	 			'previous_qty'=>$stock_qty[$i],
	 			'consumed_qty'=>$qty[$i],
	 			'consumed_date'=>$created_date,
	 			'consumed_time'=>$created_time,
	 			'is_deleted'=>0,
	 	);
	 		 $this->db->insert('tbl_consumed',$arrinv);
	 		 $stockcheck = $this->db->select('*')->from('tbl_stock')->where('tbl_stock.pro_reff_id',$item_name1[$i])->get()->result_array();
	 		 
	 		 	$proarray1 = array(
							'curr_qty'  =>$stockcheck[0]['curr_qty']-$qty[$i],
							 );
	 		 	$this->db->where('pro_reff_id',$item_name1[$i]);
				$this->db->update('tbl_stock',$proarray1);
				
	 		 
	 		 
	 	}
	 //	exit();
	 	return true;
	 }
	 function get_all_stock($inps){
	 	$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_stock');		
		$this->db->join('tbl_product','tbl_product.product_id=tbl_stock.pro_reff_id','left');
		
		if(isset($inps['product_id']) && !empty($inps['product_id']))
		{
			$this->db->where("tbl_product.product_id",$inps['product_id']);
		}		
		$query = $this->db->get()->result_array();
		return $query;
	 }
	  function get_all_consumed_stock($inps){
	 	$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_consumed');		
		$this->db->join('tbl_product','tbl_product.product_id=tbl_consumed.consumed_pro_ref_id','left');
		
		if(isset($inps['from_dt']) && !empty($inps['from_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_consumed.consumed_date,'%Y-%m-%d')>=",date('Y-m-d',strtotime($inps['from_dt'])));
		}
		if(isset($inps['to_dt']) && !empty($inps['to_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_consumed.consumed_date,'%Y-%m-%d')<=",date('Y-m-d',strtotime($inps['to_dt'])));
		}
		if(isset($inps['product_id']) && !empty($inps['product_id']))
		{
			$this->db->where("tbl_product.product_id",$inps['product_id']);
		}		
		$query = $this->db->get()->result_array();
		return $query;
	 }
    
	 

}