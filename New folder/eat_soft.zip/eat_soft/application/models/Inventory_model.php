 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Inventory_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 function get_all_item(){
		$this->db->select('*');
		$this->db->from('tbl_item');
		$this->db->where('is_deleted',0);
		$query = $this->db->get();
		
		return $query->result_array();			
	 }
	  public function add_item()
	 {
	 	extract($_REQUEST);
	 	$inps=$this->input->post();
		$created_date=date('Y-m-d');
		if(empty($inps['hidden_id']))
		{
		$array=array(
		'item_name'=>$item_name,
		'item_price'=>$item_price,
		'item_date'=>$created_date,
		'is_deleted'=>0);	
	   
	    $this->db->insert('tbl_item',$array);
	}
	else
	{
		$array=array(
		'item_name'=>$item_name,
		'item_price'=>$item_price,
		);	
		
	   $this->db->where('item_id',$hidden_id);
	    $this->db->update('tbl_item',$array);
	}
	 }
	 public function item_edit($id)
	 {
	 	$this->db->select('*')->from('tbl_item');
	 	$this->db->where('item_id',$id);
	 	$query=$this->db->get();
	 	return $query->result_array();
	 }
	 public function item_delete($id)
	 {
		$array=array(
		'is_deleted'=>1
		
		);	
		
	   $this->db->where('item_id',$id);
	    $this->db->update('tbl_item',$array);
	}
	 function get_all_product(){
		$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();		
		return $query;			
	 }
	 function get_all_table(){
		$this->db->select('*');
		$this->db->from('tbl_table');
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();		
		return $query;			
	 }
	 function get_all_row(){
		$this->db->select('*');
		$this->db->from('tbl_row');
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();		
		return $query;			
	 }
	 public function add_product()
	 {
	 	extract($_REQUEST);
	 	$created_date = date('Y-m-d');
	 	//print_r($product_id);exit;
	 	if($product_id==""){
	 	$insert_arr = array('product_name' => $product_name,
	 						'product_unit'=> $product_unit,
	 						'product_created'=>$created_date,
	 						'is_deleted'=>0
	 						 );
	 	$data = $this->db->insert('tbl_product',$insert_arr);
	 	$res = true;
	 	}else{
	 		$update_arr = array('product_name' => $product_name,
	 						'product_unit'=> $product_unit,
	 						 );
	 	$data = $this->db->where('tbl_product.product_id',$product_id)->update('tbl_product',$update_arr);
	 	$res = false;
	 	}
	 	return $res;
	 }
	 public function edit_product($id){
	 	$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('tbl_product.product_id',$id);
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();		
		return $query;
	 }
	 public function delete_product($id){
	 	$array = array('is_deleted'=>1);
	 	$data = $this->db->where('tbl_product.product_id',$id)->update('tbl_product',$array);
	 	return $data;

	 }
    public function add_row()
	 {
	 	extract($_REQUEST);
	 	$created_date = date('Y-m-d');
	 	//print_r($product_id);exit;
	 	if($row_id==""){
	 	$insert_arr = array('row_name' => $row_name,
	 						'row_created'=>$created_date,
	 						'is_deleted'=>0
	 						 );
	 	$data = $this->db->insert('tbl_row',$insert_arr);
	 	$res = true;
	 	}else{
	 		$update_arr = array('row_name' => $row_name,
	 						 );
	 	$data = $this->db->where('tbl_row.row_id',$row_id)->update('tbl_row',$update_arr);
	 	$res = false;
	 	}
	 	return $res;
	 }
	  public function add_table()
	 {
	 	extract($_REQUEST);
	 	$created_date = date('Y-m-d');
	 	//print_r($product_id);exit;
	 	if($table_id==""){
	 	$insert_arr = array('table_name' => $table_name,
	 						'table_created'=>$created_date,
	 						'is_deleted'=>0
	 						 );
	 	$data = $this->db->insert('tbl_table',$insert_arr);
	 	$res = true;
	 	}else{
	 		$update_arr = array('table_name' => $table_name,
	 						 );
	 	$data = $this->db->where('tbl_table.table_id',$table_id)->update('tbl_table',$update_arr);
	 	$res = false;
	 	}
	 	return $res;
	 }
	 public function edit_row($id){
	 	$this->db->select('*');
		$this->db->from('tbl_row');
		$this->db->where('tbl_row.row_id',$id);
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();		
		return $query;
	 }
	 public function edit_table($id){
	 	$this->db->select('*');
		$this->db->from('tbl_table');
		$this->db->where('tbl_table.table_id',$id);
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();		
		return $query;
	 }
	 public function delete_row($id){
	 	$array = array('is_deleted'=>1);
	 	$data = $this->db->where('tbl_row.row_id',$id)->update('tbl_row',$array);
	 	return $data;

	 }
	  public function delete_table($id){
	 	$array = array('is_deleted'=>1);
	 	$data = $this->db->where('tbl_table.table_id',$id)->update('tbl_table',$array);
	 	return $data;

	 }
	 

}