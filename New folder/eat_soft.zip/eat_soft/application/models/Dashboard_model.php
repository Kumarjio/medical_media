<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
          parent::__construct();
     }
    
	 
	 function get_profile($userid){	
		$array = array('cp_admin_login.admin_id' =>$userid);		
		$this->db->select('*')->from('cp_admin_login')
        ->where($array); 
		$query = $this->db->get();		
		return $query->result();			
	 }
	 // function get_lot_no(){	
		// $this->db->select('lot');
		// $this->db->distinct();
		// $this->db->from('tbl_po_inv');
		// return $this->db->get()->result();		
	 // }
	 function get_product($lot_id){	
		$this->db->select('storage_name');
		$this->db->distinct();
		$this->db->where('lot',$lot_id);
		$this->db->from('tbl_po_inv');
		$storage_id = $this->db->get()->result_array();
		$this->db->select('branch_id');
		$this->db->from('tbl_branch');		
		return $this->db->get()->result_array();			
	 }
	 function get_branch_name(){
	 	$this->db->select('*');		
		$this->db->from('tbl_branch');
		return $this->db->get()->result();	
	 }
	 function get_product_name(){
	 	$this->db->select('*');
		$this->db->distinct('style');
		$this->db->from('tbl_product');
		return $this->db->get()->result();	
	 }
	 
	 function edit_profile($id,$post) {
		$session_data = $this->session->all_userdata();
	    $password=$post['password'];
		$emp_code=$post['emp_code'];
		$name=$post['name'];
		//$mobile_number=$post['mobile_number'];
		$created_date=date('Y-m-d h:i:s');
		$array=array('password'=>$password,'name'=>$name,'emp_code'=>$emp_code,'status'=>1);	
	    $this->db->set($array);
	    $this->db->where('admin_id',$id);
		$this->db->update('cp_admin_login',$array);
		
	}
	  function get_pro_det() {
		$session_data = $this->session->all_userdata();
	    $this->db->select('tbl_leads.*,product_selling_price.price,inr_rates');
		 if(isset($inps['pono']) && $inps['pono']!='')
		    {
			    $this->db->where('tbl_leads.po_no', $inps['pono']);	
		    }
			 if(isset($inps['date']) && $inps['date']!='')
		    {
			    $this->db->where('tbl_leads.po_date', $inps['date']);	
		    }
		 $this->db->join('product_selling_price','product_selling_price.part_no = tbl_leads.part_no','left');
		$query = $this->db->get('tbl_leads')->result_array();
		 return $query;	
		
	}
	 
function get_pro_request(){
		$session_data = $this->session->all_userdata();	
	   $this->db->select('purchase_product.*,purchase_product.qty as qtys,tbl_product.i_id,tbl_product.i_name,i_category, i_code');
		$this->db->select('cp_admin_login.*');
		$this->db->where('purchase_product.location', $session_data['location']);
		
		$this->db->join('tbl_product','tbl_product.i_id = purchase_product.tbl_product_id','left');
		$this->db->join('cp_admin_login','cp_admin_login.admin_id = purchase_product.req_emp_id','left');
		$query = $this->db->get('purchase_product');	
		//echo '<pre>';print_r($query);exit;
		return $query->result();			
	 }
	 function get_search_details($get_search_details){
	 	$this->db->select('*')->from('tbl_product_img')->where('tbl_product_img.produt_img_id',$get_search_details);
	 	$this->db->join('tbl_product','tbl_product.style=tbl_product_img.style_name','left');
	 	$this->db->join('tbl_stock','tbl_stock.pro_imag_ref_id=tbl_product_img.produt_img_id','left');
	 	$this->db->join('tbl_sizefix','tbl_sizefix.size_id=tbl_stock.size_reff_id','left');
	 	$image = $this->db->get()->result_array();
	 	
	 	$this->db->select('*')->from('tbl_po_inv_item')->where('tbl_po_inv_item.product_img_ref_id',$get_search_details);
	 	$grn = $this->db->get()->result_array();

	 	return array('image'=>$image,'grn'=>$grn);
	 }
	 public function get_style($id)
	 {
	 	$data = $this->db->select('*')->from('tbl_product')->where('pro_name',$id)->get()->result_array();
	 	return $data;
	 }
	 public function get_color($id)
	 {
	 	$data = $this->db->select('*')->from('tbl_product_img')->where('style_name',$id)->join('tbl_color','tbl_color.color_id=tbl_product_img.color_ref_id','left')->get()->result_array();
	 	return $data;
	 }
	 
}