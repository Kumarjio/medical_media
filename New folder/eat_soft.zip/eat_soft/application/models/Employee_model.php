 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Employee_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 function get_all_employee(){
		$this->db->select('*');
		$this->db->from('cp_admin_login');
		$this->db->where('is_delete',0);
		$query = $this->db->get();
		
		return $query->result_array();			
	 }
	  public function add_employee()
	 {
	 	extract($_REQUEST);
	 	$inps=$this->input->post();
		$created_date=date('Y-m-d');
		if(empty($inps['hidden_id']))
		{
		$array=array(
		'username'=>$username,
		'password'=>$password,
		'name'=>$name,
		'emp_code'=>$ecode,
		'phone'=>$mobile,
		'user_type'=>$emp_type,
        'area_name'=>$area_name,
		'created_date'=>$created_date,
		'email_id'=>$email,
		'is_delete'=>0);	
	   
	    $this->db->insert('cp_admin_login',$array);
	}
	else
	{
		$array=array(
		'username'=>$username,
		'password'=>$password,
		'name'=>$name,
		'emp_code'=>$ecode,
		'phone'=>$mobile,
		'user_type'=>$emp_type,
        'area_name'=>$area_name,
		'email_id'=>$email
		);	
		//print_r($array);exit;
	   $this->db->where('admin_id',$hidden_id);
	    $this->db->update('cp_admin_login',$array);
	}
	 }
	 public function employee_edit($id)
	 {
	 	$this->db->select('*')->from('cp_admin_login');
	 	$this->db->where('admin_id',$id);
	 	$query=$this->db->get();
	 	return $query->result_array();
	 }
	 public function emp_delete($id){
	 	$array = array('is_delete' => 1);
	 	$data = $this->db->where('cp_admin_login.admin_id',$id)->update('cp_admin_login',$array);
	 	return $data;
	 }

}