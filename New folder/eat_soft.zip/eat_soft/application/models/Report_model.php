 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 function get_all_purchsae($inps){
	 	$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_purchase_inv');		
		$this->db->join('tbl_vendor','tbl_vendor.vendor_id=tbl_purchase_inv.purchase_vendor_ref_id','left');
		$this->db->join('tbl_purchase_inv_item','tbl_purchase_inv_item.purchase_inv_ref_id=tbl_purchase_inv.purchase_inv_id','left');
		$this->db->join('tbl_product','tbl_product.product_id=tbl_purchase_inv_item.purchase_product_id','left');
		$this->db->where('tbl_purchase_inv.is_deleted',0);
		
		if(isset($inps['from_dt']) && !empty($inps['from_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_purchase_inv.purchase_invoice_date,'%Y-%m-%d')>=",date('Y-m-d',strtotime($inps['from_dt'])));
		}
		if(isset($inps['to_dt']) && !empty($inps['to_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_purchase_inv.purchase_invoice_date,'%Y-%m-%d')<=",date('Y-m-d',strtotime($inps['to_dt'])));
		}
		if(isset($inps['vendor_id']) && !empty($inps['vendor_id']))
		{
			$this->db->where("tbl_vendor.vendor_id",$inps['vendor_id']);
		}
		if(isset($inps['product_id']) && !empty($inps['product_id']))
		{
			$this->db->where("tbl_product.product_id",$inps['product_id']);
		}		
		$query = $this->db->get()->result_array();
		return $query;
	 }
	 function get_all_sales($inps){
	 	$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_sales');		
		$this->db->join('cp_admin_login','cp_admin_login.admin_id=tbl_sales.server_name','left');
		$this->db->join('tbl_sale_items','tbl_sale_items.sale_item_id=tbl_sales.sal_id','left');
		$this->db->join('tbl_item','tbl_item.item_id=tbl_sale_items.sale_item_name','left');
		$this->db->join('tbl_table','tbl_table.table_id=tbl_sales.sale_table_name','left');
		$this->db->join('tbl_row','tbl_row.row_id=tbl_sales.sale_table_row','left');
		$this->db->where('tbl_sales.is_deleted',0);
		if(isset($inps['from_dt']) && !empty($inps['from_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_sales.bill_date,'%Y-%m-%d')>=",date('Y-m-d',strtotime($inps['from_dt'])));
		}
		if(isset($inps['to_dt']) && !empty($inps['to_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_sales.bill_date,'%Y-%m-%d')<=",date('Y-m-d',strtotime($inps['to_dt'])));
		}
		if(isset($inps['server_id']) && !empty($inps['server_id']))
		{
			$this->db->where("cp_admin_login.admin_id",$inps['server_id']);
		}
		if(isset($inps['item_id']) && !empty($inps['item_id']))
		{
			$this->db->where("tbl_item.item_id",$inps['item_id']);
		}
		if(isset($inps['row_id']) && !empty($inps['row_id']))
		{
			$this->db->where("tbl_row.row_id",$inps['row_id']);
		}
		if(isset($inps['table_id']) && !empty($inps['table_id']))
		{
			$this->db->where("tbl_table.table_id",$inps['table_id']);
		}		
		$query = $this->db->get()->result_array();
		return $query;
	 }
	 function get_all_values($inps){
	 	$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_value');	
		
		if(isset($inps['from_dt']) && !empty($inps['from_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_value.value_date,'%Y-%m-%d')>=",date('Y-m-d',strtotime($inps['from_dt'])));
		}
		if(isset($inps['to_dt']) && !empty($inps['to_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_value.value_date,'%Y-%m-%d')<=",date('Y-m-d',strtotime($inps['to_dt'])));
		}
		
		$query = $this->db->get()->result_array();
		return $query;
	 }
    
	 

}