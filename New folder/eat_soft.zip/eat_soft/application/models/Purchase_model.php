 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Purchase_model extends CI_Model {
     function __construct(){
          // Call the Model constructor
		  parent::__construct();
		  
     }
	 function get_all_vendor(){
		$this->db->select('*');
		$this->db->from('tbl_vendor');
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();
		
		return $query;			
	 }
	 function get_all_product(){
		$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();
		
		return $query;			
	 }
	 public function get_unitofproduct($id)
	 {
	 	$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('product_id',$id);
		$this->db->where('is_deleted',0);
		$query = $this->db->get()->result_array();
		
		return $query;			
	 }
	 public function add_purchase(){
	 	extract($_REQUEST);
	 	$created_date = date('Y-m-d');
	 	$arrinv= array(
	 			'purchase_vendor_ref_id'=>$purchase_vendor,
	 			'purchase_invoice_no'=>$invoice_no,
	 			'purchase_invoice_date'=>$invoice_date,
	 			'purchase_stotal'=>$stotal,
	 			'purchase_gtotal'=>$gtotal,
	 			'is_deleted'=>0,
	 			'purchase_status'=>0,
	 			'pending_payment'=>$gtotal,
	 			'paid_payment'=>0,
	 			'purchase_entry_date'=>$created_date,
	 	);
	 	$this->db->insert('tbl_purchase_inv',$arrinv);
        $insert_id = $this->db->insert_id();
        //$insert_id =1;
        $value_det = $this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$created_date)->get()->result_array();
        if(empty($value_det)){
        	$valladd = array('purchase_value' => $gtotal,'sales_value' => 0,'value_date' => $created_date);
        	$this->db->insert('tbl_value',$valladd);
        }else{
        	$valladd = array('purchase_value' => $gtotal+$value_det[0]['purchase_value']);
        	$this->db->where('tbl_value.value_id',$value_det[0]['value_id'])->update('tbl_value',$valladd);
        }

	 	for($i=0;$i<count($item_name1);$i++){
	 		$arrayinvitem = array(
	 				'purchase_inv_ref_id'=>$insert_id,
	 				'purchase_product_id'=>$item_name1[$i],
	 				'purchase_unit'=>$unit[$i],
	 				'purchase_qty'=>$qty[$i],
	 				'purchase_rate'=>$purrate[$i],
	 				'purchase_amount'=>$amount[$i],
	 				'purchase_sgst'=>$sgst[$i],
	 				'purchase_cgst'=>$cgst[$i],
	 				'purchase_igst'=>$igst[$i],
	 				'purchase_sgst_amt'=>$sgst_amt[$i],
	 				'purchase_cgst_amt'=>$cgst_amt[$i],
	 				'purchase_igst_amt'=>$igst_amt[$i],
	 				'purchase_total'=>$total[$i],
	 		);
	 		//print_r($arrayinvitem);
	 		 $this->db->insert('tbl_purchase_inv_item',$arrayinvitem);
	 		 $stockcheck = $this->db->select('*')->from('tbl_stock')->where('tbl_stock.pro_reff_id',$item_name1[$i])->get()->result_array();
	 		 if(empty($stockcheck)){
	 		 	$proarray1 = array(
							'pro_reff_id'  =>$item_name1[$i],
							'curr_qty'  =>$qty[$i],
							 );
	 		 	$this->db->insert('tbl_stock',$proarray1);
	 		 }else{
	 		 	$proarray1 = array(
							'curr_qty'  =>$stockcheck[0]['curr_qty']+$qty[$i],
							 );
	 		 	$this->db->where('pro_reff_id',$item_name1[$i]);
				$this->db->update('tbl_stock',$proarray1);
				
	 		 }
	 		 
	 	}
	 //	exit();
	 	return true;
	 }
	 function get_all_purchsae($inps){
	 	$session_data = $this->session->all_userdata();	
		$this->db->select('*')->from('tbl_purchase_inv');		
		$this->db->join('tbl_vendor','tbl_vendor.vendor_id=tbl_purchase_inv.purchase_vendor_ref_id','left');
		
		if(isset($inps['from_dt']) && !empty($inps['from_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_purchase_inv.purchase_invoice_date,'%Y-%m-%d')>=",date('Y-m-d',strtotime($inps['from_dt'])));
		}
		if(isset($inps['to_dt']) && !empty($inps['to_dt']))
		{
			$this->db->where("DATE_FORMAT(tbl_purchase_inv.purchase_invoice_date,'%Y-%m-%d')<=",date('Y-m-d',strtotime($inps['to_dt'])));
		}
		if(isset($inps['vendor_id']) && !empty($inps['vendor_id']))
		{
			$this->db->where("tbl_vendor.vendor_id",$inps['vendor_id']);
		}	
		$this->db->where('tbl_purchase_inv.is_deleted',0);	
		$query = $this->db->get()->result_array();
		return $query;
	 }
	 public function edit_purchase($id)
	 {
      $this->db->select('tbl_purchase_inv.*')->from('tbl_purchase_inv');
      $this->db->select('tbl_purchase_inv_item.*')->from('tbl_purchase_inv_item');
      $this->db->where('tbl_purchase_inv.purchase_inv_id',$id);
      $this->db->where('tbl_purchase_inv_item.purchase_inv_ref_id',$id);
      $query=$this->db->get();
      return $query->result_array();



	 } 
	  public function purchase_edit_update(){
	 	extract($_REQUEST);
	 	$created_date = date('Y-m-d');

$pur_chase=$this->db->select('*')->from('tbl_purchase_inv')->where('purchase_inv_id',$pur_id)->get()->result_array();
//echo "<pre>";print_r($pur_chase[0]['purchase_gtotal']);exit;
$value=$this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$pur_chase[0]['purchase_invoice_date'])->get()->result_array();
//echo "<pre>";print_r($value[0]['purchase_value']);exit;
$current_val=$value[0]['purchase_value']-$pur_chase[0]['purchase_gtotal'];
$array1=array('purchase_value'=>$current_val);
$this->db->where('tbl_value.value_id',$value[0]['value_id']);
$this->db->update('tbl_value',$array1);
	 	$arrinv= array(
	 			'purchase_vendor_ref_id'=>$purchase_vendor,
	 			'purchase_invoice_no'=>$invoice_no,
	 			'purchase_invoice_date'=>$invoice_date,
	 			'purchase_stotal'=>$stotal,
	 			'purchase_gtotal'=>$gtotal,
	 			'pending_payment'=>$gtotal,
	 		
	 	);
	 	$this->db->where('tbl_purchase_inv.purchase_inv_id',$pur_id);
	 	$this->db->update('tbl_purchase_inv',$arrinv);
       
$pur_chase1=$this->db->select('*')->from('tbl_purchase_inv')->where('purchase_inv_id',$pur_id)->get()->result_array();
//echo "<pre>";print_r($pur_chase[0]['purchase_gtotal']);exit;
$value1=$this->db->select('*')->from('tbl_value')->where('tbl_value.value_date',$pur_chase1[0]['purchase_invoice_date'])->get()->result_array();
//echo "<pre>";print_r($value[0]['purchase_value']);exit;
$current_val1=$value1[0]['purchase_value']+$gtotal;
$array2=array('purchase_value'=>$current_val1);
$this->db->where('tbl_value.value_id',$value[0]['value_id']);
$this->db->update('tbl_value',$array2);


	 	for($i=0;$i<count($item_name1);$i++){
//print_r($item_name1);
	 		$arrayinvitem = array(
	 				
	 			
	 			    'purchase_product_id'=>$item_name1[$i],
	 				'purchase_unit'=>$unit[$i],
	 				'purchase_qty'=>$qty[$i],
	 				'purchase_rate'=>$purrate[$i],
	 				'purchase_amount'=>$amount[$i],
	 				'purchase_sgst'=>$sgst[$i],
	 				'purchase_cgst'=>$cgst[$i],
	 				'purchase_igst'=>$igst[$i],
	 				'purchase_sgst_amt'=>$sgst_amt[$i],
	 				'purchase_cgst_amt'=>$cgst_amt[$i],
	 				'purchase_igst_amt'=>$igst_amt[$i],
	 				'purchase_total'=>$total[$i],
	 		);
	 	//echo "<pre>";print_r($arrayinvitem);exit;
	 		$this->db->where('tbl_purchase_inv_item.purchase_inv_item_id',$pur_ref_id[$i]);
	 		 $this->db->update('tbl_purchase_inv_item',$arrayinvitem);


	 		 $stockcheck = $this->db->select('*')->from('tbl_stock')->where('tbl_stock.pro_reff_id',$item_name1[$i])->get()->result_array();
	 		 //echo "<pre>";print_r($stockcheck);
	 		 $stockpurchase = $this->db->select('*')->from('tbl_purchase_inv_item')->where('tbl_purchase_inv_item.purchase_inv_item_id',$pur_ref_id[$i])->get()->result_array();
	 		//echo "<pre>"; print_r($stockcheck[0]['curr_qty']);
             $current=$stockcheck[0]['curr_qty']-$stockpurchase[0]['purchase_qty'];
     
	 		 	$proarray1 = array(
							
							'curr_qty'  =>$current,
							 );
	 		 	
	 		 	$this->db->where('pro_reff_id',$item_name1[$i]);
	 		 	$this->db->update('tbl_stock',$proarray1);
	 		
	 		 
	 	}
	// exit;
	 	return true;
	 }   
	 

}