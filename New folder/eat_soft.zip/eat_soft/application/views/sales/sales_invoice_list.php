

<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
/*table, th, td {
    border: 1px solid black;
}*/
.table > thead > tr > th,
.table > tbody > tr > th,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > tbody > tr > td,
.table > tfoot > tr > td  
/*  border-color: #E5E5E5;
*/ 
 border-width: 1px;
  border: 1px solid;
 @media screen { p.bodyText {font-family:verdana, arial, sans-serif;} #print_panel{ margin: 100mm 100mm 100mm 100mm; } }

</style>
<?php $this->load->view('include_css');
?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
    
<!-- PAGE TITLE -->
                
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                              <div class="panel-body">
                                <center>  <button type="button" class="btn btn-primary" onClick="print_fun('print_panel');">Print</button> <a href="<?php echo base_url();?>Sales/sale_list"><button type="button" class="btn btn-primary">Back</button></a></center>
                                    <div class="" id="print_panel">
                                      <table>
                                      <thead>
                                        <tr>
                                          <th></th>
                                          <th style="text-align: center;font-size: 15px;">Hotel Hari</th>
                                          <th></th>
                                        </tr>
                                        <tr>
                                          <th></th>
                                          <th  style="text-align: center">15/8,Purankusapuram Street,Kodambakkam</th>
                                          <th></th>
                                        </tr>
                                         <tr>
                                          <th></th>
                                          <th  style="text-align: center">CHENNAI - 6000024</th>
                                          <th></th>
                                        </tr>
                                         <tr>
                                          <th></th>
                                          <th  >GSTIN - 33ANVPM6523G1ZQ</th>
                                          <th></th>
                                        </tr>
                                        <tr>
                                          <th >Bill.No: <?php //echo $invoice[0]['bill_no'] ?></th>
                                          <th  >Date: <?php echo date('d-m-Y') ?></th>
                                          <th  >Time: <?php echo date("h:i:s A"); ?></th>
                                        </tr>
                                        <tr>
                                          <th  >Emp.Id - <?php //echo //$sale[0]['emp_id'] ?></th>
                                          <th >Name - <?php //echo $sale[0]['cus_name'] ?></th>                                          
                                          <th></th>
                                        </tr>
                                        <tr style="border-top: 2px dotted black; ">
                                          <th><span>Sl No</span></th>
                                           <th><span>Item Name</span></th>
                                          <th style="text-align: center;"><span>Rate</span></th>
                                          <th style="padding-left: 10px;">Qty</th>
                                           <th style="padding-left: 10px;">Total</th>
                                        </tr>
                                      
                                      </thead>
                                       <tbody style="margin-bottom: 20px;">
                                      
<?php
$i=1;
$qty=0;
$tot=0;
 foreach($invoice as $sale){
$qty +=$sale['sale_qty'];
$tot +=$sale['sale_item_total'];

  ?>
                                         <tr>
                                           <td><?php echo $i++; ?>
                                          <td><?php echo $sale['item_name'] ?></td>
                                <td style="text-align: center;"><?php echo $sale['sale_price'] ?></td>

                                          <td style="text-align: center;"><?php echo $sale['sale_qty'] ?></td>
                                           <td ><?php echo $sale['sale_item_total'] ?></td>
                                        </tr>
                                         <?php }?>

                                       </tbody>
                                       <tfoot>
                                           <tr style="border-top: 2px dotted black; ">
                                           <th></th>
                                           <th></th>
                                           <th >Total Qty:</th>
                                           
                                           <th><?php echo $qty;?></th>
                                         </tr>
                                            <tr >
                                           <th></th>
                                           <th></th>
                                           <th >Total amt:</th>
                                           <th></th>
                                           <th><?php echo $tot; ?></th>
                                         </tr>
                                         
                                         <tr>
                                           <th></th>
                                           <th></th>
                                           <th>GST TAX:</th>
                                           <th><?php //echo $sale[0]['comm_cgst']+$sale[0]['comm_sgst'] ?></th>
                                         </tr>
                                         <tr>
                                           <th></th>
                                           <th></th>
                                           <th style="font-size: 15px;">GRAND TOTAL:</th>
                                           <th></th>
                                           <th style="border-top: 2px dotted black; font-size: 15px;"><?php echo $invoice[0]['sales_grand_total'] ?></th>
                                         </tr>
                                       
                                       </tfoot>
                                     
                                      </table>
                                 
                            </div>
                          
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


      <!-- Matter -->

      
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
     

</body>
</html>
<script type="text/javascript">

function print_fun(ids){
  var defaultpage = document.body.innerHTML;
var printpage = document.getElementById(ids).innerHTML;
//var n = printpage.length;
  //alert(n);return false;
  
  document.body.innerHTML = printpage;
    window.print() ;
  document.body.innerHTML = defaultpage;
}

//print_fun('print_panel');
</script>