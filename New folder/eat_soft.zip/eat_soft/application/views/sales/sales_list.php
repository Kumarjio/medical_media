<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
          width: 900px; /* New width for default modal */
        }
        .modal-sm {
          width: 350px; /* New width for small modal */
        }
    }
    @media screen and (min-width: 992px) {
        .modal-lg {
          width: 950px; /* New width for large modal */
        }
    }
</style>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2> Total Sales List</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                               
  <a href="<?php echo base_url();?>Sales"  class="btn btn-primary"><span class="fa fa-plus"></span>Add Sales</a>
                                                                                      
                                    
                                                                   
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Bill No</th>
                                                    <th>Bill Date</th>
                                                    <th>Server Name</th> 
                                                    <th>Sale Tbl</th>
                                                    <th>Sale Row</th>
                                                  <!--   <th>Sale Item</th>
                                                    <th>Sale Amt</th>
                                                    <th>Sale Qty</th> -->
                                                    <th>SGST</th>
                                                    <th>CGST</th>
                                                    <th>Total</th>
                                                    <!-- <th>Sale Date</th> -->
                                                    <th>Action</th>

                                                  
                                                  
                                                </tr>
                      </thead>
                                            <tbody>
                                           <?php if(is_array($list) && count($list) ) {
                                        $cnt=1;
                                            foreach($list as $loop){
                                                    ?>
                      <tr>
                        <td><?php echo $cnt; $cnt++; ?></td>
                        <td><?php echo $loop['sale_bill_no'];?></td>
                        <td><?php echo $loop['bill_date'];?></td>
                         <td><?php echo $loop['name'];?></td>
                        <td><?php echo $loop['table_name'];?></td>
                        <td><?php echo $loop['row_name'];?></td>
                      <!--   <td><?php echo $loop['item_name'];?></td>
                        <td><?php echo $loop['sale_price'];?></td>
                        <td><?php echo $loop['sale_qty'];?></td> -->
                        <td><?php echo $loop['sgst_amt'];?></td>
                        <td><?php echo $loop['cgst_amt'];?></td>
                        <td><?php echo $loop['sales_grand_total'];?></td>
                       <!--  <td><?php echo $loop['sales_date'];?></td> -->
                      
                      
                                                
                        
                        
                                               
                                                    <td>
    <a href="<?php echo base_url();?>Sales/edit_sales/<?php echo $loop['sal_id'];?>" class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Remove"><i class="fa fa-pencil"></i></a>
   <a onclick="sales_deleted(<?php echo $loop['sal_id'];?>)" class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Remove"><i class="fa fa-trash-o"></i></a>
   <a href="<?php echo base_url();?>Sales/sales_invoice_list/<?php echo $loop['sal_id'];?>"  class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Print"><i class="fa fa-print"></i> </a>  
                
                                                    </td>
                                                  
                                                    
                                                
                      </tr>
                      <?php }} ?>
                    </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
     
     <?php $this->load->view('include_js'); ?>
 
</body>
</html>
<script type="text/javascript">
 function sales_deleted (id)
 {
//alert(id);
$.ajax({
  url:'<?php echo base_url();?>Sales/sales_delete/'+id,
  type:'POST',
  dataType:'JSON',
  success:function(result)
  {
alert('Deleted succesfully');
location.reload();
  }
});
 }  
</script>