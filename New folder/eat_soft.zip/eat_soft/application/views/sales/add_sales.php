<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
          width: 900px; /* New width for default modal */
        }
        .modal-sm {
          width: 350px; /* New width for small modal */
        }
    }
    @media screen and (min-width: 992px) {
        .modal-lg {
          width: 950px; /* New width for large modal */
        }
    }
</style>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2> Manage Sales</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                  <form class="form-horizontal"  id="sale_form" role="form" method="post">
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                       <div class="col-md-12">
                         <div class="panel panel-default">
                                <div class="panel-heading">
                                      
                                </div>
                                <div class="panel-body">
                       
                          
                             <div class="col-md-6">
                               
                                               <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Bill No<sup  style="color:#f00"> * </sup></label>
                         <?php $year = $this->db->select('*')->from('tbl_year')->where('tbl_year.year_id',1)->get()->result_array();
                                              
                                              $id = $this->db->select('*')->from('tbl_sales')->where("DATE_FORMAT(tbl_sales.bill_date,'%Y-%m-%d')>=",date('Y-m-d',strtotime($year[0]['from_year'])))->where("DATE_FORMAT(tbl_sales.bill_date,'%Y-%m-%d')<=",date('Y-m-d',strtotime($year[0]['to_year'])))->get()->num_rows();
                                              //print_r($id);
                                               ?>
                                                <div class="col-md-8">
                                                    <input type="text" required class="form-control "  name="sales_bill_no"  placeholder="Enter Item Name" readonly id="bill_no" value="<?php echo 'SB';echo $id+1;echo ' - '.$year[0]['year_value'] ?>">
                                                                                                   
                                                </div>
                                            </div>
                                               <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Bill Date<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <input type="text" required class="form-control datepicker" readonly  name="sale_bill_date"  placeholder="Enter Item Name" value="<?php echo date('Y-m-d');?>">
                                                                                                   
                                                </div>
                                            </div>
                                             <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Server Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                  <select name="server_name" class="form-control selectpicker">
                                                    <option value="">Select</option>
                                                    <?php $emp=$this->db->select('*')->from('cp_admin_login')->where('is_delete',0)->where('user_type',2)->get()->result_array(); 
                                                    foreach($emp as $list)
                                                    {

                                                    ?>
                                                    <option value="<?php echo $list['admin_id'];?>"><?php echo $list['name'];?></option>
                                                    <?php }?>

                                                  </select>
                                                                                                   
                                                </div>
                                            </div>
                                          
                                          </div>


                                            <div class="col-md-6">
                                                <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Select Row<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                             <select required name="sale_table_row" class="form-control selectpicker">
                                                      <option value="">Select</option>
                                                       <?php $tbl_row=$this->db->select('*')->from('tbl_row')->where('is_deleted',0)->get()->result_array();
                                                  foreach($tbl_row as $row)
                                                  {?>
                                                      <option value="<?php echo $row['row_id'];?>"><?php echo $row['row_name'];?></option>
                                                      <?php } ?>
                                                    </select>
                                                                                                   
                                                </div>
                                            </div>
                                                 <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Select Table<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <select required name="sale_table_name" class="form-control selectpicker">
                                                      <option value="">Select</option>
                                                      <?php $table=$this->db->select('*')->from('tbl_table')->where('is_deleted',0)->get()->result_array();
                                                  foreach($table as $row)
                                                  {?>
                                                      <option value="<?php echo $row['table_id'];?>"><?php echo $row['table_name'];?></option>
                                                      <?php }?>

                                                    </select>
                                                                                                   
                                                </div>
                                            </div>
                                            
                                            </div>
                            

                      </div>
                    </form>
                  </div>
                </div>
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                      
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table" id="mytable">
                                            <thead >
                                                <tr>
                                                    <th>Item Name</th>
                                                    <th>Price</th> 
                                                    <th>Qty</th>
                                                    <th>Total</th>
                                                  
                                                  
                                                </tr>
											</thead>



                    <tbody id="testid">
                                        
                      <tr>
                      <td>
      <select class="selectpicker form-control item itemq2" onchange="get_item(1)"     name="item_name[]" id="item_name1"   data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"><option disabled selected value="">Select Product</option><?php foreach($item as $row){ ?><option value="<?php echo $row['item_id']; ?>"><?php echo $row['item_name']; ?></option><?php } ?></select>
                      </td> 
                        <td>
         <input type="text" required class="form-control " onchange="totalamount(1)"   name="item_price[]" value="0"  readonly id="item_price1">
                      </td> 
                        <td>
         <input type="text" required class="form-control " onchange="totalamount(1)"  name="item_qty[]" required id="item_qty1">
                      </td> 
                        <td>
         <input type="text" required class="form-control "  name="sale_total[]"  value="0" readonly id="sale_total1">
                      </td>                          
											</tr>
										</tbody>
                   </table>
                   <div class="col-md-12">
                    <div class="col-md-8">

                    </div>
                    <div class="col-md-2">
                      <label><strong>Total</strong></label>
                    </div>
                     <div class="col-md-2">
                        <input type="text" class="form-control" name="stotal" style="color:#000" readonly id="stotal">
                     
                    </div>
                    <br>
                     <br>

                    <div class="col-md-7">

                    </div>
                    <div class="col-md-1">
                      <label><strong>SGST (%)</strong></label>
                    </div>
                     <div class="col-md-2">
                      <input type="text" class="form-control" name="sgst_per" style="color:#000" onchange="gtotal1()" value="0" id="sgst">
                    </div>
                    
                     <div class="col-md-2">
                      <input type="text" class="form-control" name="sgst_amt" style="color:#000" readonly id="sgst_amt">
                    </div>
                    <br>
                    <br>
                     <div class="col-md-7">

                    </div>
                    <div class="col-md-1">
                      <label><strong>CGST (%)</strong></label>
                    </div>
                     <div class="col-md-2">
                    <input type="text" class="form-control" onchange="gtotal1()"  name="cgst_per" style="color:#000" value="0" id="cgst">
                    </div>
                    
                     <div class="col-md-2">
                     <input type="text" class="form-control" readonly name="cgst_amt" style="color:#000" id="cgst_amt">
                    </div>
                    <br>
                    <br>
                    
                    <div class="col-md-8">

                    </div>
                    <div class="col-md-2">
                      <label><strong>Packing Charge</strong></label>
                    </div>
                     <div class="col-md-2">
                   <input type="text" class="form-control" onchange="gtotal1()" name="parcel_amt" value="0" style="color:#000" required id="parcel_amt">
                    </div>
                    <br>
                    <br>
                       <div class="col-md-8">

                    </div>
                    <div class="col-md-2">
                      <label><strong>Grand Total</strong></label>
                    </div>
                     <div class="col-md-2">
                     <input type="text" class="form-control" readonly name="gtotal" style="color:#000" id="gtotal">
                    </div>



                    
                                    </div>
                                </div>
                                <input type="hidden" name="testno" id="testno" value="2">
                                 <div class="panel-footer">                            
                                    <button class="btn btn-primary pull-left" type="button" style="margin-bottom:20px;" onclick="fnadd()">Add More</button>
                                    <button class="btn btn-warning pull-left" type="button" style="margin-bottom:20px;margin-left:10px;" onclick="fnremove()">Remove</button>  
                                  <button class="btn btn-primary pull-right submit" id="submit" type="submit" style="margin-bottom:20px;">Submit</button>
                  
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>   
            </form>         
            <!-- END PAGE CONTENT -->
        </div>
     
     <?php $this->load->view('include_js'); ?>

<!--  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Item</h4>
        </div>
        <div class="modal-body">
               <form class="form-horizontal"  id="item_form" role="form" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">
                                          
                                          
                       <input type="hidden" name="hidden_id" id="hid_id">                   
                                            
                                             <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Item Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <input type="text" required class="form-control "  name="item_name"  placeholder="Enter Item Name" id="item_name" value="<?php echo set_value('name');  ?>">
                                                                                                   
                                                </div>
                                            </div>
                                                                                        
                    
                                        
                                           
                                            </div>
                                             <div class="col-md-6">
                                               <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Item Price</label>
                                                <div class="col-md-8">
                                                <input type="text" required class="form-control "  name="item_price"  placeholder="Enter Item Price" id="item_price" value="0">
                                              
                                               </div>
                                            </div>
                                              
                               
                                            
                                            
                                            <div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                  
                                                <input class="btn btn-primary" value="Submit" type="submit"  >
                                                <!-- <input class="btn btn-danger pull-right" value="Back" onClick="window.history.go(-1)" type="button"> 
                                              </div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>
                                      </div>
                                        
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div> -->
</body>
</html>
<script type="text/javascript">

  $('body').on('change','.itemq2',function (){
  var pro_id = $(this).val();
//alert(pro_id);
  var values = $("select[name='item_name[]']")
              .map(function(){
                return $(this).val();
              }).get();
            //alert(values.length);
            
    for(var i=1;i<values.length;i++){
      var p_c = $('#item_name'+i).val();
      if(p_c == pro_id){
        alert('Product already added. Please Check !!!!!!!');

      }
    }

});

  function fnadd() {
    //alert('fdsafasd');
    var a=$("#testno").val();
    num=parseInt(a) + 1;
    $("#testno").val(num);
    
    $("#testid").append('<tr><td  class="forcedWidth"><select class="selectpicker form-control item itemq2" onchange="get_item('+a+')"     name="item_name[]" id="item_name'+a+'"   data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"><option disabled selected value="">Select Product</option><?php foreach($item as $row){ ?><option value="<?php echo $row['item_id']; ?>"><?php echo $row['item_name']; ?></option><?php } ?></select> </td>'

        +'<td>  <input type="text"  class="form-control "  name="item_price[]" readonly onchange="totalamount('+a+')" id="item_price'+a+'"></td>'
        +'<td><input  type="text"  class="form-control  groupOfTexbox" name="item_qty[]" onchange="totalamount('+a+')"  id="item_qty'+a+'"   /> </td>'
        
        +'<td><input  type="text"  step="any" class="form-control " name="sale_total[]"  readonly id="sale_total'+a+'"  /></td></tr>');
        
      
      $(".selectpicker").selectpicker('refresh');
      /*$(".groupOfTexbox").keypress(function (event) {
                return isNumber(event, this)
            });*/

     
  }
  
  
  function fnremove() {
    var a=$("#testno").val();
    if(a>=3){
      num=parseInt(a) - 1;
      $("#testno").val(num);
      $('#mytable tr:eq('+num+')').remove();
    }
  } 

  // get item price in item table //
   
   function get_item(item)
   {
    // alert(item);
    
    var item_id= $('#item_name'+item).val();
   //alert(item_id);
    $.ajax({
      url:'<?php echo base_url();?>Sales/get_item_price/'+item_id,
      type:'POST',
      dataType:'JSON',
      success:function(result)
      {
        //alert(result[0]['item_price']);
        console.log(result);

        $('#item_price'+item+'').val(result[0]['item_price']);

      }

    });
   }

// get item price in item table //

// Total amount sale //
  function totalamount(item)
        {
             var rate=parseFloat($('#item_price'+item).val());
             //alert(rate);
             var qty=parseFloat($('#item_qty'+item).val());  
             //alert(rate);            
              var total=parseFloat(rate)*parseFloat(qty);
             if(isNaN(total)){ } else {
                   $('#sale_total'+item).val(total);
                    gtotal1();
                }

        }  
        function gtotal1()
        {
           var a=$("#testno").val();
        a=a-1;
       // alert(a);
        var i;
        var gt=0;
         var gt1=0;
         
        for( i=1;i<=a;i++){
             var rate=parseFloat($('#item_price'+i).val());
             
            

             var qty=parseFloat($('#item_qty'+i).val());
            
              var total=parseFloat(rate)*parseFloat(qty);
             var gt= parseFloat(gt)+parseFloat(total);

              // alert(gt);
           

}
   var stotal = gt;
  //alert(stotal);
   var parcel=parseFloat($('#parcel_amt').val());
   var sgst=parseFloat($('#sgst').val());
  
   var cgst=parseFloat($('#cgst').val());
   var sgstamt=parseFloat((gt *parseFloat(sgst))/100);
    var cgstamt=parseFloat((gt *parseFloat(cgst))/100);
   
              
        
        if(stotal == '')
            {
                stotal = '00.00';
            }
        
        if(stotal!=''){
            $("#stotal").val(stotal);
            
                //$("#taxamount").val(taxamt);
                gtotal = parseFloat(stotal+sgstamt+cgstamt+parcel);
              //  alert(gtotal);
                
                    $("#gtotal").val(parseFloat(gtotal).toFixed(2));
                    $("#sgst_amt").val(parseFloat(sgstamt).toFixed(2));
                    $("#cgst_amt").val(parseFloat(cgstamt).toFixed(2));
                  
            }
            




        else{
            $("#stotal").val('00.00');
            $("#sgst_amt").val('00.00');
            $("#cgst_amt").val('00.00');
            $("#gtotal").val('00.00');
        }
        }  

// Total sale calculation//
    $('form').submit(function(e){
 e.preventDefault();
  var saleFrom = $('#sale_form').serialize();
  //alert(saleFrom);

    $.ajax({

          url:'<?php echo base_url();?>Sales/add_sales',
            type:'POST',
            data:saleFrom,
            dataType:'JSON',       
            success:function(result)
            {

               document.getElementById("sale_form").reset(); 
               window.location.href="<?php echo base_url();?>Sales/getInvoice/"+result;

               // getlist(result);
            }
          

        });
    });
    
  function item_delete($id)
  {
    alert($id);
    $.ajax({
      url:'<?php echo base_url();?>Inventory_master/delete_item/'+$id,
            type:'POST',
            dataType:'JSON',       
            success:function(result)
            {
                console.log(result);
                alert('Successfully removed this item');
                location.reload();
              }
            });
  }

    function item_edit($id)
    {
            
 $.ajax({

          url:'<?php echo base_url();?>Inventory_master/edit_item/'+$id,
            type:'POST',
            dataType:'JSON',       
            success:function(result)
            {
                console.log(result);
       
                
            $('#hid_id').val(result[0]['item_id']);
            $('#item_name').val(result[0]['item_name']);
            $('#item_price').val(result[0]['item_price']);   
           
           


            }
          

        });   
         }
</script>