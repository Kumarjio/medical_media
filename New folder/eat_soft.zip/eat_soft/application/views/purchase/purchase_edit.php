<!DOCTYPE html>
<html lang="en">
<head>
<style>



.forcedWidth{
    width:200px;
    word-wrap:break-word;
    display:inline-block;
}

</style>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    <link type="text/css" href="<?php echo base_url('assets/css/jquery-ui.css'); ?>" rel="stylesheet" />

     <!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2>Purchase Entry</h2>
                </div>
                <!-- END PAGE TITLE --> 
                               
                
                <!-- PAGE CONTENT WRAPPER -->
      <form class="form-horizontal"  id="jvalidate" role="form" action="<?php echo base_url('Purchase/editPurchaseEntry');?>" method="post" >

                <div class="row">
                        <div class="col-md-12">
                           <div class="panel panel-default">
                                <div class="panel-body">
                                  
                               
<div class="panel-body">                                                                        
            <?php foreach($puredit as $edit)?>                        
<div class="row">
  <input type="hidden" name="pur_id" value="<?php echo $edit['purchase_inv_id']; ?>">
<div class="col-md-6">
    <div class="form-group">
        <label class="col-md-4 control-label"> Vendor Name<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
            <select class="selectpicker form-control getdata "    name="purchase_vendor" id="purchase_vendor" required data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
          <option value="" disabled selected> SELECT </option>
          <?php foreach($vendor as $row){ ?>  
          <option value="<?php echo $row['vendor_id']; ?>"<?php  if($row['vendor_id']==$edit['purchase_vendor_ref_id']) {echo 'selected';}?>><?php echo $row['vendor_name']; ?></option>
                            <?php } ?>
                            </select>                                       
        </div>
    </div>
     <div class="form-group">                                        
        <label class="col-md-4 control-label">Invoice Date<sup  style="color:#f00"> * </sup></label>
        <div class="col-md-8">
            <input type="text" class="form-control datepicker "  required placeholder="Enter Date of Purchase" value="<?php echo $edit['purchase_invoice_date']; ?>" name="invoice_date" id="invoice_date" >                                               
        </div>
    </div>
</div>
<div class="col-md-6">
  
    
  
    <div class="form-group">
        <label class="col-md-4 control-label">Invoice NO<sup  style="color:#f00"> * </sup></label>  
        <div class="col-md-8">
            <input type="text" class="form-control " placeholder="Enter Invoice no" name="invoice_no" id="invoice_no" value="<?php echo $edit['purchase_invoice_no']; ?>" required /> 
        </div>
    </div>
   
    </div>
</div>
</div>

    </div>
                                
                           
                            
                            
                            
                      </div>
                            </div>
                       
             <div class="col-md-12">
              
                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                          
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table" id="mytable">
                                            <thead>
                                                <tr>
                                                    <th width="7%">Product Name<sup style="color:#f00"> * </sup></th>
                                                    <th width="7%">Unit Type<sup style="color:#f00"> * </sup></th>
                                                    <th width="10%">Qty<sup  style="color:#f00"> * </sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                    <th width="7%">Pur.Rate<sup  style="color:#f00"> * </sup></th>
                                                   <!--  <th width="7%">Amount<sup  style="color:#f00"> * </sup></th> -->
                                                   <!--  <th width="8%">SGST%<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">CGST%<sup  style="color:#f00"> * </sup></th>
                                                    <th width="8%">IGST%<sup  style="color:#f00"> * </sup></th>  -->
                                                    
                                                    <th width="10%">Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                </tr>
                      </thead>
                       <?php $sno=0;?>
        <tbody id="testid">
     <?php foreach($puredit as $edit) { $sno++?>  
     <input type="hidden" name="pur_ref_id[]" value="<?php echo $edit['purchase_inv_item_id'];?>">
            <tr>
             <td class="">
                <select  class="selectpicker form-control itemsq2" onchange="get_unit(<?php echo $sno;?>)" name="item_name1[]" id="item_name1_<?php echo $sno;?>"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"> <option value="" disabled selected>Select</option>       <?php foreach($product as $row){?><option value="<?php echo $row['product_id']; ?>" <?php if($row['product_id']==$edit['purchase_product_id']){echo 'selected';}?>><?php echo $row['product_name']; ?></option><?php }?></select>
         
                </td>
            <td><input  readonly type="text" required class="form-control  " name="unit[]" id="unit<?php echo $sno;?>" value="<?php echo $edit['purchase_unit'];?>" onchange="totalamt(<?php echo $sno;?>); "   required/> </td>
                <td>
                  <input min="0"  type="text" required class="form-control  groupOfTexbox" name="qty[]" value="<?php echo $edit['purchase_qty'];?>" id="qty<?php echo $sno;?>" onchange="totalamt(<?php echo $sno;?>); "   required/> </td>
                <td>
                  <input min="0"  type="text" step="any" class="form-control  groupOfTexbox" name="purrate[]" id="purrate<?php echo $sno;?>" value="<?php echo $edit['purchase_rate']?>" onchange="totalamt(<?php echo $sno;?>); "  required/></td>
                  <td>
                    <input   type="text" step="any" class="form-control " name="total[]"  value="<?php echo $edit['purchase_total'];?>" id="total<?php echo $sno;?>"  required readonly/>
                    <input min="0"  type="hidden" step="any" class="form-control  groupOfTexbox" value="<?php echo $edit['purchase_amount'];?>" name="amount[]" id="amount<?php echo $sno;?>" onchange="totalamt(<?php echo $sno;?>); " readonly  required/>
                    <input  type="hidden"  class="form-control  groupOfTexbox" name="sgst[]" value="<?php echo $edit['purchase_sgst'];?>" id="sgst<?php echo $sno;?>"  onchange="totalamt(<?php echo $sno;?>); "/>
                    <input  type="hidden"  class="form-control  groupOfTexbox" value="<?php echo $edit['purchase_sgst_amt'];?>" name="sgst_amt[]" id="sgst_amt<?php echo $sno;?>"    />
                    <input   type="hidden"  class="form-control  groupOfTexbox" name="cgst[]" value="<?php echo $edit['purchase_cgst'];?>" id="cgst<?php echo $sno;?>" onchange="totalamt(<?php echo $sno;?>); " value="0"   required/>
                    <input   type="hidden" value="<?php echo $edit['purchase_cgst_amt'];?>"  class="form-control  groupOfTexbox" value="0" name="cgst_amt[]" id="cgst_amt<?php echo $sno;?>"    /> 
                    <input   type="hidden" value="<?php echo $edit['purchase_igst'];?>"  class="form-control  groupOfTexbox" name="igst[]" id="igst<?php echo $sno;?>" onchange="totalamt(<?php echo $sno;?>); "    />
                    <input  value="<?php echo $edit['purchase_igst_amt'];?>" type="hidden"  class="form-control  groupOfTexbox" value="0" name="igst_amt[]"  id="igst_amt<?php echo $sno;?>"/>  </td>
            </tr>
<?php }?>
        </tbody>
                                        </table><br>
<br>
<br>

                                        <table class="table" width="100%">
    <thead>
         
       
        <!-- <tr>
            <td colspan="9" width="75%"><button type="button" style="visibility:hidden;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="opener" ></button></td>
            <td style="font-weight:bold;" width="12%">Total</td>
            <td style="font-weight:bold;" ></td>
        </tr> -->

        <!-- <tr>
            <td colspan="9" width="75%"><button type="button" style="visibility:hidden;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="opener" ></button></td>
            <td style="font-weight:bold;" width="12%">Packing Charge</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control" onchange="gtotal1()"  name="packing" value="0.00" style="color:#000" id="packing"></td>
        </tr> -->
       
        <tr>
          <input type="hidden" class="form-control" name="stotal" style="color:#000" readonly value="<?php echo $edit['purchase_stotal'];?>" id="stotal">
            <td colspan="9" width="75%"><button type="button" style="visibility:hidden;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="opener" ></button></td>
            <td style="font-weight:bold;" width="12%">Grand Total</td>
            <td style="font-weight:bold;" ><input type="text" class="form-control" readonly name="gtotal" value="<?php echo $edit['purchase_gtotal'];?>" style="color:#000" id="gtotal"></td>
        </tr>
        
                                </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

              <input type="hidden" name="testno" id="testno" value="<?php echo $sno;?>"  />
              <input type="hidden" name="extratax" id="extratax" value="" />
                   <div class="panel-footer">                            
                                   <!--  <button class="btn btn-primary pull-left" type="button" style="margin-bottom:20px;" onclick="fnadd()">Add More</button>
                                    <button class="btn btn-warning pull-left" type="button" style="margin-bottom:20px;margin-left:10px;" onclick="fnremove()">Remove</button>       
                                    <input class="btn btn-danger pull-right" value="Back" onClick="window.history.go(-1)" type="button"> -->                              
                                    <button class="btn btn-primary pull-right" type="submit"  style="margin-bottom:20px;" >Submit</button>
                  
                                </div>
                                
                                
                          
              
                        </div>
                  

             </div>
          
          </form>
          </div>
                


                        
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
    

          
          
          
          <!-- Button trigger modal -->


<!-- Modal -->



        <!-- END PAGE CONTAINER -->
          <?php $this->load->view('include_js'); ?>
     
<script type="text/javascript">
  

function get_unit(id){
//  alert(id);
  var product_id = $('#item_name1_'+id).val();
  //alert(product_id);
  $.ajax({
    url:"<?php echo base_url(); ?>Purchase/get_unitofproduct/"+product_id,
    type:"POST",
    dataType:"JSON",
    success:function(res){
      console.log(res);
      $('#unit'+id).val(res[0].product_unit);
    }
  });
}

    
  
  //Short menu navigation code//
  function fnadd() 
    {
      var supplier_id=$('#vname').val();
      //alert(supplier_id);
      //if(supplier_id != '') {         
        var num=$("#testno").val();
        a=parseInt(num) + 1;
        $("#testno").val(a);
        //alert('kaja');
        
        var inn=$("#payment_method_1").html();
        var inn=$("#item_name_1").html();
        $("#testid").append('<tr class="clearfield">'
                    +'<td class=""><select  class="selectpicker form-control itemsq2 "  name="item_name1[]" onchange="get_unit('+a+')" id="item_name1_'+a+'"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"><option value="" disabled selected>Select</option><?php foreach($product as $row){?><option value="<?php echo $row['product_id']; ?>"><?php echo $row['product_name']; ?></option><?php } ?></select></td>'
                 +'<td><input min="1" readonly  type="text" class="form-control " name="unit[]" id="unit'+a+'"  onblur="totalamt('+a+'); " required /></td>'
                 +'<td><input min="1"  type="text" class="form-control  groupOfTexbox" name="qty[]" id="qty'+a+'"  onblur="totalamt('+a+'); " required /></td>'
                 +'<td><input min="0"  type="text" step="any" class="form-control  groupOfTexbox" name="purrate[]" id="purrate'+a+'" onblur="totalamt('+a+'); "  required/></td>'
                 
        +'<td><input min="0"  type="text" step="any" class="form-control " name="total[]" id="total'+a+'" required readonly/><input min="0"  type="hidden" step="any" class="form-control  groupOfTexbox" readonly name="amount[]" id="amount'+a+'" onblur="totalamt('+a+'); "  required/><input   type="hidden" class="form-control  groupOfTexbox" name="sgst[]" id="sgst'+a+'" value="0"  onblur="totalamt('+a+'); "  /><input   type="hidden" class="form-control  groupOfTexbox" name="sgst_amt[]" id="sgst_amt'+a+'"   value="0" /><input   type="hidden" class="form-control  groupOfTexbox" name="cgst[]" id="cgst'+a+'" value="0"   onblur="totalamt('+a+'); "  /><input   type="hidden" class="form-control  groupOfTexbox" name="cgst_amt[]" id="cgst_amt'+a+'" value="0"    /><input min="1"  type="hidden" class="form-control  groupOfTexbox" name="igst[]" id="igst'+a+'" value="0"   onblur="totalamt('+a+'); "  /><br><input   type="hidden" class="form-control  groupOfTexbox" name="igst_amt[]" id="igst_amt'+a+'" /></td></tr>');
        
        $(".selectpicker").selectpicker('refresh');
        $(".groupOfTexbox").keypress(function (event) {
             return isNumber(event, this)
        }); 
        
      /*}
      else {
        alert("Select Supplier");
      }*/
    }
    function fnremove() 
    {
      var num=$("#testno").val();
        //num=parseInt(a) - 1;
        $("#testno").val(num);
        $('#mytable tr:eq('+num+')').remove();
                num2 = num-1;
                $('#testno').val(num2);
                gtotal1();
      
    } 

     
    
    function totalamt(item){
        var purrate=parseFloat($('#purrate'+item).val());
        var qty=parseFloat($('#qty'+item).val());
      var sgst=parseFloat($('#sgst'+item).val());
    var cgst=parseFloat($('#cgst'+item).val());
    var igst=parseFloat($('#igst'+item).val());
        if(!isNaN(purrate) && !isNaN(qty) && qty!=0){
        //  var tax=(parseFloat(purrate)/100)*parseFloat(purtax);
        //  var total=(parseFloat(purrate)+parseFloat(tax))*parseFloat(qty);          
                var total=(parseFloat(purrate))*parseFloat(qty);
        var sgstamt  = parseFloat(( total * parseFloat(sgst))/100);
        var cgstamt  = parseFloat(( total * parseFloat(cgst))/100);
        var igstamt  = parseFloat(( total * parseFloat(igst))/100);
        $("#amount"+item).val(total);
        $("#sgst_amt"+item).val(sgstamt);
        $("#cgst_amt"+item).val(cgstamt);
        $("#igst_amt"+item).val(igstamt);
        
        gtotal = parseFloat(total+sgstamt+cgstamt+igstamt);
        if(isNaN(total)){ } else {
                    $("#total"+item).val(gtotal);
                  gtotal1();  
                }
                
        }

        else{
                $("#total"+item).val("");
        }


    }

    function gtotal1(){
        var a=$("#testno").val();
        a=a;
       // alert(a);
        var gt=0;
     var gt1=0;
        for(i=1;i<=a;i++){
      var purrate=parseFloat($('#purrate'+i).val());
          var qty=parseFloat($('#qty'+i).val());
          var sgst=parseFloat($('#sgst'+i).val());
        var cgst=parseFloat($('#cgst'+i).val());
        var igst=parseFloat($('#igst'+i).val());
      
        var total=(parseFloat(purrate))*parseFloat(qty);
       // alert(total);
      var sgstamt  = parseFloat(( total * parseFloat(sgst))/100);
      var cgstamt  = parseFloat(( total * parseFloat(cgst))/100);
      var igstamt  = parseFloat(( total * parseFloat(igst))/100);
      //var taxamt  = parseFloat(( total * parseFloat(vat))/100);
               // var total=$('#total'+i).val();
         var gt=parseFloat(gt)+parseFloat(total);
      
        var gt1=parseFloat(gt1)+parseFloat(sgstamt)+parseFloat(cgstamt)+parseFloat(igstamt);
          //  alert(gt1);      
        }
    
    var stotal = gt;
 //alert(stotal);
    var gtot = gt1;
       //alert(stotal);
    if(stotal == '')
      {
        stotal = '00.00';
         //alert(stotal);
      }
        
        if(stotal!=''){
            $("#stotal").val(stotal);
            
        //$("#taxamount").val(taxamt);
        gtotal = parseFloat(stotal+gtot);
        
        
          $("#gtotal").val(parseFloat(gtotal).toFixed(2));
          
      }
            




        else{
            $("#stotal").val('00.00');
            $("#taxamount").val('00.00');
            $("#gtotal").val('00.00');
        }
    }
                
    
</script>
<script type="text/javascript">

$(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
 

</script>
   
</body>
</html>
   


