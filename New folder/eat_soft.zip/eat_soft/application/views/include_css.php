<META HTTP-EQUIV="Content-Type" CONTENT="text/html"; charset="utf-8" />
  <META HTTP-EQUIV="Content-Type" CONTENT="text/html"; charset="utf-8" />

  <!-- Title and other stuffs -->
  <title><?php echo $title;  ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
 <link rel="stylesheet" type="text/css" id="theme" href="<?php echo base_url('assets/css/theme-default.css'); ?>"/>
 <!--<link href="<?php //echo base_url('assets/css/multiple-select.css'); ?>" rel="stylesheet">-->
  <link href="<?php echo base_url('assets/css/bootstrap-select.css'); ?>" rel="stylesheet">
<style>.chkscroll { border:2px solid #ccc; width:265px; height: 110px; overflow-y: scroll; padding-left:10px; }</style>
 
  </head>
<body class="page-container-boxed">