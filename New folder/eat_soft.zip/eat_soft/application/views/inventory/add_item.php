<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
          width: 900px; /* New width for default modal */
        }
        .modal-sm {
          width: 350px; /* New width for small modal */
        }
    }
    @media screen and (min-width: 992px) {
        .modal-lg {
          width: 950px; /* New width for large modal */
        }
    }
</style>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2> Manage Item</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                               
  <button data-toggle="modal" data-target="#myModal" class="btn btn-primary" data-backdrop="static" data-keyboard="false"><span class="fa fa-plus"></span>Add Item</button>
                                                                                      
                                    
                                                                   
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Item name</th>
                                                    <th>Price</th> 
                                                    <th>Action</th>
                                                  
                                                  
                                                </tr>
											</thead>
                                            <tbody>
                                        	 <?php if(is_array($item) && count($item) ) {
                                        $cnt=1;
                                            foreach($item as $loop){
                                                    ?>
											<tr>
												<td><?php echo $cnt; $cnt++; ?></td>
                        <td><?php echo $loop['item_name'];?></td>
					              <td><?php echo $loop['item_price'];?></td>
                      
                      
                                                
												
												
                                               
                                                    <td>
    <button data-toggle="modal" data-target="#myModal" onclick="item_edit(<?php echo $loop['item_id'];?>)" class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><i class="fa fa-pencil"></i> </button>
   <button id="item_delete" onclick="item_delete(<?php echo $loop['item_id'];?>)" class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Remove"><i class="fa fa-trash-o"></i> </button> 
                
                                                    </td>
                                                  
                                                    
                                                
											</tr>
											<?php }} ?>
										</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
     
     <?php $this->load->view('include_js'); ?>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Item</h4>
        </div>
        <div class="modal-body">
               <form class="form-horizontal"  id="item_form" role="form" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">
                                          
                                          
                       <input type="hidden" name="hidden_id" id="hid_id">                   
                                            
                                             <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Item Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <input type="text" required class="form-control "  name="item_name"  placeholder="Enter Item Name" id="item_name" value="<?php echo set_value('name');  ?>">
                                                                                                   
                                                </div>
                                            </div>
                                                                                        
                    
                                        
                                           
                                            </div>
                                             <div class="col-md-6">
                                               <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Item Price</label>
                                                <div class="col-md-8">
                                                <input type="text" required class="form-control "  name="item_price"  placeholder="Enter Item Price" id="item_price" value="0">
                                              
                                               </div>
                                            </div>
                                              
                               
                                            
                                            
                                            <div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                  
                                                <input class="btn btn-primary" value="Submit" type="submit"  >
                                                <!-- <input class="btn btn-danger pull-right" value="Back" onClick="window.history.go(-1)" type="button"> -->
                                              </div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>
                                      </div>
                                        
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
</body>
</html>
<script type="text/javascript">
    $('form').submit(function(e){
 e.preventDefault();
  var itemFrom = $('#item_form').serialize();
  //alert(empFrom);
    $.ajax({

          url:'<?php echo base_url();?>Inventory_master/add_item',
            type:'POST',
            data:itemFrom,
            dataType:'JSON',       
            success:function(result)
            {


                document.getElementById("item_form").reset(); 
                alert('success');
                location.reload();

               // getlist(result);
            }
          

        });
    });
    
  function item_delete($id)
  {
    alert($id);
    $.ajax({
      url:'<?php echo base_url();?>Inventory_master/delete_item/'+$id,
            type:'POST',
            dataType:'JSON',       
            success:function(result)
            {
                console.log(result);
                alert('Successfully removed this item');
                location.reload();
              }
            });
  }
/*function getlist(result)
{


$.each(result, function(key, value) {
      var tr = $("<tr />")
     $.each(value, function(k, v) {
       tr.append(
         $("<td />", {
           html: v
          })[0].outerHTML
       );
      $("table tbody").append(tr)
     })
   });
}*/
    function item_edit($id)
    {
            
 $.ajax({

          url:'<?php echo base_url();?>Inventory_master/edit_item/'+$id,
            type:'POST',
            dataType:'JSON',       
            success:function(result)
            {
                console.log(result);
       
                
            $('#hid_id').val(result[0]['item_id']);
            $('#item_name').val(result[0]['item_name']);
            $('#item_price').val(result[0]['item_price']);   
           
           


            }
          

        });   
         }
</script>