<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('include_css'); ?>
</head>
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
            width: 900px;
            /* New width for default modal */
        }
        .modal-sm {
            width: 350px;
            /* New width for small modal */
        }
    }

    @media screen and (min-width: 992px) {
        .modal-lg {
            width: 950px;
            /* New width for large modal */
        }
    }
</style>

<body>
    <?php $this->load->view('menu_navigation'); ?>


    <!-- PAGE TITLE -->
    <div class="page-title">
        <h2> Manage Employee</h2>
    </div>
    <!-- END PAGE TITLE -->

    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">


        <!-- START RESPONSIVE TABLES -->
        <div class="row">


            <div class="col-md-12">

                <!-- START DEFAULT DATATABLE -->
                <div class="panel panel-default">
                    <div class="panel-heading">

                       
                       <button class="btn btn-primary" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false"><span class="fa fa-plus"></span>Add Product</button>



                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Product Name</th>
                                        <th>Unit</th>

                                        <th>Action</th>

                                    </tr>
                                </thead>
                                <tbody id="app_rows">
                                    <?php if(is_array($product) && count($product) ) {
                                        $cnt=1;
                                            foreach($product as $loop){
                                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $cnt; $cnt++; ?>
                                        </td>

                                        <td>
                                            <?php echo strtoupper($loop['product_name']) ; ?>
                                        </td>
                                        <td>
                                            <?php echo strtoupper($loop['product_unit']) ; ?>
                                        </td>
                                        <td>
                                            
                                            <button type="button" class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" onclick="edit_pro(<?php echo $loop['product_id'] ?>)"><i class="fa fa-pencil"></i> </button><button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View" onclick="delete_pro(<?php echo $loop['product_id'] ?>)"><i class="fa fa-trash-o"></i> </button>
                                        </td>



                                    </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- END DEFAULT DATATABLE -->

            </div>
        </div>
        <!-- END RESPONSIVE TABLES -->

        <!-- END PAGE CONTENT WRAPPER -->
    </div>
    </div>
    <!-- END PAGE CONTENT -->
    </div>

    <?php $this->load->view('include_js'); ?>
    <div class="modal fade " id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="model_close()">&times;</button>
                    <h4 class="modal-title add_pro_de ">Add Product</h4>
                    <h4 class="modal-title upp_pro_de hide">Edit Product</h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" id="Pro_form" role="form" method="post">

                        <div class="panel-body">

                            <div class="row">

                                <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Product Name<sup  style="color:#f00"> * </sup></label>
                                            <div class="col-md-6">
                                                <input type="hidden" name="product_id" id="product_id">
                                                <input type="text" required class="form-control " name="product_name" placeholder="Enter Product Name" id="product_name" value="<?php echo set_value('name');  ?>">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Unit<sup  style="color:#f00"> * </sup></label>
                                            <div class="col-md-5">
                                                <input type="text" required class="form-control " name="product_unit" placeholder="Enter Unit Name" id="product_unit">
                                                
                                            </div>
                                        </div>
                                        <div >
                                            <button class="btn btn-primary btn-sm col-md-offset-5">Submit</button>
                                        </div>
                                    </div>
                            </div>


                        </div>


                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" onclick="model_close()">Close</button>
                </div>
            </div>

        </div>
    </div>
</body>

</html>
<script type="text/javascript">
    function edit_pro(id){
        $('.upp_pro_de').addClass('show');
        $('.add_pro_de').addClass('hide');
     $.ajax({
            url: '<?php echo base_url();?>Inventory_master/edit_product/'+id,
            type: 'POST',
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                $('#product_id').val(res[0].product_id);
                $('#product_name').val(res[0].product_name);
                $('#product_unit').val(res[0].product_unit);
                $('#myModal').modal({
                    backdrop: 'static',
                    keyboard: false
                });

            }
        });   
    }
    function model_close(){
        document.getElementById('Pro_form').reset();
        $('#myModal').modal('hide');
        $('.upp_pro_de').addClass('hide');
    }
    function delete_pro(id){
        $.ajax({
            url: '<?php echo base_url();?>Inventory_master/delete_product/'+id,
            type: 'POST',
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                alert('Deleted Successfully');
                location.reload();

            }
        });
    }
    $("form").submit(function(e){
        e.preventDefault();
        var empFrom = $('#Pro_form').serialize();
        //alert(empFrom);
        $.ajax({
            url: '<?php echo base_url();?>Inventory_master/add_product',
            type: 'POST',
            data: empFrom,
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                //alert(res);
                if(res== true){
                   alert('Inserted Successfully'); 
               }else{
                alert('Updated Successfully'); 
               }
                
                location.reload();

            }
        });
         
    });
</script>