<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('include_css'); ?>
</head>
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
            width: 900px;
            /* New width for default modal */
        }
        .modal-sm {
            width: 350px;
            /* New width for small modal */
        }
    }

    @media screen and (min-width: 992px) {
        .modal-lg {
            width: 950px;
            /* New width for large modal */
        }
    }
</style>

<body>
    <?php $this->load->view('menu_navigation'); ?>


    <!-- PAGE TITLE -->
    <div class="page-title">
        <h2> Row and Table Manage</h2>
    </div>
    <!-- END PAGE TITLE -->

    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">


        <!-- START RESPONSIVE TABLES -->
        <div class="row">


            <div class="col-md-6">

                <!-- START DEFAULT DATATABLE -->
                <div class="panel panel-default">
                    <div class="panel-heading">

                       
                       <button class="btn btn-primary" data-toggle="modal" data-target="#myModal1" data-backdrop="static" data-keyboard="false"><span class="fa fa-plus"></span>Add Row</button>



                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Row Name</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>
                                <tbody id="app_rows">
                                    <?php if(is_array($row) && count($row) ) {
                                        $cnt=1;
                                            foreach($row as $loop){
                                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $cnt; $cnt++; ?>
                                        </td>

                                        <td>
                                            <?php echo strtoupper($loop['row_name']) ; ?>
                                        </td>
                                        <td>
                                            
                                            <button type="button" class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" onclick="edit_row(<?php echo $loop['row_id'] ?>)"><i class="fa fa-pencil"></i> </button><button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View" onclick="delete_row(<?php echo $loop['row_id'] ?>)"><i class="fa fa-trash-o"></i> </button>
                                        </td>



                                    </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- END DEFAULT DATATABLE -->

            </div>
              <div class="col-md-6">

                <!-- START DEFAULT DATATABLE -->
                <div class="panel panel-default">
                    <div class="panel-heading">

                       
                       <button class="btn btn-primary" data-toggle="modal" data-target="#myModal2" data-backdrop="static" data-keyboard="false"><span class="fa fa-plus"></span>Add Table</button>



                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Table Name</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>
                                <tbody id="app_rows">
                                    <?php if(is_array($table) && count($table) ) {
                                        $cnt=1;
                                            foreach($table as $loop){
                                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $cnt; $cnt++; ?>
                                        </td>

                                        <td>
                                            <?php echo strtoupper($loop['table_name']) ; ?>
                                        </td>
                                        <td>
                                            
                                            <button type="button" class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" onclick="edit_table(<?php echo $loop['table_id'] ?>)"><i class="fa fa-pencil"></i> </button><button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View" onclick="delete_table(<?php echo $loop['table_id'] ?>)"><i class="fa fa-trash-o"></i> </button>
                                        </td>



                                    </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- END DEFAULT DATATABLE -->

            </div>
        </div>
        <!-- END RESPONSIVE TABLES -->

        <!-- END PAGE CONTENT WRAPPER -->
    </div>
    </div>
    <!-- END PAGE CONTENT -->
    </div>

    <?php $this->load->view('include_js'); ?>
    <div class="modal fade " id="myModal1" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="model_close()">&times;</button>
                    <h4 class="modal-title add_pro_de ">Row Manage</h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" name="row_form" id="row_form" role="form" method="post">

                        <div class="panel-body">

                            <div class="row">

                                <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Row Name<sup  style="color:#f00"> * </sup></label>
                                            <div class="col-md-6">
                                                <input type="hidden" name="row_id" id="row_id">
                                                <input type="text" required class="form-control " name="row_name" placeholder="Enter Row Name" id="row_name" value="<?php echo set_value('name');  ?>">
                                            </div>
                                        </div>
                                        <div >
                                            <button class="btn btn-primary btn-sm col-md-offset-5">Submit</button>
                                        </div>
                                    </div>
                            </div>


                        </div>


                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" onclick="model_close()">Close</button>
                </div>
            </div>

        </div>
    </div>
    <!--table model statrs  -->
    <div class="modal fade " id="myModal2" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="model_close()">&times;</button>
                    <h4 class="modal-title add_pro_de ">Table Manage</h4>
                </div>
                <div class="modal-body">
                    <form class="form-horizontal" name="table_form" id="table_form" role="form" method="post">

                        <div class="panel-body">

                            <div class="row">

                                <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Table Name<sup  style="color:#f00"> * </sup></label>
                                            <div class="col-md-6">
                                                <input type="hidden" name="table_id" id="table_id">
                                                <input type="text" required class="form-control " name="table_name" placeholder="Enter Table Name" id="table_name" value="<?php echo set_value('name');  ?>">
                                            </div>
                                        </div>
                                        <div >
                                            <button class="btn btn-primary btn-sm col-md-offset-5">Submit</button>
                                        </div>
                                    </div>
                            </div>


                        </div>


                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" onclick="model_close()">Close</button>
                </div>
            </div>

        </div>
    </div>
    <!-- tabale mode ends -->
        
</body>

</html>
<script type="text/javascript">
    //close model function
    function model_close(){
        document.getElementById('table_form').reset();
        document.getElementById('row_form').reset();
        $('#myModal1').modal('hide');
        $('#myModal2').modal('hide');
    }
    //edit row
    function edit_row(id){
     $.ajax({
            url: '<?php echo base_url();?>Inventory_master/edit_row/'+id,
            type: 'POST',
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                $('#row_id').val(res[0].row_id);
                $('#row_name').val(res[0].row_name);
                $('#myModal1').modal({
                    backdrop: 'static',
                    keyboard: false
                });

            }
        });   
    }
    //edit table
    function edit_table(id){
     $.ajax({
            url: '<?php echo base_url();?>Inventory_master/edit_table/'+id,
            type: 'POST',
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                $('#table_id').val(res[0].table_id);
                $('#table_name').val(res[0].table_name);
                $('#myModal2').modal({
                    backdrop: 'static',
                    keyboard: false
                });

            }
        });   
    }
    //delete row
    function delete_row(id){
        $.ajax({
            url: '<?php echo base_url();?>Inventory_master/delete_row/'+id,
            type: 'POST',
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                alert('Deleted Successfully');
                location.reload();

            }
        });
    }
    //delete table 
    function delete_table(id){
        $.ajax({
            url: '<?php echo base_url();?>Inventory_master/delete_table/'+id,
            type: 'POST',
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                alert('Deleted Successfully');
                location.reload();

            }
        });
    }
    // Row table add
    $("form[name='row_form']").submit(function(e){
        e.preventDefault();
        var empFrom = $('#row_form').serialize();
        //alert(empFrom);
        $.ajax({
            url: '<?php echo base_url();?>Inventory_master/add_row',
            type: 'POST',
            data: empFrom,
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                //alert(res);
                if(res== true){
                   alert('Inserted Successfully'); 
               }else{
                alert('Updated Successfully'); 
               }
                
                location.reload();

            }
        });
         
    });
    // Table table add
    $("form[name='table_form']").submit(function(e){
        e.preventDefault();
        var empFrom = $('#table_form').serialize();
        //alert(empFrom);
        $.ajax({
            url: '<?php echo base_url();?>Inventory_master/add_table',
            type: 'POST',
            data: empFrom,
            dataType: 'JSON',
            success: function(res) {
                console.log(res);
                //alert(res);
                if(res== true){
                   alert('Inserted Successfully'); 
               }else{
                alert('Updated Successfully'); 
               }
                
                location.reload();

            }
        });
         
    });
</script>