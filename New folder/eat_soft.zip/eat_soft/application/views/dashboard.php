<?php $session_data = $this->session->all_userdata();
//print_r($session_data);exit;
?>
<!DOCTYPE html>
<html lang="en">

<head>        
        <!-- META SECTION -->
        <title>Hotel Hari</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
       <!-- <link rel="icon" href="favicon.ico" type="image/x-icon" />-->
        <!-- END META SECTION -->
        <style type="text/css">
        	.widget {
			   
			    min-height: 85px!important;
			  
			}
        </style>
        <!-- CSS INCLUDE -->        
		<?php $this->load->view('include_css'); ?>
        <!-- EOF CSS INCLUDE -->
       
        <?php $this->load->view('menu_navigation'); ?> 
                <div class="page-content-wrap">
                <!-- clock start -->   
                    <div class="row">            
                        <div class="col-md-3">                        
                            <div class="widget widget-primary widget-padding-sm">
                                <div class="widget-big-int plugin-clock">00:00</div>                            
                                <div class="widget-subtitle plugin-date">Loading...</div>
                                <div class="widget-controls">                                
                                    <a href="#" class="widget-control-right widget-remove" data-toggle="tooltip" data-placement="left" title="Remove Widget"><span class="fa fa-times"></span></a>
                                </div>                     
                        	</div>
                    	</div>
                    	
                    </div>
              
                 
              
            <!-- END PAGE CONTENT -->
         </div>   
        
        <!-- END PAGE CONTAINER -->
         
             <?php $this->load->view('include_js'); ?>
             <script type="text/javascript" src="<?php echo base_url('assets/js/demo_dashboard.js'); ?>"></script>
        
   
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS -->     
    
    <!-- COUNTERS // NOT INCLUDED IN TEMPLATE -->
       
        
    <!-- END COUNTERS // NOT INCLUDED IN TEMPLATE -->
    
    </body>

</html>







