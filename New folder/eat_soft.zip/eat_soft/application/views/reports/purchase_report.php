<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
<?php
if(isset($inps) && !empty($inps))
{
	
	$vendor_id = $inps['vendor_id'];
	$frmdt = $inps['from_dt'];
	$todt = $inps['to_dt']; 
    $product_id = $inps['product_id'];  
   /* $cus_id = $inps['cus_id'];*/
    //print_r($lot_id);
}
else
{
	
	
	$vendor_id = '';
	$frmdt = '';
	$todt = '';
    $product_id = '';  
 /* $cus_id = '';*/
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2>Purchase Report</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">    
                                <form action="" method="post" enctype="multipart/form-data" >
                                <div class="col-md-12">
                             <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Product Name</label>
                                    <div class="col-md-8">
                                     <?php $product = $this->db->select('*')->where('is_deleted',0)->get('tbl_product')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="product_id" id="product_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($product_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($product as $prded) { ?>
                                        <option <?=($product_id==$prded['product_id'])?'selected':''?> value="<?=$prded['product_id']?>"><?=$prded['product_name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div>
                               <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Vendor Name</label>
                                    <div class="col-md-8">
                                     <?php $vendor = $this->db->select('*')->where('is_deleted',0)->get('tbl_vendor')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="vendor_id" id="vendor_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($vendor_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($vendor as $prded) { ?>
                                        <option <?=($vendor_id==$prded['vendor_id'])?'selected':''?> value="<?=$prded['vendor_id']?>"><?=$prded['vendor_name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div>
                                
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">From Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="from_dt" value="<?=$frmdt?>" id="from_dt">                
                                    </div>
                                </div>
                                </div>
                               
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">To Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="to_dt" id="to_dt" value="<?=$todt?>">
                                    </div>
                                </div>
                                </div>
								<br><br>
                                <div class="col-md-3" style="float:right;">
                                <div class="form-group">
                                    <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div>
                                        <div class="col-md-4">
										<button type="submit" name="export" class="btn btn-primary"><span class="fa fa-download"></span>Export</button>
                                    </div>
                                </div>
                                </div>
                                </div>
                                    </form>
                                                               
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
											<tr>
												<th width="20">S.No</th>
												<th width="53">Invoice No</th>
                                                <th width="53">Invoice Date</th>
                                                 <th width="34">Vendor Name</th>
                                                <th width="34">Product Name</th>
                                                <th width="34">Unit</th>
                                                <th width="34">Unit Rate</th>
                                                <th width="34">Purchase Qty</th>
                                                <th width="34">Total</th>

                                                <th width="52">Invoice Amount</th>
                                                <th width="52">Purchase Entry Date</th>           
											</tr>
										</thead>
                                         <tbody>
                                        	<?php
                                        $sno=1;
										if(is_array($purchase) && count($purchase) ) {
											foreach($purchase as $loop){ ?>
												<tr>
													<td><?=$sno++?></td>
													<td><?=$loop['purchase_invoice_no']?></td>
                                                    <td><?=date('d-m-Y',strtotime($loop['purchase_invoice_date']))?></td>
                                                    <td><?=$loop['vendor_name']?></td>
                                                    <td><?=$loop['product_name']?></td>
                                                    <td><?=$loop['purchase_unit']?></td>
                                                    <td><?=$loop['purchase_qty']?></td>
                                                     <td><?=$loop['purchase_rate']?></td>
                                                     <td><?=number_format($loop['purchase_total'],2)?></td>
                                                    <td><?=number_format($loop['purchase_gtotal'],2)?></td>
                                                    <td><?=date('d-m-Y',strtotime($loop['purchase_entry_date']))?></td>
                                                   
                                                </tr>
											<?php }} ?>
										</tbody> 
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
<script>
  $(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
  $(document).ready(function(){
			$('.x-navigation-minimize').trigger('click');	
		});
  </script>
</body>
</html>