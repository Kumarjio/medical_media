<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
<?php
if(isset($inps) && !empty($inps))
{
	
	$server_id = $inps['server_id'];
	$frmdt = $inps['from_dt'];
	$todt = $inps['to_dt']; 
    $item_id = $inps['item_id'];
    $row_id = $inps['row_id'];
    $table_id = $inps['table_id'];

   /* $cus_id = $inps['cus_id'];*/
    //print_r($lot_id);
}
else
{
	
	
	$server_id = '';
	$frmdt = '';
	$todt = '';
    $item_id = ''; 
    $row_id = '';
    $table_id = ''; 
 /* $cus_id = '';*/
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2>Sales Report</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">    
                                <form action="" method="post" enctype="multipart/form-data" >
                                <div class="col-md-12">
                             <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Item Name</label>
                                    <div class="col-md-8">
                                     <?php $item = $this->db->select('*')->where('is_deleted',0)->get('tbl_item')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="item_id" id="item_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($item_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($item as $prded) { ?>
                                        <option <?=($item_id==$prded['item_id'])?'selected':''?> value="<?=$prded['item_id']?>"><?=$prded['item_name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div>
                               <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Server Name</label>
                                    <div class="col-md-8">
                                     <?php $server = $this->db->select('*')->where('is_delete',0)->where('user_type',2)->get('cp_admin_login')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="server_id" id="server_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($server_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($server as $prded) { ?>
                                        <option <?=($server_id==$prded['admin_id'])?'selected':''?> value="<?=$prded['admin_id']?>"><?=$prded['name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Row Name</label>
                                    <div class="col-md-8">
                                     <?php $row = $this->db->select('*')->where('is_deleted',0)->get('tbl_row')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="row_id" id="row_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($row_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($row as $prded) { ?>
                                        <option <?=($row_id==$prded['row_id'])?'selected':''?> value="<?=$prded['row_id']?>"><?=$prded['row_name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div><div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Table Name</label>
                                    <div class="col-md-8">
                                     <?php $product = $this->db->select('*')->where('is_deleted',0)->get('tbl_table')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="table_id" id="table_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($table_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($product as $prded) { ?>
                                        <option <?=($table_id==$prded['table_id'])?'selected':''?> value="<?=$prded['table_id']?>"><?=$prded['table_name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div>
                                <br>
                                <br>
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">From Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="from_dt" value="<?=$frmdt?>" id="from_dt">                
                                    </div>
                                </div>
                                </div>
                               
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">To Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="to_dt" id="to_dt" value="<?=$todt?>">
                                    </div>
                                </div>
                                </div>
								<br><br>
                                <div class="col-md-3" style="float:right;">
                                <div class="form-group">
                                    <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div>
                                        <div class="col-md-4">
										<button type="submit" name="export" class="btn btn-primary"><span class="fa fa-download"></span>Export</button>
                                    </div>
                                </div>
                                </div>
                                </div>
                                    </form>
                                                               
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
											<tr>
												<th width="20">S.No</th>
												<th width="53">Bill No</th>
                                                <th width="53">Bill Date</th>
                                                 <th width="34">Server Name</th>
                                                <th width="34">Row Name</th>
                                                <th width="34">Table Name</th>
                                                <th width="34">Item Name</th>
                                                <th width="34">Item Rate</th>
                                                <th width="34">Item Qty</th>
                                                <th width="52">Total</th>
                                                <th width="52">SGST</th>
                                                <th width="52">CGST</th>
                                                <th width="52">SGST AMT</th>
                                                <th width="52">CGST AMT</th>
                                                <th width="52">Packing Charge</th>

                                                <th width="52">Sub Total</th>
                                                <th width="52">Grand Total</th>           
											</tr>
										</thead>
                                         <tbody>
                                        	<?php
                                        $sno=1;
										if(is_array($sales) && count($sales) ) {
											foreach($sales as $loop){ ?>
												<tr>
													<td><?=$sno++?></td>
													<td><?=$loop['sale_bill_no']?></td>
                                                    <td><?=date('d-m-Y',strtotime($loop['bill_date']))?></td>
                                                    <td><?=$loop['name']?></td>
                                                    <td><?=$loop['row_name']?></td>
                                                    <td><?=$loop['table_name']?></td>
                                                    <td><?=$loop['item_name']?></td>
                                                    <td><?=$loop['sale_price']?></td>
                                                    <td><?=$loop['sale_qty']?></td>
                                                    <td><?=$loop['sale_item_total']?></td>
                                                   
                                                    <td><?=$loop['sgst_per']?></td>
                                                    <td><?=$loop['cgst_per']?></td>
                                                    <td><?=$loop['sgst_amt']?></td>
                                                    <td><?=$loop['cgst_amt']?></td>
                                                     <td><?=$loop['parcel_amt']?></td>
                                                      <td><?=$loop['sales_total']?></td>
                                                     <td><?=$loop['sales_grand_total']?></td>
                                                   
                                                   
                                                </tr>
											<?php }} ?>
										</tbody> 
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
<script>
  $(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
  $(document).ready(function(){
			$('.x-navigation-minimize').trigger('click');	
		});
  </script>
</body>
</html>