<?php $session_data = $this->session->all_userdata();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
          width: 900px; /* New width for default modal */
        }
        .modal-sm {
          width: 350px; /* New width for small modal */
        }
    }
    @media screen and (min-width: 992px) {
        .modal-lg {
          width: 950px; /* New width for large modal */
        }
    }
</style>
<body>
  <?php $this->load->view('menu_navigation'); ?>

    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2> Manage Employee</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                               
  <button data-toggle="modal" data-target="#myModal" class="btn btn-primary" data-backdrop="static" data-keyboard="false"><span class="fa fa-plus"></span>Add Employee</button>
                                                                                      
                                    
                                                                   
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    
                                                    <th>Employee Code</th>
                                                    <th>Employee Name</th>
                                                    <th>Phone</th>
                                                    <th>Email</th>
                                                    <th>Location</th>
                                                   <th>Action</th>
                                                  
                                                </tr>
											</thead>
                                            <tbody>
                                        	 <?php if(is_array($emp) && count($emp) ) {
                                        $cnt=1;
                                            foreach($emp as $loop){
                                                    ?>
											<tr>
												<td><?php echo $cnt; $cnt++; ?></td>
                       <td><?php echo $loop['emp_code'];?></td>
					   <td><?php echo $loop['name'];?></td>
					   <td><?php echo $loop['phone'];?></td>
                       <td><?php echo $loop['email_id'];?></td>
                       <td><?php echo $loop['area_name'];?></td>
                                                
												
												
                                               
                                                    <td>
    <!-- <a href="" ><button class="btn btn-success btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><i class="fa fa-eye"></i> </button></a> -->
                 <a href="#" data-toggle="modal" data-target="#myModal" onclick="Emp_edit(<?php echo $loop['admin_id'];?>)"><button class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><i class="fa fa-pencil"></i> </button></a> <a href="#" onclick="emp_delete(<?php echo $loop['admin_id'];?>)"><button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit"><i class="fa fa-trash-o"></i> </button></a>
                                                    </td>
                                                  
                                                    
                                                
											</tr>
											<?php }} ?>
										</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
     
     <?php $this->load->view('include_js'); ?>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Employee</h4>
        </div>
        <div class="modal-body">
               <form class="form-horizontal"  id="Emp_form" role="form" method="post">
                            
                                <div class="panel-body">                                                                        
                                    
                                    <div class="row">
                                        
                                        <div class="col-md-12">
                                        <div class="col-md-6">
                                          
                                          
                       <input type="hidden" name="hidden_id" id="hid_id">                   
                                            
                                             <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Employee Code<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <input type="text" required class="form-control "  name="ecode"  placeholder="Enter Employee Name" id="emp_code" value="<?php echo set_value('name');  ?>">
                                                    <div class="error" ><?php echo form_error('emp_code'); ?></div>                                               
                                                </div>
                                            </div>
                                                                                        
                       <div class="form-group">                                        
                         <label class="col-md-4 control-label">Employee Name<sup  style="color:#f00"> * </sup></label>
                                 <div class="col-md-8">
                                                    <input type="text" required class="form-control "  name="name"  placeholder="Enter Employee Name" id="customer_name" >
                                                    <div class="error" ><?php echo form_error('name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">  <?php $user_type = $this->db->select('*')->from('emp_type')->get()->result_array(); ?>                                      
                                                <label class="col-md-4 control-label">Employee Type<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <select  class="selectpicker form-control "  name="emp_type" id="emp_type"  data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true"> <option value="" disabled selected>Select</option> <?php foreach ($user_type as $key => $value) { ?>     
                                                    <option value="<?php echo $value['type_id'] ?>"><?php echo $value['type_name'] ?></option>
                                                    <?php } ?> 
                                                    </select>
                                                    <div class="error" ><?php echo form_error('name'); ?></div>                                               
                                                </div>
                                            </div>
                                            <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Location<?php /*?><sup  style="color:#f00"> * </sup><?php */?></label>
                                                <div class="col-md-8">
                                                <input type="text" required class="form-control "  name="area_name"  placeholder="Enter Location Name" id="area_name" >
                                                
                                                <div class="error" ><?php echo form_error('Area Name'); ?></div>
                                               </div>
                                            </div>
                                            </div>
                                             <div class="col-md-6">
                                                <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Mobile<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <input type="number" required class="form-control "  name="mobile"  placeholder="Enter Employee Name" id="mobile" value="">
                                                    <div class="error" ><?php echo form_error('customer_name'); ?></div>                                               
                                                </div>
                                            </div>
                                                <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Email</label>
                                                <div class="col-md-8">
                                                    <input type="text"  class="form-control"  name="email"  placeholder="Enter  email" id="email" value="">
                                                    <div class="error" ><?php echo form_error('customer_name'); ?></div>                                               
                                                </div>
                                            </div>              
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">User Name<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
                                                    <input type="text" required class="form-control" name="username"  placeholder="Enter username" id="username" value="">
                                                    <div class="error" ><?php echo form_error('area_name'); ?></div>                                               
                                                </div>
                                            </div>
                                                                                        
                                           <div class="form-group">                                        
                                                <label class="col-md-4 control-label">Passowrd<sup  style="color:#f00"> * </sup></label>
                                                <div class="col-md-8">
     <input type="text" class="form-control"  name="password"  placeholder="Enter password" id="pass" required>
                                                    <div class="error" ><?php echo form_error('city_name'); ?></div>                                               
                                                </div>
                                            </div>
                                            
                               
                                            
                                            
                                            <div class="form-group pull-right">                                        
                                                <div class="btn-group pull-right col-md-12">                  
                                                <input class="btn btn-primary" value="Submit" type="submit"  >
                                                <!-- <input class="btn btn-danger pull-right" value="Back" onClick="window.history.go(-1)" type="button"> -->
                                              </div>
                                            </div> 
                                            
                                            
                                            
                                            
                                        </div>
                                      </div>
                                        
                                    </div>
                                    

                                </div>
                               
                           
                            </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
</body>
</html>
<script type="text/javascript">
    $('form').submit(function(e){
 e.preventDefault();
  var empFrom = $('#Emp_form').serialize();
  //alert(empFrom);
    $.ajax({

          url:'<?php echo base_url();?>Employee_master/add_employee',
            type:'POST',
            data:empFrom,
            dataType:'JSON',       
            success:function(result)
            {


                document.getElementById("Emp_form").reset(); 
                alert('success');
                location.reload();

               // getlist(result);
            }
          

        });
    });
    
/*function getlist(result)
{


$.each(result, function(key, value) {
      var tr = $("<tr />")
     $.each(value, function(k, v) {
       tr.append(
         $("<td />", {
           html: v
          })[0].outerHTML
       );
      $("table tbody").append(tr)
     })
   });
}*/
function emp_delete($id){
  //alert($id);
  var del = confirm('Are you sure to delete');
  if(del == true){
  $.ajax({
          url:'<?php echo base_url();?>Employee_master/emp_delete/'+$id,
          type:'POST',
          dataType:'JSON',       
          success:function(result)
          {
            console.log(result);
            alert("Successfully Deleted");
            location.reload();
          }
        });    
}else{
  return false;
}
 
}
    function Emp_edit($id)
    {
            
 $.ajax({

          url:'<?php echo base_url();?>Employee_master/edit_employee/'+$id,
            type:'POST',
           
            dataType:'JSON',       
            success:function(result)
            {
                console.log(result);
       
                
            $('#hid_id').val(result[0]['admin_id']);
            $('#emp_code').val(result[0]['emp_code']);
            $('#emp_type').val(result[0]['user_type']);
            $('#customer_name').val(result[0]['name']);   
            $('#area_name').val(result[0]['area_name']);
            $('#email').val(result[0]['email_id']);
            $('#mobile').val(result[0]['phone']);
            $('#username').val(result[0]['username']);
            $('#pass').val(result[0]['password']);


            }
          

        });   
         }
</script>