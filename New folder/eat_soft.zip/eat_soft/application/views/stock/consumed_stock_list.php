<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('include_css'); ?>
</head>
<body>
  <?php $this->load->view('menu_navigation'); ?>
<?php
if(isset($inps) && !empty($inps))
{
	
	$product_id = $inps['product_id'];
	$frmdt = $inps['from_dt'];
	$todt = $inps['to_dt'];  
   /* $cus_id = $inps['cus_id'];*/
    //print_r($lot_id);
}
else
{
	
	
	$product_id = '';
	$frmdt = '';
	$todt = '';
 /* $cus_id = '';*/
}
?>
    
<!-- PAGE TITLE -->
                <div class="page-title">                    
                    <h2>Consumed Stock List</h2>
                </div>
                <!-- END PAGE TITLE -->                
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                 
                    <!-- START RESPONSIVE TABLES -->
                    <div class="row">
                        
                        
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">    
                                <form action="" method="post" enctype="multipart/form-data" >
                                <div class="col-md-12">
                             
                               <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Vendor Name</label>
                                    <div class="col-md-8">
                                     <?php $product = $this->db->select('*')->where('is_deleted',0)->get('tbl_product')->result_array(); ?>
                                     <select class="selectpicker  bs-select-hidden form-control" name="product_id" id="product_id" data-live-search="true" data-live-search-placeholder="Search" data-actions-box="true">
                                     <option <?=($product_id=='')?'selected':''?> value="">All</option>
                                        <?php foreach($product as $prded) { ?>
                                        <option <?=($product_id==$prded['product_id'])?'selected':''?> value="<?=$prded['product_id']?>"><?=$prded['product_name']?></option>
                                        <?php } ?>  
                                        </select>            
                                    </div>
                                </div>
                                </div>
                                
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">From Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="from_dt" value="<?=$frmdt?>" id="from_dt">                
                                    </div>
                                </div>
                                </div>
                               
                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">To Date</label>
                                    <div class="col-md-8">                                            
                                        <input type="text" class="datepickerr form-control" style="form-controlx" name="to_dt" id="to_dt" value="<?=$todt?>">
                                    </div>
                                </div>
                                </div>
								<br><br>
                                <div class="col-md-3" style="float:right;">
                                <div class="form-group">
                                    <div class="col-md-4">                                            
                                        <input type="submit" name="search" class="btn btn-success" value="Search" /></div>
                                        <div class="col-md-4">
										<button type="submit" name="export" class="btn btn-primary"><span class="fa fa-download"></span>Export</button>
                                    </div>
                                </div>
                                </div>
                                </div>
                                    </form>
                                                               
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <thead>
											<tr>
												<th width="20">S.No</th>
												<th width="53">Product Name</th>
                                                <th width="53">Unit</th>
                                                <th width="34">Consumed Qty</th>
                                                <th width="52">Consumed Date</th> 
                                                <th width="52">Action</th>           
											</tr>
										</thead>
                                         <tbody>
                                        	<?php
                                        $sno=1;
										if(is_array($consume) && count($consume) ) {
											foreach($consume as $loop){ ?>
												<tr>
													<td><?=$sno++?></td>
													<td><?=$loop['product_name']?></td>
                                                    <td><?=$loop['consumed_unit']?></td>
                                                    <td><?=number_format($loop['consumed_qty'])?></td>
                                                    <td><?=date('d-m-Y',strtotime($loop['consumed_date']))?></td>
                                                    <td><button type="button" class="btn btn-warning btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" onclick="edit_pro(<?php echo $loop['consumed_id'] ?>)"><i class="fa fa-eye"></i> </button>
                                                         <button type="button" class="btn btn-info btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Edit" onclick="edit_pro(<?php echo $loop['consumed_id'] ?>)"><i class="fa fa-pencil"></i> </button>
                                                         <button class="btn btn-danger btn-rounded btn-condensed btn-sm" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View" onclick="delete_pro(<?php echo $loop['consumed_id'] ?>)"><i class="fa fa-trash-o"></i> </button>

                                                    </td>
                                                   
                                                </tr>
											<?php }} ?>
										</tbody> 
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->

                        </div>
                    </div>
                    <!-- END RESPONSIVE TABLES -->
                    
                <!-- END PAGE CONTENT WRAPPER -->                                    
                </div>         
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->    

    
        <!-- Main bar -->
       


	    <!-- Matter -->

	    
    
    <!-- Footer ends -->    
     <?php $this->load->view('include_js'); ?>
<script>
  $(document).on('focus','.datepickerr',function() 
  {
    $( ".datepickerr" ).datepicker();
  });
  $(document).ready(function(){
			$('.x-navigation-minimize').trigger('click');	
		});
  </script>
</body>
</html>