 <?php $session_data = $this->session->all_userdata();
 // print_r($session_data);exit;
 ?>
        <!-- START PAGE CONTAINER -->
       
        <div class="page-container">
         <div class="page-sidebar">
                <!-- START X-NAVIGATION -->
                <ul class="x-navigation menu_allow">
                    <li class="xn-logo">
                        <a href="<?php echo base_url('Dashboard'); ?>">Hotel Hari</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li>
                    <li class="xn-profile">
                         <div class="profile">
                            <div class="profile-image">
                                <h2>Hotel Hari</h2>
                            </div>
                           
                        </div>                                                                        
                    </li>
                   
                    <li class="<?php echo active_link('Dashboard');  ?>">
                        <a href="<?php echo base_url('Dashboard'); ?>"  data-toggle="tooltip" data-placement="right" data-original-title="Dashboard" >
						<span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span></a>                        
                    </li> 
					
                   
					<li> <a href="<?php echo base_url();?>Employee_master" data-toggle="tooltip" data-placement="right" data-original-title="Employee">
					<span class="fa fa-files-o"></span> <span class="xn-text">Employee Master</span></a>
					</li>
					
					<li> <a href="<?php echo base_url('Vendor_master'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Supplier">
					<span class="fa fa-files-o"></span> <span class="xn-text">Vendor Master</span></a>
					</li>
					
                   <!--  <li> <a href="<?php //echo base_url('index.php/Customer'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Customer">
                    <span class="fa fa-files-o"></span> <span class="xn-text">Customer Master</span></a>
                    </li> -->
                   
					
					
                  
                     
					 <li class="xn-openable <?php echo active_link('Inventory'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Product"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Inventory Master</span></a>
                        <ul>
                            
                            <li><a href="<?php echo base_url('Inventory_master/item_list'); ?>">Item List</a></li>
                            <li><a href="<?php echo base_url('Inventory_master'); ?>">Product List</a></li>
                            <li><a href="<?php echo base_url('Inventory_master/table_master'); ?>">Table List</a></li>
                        
                          
                        	
                        </ul>
                    </li>   
					 <li class="xn-openable <?php echo active_link('Purchase'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Purchase"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Purchase</span></a>
                        <ul>
                            
                            <li><a href="<?php echo base_url('Purchase'); ?>">Add Purchase</a></li>
                            <li><a href="<?php echo base_url('Purchase/purchase_list'); ?>">Purchase List</a></li>
                        </ul>
                    </li>
                      </li>   
                     <li class="xn-openable <?php echo active_link('Stock'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Stock"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Stock</span></a>
                        <ul>    
                            <li><a href="<?php echo base_url('Stock'); ?>">Stock List</a></li>
                            <li><a href="<?php echo base_url('Stock/add_consumed_stock'); ?>">Add Consumed Stock</a></li>
                            <li><a href="<?php echo base_url('Stock/consumed_list'); ?>"> Consumed Stock List</a></li>
                            
                        </ul>
                    </li>   
                   
                        <li class="xn-openable <?php echo active_link('Sales'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Sales"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Sales</span></a>
                        <ul>
                         
                           <li>
                           <a href="<?php echo base_url('Sales'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Sales Add">
                    <span class="fa fa-plus-square"></span> <span class="xn-text"> Add Sales</span></a>
                </li>
                <li>
                       <a href="<?php echo base_url('Sales/sale_list'); ?>" data-toggle="tooltip" data-placement="right" data-original-title="Sales List">
                    <span class="fa fa-files-o"></span> <span class="xn-text"> Sales List</span></a>
                </li>
                        
                        </ul>
                    </li>
                    
                    
                 <!--   <li class="xn-openable <?php echo active_link('Retail'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Return"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Retail</span></a>
                        <ul>
                            <li><a href="<?php echo base_url('index.php/Retail'); ?>">Retail Sale</a></li>
                            <li><a href="<?php echo base_url('index.php/Retail/retail_list'); ?>">Retail Invoice</a>
                            </li>   
                            <li><a href="<?php echo base_url('index.php/Retail/retail_list_hold'); ?>">Retail Hold</a>
                            </li>                         
                        </ul>
                    </li>
                  
                    <li class="xn-openable <?php echo active_link('Wholesale'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Return"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Wholsale</span></a>
                        <ul>
                            <li><a href="<?php echo base_url('index.php/Wholesale'); ?>">Wholsale Sale</a></li>
                            <li><a href="<?php echo base_url('index.php/Wholesale/wholesale_list'); ?>">Wholesale Invoice</a></li>  
                            <li><a href="<?php echo base_url('index.php/Wholesale/wholesale_list_hold'); ?>">Wholesale Hold</a></li>                          
                        </ul>
                    </li>
                   			 -->			
				    <li class="xn-openable <?php echo active_link('Report'); ?>">
                        <a href="#" data-toggle="tooltip" data-placement="right" data-original-title="Reports"><span class="fa fa-thumb-tack"></span> <span class="xn-text">Reports</span></a>
                        <ul>
                         
                           
                            <li><a href="<?php echo base_url('Report'); ?>">Purchase Report</a></li>
                             <li><a href="<?php echo base_url('Report/sales_report'); ?>">Sales Report</a></li> 
                             <li><a href="<?php echo base_url('Report/value_report'); ?>">Purchase & Sals Value Report</a></li> 
                        
                        </ul>
                    </li>
                    
					
					
                    
                   
					
					
					
					
					
					
					
					
					
                     
				 
                            
                        </ul>
                    </li>
                    
                    
                </ul>
                <!-- END X-NAVIGATION -->
            </div>
            <!-- END PAGE SIDEBAR -->
            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START X-NAVIGATION VERTICAL -->
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <!-- TOGGLE NAVIGATION -->
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>
                    <!-- END TOGGLE NAVIGATION -->
                    <!-- SEARCH -->
                    <?php /*?><li class="xn-search">
                        <form role="form">
                            <input type="text" name="search" placeholder="Search..."/>
                        </form>
                    </li>  <?php */?> 
                    <!-- END SEARCH -->                    
                    <!-- POWER OFF -->
                    <li class="xn-icon-button pull-right last">
                        <a href="#" class="menu_allow"><span class="fa fa-power-off"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a class="menu_allow" href="<?php echo base_url('index.php/Dashboard/ProfileSettings_bk'); ?>"><span class="fa fa-lock"></span> Profile Setting</a></li>
                            <li><a class="menu_allow" href="<?php echo base_url('Login/logout'); ?>" id="logout" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Sign Out</a></li>
                        </ul>                        
                    </li> 
                    <!-- END POWER OFF -->                    

                    <!-- TASKS -->
                    
                    <!-- END TASKS -->
                </ul>
                <!-- END X-NAVIGATION VERTICAL -->   
                   <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <!--<li><a href="#">Home</a></li>                    
                    <li class="active">Dashboard</li>-->
                </ul>
                <!-- END BREADCRUMB -->                 
                